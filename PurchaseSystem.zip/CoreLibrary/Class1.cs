﻿using System;

namespace CoreLibrary
{
    public class Class1
    {
    }
}
