﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PurchaseSystem.DataAccess.Enum
{
    public enum EAgentStatusTypes
    {
        Register=1,
        Confirmation=2,
        Inactive=3,
        Active=4,
        Delete=5

    }
}
