﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PurchaseSystem.DataAccess.Enum
{
    public enum EAgentRoles
    {
        Admin=1,
        User=2
    }
}
