﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace PurchaseSystem.DataAccess.Helper
{
    public class DbHelperLayer
    {
        // string connectionString = "Data Source=SUMON-PC;Initial Catalog=EmployeeRecordManagement;Integrated Security=True";    
        // string connectionString = "Persist Security Info=False; User ID=APP51137-10; Initial Catalog=Logistics; PASSWORD=40#kq6*z; server=DBSO1D1DV01.ikco.com;";    
        string connectionString = "Persist Security Info=False; User ID=APP51137-03; Initial Catalog=Logistics; PASSWORD=49*hc%k2; server=DBSO1D1DV01.ikco.com;";

        //To View all employees details      
        public List<Models.Agent> GetAllAgents()
        {
            List<Models.Agent> lsAgente = new List<Models.Agent>();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("[PUR].[spAgentsGetAll]", con);
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    Models.Agent agent = new Models.Agent();

                    agent.Username =(rdr["UserName"]).ToString();
                    agent.Name = rdr["Name"].ToString();
                    agent.Lastname = rdr["Lastname"].ToString();
                    agent.NationalCode = rdr["NationalCode"].ToString();
                    agent.Mobile = rdr["Mobile"].ToString();
                    agent.AgentTypeId = Convert.ToInt32(rdr["AgentTypeId"]);
                    agent.AgentRoleId = Convert.ToInt32(rdr["AgentRoleId"]);
                    agent.RegDate = Convert.ToInt32(rdr["RegDate"]);
                    agent.RegTime = Convert.ToInt32(rdr["RegTime"]);
                    agent.StatusTypeId = Convert.ToInt32(rdr["StatusTypeId"]);
                    agent.Email = rdr["Email"].ToString();
                    agent.AgentTypeTitle = rdr["AgentTypeTitle"].ToString();
                    agent.AgentRoleTitle = rdr["AgentRoleTitle"].ToString();
                    agent.AgentStatusTitle = rdr["AgentStatusTitle"].ToString();
                    agent.Description = rdr["Description"].ToString();

                    lsAgente.Add(agent);
                }
                con.Close();
            }
            return lsAgente.ToList();
        }


        public Models.User GetAgentByUsername(string username)
        {
            Models.User user = new Models.User();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("[PUR].[spAgentsByUsername]", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@Username", username);
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    user.UserId = rdr["UserName"].ToString();
                    user.UserName = rdr["UserName"].ToString();
                    user.UserEmail = rdr["Email"].ToString();
                    user.password = rdr["password"].ToString();
                    user.Mobile = rdr["Mobile"].ToString();
                    user.UserRole = rdr["AgentRoleTitle"].ToString();
                }
            }
            return user;
        }



        public Boolean AddAgentFirst(Models.Agent agent)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("[PUR].[spAgentAdd]", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@Username", agent.Username);
                cmd.Parameters.AddWithValue("@Password", agent.Password);
                cmd.Parameters.AddWithValue("@Name", agent.Name);
                cmd.Parameters.AddWithValue("@Lastname", agent.Lastname);
                cmd.Parameters.AddWithValue("@NationalCode", agent.NationalCode);
                cmd.Parameters.AddWithValue("@Mobile", agent.Mobile);
                cmd.Parameters.AddWithValue("@AgentTypeId", agent.AgentTypeId);
                cmd.Parameters.AddWithValue("@AgentRoleId", agent.AgentRoleId);
                cmd.Parameters.AddWithValue("@RegDate", agent.RegDate);
                cmd.Parameters.AddWithValue("@RegTime", agent.RegTime);
                cmd.Parameters.AddWithValue("@StatusTypeId", agent.StatusTypeId);
                cmd.Parameters.AddWithValue("@Email", agent.Email);
                cmd.Parameters.AddWithValue("@Description", agent.Description);

               
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            return true;
        }



    }
}
