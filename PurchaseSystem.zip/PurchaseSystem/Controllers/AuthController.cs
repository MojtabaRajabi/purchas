﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

//using PurchaseSystem.Data;
//using PurchaseSystem.Service;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using PurchaseSystem.Models;
using System.Diagnostics;
using Microsoft.AspNetCore.Http;
using PurchaseSystem.DataAccess.Helper;
using PurchaseSystem.DataAccess.Enum;


// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PurchaseSystem.Controllers
{
    public class AuthController : Controller
    {
        DbHelperLayer dbHelperLayer = new DbHelperLayer();
        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }


        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(Agent agent)
        {
            // var status = _userService.Create(user);

            agent.AgentRoleId = (int)EAgentRoles.User;
            agent.StatusTypeId = (int)EAgentStatusTypes.Register;
            agent.Password = "";

            if (ModelState.IsValid)
            {
                if (dbHelperLayer.AddAgentFirst(agent))
                {
                    ViewBag.success = "ثبت اوليه با موفقيت انجام شد، حساب كاربري بايستي تاييد شود";
                }
                else
                {
                    ViewBag.error = "خطا در ثبت اطلاعات اوليه";
                }
            }

           // return RedirectToAction("Index");
            return View();
        }


        [HttpPost]
        public IActionResult Login(UserLogin user)
        {
            if (ModelState.IsValid)
            {
                var _user= dbHelperLayer.GetAgentByUsername(user.Username);
                //  var _user = _authService.CheckCredential(user);
                //var _user = new List<User> { new User { UserName = "mojtaba", password = "123", UserEmail = "m@m.com", UserRole = "Admin" } };
                //  var _user = _authService.CheckCredential(user);
                if (_user == null)
                {
                    TempData["error"] = "Credentials do not match.";
                    return RedirectToAction("Index", "Auth");
                }
                var identity = new ClaimsIdentity(CookieAuthenticationDefaults.AuthenticationScheme);

                //identity.AddClaim(new Claim(ClaimTypes.Name, _user[0].UserName.ToString()));
                //identity.AddClaim(new Claim(ClaimTypes.Role, _user[0].UserRole));
                //identity.AddClaim(new Claim(ClaimTypes.Email, _user[0].UserEmail));
                //HttpContext.Session.SetString("UserEmail", _user[0].UserEmail);
                //HttpContext.Session.SetString("UserId", _user[0].UserName.ToString());
                //HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));



                identity.AddClaim(new Claim(ClaimTypes.Name, _user.UserName.ToString()));
                identity.AddClaim(new Claim(ClaimTypes.Role, _user.UserRole));
                identity.AddClaim(new Claim(ClaimTypes.Email, _user.UserEmail));
                HttpContext.Session.SetString("UserEmail", _user.UserEmail);
                HttpContext.Session.SetString("UserId", _user.UserName.ToString());
                HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));


                if (_user.UserRole == "Admin")
                {
                    identity.AddClaim(new Claim(ClaimTypes.Role, "Admin"));
                    return RedirectToAction("Index", "Home");
                }
                else if (_user.UserRole == "User")
                {
                    identity.AddClaim(new Claim(ClaimTypes.Role, "User"));
                    return RedirectToAction("Index", "Home");
                }

            }
            TempData["error"] = "Credentials do not match.";
            return RedirectToAction("Index", "Auth");

            //return RedirectToAction("Index", "Home");
        }



        [HttpGet]
        public IActionResult LogOut()
        {
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Auth");
        }
        public IActionResult Forbidden()
        {
            TempData["error"] = "Permissin Denied!";
            return RedirectToAction("Index", "Auth");
        }

        /*
         * ERROR PAGE
         */
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

    }
}
