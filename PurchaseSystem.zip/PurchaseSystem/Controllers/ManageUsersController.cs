﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PurchaseSystem.DataAccess.Helper;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PurchaseSystem.Controllers
{
    public class ManageUsersController : Controller
    {
        DbHelperLayer dbLayer = new DbHelperLayer();
        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }

        public ActionResult Users()
        {
            return View();
        }

        [HttpPost]
        public IActionResult LoadData()
        {
            try
            {
                var draw = Request.Form["draw"].FirstOrDefault();
                var start = Request.Form["start"].FirstOrDefault();
                var length = Request.Form["length"].FirstOrDefault();
                var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
                var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();


                //var result = sql.GetActiveRequestsDetailsByApplicantName(start.ToValidMsgInt(), length.ToValidMsgInt(), sortColumn.ToValidMsgString(), sortColumnDir.ToValidMsgString()
                //                                                       ,  applicantName,  requestStatus);

                var result = dbLayer.GetAllAgents();
                int recordsTotal = result.Count();

                //Returning Json Data  
                //var jsonData = Json(new
                //{
                //    draw = draw,
                //    recordsFiltered = recordsTotal,
                //    recordsTotal = recordsTotal,
                //    data = result
                //});

              
                var jsonData = new { draw = draw, recordsFiltered = recordsTotal, recordsTotal = recordsTotal, data = result };
                return Ok(jsonData);


            }
            catch (Exception ex)
            {
                throw;
            }
        }



    }
}
