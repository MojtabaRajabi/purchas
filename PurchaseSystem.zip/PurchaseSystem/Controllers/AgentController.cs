﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PurchaseSystem.DataAccess.Helper;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PurchaseSystem.Controllers
{
    public class AgentController : Controller
    {
        DbHelperLayer dbLayer = new DbHelperLayer();

        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Agent()
        {
            List<Models.Agent> lstAgents = new List<Models.Agent>();
            lstAgents = dbLayer.GetAllAgents().ToList();
            return View(lstAgents);
        }


        public IActionResult LoadData()
        {
            try
            {
                var draw = Request.Form["draw"].FirstOrDefault();
                var start = Request.Form["start"].FirstOrDefault();
                var length = Request.Form["length"].FirstOrDefault();
                var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
                var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
           
               
                    //var result = sql.GetActiveRequestsDetailsByApplicantName(start.ToValidMsgInt(), length.ToValidMsgInt(), sortColumn.ToValidMsgString(), sortColumnDir.ToValidMsgString()
                    //                                                       ,  applicantName,  requestStatus);

                    var result = dbLayer.GetAllAgents().ToList();
                    int recordsTotal = result.Count();

                    //Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = result
                    });
                
            }
            catch (Exception ex)
            {
                throw;
            }
        }


    }
}
