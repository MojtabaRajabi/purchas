﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace PurchaseSystem.Models
{
    public class User
    {

        public static ClaimsIdentity Identity { get; set; }
        [Key]
        public string UserId { get; set; }
        [Required]
        public string UserEmail { get; set; }
        [Required]
        public string UserName { get; set; }
        [Required]
        public string password { get; set; }
        [Required]
        public string UserRole { get; set; }


        public string Mobile { get; set; }
        

    }
}
