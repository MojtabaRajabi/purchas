﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PurchaseSystem.Models
{
    public class Agent
    {
      
        [Required(ErrorMessage = "فيلد  الزامي است")]
        public string Username { get; set; }
        [Required(ErrorMessage = "فيلد  الزامي است")]
        public string Password { get; set; }

        [Required(ErrorMessage = "فيلد  الزامي است")]
        public string Name { get; set; }


        [Required(ErrorMessage = "فيلد  الزامي است")]
        public string Lastname { get; set; }

        [Required(ErrorMessage = "فيلد  الزامي است")]
        public string NationalCode { get; set; }
        [Required(ErrorMessage = "فيلد  الزامي است")]
        public string Mobile { get; set; }

        [Required(ErrorMessage = "فيلد  الزامي است")]
        public int AgentTypeId { get; set; }

        [Required(ErrorMessage = "فيلد  الزامي است")]
        public int AgentRoleId { get; set; }



        //[Required]
        public int RegDate { get; set; }

        //[Required]
        public int RegTime { get; set; }



        public string Description { get; set; }

        public string _RegDate { get; set; }

        public string _RegTime { get; set; }


        [Required(ErrorMessage = "فيلد  الزامي است")]
        public int StatusTypeId { get; set; }

       
        public string Email { get; set; }

       
        public string AgentTypeTitle { get; set; }


        
        public string AgentRoleTitle { get; set; }


        
        public string AgentStatusTitle { get; set; }



    
    }
}
