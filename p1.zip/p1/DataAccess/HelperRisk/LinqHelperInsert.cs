﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sanay.Lotus.Erm.Models;
using System.Data.Entity.Migrations;


namespace Sanay.Lotus.Erm.DataAccess.Helper
{
    public partial class LinqHelper
    {

        public bool InsertCorrectiveRatioInfo(CorrectiveRatioInfo obj)
        {
            try
            {
                CurrentCtxRisk.CorrectiveRatioInfos.Add(obj);
                CurrentCtxRisk.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public bool InsertSymbolSimilar(SymbolSimilar obj)
        {
            try
            {
                CurrentCtxRisk.SymbolSimilars.Add(obj);
                CurrentCtxRisk.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                throw;
            }

        }
    






        public bool InsertHolderGroupName(HolderGroupName obj)
        {
            try
            {
                CurrentCtxRisk.InsertHolderGroupName(obj.GroupName, obj.RegDate, obj.RegTime, obj.RegUser);
                return true;
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public bool InsertDebtHolderGroupName(DebtHolderGroupName obj)
        {
            try
            {
                CurrentCtxFund.InsertDebtHolderGroupName(obj.GroupName, obj.RegDate, obj.RegTime, obj.RegUser);
                return true;
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public bool InsertHolderToGroup(HolderGroup obj)
        {
            try
            {
                CurrentCtxFund.HolderGroups.Add(obj);
                CurrentCtxFund.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                throw;
            }
        }



        public bool InsertHolderToDebtGroup(DebtHolderGroup obj)
        {
            try
            {
                CurrentCtxFund.DebtHolderGroups.Add(obj);
                CurrentCtxFund.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                throw;
            }
        }




        public int InsertHeatMap(AssetClass obj)
        {
            try
            {

                CurrentCtxRisk.AssetClasses.Add(obj);
                CurrentCtxRisk.SaveChanges();

                return 0;
            }
            catch (Exception ex)
            {
                throw;
            }

        }



        public int InsertAssetClassTypeDetaile(AssetClassTypeDetaile obj)
        {
            try
            {

                CurrentCtxRisk.AssetClassTypeDetailes.Add(obj);
                CurrentCtxRisk.SaveChanges();

                return 0;
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        public int InsertHeatMapDetailes(AssetClassDetaile obj)
        {
            try
            {

                CurrentCtxRisk.AssetClassDetailes.Add(obj);
                CurrentCtxRisk.SaveChanges();

                return 0;
            }
            catch (Exception ex)
            {
                throw;
            }

        }




        public bool InsertHistoricalSymbolPrice(string Symbol, double Weight)
        {
            try
            {


                CurrentCtxDebt.Database.CommandTimeout = 1200;
                CurrentCtxRisk.InsertAutomaticHistoricalSymbolPrice(Symbol, Weight);
                return true;
            }
            catch (Exception ex)
            {
                throw;
            }
        }



        public bool InsertDefaultFluctuationPercent(DefaultFluctuationPercent obj)
        {
            try
            {
                CurrentCtxRisk.DefaultFluctuationPercents.Add(obj);
                CurrentCtxRisk.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                throw;
            }

        }






    }
}