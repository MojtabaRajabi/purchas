﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Ajax.Utilities;
using Sanay.Library.DataAccess;
using Sanay.Lotus.Erm.Lib.Enum;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Core.Objects;

namespace Sanay.Lotus.Erm.DataAccess.Helper
{
    public partial class LinqHelper
    {
        public List<CalculateVarMetrix_Result> GetSymbolsRiskMetrics(int startDate, int endDate,int HasCheck,string fields)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxRisk.CalculateVarMetrix( startDate, endDate, HasCheck,fields).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<CalculateFastVarMetrix_Result> GetSavedSymbolsRiskMetrics(int startDate, int endDate, int HasCheck, string fields)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxRisk.CalculateFastVarMetrix(startDate, endDate, HasCheck, fields).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetHeatMaps_Result> GetHeatmap(string User)
        {
            try
            {
                var objFetch = CurrentCtxRisk.GetHeatMaps(User).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public AssetClass GetAssetClasseById(int Id)
        {
            try
            {
                var objFetch = CurrentCtxRisk.AssetClasses.FirstOrDefault(c => c.Id == Id);
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }





        public List<GetAssetClassTypeDetailes_Result> GetAssetClassTypeDetailes(int AssetClassId)
        {
            try
            {
                var objFetch = CurrentCtxRisk.GetAssetClassTypeDetailes(AssetClassId).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public AssetClassTypeDetaile GetAssetClassTypeDetailesById(int Id)
        {
            try
            {
                var objFetch = CurrentCtxRisk.AssetClassTypeDetailes.FirstOrDefault(c => c.Id ==Id);
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetHeatMapDetailes_Result> GetHeatMapDetailes(int Id,string User)
        {
            try
            {
                var objFetch = CurrentCtxRisk.GetHeatMapDetailes(Id, User).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<DefaultFluctuationPercentsType> GetDefaultFluctuationPercentsTypes()
        {
            try
            {
                var objFetch = CurrentCtxRisk.DefaultFluctuationPercentsTypes.ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public List<GetAdjustmentRatiosByFilter_Result> GetAdjustmentRatiosByFilter(int companyId, int ajustTypeId, int startDate, int endDate, int minRow, int maxRow)
        {
            try
            {
                var objFetch = CurrentCtxRisk.GetAdjustmentRatiosByFilter(companyId, ajustTypeId, startDate, endDate, minRow, maxRow).ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetFundTrades_Result> GetFundTrades(  int fundId, int startDate, int endDate)
        {
            try
            {


                var objFetch = CurrentCtxFund.GetFundTrades(fundId, startDate, endDate).ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetSumFundTrades_Result> GetSumFundTrades(int fundId, int startDate, int endDate,int  group,int type)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetSumFundTrades(fundId, startDate, endDate, group, type).ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetSumFundTradesDetailes_Result> GetSumFundTradesDetailes(int fundId, int startDate, int endDate, int group, int type)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetSumFundTradesDetailes(fundId, startDate, endDate, group, type).ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public int DeletePortfolio(int FundId,int PDate)
        {
            try
            {
                CurrentCtxFund.DeleteFundPortfolioByDate(FundId, PDate);
                CurrentCtxFund.SaveChanges();
                return 1;
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public int InsertPortfolioSymbol(FundPortfolio obj)
        {
            try
            {
                CurrentCtxFund.InsertPortfolioSymbols(obj.FundId, obj.PDate,(int)obj.Count, obj.Instrument, obj.IsRight, obj.RegDate, obj.RegTime);
                CurrentCtxFund.SaveChanges();
                return 1;
            }
            catch (Exception ex)
            {
                throw;
            }

        }





        public List<GetSumFundTradesBuy_Result> GetSumFundTradesBuy(int fundId, int startDate, int endDate)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetSumFundTradesBuy(fundId, startDate, endDate).ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetSumFundTradesSell_Result> GetSumFundTradesSell(int fundId, int startDate, int endDate)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetSumFundTradesSell(fundId, startDate, endDate).ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<GetFundProfits_Result> GetFundProfits(int fundId, int startDate, int endDate)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetFundProfits(fundId, startDate, endDate).ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }






        public List<GetAdjustedTradesAllDays_Result> GetAdjustedTradesAllDays(int companyId, int startDate, int endDate,string sort, string sortType,int minRow,int maxRow)
        {
            try
            {
                var objFetch = CurrentCtxRisk.GetAdjustedTradesAllDays(companyId, startDate, endDate, sort, sortType, minRow, maxRow).ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetTrades_Result> GetTrades(bool State, int startDate, int endDate)
        {
            try
            {
                var objFetch = CurrentCtxRisk.GetTrades(State,startDate,endDate).ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<GetLastCorrectiveRatioInfos_Result> GetLastCorrectiveRatioInfos()
        {
            try
            {
                var objFetch = CurrentCtxRisk.GetLastCorrectiveRatioInfos().ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetGroupCorrectiveRatioInfos_Result> GetGroupCorrectiveRatioInfos()
        {
            try
            {
                var objFetch = CurrentCtxRisk.GetGroupCorrectiveRatioInfos().ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetCorrectiveRatioInfos_Result> GetCorrectiveRatioInfos(int year,int month,int cycle)
        {
            try
            {
                var objFetch = CurrentCtxRisk.GetCorrectiveRatioInfos(year,month,cycle).ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public GetDefaultFluctuationPercents_Result GetMarketRiskConfigById(int id)
        {
            try
            {
                return CurrentCtxRisk.GetDefaultFluctuationPercents().FirstOrDefault(t => t.Id == id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetDefaultFluctuationPercents_Result> GetDefaultFluctuationPercent()
        {
            try
            {
                var objFetch =  CurrentCtxRisk.GetDefaultFluctuationPercents().ToList();      

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public bool insertHistoricalSymbolAllPrice(int startDate, int endDate, int symbolId)
        {
            try
            {
                  CurrentCtxRisk.InsertHistoricalSymbolAllPrice(startDate,endDate, symbolId);

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }


        public int  GetLoadFundLastTradeDate( )
        {
            try
            {

                var obj= CurrentCtxRisk.GetLastFundsTrade().FirstOrDefault();

                return (int) obj;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }



        public List<Industry> GetIndustries(string industryName)
        {
            try
            {
                var objFetch = CurrentCtxRisk.Industries.Where(s => s.IndustryName.Contains(industryName)).ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<PreviewAutomaticHistoricalSymbolPrice_Result> PreviewAutomaticHistoricalSymbolPrice(string Symbol)
        {
            try
            {
                var objFetch = CurrentCtxRisk.PreviewAutomaticHistoricalSymbolPrice(Symbol).ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<HolderGroupName> GetHolderGroupNames()
        {
            try
            {
                var objFetch = CurrentCtxFund.HolderGroupNames.ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<DebtHolderGroupName> GetDebtHolderGroupNames()
        {
            try
            {
                var objFetch = CurrentCtxFund.DebtHolderGroupNames.ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<HolderGroup> GetHolderGroups()
        {
            try
            {
                var objFetch = CurrentCtxFund.HolderGroups.ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetHolderToGroups_Result> GetHolderToGroups()
        {
            try
            {
                var objFetch = CurrentCtxFund.GetHolderToGroups().ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<GetDebtHolderToGroups_Result> GetDebtHolderToGroups()
        {
            try
            {
                var objFetch = CurrentCtxFund.GetDebtHolderToGroups().ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }






        public List<Group> GetGroups(string groupsName)
        {
            try
            {
                var objFetch = CurrentCtxRisk.Groups.Where(s=>s.GroupName.Contains(groupsName)).ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<SymbolSimilar> GetSymbolSimilar()
        {
            try
            {             
                var objFetch = CurrentCtxRisk.SymbolSimilars.ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<Company> GetCompanies(int CoId, int GroupID, int IndustryID, int MarketID,string TseSymbol)
        {
            try
            {
                var objFetch = CurrentCtxRisk.Companies.Where(x => 
                                                             (x.CoID==CoId || CoId==-1)
                                                          && (x.GroupID== GroupID || GroupID == -1)
                                                          && (x.IndustryID == IndustryID || IndustryID == -1)
                                                          && (x.MarketID== MarketID || MarketID == -1)
                                                          && (x.CoTSESymbol== TseSymbol || TseSymbol == "-1")
                                                          ).ToList();
                //List<GetEtemadFunds_Result> objFetchSorted = new List<GetEtemadFunds_Result>();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }





        public List<GetSymbolPriceGaps_Result> GetSymbolPriceGap(int CoId)
        {
            try
            {
                var objFetch = CurrentCtxRisk.GetSymbolPriceGaps(CoId).ToList();
                //List<GetEtemadFunds_Result> objFetchSorted = new List<GetEtemadFunds_Result>();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetSymbolPriceGapsDetailes_Result> GetSymbolPriceGapDetails(string  Symbol)
        {
            try
            {
                var objFetch = CurrentCtxRisk.GetSymbolPriceGapsDetailes(Symbol).ToList();
                //List<GetEtemadFunds_Result> objFetchSorted = new List<GetEtemadFunds_Result>();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetFundPortfolioSymbolAssets_Result> GetFundPortfolioSymbolAssets(int startDate,int EndDate,int FundId,string Symbol)
        {
            try
            {
                var objFetch = CurrentCtxRisk.GetFundPortfolioSymbolAssets(startDate, EndDate, FundId, Symbol).ToList();
                //List<GetEtemadFunds_Result> objFetchSorted = new List<GetEtemadFunds_Result>();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<GetStockMoneyInputs_Result> GetHistoricalMoneyInputs(int startDate, int EndDate, string Symbol,int start,int lenght)
        {
            try
            {
                var objFetch = CurrentCtxRisk.GetStockMoneyInputs(startDate, EndDate, Symbol, start, lenght).ToList();
                //List<GetEtemadFunds_Result> objFetchSorted = new List<GetEtemadFunds_Result>();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }








        public List<GetSymbolSimilars_Result> GetSymbolSimilars(long inscode)
        {
            try
            {
                var objFetch = CurrentCtxRisk.GetSymbolSimilars(inscode).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



    }
}