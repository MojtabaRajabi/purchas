﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sanay.Lotus.Erm.Lib.Dto;

namespace Sanay.Lotus.Erm.DataAccess.Helper
{
    public partial class LinqHelper
    {
        public bool DeleteSymbolSimilars(int id)
        {
            try
            {
                CurrentCtxRisk.RemoveSymbolSimilar(id);
                CurrentCtxRisk.SaveChanges();
                return true;

            }
            catch (Exception ex)
            {
                return false;
            }
        }




        public bool DeleteFundPortfolioByDate(int fundId,int PDate)
        {
            try
            {
                CurrentCtxFund.DeleteFundPortfolioByDate(fundId,PDate);
                return true;

            }
            catch (Exception ex)
            {
                return false;
            }
        }













        public bool DeleteHistoricalSymbolPrices(int SymbolId)
        {
            try
            {
                 CurrentCtxRisk.RemoveHistoricalSymbolPrice(SymbolId);
                 CurrentCtxRisk.SaveChanges();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }



        public bool DeleteHeatMap(int id)
        {
            try
            {

                var obj = CurrentCtxRisk.RemoveHeatMap(id);

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }


        public bool DeleteAssetClassTypeDetailes(int id)
        {
            try
            {
                var obj = CurrentCtxRisk.RemoveAssetClassTypeDetailes(id);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }



        public bool DeleteHeatMapDetailes(int id)
        {
            try
            {
                var obj = CurrentCtxRisk.RemoveHeatMapDetailes(id);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }






        public void DeleteConfigs(int id)
        {
            try
            {
                var obj = CurrentCtxRisk.DefaultFluctuationPercents.Where(x => x.Id == id).FirstOrDefault();
                if (obj != null)
                {

                    CurrentCtxRisk.DefaultFluctuationPercents.Remove(obj);
                    CurrentCtxRisk.SaveChanges();
                }

            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public bool DeleteHolderGroup(int id)
        {
            try
            {
                CurrentCtxFund.deleteHolderGroup(id);
                 return true;

            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public bool DeleteDebtHolderGroup(int id)
        {
            try
            {
                CurrentCtxFund.deleteDebtHolderGroup(id);
                 return true;

            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public bool DeleteHolderToGroups(int id)
        {
            try
            {
                CurrentCtxFund.DeleteHolderToGroups(id);
                return true;

            }
            catch (Exception ex)
            {
                return false;
            }
        }


        public bool DeleteDebtHolderToGroups(int id)
        {
            try
            {
                CurrentCtxFund.DeleteDebtHolderToGroups(id);
                return true;

            }
            catch (Exception ex)
            {
                return false;
            }
        }




    }
}