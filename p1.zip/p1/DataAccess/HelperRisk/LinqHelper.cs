﻿using System;
using System.Linq;
using System.Web;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.Models;
using System.Data.Entity.Migrations;
using Sanay.Lotus.Erm.Lib.Enum;

namespace Sanay.Lotus.Erm.DataAccess.Helper
{
    public partial class LinqHelper : System.Web.UI.Page
    {
       


        public static ERMEntitiesRisk CurrentCtxRisk
        {
            get
            {
                try
                {
                    var ctx = HttpContext.Current.Items["CtxPerRequestRisk"] as ERMEntitiesRisk;
                    
                    return ctx ?? new ERMEntitiesRisk();
                }
                catch
                {
                    return new ERMEntitiesRisk();
                }
            }
        }


    }
}