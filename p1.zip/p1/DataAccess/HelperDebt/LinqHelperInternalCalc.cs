﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Ajax.Utilities;
using Sanay.Library.DataAccess;
using Sanay.Lotus.Erm.Lib.Enum;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Core.Objects;
using OfficeOpenXml;
using System.Web.Mvc;
using OfficeOpenXml;
using Sanay.Library.Utility;
//using ee= Microsoft.Office.Interop.Excel;
using Excel.FinancialFunctions;

namespace Sanay.Lotus.Erm.DataAccess.Helper
{
    public partial class LinqHelper
    {


        public List<GetDurationParameters_Result> GetDuration()
        {
            try
            {
                List<GetDurationParameters_Result> data = new List<GetDurationParameters_Result>();
                var lq = new LinqHelper();
                var obj = CurrentCtxDebt.GetDurationParameters(Assistant.TodayDateInt()).ToList();
                var today = Assistant.TodayDateInt();
                var starDate = Assistant.DaysBetweenDates(12781011, today);
                for (var i = 1; i < obj.Count(); i++)
                {
                    if (obj[i].GroupCode == 0 || obj[i].GroupCode == null)
                    {
                        DateTime start = new DateTime(1900, 01, 01);
                        var endDate = Assistant.DaysBetweenDates(12781011, (int)obj[i].MaxCopDate);
                        double modifiedDuration;
                        if (endDate != 0 && starDate != 0 && starDate<endDate && obj[i].CopCount>0 &&  obj[i].ClosingPrice>0)
                        {
                              modifiedDuration = Financial.MDuration(
                                                        start.AddDays(starDate),
                                                        start.AddDays(endDate),
                                                        ((obj[i].Rate.ToValidMsgdouble()) / 100),
                                                        (obj[i].Rate.ToValidMsgdouble() / 100 * (double)obj[i].NominalPrice / (double)obj[i].ClosingPrice),
                                                        (Frequency)obj[i].CopCount,
                                                        (DayCountBasis)3);
                        }else
                        {
                              modifiedDuration = 0;
                        }
                        var d = 0.00;
                        if (modifiedDuration is IConvertible)
                        {
                            d = ((IConvertible)modifiedDuration).ToDouble(null);
                        }
                        else
                        {
                            d = 0d;
                        }
                        data.Add(new GetDurationParameters_Result { Isin = obj[i].Isin, Duration = d, GroupCode = obj[i].GroupCode });
                    }
                    else
                        data.Add(new GetDurationParameters_Result { Isin = obj[i].Isin, Duration = obj[i].Duration, GroupCode = obj[i].GroupCode });
                }
                return data;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



    }
}