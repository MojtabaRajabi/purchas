﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Ajax.Utilities;
using Sanay.Library.DataAccess;
using Sanay.Lotus.Erm.Lib.Enum;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Core.Objects;
using Sanay.Library.Utility;

namespace Sanay.Lotus.Erm.DataAccess.Helper
{
    public partial class LinqHelper
    {

        public List<GetSymbolsShareHolders_Result> GetSymbolsShareHolders()
        {
            try
            {

                var res = CurrentCtxDebt.GetSymbolsShareHolders().ToList();
                return res;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetRiskSymbolsShareHolders_Result> GetRiskSymbolsShareHolders(string Symbol,string Holder,string MarketName,string GroupName, int  start, int lenght)
        {
            try
            {
                var res = CurrentCtxRisk.GetRiskSymbolsShareHolders(Symbol,Holder, GroupName, MarketName, start, lenght).ToList();
                return res;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetRiskSymbolsShareHolders2_Result> GetRiskSymbolsShareHolders2(string Symbol, string Holder, string MarketName, string GroupName, int start, int lenght)
        {
            try
            {
                var res = CurrentCtxRisk.GetRiskSymbolsShareHolders2(Symbol, Holder, GroupName, MarketName, start, lenght).ToList();
                return res;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<MajorShareHoldersRisk> GetRiskShareHolders()
        {
            try
            {
                var res = CurrentCtxFund.MajorShareHoldersRisks.ToList();
                return res;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<HolderGroupName> ShareHolderGroupNames()
        {
            try
            {
                var res = CurrentCtxFund.HolderGroupNames.ToList();
                return res;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<MoneyInputSymbol> MoneyInputSymbols()
        {
            try
            {
                var res = CurrentCtxFund.MoneyInputSymbols.ToList();
                return res;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<MajorShareHolder> MajorShareHolders()
        {
            try
            {
                var res = CurrentCtxFund.MajorShareHolders.ToList();
                return res;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<DebtHolderGroupName> ShareDebtHolderGroupNames()
        {
            try
            {
                var res = CurrentCtxFund.DebtHolderGroupNames.ToList();
                return res;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<GetSymbolsShareHoldersProperties_Result> GetSymbolsShareHoldersProperties()
        {
            try
            {

                var res = CurrentCtxDebt.GetSymbolsShareHoldersProperties().ToList();
                return res;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetSymbolsShareHoldersPropertiesWithValue_Result> GetSymbolsShareHoldersPropertiesWithValue()
        {
            try
            {

                var res = CurrentCtxDebt.GetSymbolsShareHoldersPropertiesWithValue().ToList();
                return res;
            }
            catch (Exception ex)
            {
                return null;
            }
        }








        public List<string> GetSymbolMarketMaker()
        {
            try
            {
                using (var db = new ERMEntitiesDebt())
                {
                    db.Configuration.ProxyCreationEnabled = false;
                    db.Configuration.LazyLoadingEnabled = false;
                    return CurrentCtxDebt
                        .Symbols.Select(c=>c.MarketMaker).Distinct()
                        .ToList();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public GetSymbolGroupsByIsin_Result GetSymbolGroupsByIsin(string isin)
        {
            try
            {

                var res = CurrentCtxDebt.GetSymbolGroupsByIsin(isin).FirstOrDefault();
                return res;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public bool CheckSymbolGroup(SymbolGroup obj)
        {
            try
            {
                return !(CurrentCtxDebt.CheckSymbolGroup(obj.GroupsNameId, obj.SymbolIsin).FirstOrDefault() > 0);
            }
            catch (Exception)
            {
                return false;
            }
        }







        public List<GetSymbolYtmSpreadHistorical_Result> GetSymbolYtmSpreadHistorical(string isin1, string isin2)
        {

            try
            {
                CurrentCtxDebt.Configuration.ProxyCreationEnabled = false;
                CurrentCtxDebt.Configuration.LazyLoadingEnabled = false;
                return CurrentCtxDebt.GetSymbolYtmSpreadHistorical(isin1, isin2).ToList();
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        public List<GetSymbolGroupYtmHistorical_Result> GetSymbolGroupYtmHistorical(int groupId1, int groupId2)
        {

            try
            {
                CurrentCtxDebt.Configuration.ProxyCreationEnabled = false;
                CurrentCtxDebt.Configuration.LazyLoadingEnabled = false;
                return CurrentCtxDebt.GetSymbolGroupYtmHistorical(groupId1, groupId2).ToList();
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        public List<GetSymbolGroupYtm_Result> GetSymbolGroupYtm(int date)
        {

            try
            {
                CurrentCtxDebt.Configuration.ProxyCreationEnabled = false;
                CurrentCtxDebt.Configuration.LazyLoadingEnabled = false;
                return CurrentCtxDebt.GetSymbolGroupYtm(date).ToList();
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        public GetInstrumentsBySymbol_Result GetInstrumentsBySymbol(string symbolName)
        {
            try
            {
                return CurrentCtxDebt.GetInstrumentsBySymbol(symbolName).FirstOrDefault();
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public List<Symbol> GetNamesSymbols()
        {
            try
            {
                CurrentCtxDebt.Configuration.ProxyCreationEnabled = false;
                CurrentCtxDebt.Configuration.LazyLoadingEnabled = false;
                return CurrentCtxDebt.Symbols.ToList();
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetSymbolGroupsName_Result> GetSymbolGroupsName()
        {
            try
            {
                return CurrentCtxDebt.GetSymbolGroupsName("%%", 0, 0, 0).ToList();
            }
            catch (Exception)
            {
                return null;
            }
        }

        public List<PortfolioDeposit> GetPortfolioDepositsT(int id)
        {
            try
            {
                CurrentCtxDebt.Configuration.ProxyCreationEnabled = false;
                CurrentCtxDebt.Configuration.LazyLoadingEnabled = false;
                return CurrentCtxDebt.PortfolioDeposits.Where(c => c.Id == id).ToList();
            }
            catch (Exception)
            {
                return null;
            }
        }
        public List<GetPortfolioDeposits_Result> GetPortfolioDeposits(int pid)
        {
            try
            {
                CurrentCtxDebt.Configuration.ProxyCreationEnabled = false;
                CurrentCtxDebt.Configuration.LazyLoadingEnabled = false;
                return CurrentCtxDebt.GetPortfolioDeposits(pid).ToList();
            }
            catch (Exception)
            {
                return null;
            }
        }

        public List<PortfolioBond> GetPortfolioBondsT(int id)
        {
            try
            {
                CurrentCtxDebt.Configuration.ProxyCreationEnabled = false;
                CurrentCtxDebt.Configuration.LazyLoadingEnabled = false;
                return CurrentCtxDebt.PortfolioBonds.Where(c => c.Id == id).ToList();
            }
            catch (Exception)
            {
                return null;
            }
        }
        public List<GetPortfolioBonds_Result> GetPortfolioBonds(int pid)
        {
            try
            {
                CurrentCtxDebt.Configuration.ProxyCreationEnabled = false;
                CurrentCtxDebt.Configuration.LazyLoadingEnabled = false;
                return CurrentCtxDebt.GetPortfolioBonds(pid).ToList();
            }
            catch (Exception)
            {
                return null;
            }
        }

        public List<GetPortfolioById_Result> GetPortfolioById(int id)
        {
            try
            {
                CurrentCtxDebt.Configuration.ProxyCreationEnabled = false;
                CurrentCtxDebt.Configuration.LazyLoadingEnabled = false;
                return CurrentCtxDebt.GetPortfolioById(id).ToList();
            }
            catch (Exception)
            {
                return null;
            }
        }

        public List<Portfolio> GetPortfolio(string userName)
        {
            try
            {
                using (var db = new ERMEntitiesDebt())
                {

                    db.Configuration.ProxyCreationEnabled = false;
                    db.Configuration.LazyLoadingEnabled = false;
                    return db.Portfolios.Where(c => c.UserName == userName).ToList();
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        public List<GetMarketValues_Result> GetMarketValueInRange(int date )
        {
            try
            {

                return CurrentCtxDebt
                    .GetMarketValues( date)
                    .ToList();

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public List<GetMarketTotalValueInRange_Result> GetMarketTotalValueInRange(string StartDate, string EndDate)
        {
            try
            {
                return CurrentCtxDebt
                    .GetMarketTotalValueInRange(Convert.ToInt32(StartDate), Convert.ToInt32(EndDate))
                    .ToList();

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public List<GetTotalLimitsSell_Result> GetTotalLimitsSell()
        {
            try
            {
                var objFetch = CurrentCtxDebt.GetTotalLimitsSell().ToList();
                /////////////////////////////////////////
                return objFetch;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public List<GetTotalLimitsBuy_Result> GetTotalLimitsBuy()
        {
            try
            {
                var objFetch = CurrentCtxDebt.GetTotalLimitsBuy().ToList();
                /////////////////////////////////////////
                return objFetch;
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public ObjectResult<int?> CheckHasWeek(int Pdate)
        {
            using (var db = new ERMEntitiesDebt())
            {
                db.Configuration.ProxyCreationEnabled = false;
                db.Configuration.LazyLoadingEnabled = false;
                return CurrentCtxDebt.CheckHasWeek(Pdate);

            }
        }


        public List<GetWeekTradeDetailsByUserFilter_Result> GetUserFilterWeekTradeDetailes(string User, int pDate)
        {
            try
            {
                using (var db = new ERMEntitiesDebt())
                {
                    db.Configuration.ProxyCreationEnabled = false;
                    db.Configuration.LazyLoadingEnabled = false;
                    return CurrentCtxDebt
                        .GetWeekTradeDetailsByUserFilter(User, pDate)
                        .ToList();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        public List<WeekTrade> GetWeekTrades(int startDate, int endDate)
        {
            using (var db = new ERMEntitiesDebt())
            {
                db.Configuration.ProxyCreationEnabled = false;
                db.Configuration.LazyLoadingEnabled = false;
                return CurrentCtxDebt.WeekTrades.Where(c => c.StartWeek > startDate && c.EndWeek < endDate).ToList();
            }
        }

        public List<GetSymbolsMaturityShares_Result> GetSymbolsShares(int startDate, int endDate)
        {
            using (var db = new ERMEntitiesDebt())
            {
                db.Configuration.ProxyCreationEnabled = false;
                db.Configuration.LazyLoadingEnabled = false;
                return CurrentCtxDebt.GetSymbolsMaturityShares(startDate,endDate).ToList();
            }
        }


        public List<GetSymbolsMaturitySharesSymbols_Result> GetAllSymbolsShares(int startDate, int endDate,int TypeState,int CouponState )
        {
            using (var db = new ERMEntitiesDebt())
            {
                db.Configuration.ProxyCreationEnabled = false;
                db.Configuration.LazyLoadingEnabled = false;
                CurrentCtxDebt.Database.CommandTimeout = 1200;
                return CurrentCtxDebt.GetSymbolsMaturitySharesSymbols(startDate, endDate, TypeState, CouponState).ToList();
            }
        }


        public List<GetSymbolsHoldersMaturityShares_Result> GetHolderShares(string Holder )
        {
            using (var db = new ERMEntitiesDebt())
            {
                db.Configuration.ProxyCreationEnabled = false;
                db.Configuration.LazyLoadingEnabled = false;
                return CurrentCtxDebt.GetSymbolsHoldersMaturityShares(Holder).ToList();
            }
        }

        public List<GetSymbolsHoldersMaturitySharesName_Result> GetHolderSharesName(string Holder)
        {
            using (var db = new ERMEntitiesDebt())
            {
                db.Configuration.ProxyCreationEnabled = false;
                db.Configuration.LazyLoadingEnabled = false;
                return CurrentCtxDebt.GetSymbolsHoldersMaturitySharesName(Holder).ToList();
            }
        }





        public List<GetAvgMarket_Result> GetAvgMarket(int todayDate)
        {
            using (var db = new ERMEntitiesDebt())
            {
                CurrentCtxDebt.Database.CommandTimeout = 1200;

                var objFetch = CurrentCtxDebt.GetAvgMarket(todayDate).ToList();
                return objFetch;
            }
        }



        public List<GetSymbolHistoricYtmAvg_Result> GetSymbolHistoricYtmAvg()
        {
            using (var db = new ERMEntitiesDebt())
            {
                CurrentCtxDebt.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxDebt.GetSymbolHistoricYtmAvg().ToList();
                return objFetch;
            }
        }



        public List<GetSymbolHistoricNYtmAvg_Result> GetSymbolHistoricNYtmAvg()
        {
            using (var db = new ERMEntitiesDebt())
            {
                CurrentCtxDebt.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxDebt.GetSymbolHistoricNYtmAvg().ToList();
                return objFetch;
            }
        }




        public List<GetWeekTradesByUserFilter_Result> GetUserFilterWeekTradeList(string User, int StartDate, int EndDate)
        {
            using (var db = new ERMEntitiesDebt())
            {

                db.Configuration.ProxyCreationEnabled = false;
                db.Configuration.LazyLoadingEnabled = false;
                return CurrentCtxDebt
                    .GetWeekTradesByUserFilter(User, StartDate, EndDate)
                    .ToList();

            }
        }


        public List<GetSymbolValues_Result> GetSymbolValues(int StartDate, int EndDate, int GroupId, int MinVolume, int YTMorNYTM, int MaturityDate)
        {
            try
            {
                using (var db = new ERMEntitiesDebt())
                {
                    db.Configuration.ProxyCreationEnabled = false;
                    db.Configuration.LazyLoadingEnabled = false;
                    return CurrentCtxDebt
                        .GetSymbolValues(StartDate, EndDate, GroupId, MinVolume, YTMorNYTM, MaturityDate)
                        .ToList();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public List<GetSymbolValuesCompare_Result> GetSymbolValuescompare(int StartDate, int EndDate, int GroupId, int MinVolume, int YTMorNYTM, int StartDiff, int EndDiff, int MaturityDate)
        {
            try
            {
                using (var db = new ERMEntitiesDebt())
                {
                    db.Configuration.ProxyCreationEnabled = false;
                    db.Configuration.LazyLoadingEnabled = false;
                    return CurrentCtxDebt
                        .GetSymbolValuesCompare(StartDate, EndDate, GroupId, MinVolume, YTMorNYTM, StartDiff, EndDiff, 0, MaturityDate)
                        .ToList();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


















        public bool InsertUserFilterWeekTradeDetail(string User, string Records, int pDate)
        {
            try
            {
                CurrentCtxDebt.InsertUserFilterWeekTradeDetails(User, Records, pDate);
                CurrentCtxDebt.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                return false;


            }
        }
        public bool DeleteUserFilterWeekTradeDetail(string User, int pDate)
        {
            try
            {
                CurrentCtxDebt.DeleteUserFilterWeekTradeDetails(User, pDate);
                CurrentCtxDebt.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                return false;


            }
        }



        public GetWeekTradesByUserFilter_Result GetUserFilterWeekTrade(string User, int pDate)
        {
            try
            {
                using (var db = new ERMEntitiesDebt())
                {
                    db.Configuration.ProxyCreationEnabled = false;
                    db.Configuration.LazyLoadingEnabled = false;
                    return CurrentCtxDebt
                        .GetWeekTradesByUserFilter(User, pDate, pDate)
                        .FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public GetWeekTradesByFilter_Result GetWeekTradesbyFilter(int Pdate, int hasfilter, int numDay, double measureValue, string Fields, int hasSelect)
        {
            try
            {

                CurrentCtxDebt.Configuration.ProxyCreationEnabled = false;
                CurrentCtxDebt.Configuration.LazyLoadingEnabled = false;

                return CurrentCtxDebt.GetWeekTradesByFilter(Pdate, hasfilter, numDay, measureValue, Fields, hasSelect).FirstOrDefault();
            }
            catch (Exception ex)
            {
                return null;
            }
        }










        public List<GetWeekTradeDetailsByFilter_Result> GetWeekTradeDetailsByFilter(string Pdate, int HasFilter, int NumDay, double MeasureValue, string Fields, int ChSelecte)
        {
            try
            {
                using (var db = new ERMEntitiesDebt())
                {
                    db.Configuration.ProxyCreationEnabled = false;
                    db.Configuration.LazyLoadingEnabled = false;
                    return CurrentCtxDebt
                        .GetWeekTradeDetailsByFilter(Pdate, HasFilter, NumDay, MeasureValue, Fields, ChSelecte)
                        .ToList();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public List<GetSymbolMaturity_Result> GetSymbolMaturity(int startDate, int endDate)
        {
            try
            {
                using (var db = new ERMEntitiesDebt())
                {
                    db.Configuration.ProxyCreationEnabled = false;
                    db.Configuration.LazyLoadingEnabled = false;
                    return CurrentCtxDebt
                        .GetSymbolMaturity(startDate, endDate)
                        .ToList();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }






        public List<GetSymbolsByFilter_Result> GetSymbolByFilter(string symbol, string name, string marketMaker, string promisor, string sponsor, byte marketId, byte groupNameId
                                                              , int publishDate, int maturityDate, string rate, string isin, int pDate, byte IsClosingPrice, string chSetting2,
                                                                int startIndex, int count, string sort, string sortColumnDir, out int resultCount
            )
        {
            try
            {
                // var db = new ERMEntitiesDebt();

                //db.Configuration.ProxyCreationEnabled = false;
                //db.Configuration.LazyLoadingEnabled = false;
                //CurrentCtxDebt.Database.CommandTimeout = 1200;

                var objFetch = CurrentCtxDebt.GetSymbolsByFilter(symbol, name, marketMaker, promisor, sponsor, marketId, groupNameId, publishDate, maturityDate, rate, isin, pDate, IsClosingPrice
                    , startIndex, int.MaxValue).ToList();
                //GetUsers(string fullName, string userName, string email, string mobile, Nullable < int > startDate, Nullable < int > endDate, Nullable < byte > statusId, Nullable < byte > userTypeId, Nullable < int > minRow, Nullable < int > maxRow)
                /////////////////////////////////////////


                var sorting = sort + " " + sortColumnDir.ToUpper();


                if (string.IsNullOrEmpty(sorting) || sorting.Equals("_Price ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.Price).ToList();
                }
                else if (sorting.Equals("_Price DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.Price).ToList();
                }

                ///////////////////////////////////////
                if (string.IsNullOrEmpty(sorting) || sorting.Equals("Nytm ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.Nytm).ToList();
                }
                else if (sorting.Equals("Nytm DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.Nytm).ToList();
                }

                /////////////////////////////////////////
                if (string.IsNullOrEmpty(sorting) || sorting.Equals("Id ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.Id).ToList();
                }
                else if (sorting.Equals("Id DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.Id).ToList();
                }

                /////////////////////////////////////////
                //if (string.IsNullOrEmpty(sorting) || sorting.Equals("RowNum ASC"))
                //{
                //    objFetch = objFetch.OrderBy(p => p.RowNum).ToList();
                //}
                //else if (sorting.Equals("RowNum DESC"))
                //{
                //    objFetch = objFetch.OrderByDescending(p => p.RowNum).ToList();
                //} 


                if (string.IsNullOrEmpty(sorting) || sorting.Equals("MaturityDays ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.MaturityDays).ToList();
                }
                else if (sorting.Equals("MaturityDays DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.MaturityDays).ToList();
                }


                /////////////////////////////////////////
                if (string.IsNullOrEmpty(sorting) || sorting.Equals("Volume ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.Volume).ToList();
                }
                else if (sorting.Equals("Volume DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.Volume).ToList();
                }


                /////////////////////////////////////////
                if (string.IsNullOrEmpty(sorting) || sorting.Equals("PaymentPerYear ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.PaymentPerYear).ToList();
                }
                else if (sorting.Equals("PaymentPerYear DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.PaymentPerYear).ToList();
                }


                /////////////////////////////////////////
                if (string.IsNullOrEmpty(sorting) || sorting.Equals("MarketName ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.MarketName).ToList();
                }
                else if (sorting.Equals("MarketName DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.MarketName).ToList();
                }
                /////////////////////////////////////////
                if (string.IsNullOrEmpty(sorting) || sorting.Equals("MarketName ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.MarketName).ToList();
                }
                else if (sorting.Equals("MarketName DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.MarketName).ToList();
                }


                /////////////////////////////////////////
                if (string.IsNullOrEmpty(sorting) || sorting.Equals("SellAgent ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.SellAgent).ToList();
                }
                else if (sorting.Equals("SellAgent DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.SellAgent).ToList();
                }

                /////////////////////////////////////////
                if (string.IsNullOrEmpty(sorting) || sorting.Equals("Total ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.Total).ToList();
                }
                else if (sorting.Equals("Total DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.Total).ToList();
                }


                /////////////////////////////////////////
                if (string.IsNullOrEmpty(sorting) || sorting.Equals("_MaturityDate ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.MaturityDate).ToList();
                }
                else if (sorting.Equals("_MaturityDate DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.MaturityDate).ToList();
                }

                /////////////////////////////////////////
                if (string.IsNullOrEmpty(sorting) || sorting.Equals("_PublishDate ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.PublishDate).ToList();
                }
                else if (sorting.Equals("_PublishDate DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.PublishDate).ToList();
                }
                /////////////////////////////////////////
                if (string.IsNullOrEmpty(sorting) || sorting.Equals("Symbol ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.Symbol).ToList();
                }
                else if (sorting.Equals("Symbol DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.Symbol).ToList();
                }
                ///////////////////////////////////////
                if (string.IsNullOrEmpty(sorting) || sorting.Equals("Name ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.Name).ToList();
                }
                else if (sorting.Equals("Name DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.Name).ToList();
                }
                ///////////////////////////////////////
                if (string.IsNullOrEmpty(sorting) || sorting.Equals("Rate ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.Rate).ToList();
                }
                else if (sorting.Equals("Rate DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.Rate).ToList();
                }
                ///////////////////////////////////////
                if (string.IsNullOrEmpty(sorting) || sorting.Equals("MarketMaker ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.MarketMaker).ToList();
                }
                else if (sorting.Equals("MarketMaker DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.MarketMaker).ToList();
                }
                ///////////////////////////////////////
                if (string.IsNullOrEmpty(sorting) || sorting.Equals("Promisor ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.Promisor).ToList();
                }
                else if (sorting.Equals("Promisor DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.Promisor).ToList();
                }
                ///////////////////////////////////////
                if (string.IsNullOrEmpty(sorting) || sorting.Equals("Sponsor ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.Sponsor).ToList();
                }
                else if (sorting.Equals("Sponsor DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.Sponsor).ToList();
                }
                ///////////////////////////////////////
                if (string.IsNullOrEmpty(sorting) || sorting.Equals("Founder ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.Founder).ToList();
                }
                else if (sorting.Equals("Founder DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.Founder).ToList();
                }
                ///////////////////////////////////////
                if (string.IsNullOrEmpty(sorting) || sorting.Equals("Ytm ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.Ytm).ToList();
                }
                else if (sorting.Equals("Ytm DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.Ytm).ToList();
                }

                ///////////////////////////////////////
                if (string.IsNullOrEmpty(sorting) || sorting.Equals("_MarketValue ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.MarketValue).ToList();
                }
                else if (sorting.Equals("_MarketValue DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.MarketValue).ToList();
                }

                ///////////////////////////////////////
                if (string.IsNullOrEmpty(sorting) || sorting.Equals("_dayLastDate ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.dayLastDate).ToList();
                }
                else if (sorting.Equals("_dayLastDate DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.dayLastDate).ToList();
                }


                ///////////////////////////////////////
                if (string.IsNullOrEmpty(sorting) || sorting.Equals("_Volume ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.Volume).ToList();
                }
                else if (sorting.Equals("_Volume DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.Volume).ToList();
                }
                ///////////////////////////////////////
                if (string.IsNullOrEmpty(sorting) || sorting.Equals("_TradeCount ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.TradeCount).ToList();
                }
                else if (sorting.Equals("_TradeCount DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.TradeCount).ToList();
                }

                ///////////////////////////////////////
                if (string.IsNullOrEmpty(sorting) || sorting.Equals("_SymbolType ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.SymbolType).ToList();
                }
                else if (sorting.Equals("_SymbolType DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.SymbolType).ToList();
                }







                /////////////////////////////////////////
                if (chSetting2 == "1")
                {
                    objFetch = objFetch.OrderBy(p => p.GroupName).ToList();
                }

                if (string.IsNullOrEmpty(sorting) || sorting.Equals("_Groups ASC"))
                {
                    objFetch = objFetch.OrderBy(p => p.GroupName).ToList();
                }
                else if (sorting.Equals("_Groups DESC"))
                {
                    objFetch = objFetch.OrderByDescending(p => p.GroupName).ToList();
                }

                /////////////////////////////////////////


                resultCount = objFetch.Count();
                return objFetch;




            }
            catch (Exception ex)
            {
                throw;
            }

        }

         

        public GetSymbolByIsin_Result GetSymbolByIsin(string symbolName)
        {
            try
            {
                var objFetch = CurrentCtxDebt.GetSymbolByIsin(symbolName).FirstOrDefault();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetLastSymbolsUpdate_Result> GetLastSymbolsUpdate()
        {
            try
            {
                var objFetch = CurrentCtxDebt.GetLastSymbolsUpdate().ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetSymbolDailyInterestBySymbol_Result> GetSymbolDailyInterest(string Symbol, int Date)
        {
            try
            {
                var objFetch = CurrentCtxDebt.GetSymbolDailyInterestBySymbol(Symbol, Date, 0, int.MaxValue).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public List<GetSymbolCouponBySymbolName_Result> GetSymbolCoupons(string Symbol, int Date)
        {
            try
            {
                var objFetch = CurrentCtxDebt.GetSymbolCouponBySymbolName(Symbol, Date, 0, int.MaxValue).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetHistoricalSymbolPrice_Result> GetSymbolHistoricalPrice(string Symbol,int hascheck,string fields)
        {
            try
            {
                var objFetch = CurrentCtxRisk.GetHistoricalSymbolPrice(hascheck,fields).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<CalcPortfolioVarByYield_Result> CalculatePortfolioYieldVAR(int StartDate, int EndDate, int FundId,int interval)
        {
            try
            {
                var objFetch = CurrentCtxRisk.CalcPortfolioVarByYield(StartDate, EndDate, FundId, interval).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public double GetFundLastValue(int FundId)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetFundLastValue( FundId ).FirstOrDefault();
                return (double) objFetch;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }





        public List<CalculateSemiSTDV2_Result> CalculateSemiSTDV2(int fundId, int startDate , int EndDate,int valPeriod)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200000;

                var objFetch =   CurrentCtxRisk.CalculateSemiSTDV2(fundId, startDate, EndDate,valPeriod).ToList();
                return  objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<CalculateSemiSTDV2All_Result> CalculateSemiSTDV2All(int fundId, int startDate, int EndDate )
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200000;

                var objFetch = CurrentCtxRisk.CalculateSemiSTDV2All(fundId, startDate, EndDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<CalculateSymbolSemiSTDV2_Result> CalculateSymbolSemiSTDV2(int SymbolId, int startDate, int EndDate)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200000;

                var objFetch = CurrentCtxRisk.CalculateSymbolSemiSTDV2(SymbolId, startDate, EndDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<CalculateFundYield_Result> GetPortfolioYield(int fundId, int startDate, int EndDate,int ValState)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;

              

                var objFetch = CurrentCtxRisk.CalculateFundYield(startDate, EndDate, fundId, ValState).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<CalculateFundYieldNAdjPrice_Result> CalculateFundYieldNAdjPrice(int fundId, int startDate, int EndDate, int ValState)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;



                var objFetch = CurrentCtxRisk.CalculateFundYieldNAdjPrice(startDate, EndDate, fundId, ValState).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<CalculateFundYieldSimplePrice_Result> CalculateFundYieldSimplePrice(int fundId, int startDate, int EndDate, int ValState)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxRisk.CalculateFundYieldSimplePrice(startDate, EndDate, fundId, ValState).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetFundPortfolioUpdateStatus_Result> GetFundPortfolioUpdateStatus(int fundId, int startDate, int EndDate, int startRow,int lenght)
        {
            try
            {
                CurrentCtxFund.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxFund.GetFundPortfolioUpdateStatus(fundId,startDate, EndDate,startRow,lenght).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetPortfolioSymbolsByDate_Result> GetPortfolioSymbolsByDate(int fundId, int pDate)
        {
            try
            {
                CurrentCtxFund.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxFund.GetPortfolioSymbolsByDate(fundId, pDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<GetPortfolioYieldRanking_Result> GetPortfolioYieldRanking(  int EndDate,int fundId )
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;



                var objFetch = CurrentCtxRisk.GetPortfolioYieldRanking(EndDate, fundId).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }





        public List<CalculateSymbolYield_Result> GetSymbolYield(int symbolId, int startDate, int EndDate, int ValState)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;



                var objFetch = CurrentCtxRisk.CalculateSymbolYield(startDate, EndDate, symbolId, ValState).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<CalculateFundYieldRawDataSumBuys_Result> CalculateFundYieldRawDataSumBuys(int fundId, int startDate, int EndDate, int ValState)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;

                var objFetch = CurrentCtxRisk.CalculateFundYieldRawDataSumBuys(startDate, EndDate, fundId, ValState).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public List<CalculateFundYieldRawDataSumBuysNAdjPrice_Result> CalculateFundYieldRawDataSumBuysNAdjPrice(int fundId, int startDate, int EndDate, int ValState)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;

                var objFetch = CurrentCtxRisk.CalculateFundYieldRawDataSumBuysNAdjPrice(startDate, EndDate, fundId, ValState).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<CalculateFundYieldRawDataSumBuysSimplePrice_Result> CalculateFundYieldRawDataSumBuysSimplePrice(int fundId, int startDate, int EndDate, int ValState)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;

                var objFetch = CurrentCtxRisk.CalculateFundYieldRawDataSumBuysSimplePrice(startDate, EndDate, fundId, ValState).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<CalculateFundYieldRawDataSumSales_Result> CalculateFundYieldRawDataSumSales(int fundId, int startDate, int EndDate, int ValState)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;

                var objFetch = CurrentCtxRisk.CalculateFundYieldRawDataSumSales(startDate, EndDate, fundId, ValState).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<CalculateFundYieldRawDataSumSalesNAdjPrice_Result> CalculateFundYieldRawDataSumSalesNAdjPrice(int fundId, int startDate, int EndDate, int ValState)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;

                var objFetch = CurrentCtxRisk.CalculateFundYieldRawDataSumSalesNAdjPrice(startDate, EndDate, fundId, ValState).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<CalculateFundYieldRawDataSumSalesSimplePrice_Result> CalculateFundYieldRawDataSumSalesSimplePrice(int fundId, int startDate, int EndDate, int ValState)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;

                var objFetch = CurrentCtxRisk.CalculateFundYieldRawDataSumSalesSimplePrice(startDate, EndDate, fundId, ValState).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<CalculateFundYieldRawDataValue_Result> CalculateFundYieldRawDataValue(int fundId, int startDate, int EndDate, int ValState)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;

                var objFetch = CurrentCtxRisk.CalculateFundYieldRawDataValue(startDate, EndDate, fundId, ValState).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<CalculateFundYieldRawDataValueNAdjPrice_Result> CalculateFundYieldRawDataValueNAdjPrice(int fundId, int startDate, int EndDate, int ValState)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;

                var objFetch = CurrentCtxRisk.CalculateFundYieldRawDataValueNAdjPrice(startDate, EndDate, fundId, ValState).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<CalculateFundYieldRawDataValueSimplePrice_Result> CalculateFundYieldRawDataValueSimplePrice(int fundId, int startDate, int EndDate, int ValState)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;

                var objFetch = CurrentCtxRisk.CalculateFundYieldRawDataValueSimplePrice(startDate, EndDate, fundId, ValState).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<CalculateFundYieldRawDataSumProfits_Result> CalculateFundYieldRawDataSumProfits(int fundId, int startDate, int EndDate, int ValState)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;

                var objFetch = CurrentCtxRisk.CalculateFundYieldRawDataSumProfits(startDate, EndDate, fundId, ValState).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }






        public List<CalcPortfolioVAR_Result> GetPortfolioVAR(int StartDate , int EndDate ,  int hascheck, string fields, int fundId)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200000;

                var objFetch = CurrentCtxRisk.CalcPortfolioVAR(StartDate, EndDate, hascheck, fields, fundId).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<CalcPortfolioWeeklyVAR_Result> CalcPortfolioWeeklyVAR(int StartDate, int EndDate, int hascheck, string fields, int fundId)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 12000;

                var objFetch = CurrentCtxRisk.CalcPortfolioWeeklyVAR(StartDate, EndDate, hascheck, fields, fundId).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<CalculateSymbolVARV2_Result> CalcSymbolVARV2(int StartDate, int EndDate,   int Interval, int SymbolId)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 12000;

                var objFetch = CurrentCtxRisk.CalculateSymbolVARV2(SymbolId,StartDate, EndDate, Interval).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetPortfolioVaRRanking_Result> GetPortfolioVaRRanking(int FundId,int StartDate, int EndDate)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 12000;

                var objFetch = CurrentCtxRisk.GetPortfolioVaRRanking(FundId, StartDate, EndDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetPortfolioSemiSTDRanking_Result> GetPortfolioSemiSTDRanking(int StartDate, int EndDate, int FundId)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 12000;

                var objFetch = CurrentCtxRisk.GetPortfolioSemiSTDRanking(FundId, StartDate, EndDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetPortfolioTrackingErrorRanking_Result> GetPortfolioTrackingErrorRanking(int StartDate, int EndDate, int FundId)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 12000;

                var objFetch = CurrentCtxRisk.GetPortfolioTrackingErrorRanking(FundId, StartDate, EndDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetPortfolioBetaRanking_Result> GetPortfolioBetaRanking(int StartDate, int EndDate, int FundId)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 12000;

                var objFetch = CurrentCtxRisk.GetPortfolioBetaRanking(FundId, StartDate, EndDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

    public List<GetPortfolioPerformanceEvaluationRanking_Result> GetPortfolioPerformanceEvaluationRanking(int StartDate, int EndDate, int FundId,double Percent)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 12000;

                var objFetch = CurrentCtxRisk.GetPortfolioPerformanceEvaluationRanking(FundId, StartDate, EndDate,Percent).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<CalcPortfolioMonthlyVAR_Result> CalcPortfolioMonthlyVAR(int StartDate, int EndDate, int hascheck, string fields,int fundId)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 12000;

                var objFetch = CurrentCtxRisk.CalcPortfolioMonthlyVAR(StartDate, EndDate, hascheck, fields,fundId).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

 
 


        public List<GetHistoricalSymbolPriceBySymbol_Result> GetSymbolHistoricalPriceBySymbol(string Symbol)
        {
            try
            {
                var objFetch = CurrentCtxRisk.GetHistoricalSymbolPriceBySymbol(Symbol).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetHistoricalSymbolPriceByFundId_Result> GetHistoricalSymbolPriceByFundId(int FundId,int Pdate)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetHistoricalSymbolPriceByFundId(FundId, Pdate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }







        public List<HistoricalSymbolPrice> GetPortolioSymbolWeights()
        {
            try
            {
                var objFetch = CurrentCtxRisk.HistoricalSymbolPrices.ToList();
                return objFetch;
            }
            catch (Exception ex)
            { 
                return null;
            }
        }









        public List<GetSymbolCashFlow_Result> GetChashFlow(string Isin, int Date)
        {
            try
            {
                var objFetch = CurrentCtxDebt.GetSymbolCashFlow(Isin, Date).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<SymbolLatest> GetDebtSymbolLatest(string Symbol)
        {
            try
            {
                //Symbol = Symbol.ToLikeMsgString();
                var objFetch = CurrentCtxDebt.SymbolLatests.Where(c => (  Symbol =="%%" || c.Symbol.Contains(Symbol))&& c.SymbolType==1).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }











        public List<SymbolLatest> GetSymbols()
        {
            try
            {
                var objFetch = CurrentCtxDebt.SymbolLatests.Where(c=>c.SymbolType==1).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetDebtbondSymbols_Result> GetDebtBondSymbols()
        {
            try
            {
                var objFetch = CurrentCtxDebt.GetDebtbondSymbols().ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public int GetDebtBondNum(string symbol)
        {
            try
            {
                var objFetch =  CurrentCtxDbo.GetPsitionNumBySymbol(symbol).FirstOrDefault();
                return (int)  objFetch;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }





        public List<GetInstruments_Result> GetInstrumentSymbols()
        {
            try
            {
                var objFetch = CurrentCtxDebt.GetInstruments().ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetHistoricalSymbolPrice_Result> GetInstrumentSymbolsDistinct()
        {
            try
            {
                var objFetch = CurrentCtxRisk.GetHistoricalSymbolPrice(0,"").ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetFundPortfolioIndustry_Result> GetIndustryChart(int FundId,int Date)
        {
            try
            {
                var objFetch = CurrentCtxRisk.GetFundPortfolioIndustry(FundId, Date).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetRiskShareHolderHistoricalOwnership_Result> GetRiskShareHolderHistoricalOwnership(int startDate, int endDate,string Holder)
        {
            try
            {
                var objFetch = CurrentCtxRisk.GetRiskShareHolderHistoricalOwnership(startDate, endDate, Holder).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetMajorShareHolderSymbolHistoricalAllDate_Result> GetMajorShareHolderSymbolHistoricalAllDate(int startDate, int endDate, string Holder, string Symbol)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetMajorShareHolderSymbolHistoricalAllDate(Holder, Symbol,startDate, endDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public int InsertFundSymbolsToPortfolio(int FundId,int Removecheck)
        {
            try
            {
                    CurrentCtxRisk.Database.CommandTimeout = 1200;
                    var objFetch = CurrentCtxRisk.InsertFundSymbolsToPortfolio((int)FundId, (int)Removecheck);
                    return objFetch;
             }
            catch (Exception ex)
            {
                return 0;
            }
        }






        public List<GetSymbolByIsin_Result> GetSymbolDetailByIsin(string isin)
        {
            try
            {
                var objFetch = CurrentCtxDebt.GetSymbolByIsin(isin).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }








        public double GetSpYtmByRate(string Isin, int buyDate, int buyPrice, int sellDate, int sellPrice)
        {
            try
            {
                ((IObjectContextAdapter)CurrentCtxDebt).ObjectContext.CommandTimeout = 2000;
                var objFetch = CurrentCtxDebt.GetSpYtmByRate(Isin, buyDate, buyPrice, sellDate, sellPrice)
                    .FirstOrDefault();
                return (double)objFetch;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }

        public double GetSpYtmByBuyPrice(string Isin, int buyDate, int sellDate, int sellPrice, decimal NominalRate)
        {
            try
            {
                ((IObjectContextAdapter)CurrentCtxDebt).ObjectContext.CommandTimeout = 2000;
                var objFetch = CurrentCtxDebt.GetSpYtmByBuyPrice(Isin, buyDate, sellDate, sellPrice, NominalRate / 100).FirstOrDefault();
                return (double)objFetch;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }

        public double GetSpYtmBySellPrice(string Isin, int buyDate, int BuyPrice, int sellDate, decimal NominalRate)
        {
            try
            {
                ((IObjectContextAdapter)CurrentCtxDebt).ObjectContext.CommandTimeout = 2000;
                var objFetch = CurrentCtxDebt.GetSpYtmBySellPrice(Isin, buyDate, BuyPrice, sellDate, NominalRate / 100).FirstOrDefault();
                return (int)objFetch; //todo:
                //return 0;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }


        public List<GetSymbolYtmHistorical_Result> GetSymbolYtmHistorical(string isin)
        {
            try
            {
                var objFetch = CurrentCtxDebt.GetSymbolYtmHistorical(isin).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }























    }
}