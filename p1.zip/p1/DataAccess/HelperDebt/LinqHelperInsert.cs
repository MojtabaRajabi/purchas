﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sanay.Lotus.Erm.Models;
using System.Data.Entity.Migrations;


namespace Sanay.Lotus.Erm.DataAccess.Helper
{
    public partial class LinqHelper
    {
        public void InsertPortfolioDeposits(PortfolioDeposit obj)
        {
            try
            {
                CurrentCtxDebt.PortfolioDeposits.Add(obj);
                CurrentCtxDebt.SaveChanges();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void InsertPortfolioBonds(PortfolioBond obj)
        {
            try
            {
                CurrentCtxDebt.PortfolioBonds.Add(obj);
                CurrentCtxDebt.SaveChanges();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void InsertSymbolGroups(SymbolGroup obj)
        {
            try
            {
                CurrentCtxDebt.InsertSymbolGroups(obj.GroupsNameId, obj.SymbolIsin, obj.RegDate, obj.StatusId);
                CurrentCtxDebt.SaveChanges();
            }
            catch (Exception ex)
            {
            }
        }
        public void InsertSymbolBlockByIsin(SymbolGroup obj)
        {
            try
            {
                CurrentCtxDebt.InsertSymbolBlockByIsin(obj.SymbolIsin);
                CurrentCtxDebt.SaveChanges();
            }
            catch (Exception ex)
            {
            }
        }






        public int InsertPortfolio(Portfolio obj)
        {
            try
            {
                CurrentCtxDebt.Portfolios.Add(obj);
                CurrentCtxDebt.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }
        }





        public int InsertSymbol(Symbol obj)
        {
            try
            {
                CurrentCtxDebt.InsertSymbol(obj.Symbol1, obj.Isin, obj.Name, obj.MarketId, obj.PublishDate, obj.MaturityDate,
                                            obj.MarketDesc, obj.Rate, obj.Total, obj.TotalAccepted, obj.Publisher, obj.Promisor, obj.Sponsor,
                                            obj.Founder, obj.MarketMaker, obj.SellAgent, obj.Accounter, obj.SecondaryDate, obj.ProfitPaymentOperat,
                                            obj.MarketMakerId, obj.SymbolType, obj.TotalBond, obj.TotalAcceptedNumber,obj.NominalPrice,obj.BuyPriceGuarantee,obj.MaxDailyGuarantee);
                CurrentCtxDebt.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public bool UpdateSymbolGroups(int Id, int GroupsNameId, int RegDate, string InsCode)
        {
            try
            {
                CurrentCtxDebt.UpdateSymbolGroups(Id, GroupsNameId, RegDate, InsCode);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }



        public int UpdateSymbolBlock(Symbol obj)
        {
            try
            {
                CurrentCtxDebt.UpdateSymbolBlock(obj.Isin, obj.Name, obj.MarketId, obj.PublishDate, obj.MaturityDate, obj.MarketDesc, obj.Rate
                                               , obj.Total, obj.TotalAccepted, obj.Publisher, obj.Promisor, obj.Sponsor, obj.Founder, obj.MarketMaker, obj.SellAgent, obj.Accounter
                                               , obj.SecondaryDate, obj.ProfitPaymentOperat, obj.MarketMakerId, obj.SymbolType, obj.NominalPrice, obj.BuyPriceGuarantee, obj.MaxDailyGuarantee
                                               , obj.TotalAcceptedNumber, obj.TotalBond, obj.MinYieldRate, obj.MaxYieldRate, (double)obj.BuyPriceGuarantee, obj.InitialPrice, obj.BaseAsset);




                CurrentCtxDebt.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }




        public int UpdateDebtSymbol(Symbol obj)
        {
            try
            {
                CurrentCtxDebt.Symbols.AddOrUpdate(obj);
                CurrentCtxDebt.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }





        public int InsertSymbolCoupons(Lib.Dto.SymbolCoupons obj)
        {
            try
            {
                CurrentCtxDebt.InsertSymbolCoupons(obj.Symbol, obj.Pdate, obj.Interest.Replace("/", ".").Replace(",", ""));
                CurrentCtxDebt.SaveChanges();
                return 1;
            }
            catch (Exception ex)
            {
                throw;
            }

        }



        public int InsertHistoricalSymbolPrice(Lib.Dto.HistoricalSymbolPrice obj)
        {
            try
            {
                CurrentCtxRisk.InsertHistoricalSymbolPrice(obj.Symbol, obj.DatePrice
                                                         , obj.SymbolPrice.Replace("/", ".").Replace(",", "")
                                                         , obj.Indicator.Replace("/", ".").Replace(",", ""));
                CurrentCtxDebt.SaveChanges();
                return 1;
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public int InsertSymbolCouponsBlock(string Symb)
        {
            try
            {
                CurrentCtxDebt.InsertSymbolCouponsBlock(Symb);
                CurrentCtxDebt.SaveChanges();
                return 1;
            }
            catch (Exception ex)
            {
                throw;
            }

        }



        public int InsertSymbolDailyInterestsBlock(string Symb)
        {
            try
            {
                CurrentCtxDebt.InsertSymbolDailyInterestBlock(Symb);
                CurrentCtxDebt.SaveChanges();
                return 1;
            }
            catch (Exception ex)
            {
                throw;
            }

        }




        public int InsertSymbolDailyInterest(Lib.Dto.SymbolCoupons obj)
        {
            try
            {
                CurrentCtxDebt.InsertSymbolDailyInterest(obj.Symbol, obj.Pdate, obj.Interest.Replace("/", ".").Replace(",", ""));
                CurrentCtxDebt.SaveChanges();
                return 1;
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        public int DeleteSymbolDailyInterest(string symbol)
        {
            try
            {
                CurrentCtxDebt.DeleteSymbolDailyInterestBySymbol(symbol);
                CurrentCtxDebt.SaveChanges();
                return 1;
            }
            catch (Exception ex)
            {
                throw;
            }

        }







    }
}