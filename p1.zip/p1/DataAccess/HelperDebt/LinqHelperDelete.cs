﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sanay.Lotus.Erm.DataAccess.Helper
{
    public partial class LinqHelper
    {

        public void DeletePortfolioDeposits(PortfolioDeposit obj)
        {
            try
            {

                if (obj != null)
                {

                    CurrentCtxDebt.PortfolioDeposits.Remove(obj);
                    CurrentCtxDebt.SaveChanges();
                }

            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void DeletePortfolioBonds(PortfolioBond obj)
        {
            try
            {
               
                if (obj != null)
                {

                    CurrentCtxDebt.PortfolioBonds.Remove(obj);
                    CurrentCtxDebt.SaveChanges();
                }

            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void DeletePortfolio(int Id)
        {
            try
            {
                CurrentCtxDebt.RemovePortfolio(Id);
                CurrentCtxDebt.SaveChanges();

            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public int DeleteSymbolCoupons(string symbol)
        {
            try
            {
                CurrentCtxDebt.DeleteSymbolCouponsBySymbol(symbol);
                CurrentCtxDebt.SaveChanges();
                return 1;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public int DeleteHistoricalSymbolPrice(string symbol)
        {
            try
            {
                CurrentCtxRisk.DeleteHistoricalSymbolPriceBySymbol(symbol);
                CurrentCtxDebt.SaveChanges();
                return 1;
            }
            catch (Exception ex)
            {
                throw;
            }
        }










    }
}