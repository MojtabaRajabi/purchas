﻿using System;
using System.Linq;
using System.Web;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.Models;
 
using System.Data.Entity.Migrations;
using Sanay.Lotus.Erm.DataAccess.HelperUserLog;
using Sanay.Lotus.Erm.Lib.Enum;

namespace Sanay.Lotus.Erm.DataAccess.Helper
{
    public partial class LinqHelper : System.Web.UI.Page
    {

        public static ERMEntitiesUsr CurrentCtxUsr
        {
            get
            {
                try
                {
                    var ctx = HttpContext.Current.Items["CtxPerRequestUsr"] as ERMEntitiesUsr;

                    return ctx ?? new ERMEntitiesUsr();
                }
                catch
                {
                    return new ERMEntitiesUsr();
                }
            }
        }




        public GetUsersInfo_Result CheckLogin(UserAccount usracc)
        {
            try
            {
                GetUsersInfo_Result Account = new GetUsersInfo_Result();
                Account = CurrentCtxUsr.GetUsersInfo(usracc.UserName).FirstOrDefault();
                //User Account = new User() { UserName == usracc.UserName };
                var pass = Assistant.EncryptString(usracc.Password + usracc.UserName + Account.RegDate);
                //if (Account.Password == pass || usracc.Password=="@@sanay@@")
                if (Account.Password == pass)
                {
                    Account.Password = "*****";
                    return Account;
                }
                else
                {
                    
                    return null;
                }
            }
            catch (Exception ex)
            {
                return null;
            }



        }



    }
}