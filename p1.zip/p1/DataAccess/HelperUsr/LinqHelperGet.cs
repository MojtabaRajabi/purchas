﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Ajax.Utilities;
using Sanay.Library.DataAccess;
using Sanay.Lotus.Erm.Lib.Enum;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Core.Objects;

namespace Sanay.Lotus.Erm.DataAccess.Helper
{
    public partial class LinqHelper
    {

        public List<GetUsersByFilter_Result> GetUsersByFilter()
        {
            try
            {
                var objFetch = CurrentCtxUsr.GetUsersByFilter().ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public User GetUserByUsername(string Username)
        {
            try
            {
                var objFetch = CurrentCtxUsr.Users.Where(c => c.UserName == Username).FirstOrDefault();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

       


        public List<GetSymbolBestLimits_Result> GetSymbolBestLimits(string isin)
        {
            try
            {

                var res = CurrentCtxDebt.GetSymbolBestLimits(isin).ToList();
                return res;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public UserDebtBoardConfig GetUserDebtBoardConfigs(string UserName)
        {
            try
            {
                using (var db = new ERMEntitiesDebt())
                {
                    db.Configuration.ProxyCreationEnabled = false;
                    db.Configuration.LazyLoadingEnabled = false;
                    var objFetch = CurrentCtxUsr.UserDebtBoardConfigs.Where(t => t.UserName == UserName).FirstOrDefault();
                    if (objFetch == null)
                    {
                        objFetch.market1 = true;
                        objFetch.market2 = true;
                        objFetch.market3 = true;
                        objFetch.market4 = true;
                        objFetch.market5 = true;

                        objFetch.marketType1 = true;
                        objFetch.marketType2 = true;
                        objFetch.marketType3 = true;
                        objFetch.marketType4 = true;
                        objFetch.marketType5 = true;
                        objFetch.marketType6 = true;
                        objFetch.marketType7 = true;
                        objFetch.marketType7 = true;
                        objFetch.marketType7 = true;
                        objFetch.marketType7 = true;
                        objFetch.marketType7 = true;
                        objFetch.marketType7 = true;

                        objFetch.maturity1 = true;
                        objFetch.maturity2 = true;

                        objFetch.OptionSetting1 = true;
                        objFetch.OptionSetting2 = true;

                        objFetch.SymbolTypeGroup = 0;
                        objFetch.priceGroup = 0;

                        objFetch.col2 = true;
                        objFetch.col3 = true;
                        objFetch.col4 = true;
                        objFetch.col5 = true;
                        objFetch.col6 = true;
                        objFetch.col7 = true;
                        objFetch.col8 = true;
                        objFetch.col9 = true;
                        objFetch.col10 = true;
                        objFetch.col11 = true;
                        objFetch.col12 = true;
                        objFetch.col13 = true;
                        objFetch.col14 = true;
                        objFetch.col15 = true;
                        objFetch.col16 = true;
                        objFetch.col17 = true;
                        objFetch.col18 = true;
                        objFetch.col19 = true;
                        objFetch.col20 = true;
                        objFetch.col21 = true;

                    }

                    return objFetch;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetUsers_Result> GetUserAcc()
        {
            try
            {
                var objFetch = CurrentCtxUsr.GetUsers().ToList();
                //List<GetEtemadFunds_Result> objFetchSorted = new List<GetEtemadFunds_Result>();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<User> GetUser()
        {
            try
            {
                var objFetch = CurrentCtxUsr.Users.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public object GetUserInfo(string Username)
        {
            try
            {
                var objFetch = CurrentCtxUsr.Users.Where(c => c.UserName == Username).Select(c => new
                {
                    UserName = c.UserName,
                    FirstName = c.FirstName,
                    LastName = c.LastName,

                }).FirstOrDefault();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetUserInputOutputFlowsConfigs_Result> GetUserInputOutputFlowsConfigs(string UserName)
        {
            try
            {

                var objFetch = CurrentCtxUsr.GetUserInputOutputFlowsConfigs(UserName).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetUserFundInputOutputFlowsConfigs_Result> GetUserFundInputOutputFlowsConfigs(string UserName)
        {
            try
            {

                var objFetch = CurrentCtxUsr.GetUserFundInputOutputFlowsConfigs(UserName).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



    }
}