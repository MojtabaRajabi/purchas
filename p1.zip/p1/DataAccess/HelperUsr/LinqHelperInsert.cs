﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sanay.Lotus.Erm.Models;
using System.Data.Entity.Migrations;
using Sanay.Lotus.Erm.Lib.Enum;
using Sanay.Library.Utility;


namespace Sanay.Lotus.Erm.DataAccess.Helper
{
    public partial class LinqHelper
    {

    


        public int AddUserDebtBoardConfig(UserDebtBoardConfig obj)
        {
            try
            {
                CurrentCtxUsr.UserDebtBoardConfigs.AddOrUpdate(c => c.UserName, obj);
                CurrentCtxUsr.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public int AddUserInputOutputFlowsConfig(UserInputOutputFlowsConfig obj)
        {
            try
            {
                CurrentCtxUsr.UserInputOutputFlowsConfigs.AddOrUpdate(c => c.UserName, obj);
                CurrentCtxUsr.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }

           public int AddUserFundInputOutputFlowsConfig(UserFundInputOutputFlowsConfig obj)
        {
            try
            {
                CurrentCtxUsr.UserFundInputOutputFlowsConfigs.AddOrUpdate(c => c.UserName, obj);
                CurrentCtxUsr.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        public string InsertUser(User obj)
        {
            try
            {
                var usr = CurrentCtxUsr.Users.Where(c => c.UserName == obj.UserName).FirstOrDefault();
                if (usr == null)
                {
                    CurrentCtxUsr.Users.Add(obj);
                    CurrentCtxUsr.SaveChanges();
                    return obj.UserName;
                }
                else
                {
                      return "ErrorDuplicate";
                }
               
            }
            catch (Exception ex)
            {
                throw;
            }
        }


    }
}