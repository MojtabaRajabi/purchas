﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sanay.Lotus.Erm.DataAccess.Helper
{
    public partial class LinqHelper
    {
        public bool DeleteUser(string username)
        {
            try
            {

                User user = new User() { UserName = username };
                CurrentCtxUsr.Users.Attach(user);
                CurrentCtxUsr.Users.Remove(user);
                CurrentCtxUsr.SaveChanges();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

    }
}