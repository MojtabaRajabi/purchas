﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Web;
using OfficeOpenXml.FormulaParsing.Utilities;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.Models;

namespace Sanay.Lotus.Erm.DataAccess.Helper
{
    public partial class LinqHelper
    {

        public bool UpdatePassword(UserAccount userInfo)
        {
            try
            {

                //User User = new User();
                var objFetch = CurrentCtxUsr.Users.Where(c => c.UserName == userInfo.UserName).FirstOrDefault();
                objFetch.Password = Assistant.EncryptString(userInfo.NewPassword + objFetch.UserName + objFetch.RegDate);
                objFetch.StatusId = 1;
                //objFetch.Password = userInfo.NewPassword;
                CurrentCtxUsr.SaveChanges();


                return true;
            }
            catch (Exception ex)
            {
                return false;
            }

        }


        public string UpdateUserAcc(User obj)
        {
            try
            {

                CurrentCtxUsr.Users.AddOrUpdate(obj);
                CurrentCtxUsr.SaveChanges();
                return obj.UserName;
            }
            catch (Exception ex)
            {
                throw;
            }
        }



        public string UpdatePosition(Position obj)
        {
            try
            {
                var oldRecord = CurrentCtxDbo.Positions.FirstOrDefault(c=>c.Id== obj.Id);
                oldRecord.Num = obj.Num;
                oldRecord.Date = obj.Date;
                oldRecord.Profit = obj.Profit;
                oldRecord.Interest = obj.Interest;
                oldRecord.AvgPrice = obj.AvgPrice;
                oldRecord.ClosingPrice = obj.ClosingPrice;
                oldRecord.GuaranteedProfitEarned = obj.GuaranteedProfitEarned;
                oldRecord.GuaranteedEarning = obj.GuaranteedEarning;
                oldRecord.PrincipalAmount = obj.PrincipalAmount;
                oldRecord.IsPoint = obj.IsPoint==true?true:false;
                oldRecord.IsUpdate = obj.IsUpdate;
                oldRecord.TradeType = obj.TradeType;
                CurrentCtxDbo.Positions.AddOrUpdate(oldRecord);
                CurrentCtxDbo.SaveChanges();
                return obj.Symbol;
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public string UpdatePermission(Permission obj)
        {
            try
            {

                var res = CurrentCtxUsr.Permissions.FirstOrDefault(t => t.UserName == obj.UserName);
                if (res == null)
                {
                    CurrentCtxUsr.Permissions.AddOrUpdate(obj);
                    CurrentCtxUsr.SaveChanges();
                }
                else
                {
                    res.IsCompany = obj.IsCompany;
                    res.IsDebtBoard = obj.IsDebtBoard;
                    res.IsFinancial = obj.IsFinancial;
                    res.IsFund = obj.IsFund;
                    res.IsSetting = obj.IsSetting;
                    res.IsRisk = obj.IsRisk;
                    res.IsHeatmap = obj.IsHeatmap;
                    CurrentCtxUsr.Permissions.AddOrUpdate(res);
                    CurrentCtxUsr.SaveChanges();
                }
                return obj.UserName;
            }
            catch (Exception ex)
            {
                throw;
            }

        }





    }
}