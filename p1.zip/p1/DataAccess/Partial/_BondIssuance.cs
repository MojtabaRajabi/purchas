﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Sanay.Library.Utility;

namespace Sanay.Lotus.Erm.DataAccess
{
    public partial class BondIssuance
    {
        public string _PublishDate => Assistant.DateToDisplayMode(PublishDate);
        public string _RedeemDate => Assistant.DateToDisplayMode(RedeemDate);
        public string _SupplyAdvice => $"{SupplyAdvice:N0}";
        public string _SupplyAdviceDate => Assistant.DateToDisplayMode(SupplyAdviceDate);
        public string _Value => $"{Value:N0}";
        public string _BondRate => $"{BondRate:G}" + " %";
        public string _IpoFee => $"{IpoFee:G}" + " %";
        public string _MarketMakingFeeFirstYear => $"{MarketMakingFeeFirstYear:G}" + " %";
        public string _MarketMakingFeeOtherYear => $"{MarketMakingFeeOtherYear:G}" + " %";
        public string _InitialCapital => $"{InitialCapital:G}" + " %";
        public string _CouponPeriod => $"{CouponPeriod:N0}"+" " + "ماهه";
        public string _CreateDate => Assistant.DateToDisplayMode(RegDate);
        public string _CreateTime => Assistant.TimeToDisplayMode(RegTime??0);
    }
}