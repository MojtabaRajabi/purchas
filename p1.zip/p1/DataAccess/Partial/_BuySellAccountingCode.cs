﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Sanay.Library.Utility;

namespace Sanay.Lotus.Erm.DataAccess
{
    //public partial class BuySellAccountingCode
    //{
    //    //public string _BuyTotal => $"{BuyTotal.TryParseInt64():N0}";
    //    //public string _BuyFee => $"{BuyFee.TryParseInt64():N0}";
    //    //public string _BuyInterest => $"{BuyInterest.TryParseInt64():N0}";
    //    //public string _BuyTotalAndFee => $"{BuyTotalAndFee.TryParseInt64():N0}";
    //    //public string _SellTotal => $"{SellTotal.TryParseInt64():N0}";
    //    //public string _SellFee => $"{SellFee.TryParseInt64():N0}";
    //    //public string _SellInterest => $"{SellInterest.TryParseInt64():N0}";
    //    //public string _SellTotalAndFee => $"{SellTotalAndFee.TryParseInt64():N0}";

    //} 
}