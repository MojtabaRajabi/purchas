﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Sanay.Library.Utility;

namespace Sanay.Lotus.Erm.DataAccess
{
    public partial class CalculateFundYieldSimplePrice_Result
    {
 
        public string _StartValue => $"{StartValue:N0}" + "";
        public string _EndValue => $"{EndValue:N0}" + "";
        public string _ProtfolioYield => $"{ProtfolioYield:N4}" + "";
        public string _SumBuys => $"{SumBuys:N0}" + "";
        public string _SumProfit => $"{SumProfit:N0}" + "";
        public string _SumSales => $"{SumSales:N0}" + "";
        public string _DatePrice => Assistant.DateToDisplayMode((int)DatePrice);



    }
}