﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sanay.Library.Utility;

namespace Sanay.Lotus.Erm.DataAccess
{
    public partial class CalcPortfolioVarByYield_Result
    {

        public string  _Title { get; set; }

        public string _VaR1 => $"{VaR1:N5}";
        public string _VaR2 => $"{VaR2:N5}";
        public string _VarMonteCarlo => $"{VarMonteCarlo:N5}";












    }
}