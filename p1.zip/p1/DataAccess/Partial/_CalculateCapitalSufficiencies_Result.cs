﻿using Sanay.Library.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sanay.Lotus.Erm.DataAccess
{
    public partial class CalculateCapitalSufficiencies_Result
    {

        public string _MinYearGap => $"{MinYearGap:N0}";
        public string _Val => $"{MinNetInputOutput:N0}";
        public string _MinNetInputOutput => $"{MinNetInputOutputAcc:N0}";
        public string _LastYearGap => $"{LastYearGap:N0}";
        public string _LastNetInputOutput => $"{LastNetInputOutput:N0}";
        public string _LastNetInputOutputAcc => $"{LastNetInputOutputAcc:N0}";
        public string _TotalAdditional => $"{TotalAdditional:N0}";
        public string _TotalDeposit => $"{TotalDeposit:N0}";
        public string _TotalBondIssuances => $"{TotalBondIssuances:N0}";
        public string _TotalBondProfit => $"{TotalBondProfit:N0}";
        public string _SumTotla => $"{SumTotla:N0}";
        public string _Date => Assistant.DateToDisplayMode(Date);
         

    }
}