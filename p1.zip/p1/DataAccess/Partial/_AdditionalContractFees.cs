﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Web.Security;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dic;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Models;
using Sanay.Library.Utility;
namespace Sanay.Lotus.Erm.DataAccess
{
    public partial class AdditionalContractFee
    {
        public string _StartDate => Assistant.DateToDisplayMode(StartDate);
        public string _EndDate => Assistant.DateToDisplayMode(EndDate);
        public int _IsBuyInt => Assistant.BuySellStateInt(IsBuy);
        public string _IsBuy => Assistant.BuySellStateStr(IsBuy);

        public string _Addition => $"{Addition:G}" + " %";
        public string _Redeem => $"{Redeem:N0}";
        public string _TotalValue => $"{TotalValue:N0}"  ;
        public string _NominalValue => $"{NominalValue:G}" + " %";
    
        public string _RegDate => Assistant.DateToDisplayMode(RegDate);
        public string _RegTime => Assistant.TimeToDisplayMode((int)RegTime);



    }
}