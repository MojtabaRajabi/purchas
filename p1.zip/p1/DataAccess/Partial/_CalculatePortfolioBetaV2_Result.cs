﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Sanay.Library.Utility;

namespace Sanay.Lotus.Erm.DataAccess
{
    public partial class CalculatePortfolioBetaV2_Result
    {

   

 
        public string _STDEVH => $"{STDEVH:N4}" + "";
        public string _STDEVC => $"{STDEVC:N4}" + "";
        public string _COV => $"{COV:N4}" + "";
        public string _Beta => $"{Beta:N4}" + "";







    }
}