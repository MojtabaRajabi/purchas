﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sanay.Lotus.Erm.DataAccess.Helper
{
    public partial class LinqHelper
    {
        public bool DeleteFundDividends(Guid id, int fundId)
        {
            try
            {
                var obj = CurrentCtxFund.RemoveFundDividends(id, fundId);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool DeleteFundDeposits(Guid id, int fundId)
        {
            try
            {
                var obj = CurrentCtxFund.RemoveFundDeposits(id, fundId);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool DeleteFundDebt(int id)
        {
            try
            {

                FundBondAsset Code = new FundBondAsset() { Id = id };
                CurrentCtxFund.FundBondAssets.Attach(Code);
                CurrentCtxFund.FundBondAssets.Remove(Code);
                CurrentCtxFund.SaveChanges();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

       



    }
}