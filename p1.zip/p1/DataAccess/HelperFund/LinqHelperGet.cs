﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Ajax.Utilities;
using Sanay.Library.DataAccess;
using Sanay.Lotus.Erm.Lib.Enum;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Core.Objects;
using System.Web.UI.WebControls;
using System.Data.Entity.Migrations;



namespace Sanay.Lotus.Erm.DataAccess.Helper
{
    public partial class LinqHelper
    {


        public Nav GetLastNavByDate(int date, int fundId)
        {
            try
            {
                var objFetch = CurrentCtxFund.Navs.Where(c => c.Date <= date && c.FundId == fundId).OrderByDescending(c => c.Date).ThenByDescending(n => n.Id).FirstOrDefault();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public List<PreviewAutomaticFundDividendsInputOutputFlowCycle_Result> PreviewAutomaticFundDividendsInputOutputFlowCycle(double InterestRate, double Nav, int InterestDate)
        {
            try
            {
                var objFetch = CurrentCtxFund.PreviewAutomaticFundDividendsInputOutputFlowCycle(InterestDate, InterestRate, Nav).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public FundDividend GetFundDividendById(Guid Id)
        {
            try
            {
                var objFetch = CurrentCtxFund.FundDividends.Where(c => c.Id == Id).FirstOrDefault();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<FundDividend> GetFundDividendByFundId(int fId)
        {
            try
            {
                var objFetch = CurrentCtxFund.FundDividends.Where(c => c.FundId == fId).ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetFundInputOutputFlowsByDateFlow_Result> GetFundInputOutputFlowsByDateFlow(int flowDate, int flowType)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetFundInputOutputFlowsByDateFlow(flowDate, flowType).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public List<GetFundInputOutputFlowsFilter_Result> GetFundIOFlowDetails(int startDate, int endDate, int Flow, string tag, int isFuture, int fundId, int startValue, int endValue, int start, int lenght)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetFundInputOutputFlowsFilter(startDate, endDate, Flow, tag, isFuture, fundId, startValue, endValue, start, lenght).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public List<PreviewAutomaticFundDepositsInputOutputFlowCycle_Result> PreviewAutomaticFundDepositsInputOutputFlowCycle(double rate, double deposit, double Blocked, int payDate, int StartDate, int MaturityDate)
        {
            try
            {
                var objFetch = CurrentCtxFund.PreviewAutomaticFundDepositsInputOutputFlowCycle(StartDate, MaturityDate, payDate, deposit, rate, deposit).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<FundDeposit> GetFundDeposits()
        {
            try
            {
                var objFetch = CurrentCtxFund.FundDeposits.ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public FundDeposit GetFundDepositsById(Guid Id)
        {
            try
            {
                var objFetch = CurrentCtxFund.FundDeposits.Where(c => c.Id == Id).FirstOrDefault();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public List<FundDeposit> GetFundDepositsByFundId(int fId)
        {
            try
            {
                var objFetch = CurrentCtxFund.FundDeposits.Where(c => c.FundId == fId).ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetLastFundPortfolios_Result> GetLastFundPortfolios(int fId)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetLastFundPortfolios(fId).ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetLastFundPortfoliosByDate_Result> GetLastFundPortfoliosByDate(int fId, int Date)
        {
            try
            {
                CurrentCtxDbo.Database.CommandTimeout = 6000;

                var objFetch = CurrentCtxFund.GetLastFundPortfoliosByDate(fId, Date).ToList();

                return objFetch; 
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<CalculatePortfolioYieldForVaRRawDataSymbols_Result> CalculatePortfolioYieldForVaRRawDataSymbols(int StartDate, int EndDate, int FundId, int Interval)
        {
            try
            {
                CurrentCtxDbo.Database.CommandTimeout = 6000;
                var objFetch = CurrentCtxRisk.CalculatePortfolioYieldForVaRRawDataSymbols(StartDate, EndDate, FundId, Interval).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<CalculatePortfolioYieldForVaRRawDataSymbolWeight_Result> CalculatePortfolioYieldForVaRRawDataSymbolWeight(int StartDate, int EndDate, int FundId, int Interval)
        {
            try
            {
                CurrentCtxDbo.Database.CommandTimeout = 6000;
                var objFetch = CurrentCtxRisk.CalculatePortfolioYieldForVaRRawDataSymbolWeight(StartDate, EndDate, FundId, Interval).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<CalculatePortfolioYieldForVaRRawDataDailyRet_Result> CalculatePortfolioYieldForVaRRawDataDailyRet(int StartDate, int EndDate, int FundId, int Interval)
        {
            try
            {
                CurrentCtxDbo.Database.CommandTimeout = 6000;
                var objFetch = CurrentCtxRisk.CalculatePortfolioYieldForVaRRawDataDailyRet(StartDate, EndDate, FundId, Interval).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<CalculatePortfolioYieldForVaR_Result> CalculatePortfolioYieldForVaR(int StartDate, int EndDate, int FundId, int Interval)
        {
            try
            {
                CurrentCtxDbo.Database.CommandTimeout = 6000;
                var objFetch = CurrentCtxRisk.CalculatePortfolioYieldForVaR(StartDate, EndDate, FundId, Interval).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }





        public List<GetLotusFundList_Result> GetLotusFundList()
        {
            try
            {
                CurrentCtxDbo.Database.CommandTimeout = 120000;

                var objFetch = CurrentCtxFund.GetLotusFundList().ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }






        //public List<string> GetFundPortfoliosInstrumentType()
        //{
        //    try
        //    {
        //        var objFetch = CurrentCtxFund.FundPortfolios.Select(c => c.InstrumentTypeTitle).Distinct().OrderBy(c => c).ToList();

        //        return objFetch;
        //    }
        //    catch (Exception ex)
        //    {
        //        return null;
        //    }
        //}
        public List<string> GetFundPortfoliosSymbols()
        {
            try
            {
                var objFetch = CurrentCtxFund.FundPortfolios.Select(c => c.Instrument).Distinct().OrderBy(c => c).ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<Fund> getFundlist()
        {
            try
            {
                var objFetch = CurrentCtxFund.Funds.ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<FundPortfolio> GetFundPortfoliosById(int fId)
        {
            try
            {
                var objFetch = CurrentCtxFund.FundPortfolios.Where(c => c.FundId == fId).ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetLastFundPortfoliosByDate_Result> GetFundPortfoliosByDate(int fId, int date)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetLastFundPortfoliosByDate(fId, date).ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<OrderStatistic> GetOrderStatisticsById(int fId)
        {
            try
            {
                var objFetch = CurrentCtxFund.OrderStatistics.Where(c => c.FundId == fId).ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public List<Nav> GetNavsByDateId(int fId, int date)
        {
            try
            {
                var objFetch = CurrentCtxFund.Navs.Where(c => c.FundId == fId && c.Date == date).ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<Nav> GetNavsById(int fId)
        {
            try
            {
                var objFetch = CurrentCtxFund.Navs.Where(c => c.FundId == fId).ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetLatestFunds_Result> GetLatestFunds(int minRow, int lenght,int PDate)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetLatestFunds(PDate,minRow, lenght).ToList();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<FundIndustry> GetFundIndustries(int startDate, int endDate, int fundId)
        {
            try
            {
                var objFetch = CurrentCtxFund.FundIndustries.Where(c => c.RegDate >= startDate && c.RegDate <= endDate && c.FundId == fundId).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetFundIndustrieTypsFunds_Result> GetFundIndustrieTypsFunds(string fundsId)
        {
            try
            {
                return CurrentCtxFund.GetFundIndustrieTypsFunds(fundsId).ToList();
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<FundMixAsset> GetFundMixAsset(int startDate, int endDate, int fundId)
        {
            try
            {
                return CurrentCtxFund.FundMixAssets.Where(c => c.JalaliDate >= startDate && c.JalaliDate <= endDate && c.FundId == fundId).ToList();
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<FundYtm> GetFundYtms(int startDate, int endDate, int fundId)
        {
            try
            {
                return CurrentCtxFund.FundYtms.Where(c => c.JalaliDate >= startDate && c.JalaliDate <= endDate && c.FundId == fundId).ToList();
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public FundSell GetFundSellById(Guid id)
        {
            try
            {
                return CurrentCtxDbo.FundSells.FirstOrDefault(t => t.Id == id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetMajorShareHoldersByIsin_Result> GetMajorShareHolderByIsin(string isin)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetMajorShareHoldersByIsin(isin).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<FundBondAsset> GetFundBondAsset(int FundId)
        {
            try
            {
                var objFetch = CurrentCtxFund.FundBondAssets.Where(x => x.FundId == FundId).ToList();
                //List<GetEtemadFunds_Result> objFetchSorted = new List<GetEtemadFunds_Result>();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public bool AddContractFlow(int id)
        {
            try
            {

                CurrentCtxFund.UpdateFundContractFlow(id);
                CurrentCtxFund.SaveChanges();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool UpdateContracts(Service obj)
        {
            try
            {
                CurrentCtxUserLog.Services.AddOrUpdate(obj);
                CurrentCtxUserLog.SaveChanges();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool UpdateAssetClass(AssetClass obj)
        {
            try
            {
                CurrentCtxRisk.AssetClasses.AddOrUpdate(obj);
                CurrentCtxRisk.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }




        public List<GetFundIndustriesByFundId_Result> GetFundIndustriesByFundId(int Id)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetFundIndustriesByFundId(Id).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetFundMixAssetsByFundId_Result> GetFundMixAssetsByFundId(int Id)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetFundMixAssetsByFundId(Id).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetFundById_Result> GetFundDataByFundId(int Id)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetFundById(Id).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetFundPropertiesByDate_Result> getFundsCompareChart(int startDate, int endDate, int fundId)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetFundPropertiesByDate(fundId, startDate, endDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }





        public List<GetMajorSymbolsByFundId_Result> GetFundSymbolsByFundId(int Id, int date)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetMajorSymbolsByFundId(Id, date).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<GetFundPropertiesByFundId_Result> GetFundPropertiesByFundId(int Id)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetFundPropertiesByFundId(Id).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<Company> GetCoSymbols()
        {
            try
            {
                var objFetch = CurrentCtxRisk.Companies.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetCompanies_Result> GetMainCoSymbols()
        {
            try
            {
                var objFetch = CurrentCtxRisk.GetCompanies().ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public FundPortfolio GetlastFundPortfolio()
        {
            try
            {
                var objFetch = CurrentCtxFund.FundPortfolios.OrderByDescending(s => s.PDate).FirstOrDefault(); ;
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }





        public List<Company> GetCoSymbolsGroups()
        {
            try
            {
                var objFetch = CurrentCtxRisk.Companies.ToList().GroupBy(x => x.GroupName).Select(y => y.First()).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public List<InputOutputFlowsSource> GetTagSources()
        {
            try
            {
                var objFetch = CurrentCtxDbo.InputOutputFlowsSources.ToList().ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<FundContract> GetFundCategory()
        {
            try
            {
                var objFetch = CurrentCtxFund.FundContracts.ToList().GroupBy(x => x.CategoryName).Select(y => y.First()).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<Fund> GetFundInvestorOrdersFunds()
        {
            try
            {
                var objFetch = CurrentCtxFund.Funds.ToList().GroupBy(x => x.Id).Select(y => y.First()).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public List<FundInvestorOrder> GetFundInvestorOrdersType()
        {
            try
            {
                var objFetch = CurrentCtxFund.FundInvestorOrders.ToList().GroupBy(x => x.TypeId).Select(y => y.First()).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<FundContract> GetFundContractState()
        {
            try
            {
                var objFetch = CurrentCtxFund.FundContracts.ToList().GroupBy(x => x.ContractState).Select(y => y.First()).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<FundContract> GetFundContractSector()
        {
            try
            {
                var objFetch = CurrentCtxFund.FundContracts.ToList().GroupBy(x => x.ContractSector).Select(y => y.First()).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<FundContract> GetFundContractType()
        {
            try
            {
                var objFetch = CurrentCtxFund.FundContracts.ToList().GroupBy(x => x.ContractType).Select(y => y.First()).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<Company> GetCoSymbolsIndustry()
        {
            try
            {
                var objFetch = CurrentCtxRisk.Companies.ToList().GroupBy(x => x.IndustryName).Select(y => y.First()).ToList(); ;
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<Company> GetCoMarket()
        {
            try
            {
                var objFetch = CurrentCtxRisk.Companies.ToList().GroupBy(x => x.MarketName).Select(y => y.First()).ToList(); ;
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }





        public List<Company> GetGroupAndIndustryBySymbol(int SymbolCoId)
        {
            try
            {

                var gId = CurrentCtxRisk.Companies.Where(x => x.CoID == SymbolCoId).ToList();

                return gId;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<Company> GetIndustryBySymbol(string SymbolName)
        {
            try
            {
                var gId = CurrentCtxRisk.Companies.Where(x => x.CoName == SymbolName).FirstOrDefault();



                var objFetch = CurrentCtxRisk.Companies.Where(x => x.IndustryID == gId.IndustryID).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetCompanies_Result> GetSimilarSymbols(int SymbolGroup, int SymbolIndustry)
        {
            try
            {

                var objFetch = CurrentCtxRisk.GetCompanies().Where(x =>
                                                             (x.GroupID == SymbolGroup || SymbolGroup == -1)
                                                          && (x.IndustryID == SymbolIndustry || SymbolIndustry == -1)
                                                             ).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public string GetFundsName(int id)
        {
            try
            {
                var objFetch = CurrentCtxFund.Funds.Where(c => c.Id == id).FirstOrDefault().Name;
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<Fund> GetFunds()
        {
            try
            {
                var objFetch = CurrentCtxFund.Funds.OrderBy(c => c.Id).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public GetFundByName_Result GetFundIdByFundName(string fundName)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetFundByName(fundName).FirstOrDefault();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetFundPropertiesByDate_Result> GetFundNAVs(int fundId,int startDate,int endDate)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetFundPropertiesByDate(fundId,startDate,endDate).OrderByDescending(c => c.JalaliDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public List<CheckFundData_Result> CheckFundData(int Pdate)
        {
            try
            {
                var objFetch = CurrentCtxDbo.CheckFundData(Pdate).OrderBy(c => c.FundType).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetFundsMarketCapitalTurnover_Result> GetFundsMarketCapitalTurnover(int startDate, int endDate,string FundType)
        {
            try
            {
                //-------------------------
                var objFetch = CurrentCtxFund.GetFundsMarketCapitalTurnover(startDate, endDate,FundType).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        public List<GetFundsManagerCapitalTurnover_Result> GetFundsManagerCapitalTurnover(int startDate, int endDate, string manager)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetFundsManagerCapitalTurnover(startDate, endDate, manager).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

   public List<GetFundsCapitalTurnoverFundDetailes_Result> GetFundsCapitalTurnoverFundDetailes(int startDate, int endDate, string manager)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetFundsCapitalTurnoverFundDetailes(startDate, endDate, manager).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetContractDetailDebtTrading_Result> LoadContractDetailDebtTrading(int Id)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetContractDetailDebtTrading(Id).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<GetContractDetailDebtReception_Result> LoadContractDetailDebtReception(int Id)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetContractDetailDebtReception(Id).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetContractDetailReception_Result> LoadContractDetailReception(int Id)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetContractDetailReception(Id).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetContractDetailPurchaseOfServices_Result> LoadContractDetailPurchaseOfServices(int Id)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetContractDetailPurchaseOfServices(Id).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetContractDetailCapitalIncreaseSupplyAdvice_Result> GetContractDetailCapitalIncreaseSupplyAdvice(int Id)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetContractDetailCapitalIncreaseSupplyAdvice(Id).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<CheckData_Result> LoadDataAnalysis(int Date)
        {
            try
            {
                var objFetch = CurrentCtxDbo.CheckData(Date).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<GetContractDetailAdvice_Result> LoadContractDetailAdvice(int Id)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetContractDetailAdvice(Id).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public List<GetContractDetailAdviceFinancialServices_Result> ContractDetailAdviceFinancialServices(int Id)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetContractDetailAdviceFinancialServices(Id).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<GetContractDetailDebtBuySells_Result> LoadContractDetailDebtBuySell(int Id)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetContractDetailDebtBuySells(Id).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetContractDetailValuations_Result> LoadContractDetailValuations(int Id)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetContractDetailValuations(Id).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetFundContracts_Result> GetFundContracts(int CategoryId, string ContractType, string ContractState, string ContractSector)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetFundContracts(CategoryId, ContractType, ContractState, ContractSector).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<FundPayment> GetFundPayments(int Id)
        {
            try
            {
                var objFetch = CurrentCtxFund.FundPayments.Where(c => c.ContractId == Id).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<FundCorrectiveComment> GetFundCorrectiveComments(int Id)
        {
            try
            {
                var objFetch = CurrentCtxFund.FundCorrectiveComments.Where(c => c.ContractId == Id).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<GetFundInvestorOrdersById_Result> GetFundInvestorOrdersById(int Fund, int FundType, int StartDate, int EndDate)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetFundInvestorOrdersById(Fund, FundType, StartDate, EndDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }






        public List<Fund> GetFunds(string FundType)
        {
            try
            {
                var objFetch = CurrentCtxFund.Funds.Where(c => (FundType == "%%" || c.FundType == FundType)).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetAllFunds_Result> GetFunds(string Name, string Manager, string Guaranteer, string Owner, string FundType, string sortColumn, string sortColumnDir)
        {
            try
            {
                List<GetAllFunds_Result> sortedList = new List<GetAllFunds_Result>();
                var objFetch = CurrentCtxFund.GetAllFunds().Where(c => (Name == "%%" || c.Name == Name)
                                                       && (Manager == "%%" || c.Manager == Manager)
                                                       && (Guaranteer == "%%" || c.Guaranteer == Guaranteer)
                                                       && (Owner == "%%" || c.Owner == Owner)
                                                       && (FundType == "%%" || c.FundType == FundType)).ToList();
                //var objFetch = CurrentCtx.GetTalaFunds(nationalId, Name, startDate, endDate, 0, int.MaxValue).ToList();
                //List<GetEtemadFunds_Result> objFetchSorted = new List<GetEtemadFunds_Result>();
                if (sortColumnDir == "asc")
                {
                    if (sortColumn == "Id") { sortedList = objFetch.OrderBy(s => s.Id).ToList(); }
                    else if (sortColumn == "Name") { sortedList = objFetch.OrderBy(s => s.Name).ToList(); }
                    else if (sortColumn == "Manager") { sortedList = objFetch.OrderBy(s => s.Manager).ToList(); }
                    else if (sortColumn == "Guaranteer") { sortedList = objFetch.OrderBy(s => s.Guaranteer).ToList(); }
                    else if (sortColumn == "Owner") { sortedList = objFetch.OrderBy(s => s.Owner).ToList(); }
                    else if (sortColumn == "FundType") { sortedList = objFetch.OrderBy(s => s.FundType).ToList(); }
                    else if (sortColumn == "Type") { sortedList = objFetch.OrderBy(s => s.Type).ToList(); }
                    else if (sortColumn == "NAV") { sortedList = objFetch.OrderBy(s => s.NAV).ToList(); }
                    else sortedList = objFetch.OrderBy(s => s.Url).ToList();
                }
                else
                {
                    if (sortColumn == "Id") { sortedList = objFetch.OrderByDescending(s => s.Id).ToList(); }
                    else if (sortColumn == "Name") { sortedList = objFetch.OrderByDescending(s => s.Name).ToList(); }
                    else if (sortColumn == "Manager") { sortedList = objFetch.OrderByDescending(s => s.Manager).ToList(); }
                    else if (sortColumn == "Guaranteer") { sortedList = objFetch.OrderByDescending(s => s.Guaranteer).ToList(); }
                    else if (sortColumn == "Owner") { sortedList = objFetch.OrderByDescending(s => s.Owner).ToList(); }
                    else if (sortColumn == "FundType") { sortedList = objFetch.OrderByDescending(s => s.FundType).ToList(); }
                    else if (sortColumn == "Type") { sortedList = objFetch.OrderByDescending(s => s.Type).ToList(); }
                    else if (sortColumn == "NAV") { sortedList = objFetch.OrderByDescending(s => s.NAV).ToList(); }
                    else sortedList = objFetch.OrderByDescending(s => s.Url).ToList();
                }
                return sortedList;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<string> GetLastMajorShareHolders()
        {
            try
            {
                var objFetch = CurrentCtxFund.GetLastMajorShareHolders().ToList();
                //List<GetEtemadFunds_Result> objFetchSorted = new List<GetEtemadFunds_Result>();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    

        public List<string> GetLastMajorShareHoldersRisk()
        {
            try
            {
                var objFetch = CurrentCtxFund.GetLastMajorShareHoldersRisk().ToList();
                //List<GetEtemadFunds_Result> objFetchSorted = new List<GetEtemadFunds_Result>();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetLastMajorShareHoldersDebt_Result> GetLastMajorShareHoldersDebt()
        {
            try
            {
                var objFetch = CurrentCtxFund.GetLastMajorShareHoldersDebt().ToList();
                //List<GetEtemadFunds_Result> objFetchSorted = new List<GetEtemadFunds_Result>();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }







    }
}