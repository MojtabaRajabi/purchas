﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sanay.Lotus.Erm.Models;
using System.Data.Entity.Migrations;


namespace Sanay.Lotus.Erm.DataAccess.Helper
{
    public partial class LinqHelper
    {
        public void AutomaticDividendsFundIOFlowCycle(Guid id, int fundId)
        {
            try
            {
                CurrentCtxFund.AutomaticDividendsFundIOFlowCycle(id, fundId);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public Guid InsertFundDividends(FundDividend obj)
        {
            try
            {
                obj.Id = Guid.NewGuid();
                CurrentCtxFund.FundDividends.Add(obj);
                CurrentCtxFund.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public void AutomaticDepositsFundIOFlowCycle(Guid id, int fundId)
        {
            try
            {
                CurrentCtxFund.AutomaticDepositsFundIOFlowCycle(id, fundId);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public Guid InsertFundDeposits(FundDeposit obj)
        {
            try
            {
                obj.Id = Guid.NewGuid();
                CurrentCtxFund.FundDeposits.Add(obj);
                CurrentCtxFund.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }
        public bool InsertFundBondAssets(FundBondAsset obj)
        {
            try
            {
                CurrentCtxFund.FundBondAssets.Add(obj);
                CurrentCtxFund.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                throw;
            }

        }


    }
}