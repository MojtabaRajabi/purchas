﻿using System;
using System.Linq;
using System.Web;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.Models;
using System.Data.Entity.Migrations;
using Sanay.Lotus.Erm.Lib.Enum;

namespace Sanay.Lotus.Erm.DataAccess.Helper
{
    public partial class LinqHelper : System.Web.UI.Page
    {

        public static ERMEntitiesDbo CurrentCtxDbo
        {
            get
            {
                try
                {
                    var ctx = HttpContext.Current.Items["CtxPerRequestDbo"] as ERMEntitiesDbo;
                    
                    return ctx ?? new ERMEntitiesDbo();
                }
                catch
                {
                    return new ERMEntitiesDbo();
                }
            }
        }



        public bool Delete_Code(int id)
        {
            try
            {

                BuySellAccountingCode Code = new BuySellAccountingCode() { Id = id };
                CurrentCtxDbo.BuySellAccountingCodes.Attach(Code);
                CurrentCtxDbo.BuySellAccountingCodes.Remove(Code);
                CurrentCtxDbo.SaveChanges();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool DeleteAdditionalContractFee(Guid id)
        {
            try
            {
               var obj= CurrentCtxDbo.AdditionalContractFees.FirstOrDefault(t => t.Id == id);
                if (obj.IsBuy == true)
                {
                    RemoveAdditionalContractFeesBuy(obj.Id);
                }
                else
                {
                    RemoveAdditionalContractFeesSell(obj.Id);
                }
                //CurrentCtx.AdditionalContractFees.Attach(AdditionalContractFee);
                //CurrentCtx.AdditionalContractFees.Remove(AdditionalContractFee);
                //CurrentCtx.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool DeleteFundBuySellShares(Guid id)
        {
            try
            {
                var obj = CurrentCtxFund.FundBuySellShares.FirstOrDefault(t => t.Id == id);

                if (obj.IsBuy == true)
                {
                    RemoveFundBuySellSharesBuy(obj.Id);
                }
                else
                {
                    RemoveFundBuySellSharesSell(obj.Id);
                }



                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public bool DeleteFundSharesProfits(Guid id)
        {
            try
            {
                var obj = CurrentCtxFund.FundSharesProfits.FirstOrDefault(t => t.Id == id);
                RemoveFundSharesProfit(obj.Id, 1);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }






        public bool Delete_CapitalSufficiencies(int id)
        {
            try
            {

                CapitalSufficiency Capitalsufficiency = new CapitalSufficiency() { Id = id };
                CurrentCtxDbo.CapitalSufficiencies.Attach(Capitalsufficiency);
                CurrentCtxDbo.CapitalSufficiencies.Remove(Capitalsufficiency);
                CurrentCtxDbo.SaveChanges();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }



        public bool DeleteDeposit(Guid id)
        {
            try
            {

                var obj = CurrentCtxDbo.RemoveDeposits(id);

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        
        public bool DeleteInflowsLowOccurrence(Guid id)
        {
            try
            {

                var obj = CurrentCtxDbo.RemoveInflowsLowOccurrence(id);

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool DeleteOtherFundUnit(int id)
        {
            try
            {

                OtherFundUnit OtherFundUnit = new OtherFundUnit() { Id = id };
                CurrentCtxDbo.OtherFundUnits.Attach(OtherFundUnit);
                CurrentCtxDbo.OtherFundUnits.Remove(OtherFundUnit);
                CurrentCtxDbo.SaveChanges();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }



        public bool DeleteIOFlowFunds(Guid id)
        {
            try
            {

                var obj = CurrentCtxDbo.RemoveIOFlowFund(id);

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }





        public bool DeleteDebtSymbol(int id)
        {
            try
            {
                var obj = CurrentCtxDebt.DeleteSymbol(id);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool DeleteDebtBondSymbol(Guid id)
        {
            try
            {
                var obj = CurrentCtxDbo.RemoveDebtBonds(id);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool DeleteFundDebtBondSymbol(Guid id,int fundId)
        {
            try
            {
                var obj = CurrentCtxFund.RemoveFundDebtBonds(id, fundId);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }




        public bool DeletePositionPoint(int id)
        {
            try
            {
                Position pos = new Position() { Id = id };
                CurrentCtxDbo.Positions.Attach(pos);
                CurrentCtxDbo.Positions.Remove(pos);
                CurrentCtxDbo.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }


        public bool DeleteCurrentTaxAndCosts(Guid id)
        {
            try
            {
                var obj = CurrentCtxDbo.RemoveCurrentTaxAndCosts(id);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool DeleteFundSell(Guid id)
        {
            try
            {
                var obj = CurrentCtxDbo.RemoveFundSells(id);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }




        public bool DeleteBondIssuances(Guid id)
        {
            try
            {
                var obj = CurrentCtxDbo.RemoveBondIssuances(id);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool DeleteFutureDebtBonds(Guid id)
        {
            try
            {
                var obj = CurrentCtxDbo.RemoveFutureDebtBonds(id);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }


        public bool DeleteCapitalBonds(Guid id)
        {
            try
            {
                var obj = CurrentCtxDbo.RemoveCapitalBonds(id);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }


        public bool RemoveManualFlowsCapitalIncreases(Guid id)
        {
            try
            {
                var obj = CurrentCtxDbo.RemoveManualFlowsCapitalIncreases(id);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }


        public bool RemoveAdditionalContractFeesBuy(Guid id)
        {
            try
            {
                var obj = CurrentCtxDbo.RemoveAdditionalContractFeesBuy(id);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool RemoveAdditionalContractFeesSell(Guid id)
        {
            try
            {
                var obj = CurrentCtxDbo.RemoveAdditionalContractFeesSell(id);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }


        public bool RemoveFundBuySellSharesSell(Guid id)
        {
            try
            {
                var obj = CurrentCtxFund.RemoveFundBuySellSharesSell(id);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool RemoveFundBuySellSharesBuy(Guid id)
        {
            try
            {
                var obj = CurrentCtxFund.RemoveFundBuySellSharesBuy(id);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool RemoveFundSharesProfit(Guid id,int FundId)
        {
            try
            {
                var obj = CurrentCtxFund.RemoveFundSharesProfit(id, FundId);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool RemoveManualFlowsOutputCosts(Guid id)
        {
            try
            {
                var obj = CurrentCtxDbo.RemoveManualFlowsOutputCosts(id);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }


      

        public bool DeleteSymbol(int id)
        {
            try
            {

                BuySellsSymbol Code = new BuySellsSymbol() { Id = id };
                CurrentCtxDbo.BuySellsSymbols.Attach(Code);
                CurrentCtxDbo.BuySellsSymbols.Remove(Code);
                CurrentCtxDbo.SaveChanges();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }


        public bool DeleteManualFlows(Guid id)
        {
            try
            {
                var obj = CurrentCtxDbo.ManualFlows.FirstOrDefault(c => c.Id == id);
                if (obj != null)
                {
                    switch (obj.TypeId)
                    {
                        case (int)ManualFlowType.CapitalIncreases:
                            RemoveManualFlowsCapitalIncreases(obj.Id);
                            break;
                        case (int)ManualFlowType.OutputCosts:
                            RemoveManualFlowsOutputCosts(obj.Id);
                            break;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool DeleteBroker(int id)
        {
            try
            {

                BuySellsBroker Code = new BuySellsBroker() { Id = id };
                CurrentCtxDbo.BuySellsBrokers.Attach(Code);
                CurrentCtxDbo.BuySellsBrokers.Remove(Code);
                CurrentCtxDbo.SaveChanges();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }


        public void UpdateCode(BuySellAccountingCode objacc)
        {
            try
            {

                BuySellAccountingCode Code = new BuySellAccountingCode() { Id = objacc.Id };
                Code = objacc;
                CurrentCtxDbo.SaveChanges();
            }
            catch (Exception ex)
            {
            }
        }

        public void UpdateManualFlow(ManualFlow obj)
        {
            try
            {
                CurrentCtxDbo.ManualFlows.AddOrUpdate(obj);
                CurrentCtxDbo.SaveChanges();
            }
            catch (Exception ex)
            {
            }
        }

        public void UpdateOtherFundUnit(OtherFundUnit obj)
        {
            try
            {
                CurrentCtxDbo.OtherFundUnits.AddOrUpdate(obj);
                CurrentCtxDbo.SaveChanges();
            }
            catch (Exception ex)
            {
            }
        }




        public bool DeleteIOFlow(int startDate, int endDate, int flowType)
        {
            try
            {

                CurrentCtxDbo.RemoveInputOutputFlow(startDate, endDate, flowType);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }


        public bool DeleteContractFlowByTag(int contractId)
        {
            try
            {
                var obj = CurrentCtxDbo.RemoveContractFlowByTag(contractId);
                CurrentCtxFund.UpdateFundContractIsReg(contractId, 0);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }





    }
}