﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sanay.Lotus.Erm.Models;
using System.Data.Entity.Migrations;


namespace Sanay.Lotus.Erm.DataAccess.Helper
{
    public partial class LinqHelper
    {
      

        public int InsertBuySellAccountingCode(BuySellAccountingCode obj)
        {
            try
            {
                CurrentCtxDbo.BuySellAccountingCodes.Add(obj);
                CurrentCtxDbo.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public Guid InsertFutureDebtBond(FutureDebtBond obj)
        {
            try
            {
                obj.Id = Guid.NewGuid();
                CurrentCtxDbo.FutureDebtBonds.Add(obj);
                CurrentCtxDbo.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public Guid InsertCapitalBond(CapitalBond obj)
        {
            try
            {
                obj.Id = Guid.NewGuid();
                CurrentCtxDbo.CapitalBonds.Add(obj);
                CurrentCtxDbo.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public Guid InsertBondIssuance(BondIssuance obj)
        {
            try
            {
                obj.Id = Guid.NewGuid();
                CurrentCtxDbo.BondIssuances.Add(obj);
                CurrentCtxDbo.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        public Guid InsertAdditionalContractFee(AdditionalContractFee obj)
        {
            try
            {
                obj.Id = Guid.NewGuid();
                CurrentCtxDbo.AdditionalContractFees.Add(obj);
                CurrentCtxDbo.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public Guid InsertFundBuySellShares(FundBuySellShare obj)
        {
            try
            {
                obj.Id = Guid.NewGuid();
                CurrentCtxFund.FundBuySellShares.Add(obj);
                CurrentCtxFund.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }

          public Guid InsertFundSharesProfits(FundSharesProfit obj)
        {
            try
            {
                obj.Id = Guid.NewGuid();
                CurrentCtxFund.FundSharesProfits.Add(obj);
                CurrentCtxFund.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }





        public int InsertCapitalsufficiency(CapitalSufficiency obj)
        {
            try
            {
                CurrentCtxDbo.CapitalSufficiencies.Add(obj);
                CurrentCtxDbo.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public Guid InsertDeposit(Deposit obj)
        {
            try
            {
                obj.Id = Guid.NewGuid();
                CurrentCtxDbo.Deposits.Add(obj);
                CurrentCtxDbo.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }
        

        public Guid InsertInflowsLowOccurrence(InflowsLowOccurrence obj)
        {
            try
            {
                obj.Id = Guid.NewGuid();
                CurrentCtxDbo.InflowsLowOccurrences.Add(obj);
                CurrentCtxDbo.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }



        public int InsertOtherFundUnit(OtherFundUnit obj)
        {
            try
            {
                
                CurrentCtxDbo.OtherFundUnits.Add(obj);
                CurrentCtxDbo.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }



        public Guid InsertIOFlowFund(IOFlowFund obj)
        {
            try
            {
                obj.Id = Guid.NewGuid();
                CurrentCtxDbo.IOFlowFunds.Add(obj);
                CurrentCtxDbo.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        public void AutoGenerateDeposit(Guid id)
        {
            try
            {
                CurrentCtxDbo.AutomaticDepositsInputOutputFlowCycle(id);
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public void AutoGenerateInflowsLowOccurrence(Guid id)
        {
            try
            {
                CurrentCtxDbo.AutomaticInflowsLowOccurrenceInputOutputFlow(id);
            }
            catch (Exception ex)
            {
                throw;
            }

        }







        public void AutoGenerateIOFlowFund(Guid id)
        {
            try
            {
                CurrentCtxDbo.AutomaticIOFlowFundInputOutputFlow(id);
            }
            catch (Exception ex)
            {
                throw;
            }

        }



        public void AutoGenerateDebtBonds(Guid id)
        {
            try
            {
                CurrentCtxDbo.AutomaticDebtBondsInputOutputFlowCycle(id);
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        public void AutoGeneratePositionDebtBonds(int startDate, int endDate)
        {
            try
            {
                CurrentCtxDbo.InsertDebtInterestFlow(startDate, endDate);
            }
            catch (Exception ex)
            {
                throw;
            }

        }





        public void AutoGenerateFundDebtBonds(Guid id,int fundId)
        {
            try
            {
                CurrentCtxFund.AutomaticDebtBondFundIOFlowCycle(id,fundId);
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        public void AutomaticTaxAndInsuranceInputOutputFlowCycle(Guid id)
        {
            try
            {
                CurrentCtxDbo.AutomaticTaxAndInsuranceInputOutputFlowCycle(id);
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public void AutomaticBondIssuancesInputOutputFlow(Guid id)
        {
            try
            {
                CurrentCtxDbo.AutomaticBondIssuancesInputOutputFlow(id);
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public void AutomaticAdditionalContractFeesBuyInputOutputFlow(Guid id)
        {
            try
            {
                CurrentCtxDbo.AutomaticAdditionalContractFeesBuyInputOutputFlow(id);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void AutomaticAdditionalContractFeesSellInputOutputFlow(Guid id)
        {
            try
            {
                CurrentCtxDbo.AutomaticAdditionalContractFeesSellInputOutputFlow(id);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void AutomaticBuySharesFundIOFlow(Guid id, int fundId)
        {
            try
            {
                CurrentCtxFund.AutomaticBuySharesFundIOFlow(id, fundId);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void AutomaticSharesProfitFundIOFlow(Guid id, int fundId)
        {
            try
            {
                CurrentCtxFund.AutomaticSharesProfitFundIOFlow(id, fundId);
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public void AutomaticSellSharesFundIOFlow(Guid id,int fundId)
        {
            try
            {
                CurrentCtxFund.AutomaticSellSharesFundIOFlow(id,fundId);
            }
            catch (Exception ex)
            {
                throw;
            }
        }




        public void AutomaticFutureDebtBondsInputOutputFlow(Guid id)
        {
            try
            {
                CurrentCtxDbo.AutomaticFutureDebtBondsInputOutputFlow(id);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void AutomaticCapitalBondsInputOutputFlow(Guid id)
        {
            try
            {
                CurrentCtxDbo.AutomaticCapitalBondsInputOutputFlow(id);
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public void AutomaticManualFlowsCapitalIncreasesInputOutputFlow(Guid id)
        {
            try
            {
                CurrentCtxDbo.AutomaticManualFlowsCapitalIncreasesInputOutputFlow(id);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void AutomaticManualFlowsOutputCostsInputOutputFlow(Guid id)
        {
            try
            {
                CurrentCtxDbo.AutomaticManualFlowsOutputCostsInputOutputFlow(id);
            }
            catch (Exception ex)
            {
                throw;
            }
        }



        public Guid InsertDebtBonds(DebtBond obj)
        {
            try
            {
                obj.Id = Guid.NewGuid();
                CurrentCtxDbo.DebtBonds.Add(obj);
                CurrentCtxDbo.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public Guid InserFundtDebtBonds(FundDebtBond obj)
        {
            try
            {
                obj.Id = Guid.NewGuid();
                CurrentCtxFund.FundDebtBonds.Add(obj);
                CurrentCtxFund.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }
        }




        public Guid InsertCurrentTaxAndCost(CurrentTaxAndCost obj)
        {
            try
            {
                obj.Id = Guid.NewGuid();
                CurrentCtxDbo.CurrentTaxAndCosts.Add(obj);
                CurrentCtxDbo.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
         


        public void AutomaticFundSellInputOutputFlow(Guid id)
        {
            try
            {
                CurrentCtxDbo.AutomaticFundSellsInputOutputFlow(id);
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        public Guid InsertFundSell(FundSell obj)
        {
            try
            {
                obj.Id = Guid.NewGuid();
                CurrentCtxDbo.FundSells.Add(obj);
                CurrentCtxDbo.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }
        }



     




        public int InsertBroker(BuySellsBroker obj)
        {
            try
            {
                CurrentCtxDbo.BuySellsBrokers.Add(obj);
                CurrentCtxDbo.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public Guid InsertManualFlow(ManualFlow obj)
        {
            try
            {
                obj.Id = Guid.NewGuid();
                CurrentCtxDbo.ManualFlows.Add(obj);
                CurrentCtxDbo.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public int InsertSymbol(BuySellsSymbol obj)
        {
            try
            {
                CurrentCtxDbo.BuySellsSymbols.Add(obj);
                CurrentCtxDbo.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        public int InsertInputOutputFlow(DataAccess.InputOutputFlow obj)
        {
            try
            {
                CurrentCtxDbo.InputOutputFlows.Add(obj);
                CurrentCtxDbo.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public int InsertCapitalSufficiency(CapitalSufficiency obj)
        {
            try
            {
                CurrentCtxDbo.CapitalSufficiencies.Add(obj);
                CurrentCtxDbo.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }


  
    
 

  




        public int InsertPosition(Position obj)
        {
            try
            {
                //CurrentCtx.Positions.Add(obj);
                CurrentCtxDbo.InsertPosition(obj.Symbol, obj.Account,
                    obj.Date,
                    obj.ActionId,
                    obj.ParentId,
                    obj.Num,
                    obj.ClosingPrice,
                    obj.Interest,
                    obj.AvgPrice,
                    obj.Fee,
                    obj.Profit,
                    obj.GuaranteedProfitEarned,
                    obj.GuaranteedEarning,
                    obj.PrincipalAmount
                    );

                CurrentCtxDbo.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public int InsertPosition(DataAccess.File obj)
        {
            try
            {
                CurrentCtxDbo.Files.AddOrUpdate(obj);
                CurrentCtxDbo.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        public int InsertInputOutputFlowGenerate(DataAccess.InputOutputFlowGenerate obj)
        {
            try
            {
                CurrentCtxDbo.InputOutputFlowGenerates.AddOrUpdate(obj);
                CurrentCtxDbo.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public  void  InsertBuy(string symbol, string account,int date, decimal shares,decimal price, decimal intrest, decimal sumAllFee, decimal brokerFee, string brokerCode)
        {
            try
            {
                CurrentCtxDbo.InsertBuy(symbol, account, date, shares, price, intrest, sumAllFee, brokerFee, brokerCode);
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public void InsertBuySell(string symbol, string account, int date, decimal shares, decimal price, decimal intrest, decimal sumAllFee, decimal brokerFee, string brokerCode, int orderType)
        {
            try
            {
                CurrentCtxDbo.InsertBuySell(symbol, account, date, shares, price, intrest, sumAllFee, brokerFee, brokerCode, orderType);
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public void InsertOrderBuy(string symbol, string account, int date, decimal shares, decimal price, decimal intrest, decimal sumAllFee, decimal brokerFee, string brokerCode, int regDate, int regTime, string regUser)
        {
            try
            {
                CurrentCtxDbo.InsertOrderBuy(symbol, account, date, shares, price, intrest, sumAllFee, brokerFee, brokerCode,  regDate,  regTime,  regUser);
            }
            catch (Exception ex)
            {
                throw;
            }
        }



        public void InsertOrderSell(string symbol, string account, int date, decimal shares, decimal price, decimal intrest, decimal sumAllFee, decimal brokerFee, string brokerCode, int regDate, int regTime, string regUser)
        {
            try
            {
                CurrentCtxDbo.InsertOrderSell(symbol, account, date, shares, price, intrest, sumAllFee, brokerFee, brokerCode,  regDate,  regTime,  regUser);
            }
            catch (Exception ex)
            {
                throw;
            }
        }




        public int AddBuy(BuySell obj)
        {
            try
            {
                CurrentCtxDbo.InsertBuy(obj.Symbol, obj.Account, obj.TradeDate, obj.Shares, obj.Price, obj.Intrest, obj.SumAllFee, obj.BrokerFee, obj.BrokerCode);
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public void InsertSymbolCouponsInPosition(string symbolDbo, string account, string symbolDebt, int regDate, int regTime, string regUser)
        {
            try
            {
                CurrentCtxDbo.InsertPositionCouponMaps( symbolDbo,  symbolDebt,   regDate,  regTime,  regUser);
            }
            catch (Exception ex)
            {
                throw;
            }

        }



    }
}