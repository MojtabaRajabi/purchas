﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sanay.Lotus.Erm.DataAccess.Helper
{
    public partial class LinqHelper
    {
        public void RemoveInputOutputFlowById(int id)
        {
            try
            {
                    CurrentCtxDbo.RemoveInputOutputFlowById(id);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

    }
}