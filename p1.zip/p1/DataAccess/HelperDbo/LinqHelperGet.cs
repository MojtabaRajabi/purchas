﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Web;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.Models;
using Sanay.Lotus.Erm.Lib.Enum;


namespace Sanay.Lotus.Erm.DataAccess.Helper
{
    public partial class LinqHelper
    {
        public List<GetCheckPositions_Result> GetCheckPositions(string symbol, string account,int date)
        {
            try
            {
                return CurrentCtxDbo.GetCheckPositions(symbol,account,date).ToList();
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public ManualFlow GetManualFlowById(Guid id)
        {
            try
            {
                return CurrentCtxDbo.ManualFlows.FirstOrDefault(t => t.Id == id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public GetFileById_Result GetFileById(int id)
        {
            try
            {
                var objFetch = CurrentCtxDbo.GetFileById(id).FirstOrDefault();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetInputOutputFlowCycleById_Result> GetIOFlowGenerateFileById(int id)
        {
            try
            {
                var objFetch = CurrentCtxDbo.GetInputOutputFlowCycleById(id).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<GetInputOutputFlowCycle_Result> GetInputOutputFlowCycle(int IOFlowCycles, int StartDate, int EndDate, double Value)
        {
            try
            {
                var objFetch = CurrentCtxDbo.GetInputOutputFlowCycle(IOFlowCycles, StartDate, EndDate, Value).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<PositionsLatest> GetPosition(string col, string sort, string searchValue)
        {
            try
            {
                var objFetch = CurrentCtxDbo.PositionsLatests.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<PositionsLatest> GetPosition()
        {
            try
            {

                //var objFetch = CurrentCtxDbo.PositionsLatests.Where(c => c.Symbol != "گژطلا").ToList();
                var objFetch = CurrentCtxDbo.PositionsLatests.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetPositionsById_Result> GetPositionsById(int Id)
        {
            try
            {
                var objFetch = CurrentCtxDbo.GetPositionsById(Id).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<GetPositionPoints_Result> GetPositionPoints()
        {
            try
            {

                var objFetch = CurrentCtxDbo.GetPositionPoints().ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public GetResultCapitalSufficienciesById_Result GetResultCapitalSufficienciesById(int id)
        {
            try
            {

                var objFetch = CurrentCtxDbo.GetResultCapitalSufficienciesById(id).FirstOrDefault();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetPositionsByCycle_Result> GetSymbolTimeline(int StartDate, int EndDate, int Cycle, int Position)
        {
            try
            {
                var objFetch = CurrentCtxDbo.GetPositionsByCycle(StartDate, EndDate, Cycle, Position, 6).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }





        public List<GetBuysAccounting_Result> GetIssuanceBuys(string symbol, string account, int startDate, int endDate)
        {
            try
            {
                var objFetch = CurrentCtxDbo.GetBuysAccounting(startDate, endDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetBuysAccounting_Result> GetBuysAccounting(int startDate, int endDate)
        {
            try
            {
                CurrentCtxDbo.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxDbo.GetBuysAccounting(startDate, endDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetAccountingBuys_Result> GetAccountingBuys(int parStartDate, int parEndDate, string parSymbol, string parAccount)
        {
            try
            {
                CurrentCtxDbo.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxDbo.GetAccountingBuys(parStartDate, parEndDate, parSymbol, parAccount).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<GetPositionKardex_Result> GetPositionKardex(int parStartDate, int parEndDate, string parSymbol, string parAccount)
        {
            try
            {
                CurrentCtxDbo.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxDbo.GetPositionKardex(parSymbol, parAccount ,parStartDate, parEndDate,0,int.MaxValue).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetCouponProfitSymbols_Result> GetCouponProfitSymbols(int startDate, int endDate)
        {
            try
            {
                CurrentCtxDbo.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxDbo.GetCouponProfitSymbols(startDate, endDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public List<GetAdjustedTradesAllDaysByCompanyId_Result> GetAdjustedTradesAllDaysByCompanyId( int companyId,int startDate, int endDate)
        {
            try
            {
                CurrentCtxDbo.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxRisk.GetAdjustedTradesAllDaysByCompanyId(companyId,startDate, endDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetHistoricalAllSymbolPrice_Result> GetSymbolPriceGapCalculations(int startDate, int endDate,int SymbolId)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxRisk.GetHistoricalAllSymbolPrice().Where(c=>c.SymbolId== SymbolId && c.DatePrice>= startDate && c.DatePrice<= endDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetSymbolDaysRequiredSale_Result> GetSymbolDaysRequiredSale(int fundId, string symbol,int period, double percentageParticipation,int StartDate,int EnDate)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxRisk.GetSymbolDaysRequiredSale( fundId,  symbol, period, percentageParticipation,StartDate,EnDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetFundPortfolioSymbolCount_Result> GetFundPortfolioSymbolCount(int startDate, int endDate,int FundId, string  Symbol)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxRisk.GetFundPortfolioSymbolCount(startDate, endDate,FundId, Symbol).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetSymbolOwnershippercentage_Result> GetSymbolOwnershippercentage(int startDate, int endDate, int FundId, string Symbol)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxRisk.GetSymbolOwnershippercentage(FundId, Symbol,startDate, endDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<GetFundsCapitalTurnoverByManager_Result> GetFundsCapitalTurnoverByManager(int startDate, int endDate,string manager )
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxFund.GetFundsCapitalTurnoverByManager(startDate, endDate, manager).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetFundsCapitalTurnoverDetailesByManager_Result> GetFundsCapitalTurnoverDetailesByManager(int startDate, int endDate, string manager)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxFund.GetFundsCapitalTurnoverDetailesByManager(startDate, endDate, manager).ToList();
                return objFetch;
            }
            catch (Exception ex) 
            {
                return null;
            }
        }

        public void InsertChartDescription(FundTypeDescription obj)
        {
            try
            {

                var obj2 = new FundTypeDescription();
                obj2= CurrentCtxFund
                        .FundTypeDescriptions.Where(c => c.PDate== obj.PDate && c.FundTypeName== obj.FundTypeName).FirstOrDefault();


                if (obj2!=null)
                CurrentCtxFund.FundTypeDescriptions.Remove(obj2);


                CurrentCtxFund.FundTypeDescriptions.AddOrUpdate(obj);
                CurrentCtxFund.SaveChanges();



            }

            catch (Exception ex)
            {
             }
        }






        public List<CalculateSymbolVAR_Result> GetSymbolVaR(int startDate, int endDate, int SymbolId)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxRisk.CalculateSymbolVAR(SymbolId, startDate, endDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<CalculateFastSymbolVAR_Result> GetFastSymbolVaR(int startDate, int endDate, int SymbolId,int interval)
        {
            try
            {
                CurrentCtxRisk.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxRisk.CalculateFastSymbolVAR(SymbolId, startDate, endDate, interval).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }







        public List<GetAccountingSells_Result> GetAccountingSells(int parStartDate, int parEndDate, string parSymbol, string parAccount)
        {
            try
            {
                CurrentCtxDbo.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxDbo.GetAccountingSells(parStartDate, parEndDate, parSymbol, parAccount).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetSellsAccounting_Result> GetSellsAccounting(int startDate, int endDate)
        {
            try
            {
                CurrentCtxDbo.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxDbo.GetSellsAccounting(startDate, endDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetSellsAccounting_Result> GetIssuanceSells(string symbol, string account, int startDate, int endDate)
        {
            try
            {
                var objFetch = CurrentCtxDbo.GetSellsAccounting(startDate, endDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<CalculateCapitalSufficiencies_Result> GetCalculateCapitalSufficiencies(int startDate, int endDate)
        {
            try
            {
                var objFetch = CurrentCtxDbo.CalculateCapitalSufficiencies(startDate, endDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }








        public BuySellAccountingCode GetCodeById(int id)
        {
            try
            {
                var objFetch = CurrentCtxDbo.BuySellAccountingCodes.Where(c => c.Id == id).FirstOrDefault();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<BuySellAccountingCode> GetBuySellAccountingCode()
        {
            try
            {
                var objFetch = CurrentCtxDbo.BuySellAccountingCodes.Where(c => c.IsObsolete != true).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<FutureDebtBond> GetFutureDebtBond()
        {
            try
            {
                var objFetch = CurrentCtxDbo.FutureDebtBonds.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<CapitalBond> GetCapitalBonds()
        {
            try
            {
                var objFetch = CurrentCtxDbo.CapitalBonds.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<BondIssuance> GetBondIssuances()
        {
            try
            {
                var objFetch = CurrentCtxDbo.BondIssuances.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<AdditionalContractFee> GetAdditionalContractFee()
        {
            try
            {
                var objFetch = CurrentCtxDbo.AdditionalContractFees.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<ContractDetailDebtBuySell> GetContractDetailDebtBuySells()
        {
            try
            {
                var objFetch = CurrentCtxFund.ContractDetailDebtBuySells.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<ContractDetailReception> GetContractDetailReception()
        {
            try
            {
                var objFetch = CurrentCtxFund.ContractDetailReceptions.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public List<ContractDetailDebtReception> GetContractDetailDebtReception()
        {
            try
            {
                var objFetch = CurrentCtxFund.ContractDetailDebtReceptions.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<ContractDetailCapitalIncreaseSupplyAdvice> GetContractDetailCapitalIncreaseSupplyAdvices()
        {
            try
            {
                var objFetch = CurrentCtxFund.ContractDetailCapitalIncreaseSupplyAdvices.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<ContractDetailDebtTrading> GetContractDetailDebtTrading()
        {
            try
            {
                var objFetch = CurrentCtxFund.ContractDetailDebtTradings.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public List<ContractDetailAdvice> GetContractDetailAdvices()
        {
            try
            {
                var objFetch = CurrentCtxFund.ContractDetailAdvices.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<ContractDetailPurchaseOfService> GetContractDetailPurchaseOfService()
        {
            try
            {
                var objFetch = CurrentCtxFund.ContractDetailPurchaseOfServices.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<ContractDetailValuation> GetContractDetailValuations()
        {
            try
            {
                var objFetch = CurrentCtxFund.ContractDetailValuations.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<ContractDetailAdviceFinancialService> GetContractDetailAdviceFinancialServices()
        {
            try
            {
                var objFetch = CurrentCtxFund.ContractDetailAdviceFinancialServices.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<FundBuySellShare> GetFundBuySellShares()
        {
            try
            {
                var objFetch = CurrentCtxFund.FundBuySellShares.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
           public List<FundSharesProfit> GetFundSharesProfits()
        {
            try
            {
                var objFetch = CurrentCtxFund.FundSharesProfits.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }







        public List<CapitalSufficiency> GetCapitalSufficiencies()
        {
            try
            {
                var objFetch = CurrentCtxDbo.CapitalSufficiencies.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<Deposit> GetDeposits()
        {
            try
            {
                var objFetch = CurrentCtxDbo.Deposits.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<InflowsLowOccurrence> GetInflowsLowOccurrence()
        {
            try
            {
                var objFetch = CurrentCtxDbo.InflowsLowOccurrences.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<OtherFundUnit> GetOtherFundUnits()
        {
            try
            {
                var objFetch = CurrentCtxDbo.OtherFundUnits.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }





        public List<IOFlowFund> GetIOFlowFund()
        {
            try
            {
                var objFetch = CurrentCtxDbo.IOFlowFunds.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<GetInputOutputFlowsByDateFlow_Result> GetInputOutputFlowsByDateFlow(int flowDate, int flowType)
        {
            try
            {
                var objFetch = CurrentCtxDbo.GetInputOutputFlowsByDateFlow(flowDate, flowType).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<DebtBond> GetDebtBonds()
        {
            try
            {
                var objFetch = CurrentCtxDbo.DebtBonds.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetDebtBonds_Result> GetDebtBondswithClosing()
        {
            try
            {
                var objFetch = CurrentCtxDbo.GetDebtBonds().ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<FundDebtBond> GetFundDebtBonds()
        {
            try
            {
                var objFetch = CurrentCtxFund.FundDebtBonds.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<CurrentTaxAndCost> GetCurrentTaxAndCost()
        {
            try
            {
                var objFetch = CurrentCtxDbo.CurrentTaxAndCosts.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<FundSell> GetFundSell()
        {
            try
            {
                var objFetch = CurrentCtxDbo.FundSells.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }











        public List<BuySellsAccount> GetBuySellAccountingCodes()
        {
            try
            {
                var objFetch = CurrentCtxDbo.BuySellsAccounts.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<BuySellsSymbol> GetBuySellsSymbol()
        {
            try
            {
                var objFetch = CurrentCtxDbo.BuySellsSymbols.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetInstruments_Result> GetInstruments()
        {
            try
            {
                var objFetch = CurrentCtxDebt.GetInstruments().ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }






        public List<string> GetSymbolsCoupons()
        {
            try
            {
                var objFetch = CurrentCtxDbo.GetSymbolsCoupons().ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }





        public List<ManualFlow> GetCapitalIncreases()
        {
            try
            {
                var objFetch = CurrentCtxDbo.ManualFlows.Where(c => c.TypeId == 1).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public List<ManualFlow> GetOutputCosts()
        {
            try
            {
                var objFetch = CurrentCtxDbo.ManualFlows.Where(c => c.TypeId == 2).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<BuySellsBroker> GetBuySellsBroker()
        {
            try
            {
                var objFetch = CurrentCtxDbo.BuySellsBrokers.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetPillar_Result> GetPillar()
        {
            try
            {
                var objFetch = CurrentCtxDbo.GetPillar().ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<BuySellsAccount> GetBuySellsAccount()
        {
            try
            {
                var objFetch = CurrentCtxDbo.BuySellsAccounts.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<BuySellsBroker> GetBrokers()
        {
            try
            {
                var objFetch = CurrentCtxDbo.BuySellsBrokers.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


         



        public List<BuySellAccountingCode> BuySellAccountingCode()
        {
            try
            {
                var objFetch = CurrentCtxDbo.BuySellAccountingCodes.ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<GetBuySells_Result> GetBuySells(int start, int length, string searchValue, int tradetype, string symbol, string account, int startDate, int endDate)
        {
            try
            {
                var portType = -1;
                var objFetch = CurrentCtxDbo.GetBuySells(symbol, account, tradetype, startDate, endDate, portType, start, length).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetPositionOperation_Result> GetPositionOperation(int start, int length,string symbol,int startDate, int endDate)
        {
            try
            {
                var objFetch = CurrentCtxDbo.GetPositionOperation( symbol, startDate,  endDate, start, length).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<CalculatePortfolioBetaV2_Result>  GetPortfolioBeta(int fundId, int StartDate, int EndDate)
        {
            try
            {

                CurrentCtxRisk.Database.CommandTimeout = 1200;


                var objFetch =  CurrentCtxRisk.CalculatePortfolioBetaV2(fundId, StartDate, EndDate).ToList();
                return   objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<CalculateSymbolBetaV2_Result> GetSymbolBeta(int SymbolId, int StartDate, int EndDate)
        {
            try
            {

                CurrentCtxRisk.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxRisk.CalculateSymbolBetaV2(SymbolId, StartDate, EndDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<double?> CalculatePortfolioTrackingError(int fundId, int StartDate, int EndDate)
        {
            try
            {

                CurrentCtxRisk.Database.CommandTimeout = 1200;

                var objFetch = CurrentCtxRisk.CalculatePortfolioTrackingError(fundId, StartDate, EndDate).ToList();
                return   objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<double?> CalculateSymbolTrackingError(int SymbolId, int StartDate, int EndDate)
        {
            try
            {

                CurrentCtxRisk.Database.CommandTimeout = 1200;

                var objFetch = CurrentCtxRisk.CalculateSymbolTrackingError(SymbolId, StartDate, EndDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<CalculatePortfolioPerformanceEvaluation_Result> CalculatePortfolioPerformanceEvaluation(int fundId, int StartDate, int EndDate,double Percent)
        {
            try
            {

                CurrentCtxRisk.Database.CommandTimeout = 1200;

                var objFetch = CurrentCtxRisk.CalculatePortfolioPerformanceEvaluation(fundId, StartDate, EndDate,Percent).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<CalculateSymbolPerformanceEvaluation_Result> CalculateSymbolPerformanceEvaluation(int SymbolId, int StartDate, int EndDate, double Percent)
        {
            try
            {

                CurrentCtxRisk.Database.CommandTimeout = 1200;

                var objFetch = CurrentCtxRisk.CalculateSymbolPerformanceEvaluation(SymbolId, StartDate, EndDate, Percent).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }





        public List<GetInputOutputFlowsFilter_Result> GetIOFlowDetails(int startDate, int endDate, int Flow,int TagSource, string tag, int type, int startValue, int endValue, int start, int lenght)
        {
            try
            {
                var objFetch = CurrentCtxDbo.GetInputOutputFlowsFilter(startDate, endDate, Flow, TagSource, tag, type,   startValue, endValue, start, lenght).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<PreviewAutomaticDepositsInputOutputFlowCycle_Result> PreviewAutomaticDepositsInputOutputFlowCycle(double rate, double deposit, double Blocked, int payDate, int StartDate, int MaturityDate)
        {
            try
            {
                var objFetch = CurrentCtxDbo.PreviewAutomaticDepositsInputOutputFlowCycle(StartDate, MaturityDate, payDate, deposit, rate, deposit).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
          public List<PreviewAutomaticInflowsLowOccurrenceInputOutputFlow_Result> PreviewAutomaticInflowsLowOccurrenceInputOutputFlowCycle(string Title, double ReportedFlow, int PayDate, double ProbabilityOfOccurrence, int EffectiveFlow)
        {
            try
            {
                var objFetch = CurrentCtxDbo.PreviewAutomaticInflowsLowOccurrenceInputOutputFlow(Title, ReportedFlow, PayDate, ProbabilityOfOccurrence, EffectiveFlow).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<PreviewImportMFRContract_Result> PreviewMFRInputOutputFlowCycle(int ContractId)
        {
            try
            {
                var objFetch = CurrentCtxDbo.PreviewImportMFRContract(ContractId).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<PreviewAutomaticIOFlowFundInputOutputFlow_Result> PreviewAutomaticIOFlowFundInputOutputFlowCycle(Nullable<long> num, Nullable<int> profitSharingDate, Nullable<int> profitRate, Nullable<int> endDate, Nullable<int> buyUnit, Nullable<int> buyUnitDate, Nullable<int> cycle, Nullable<long> NAV, Nullable<int> numUnitsInvested, Nullable<int> priceRevocation, Nullable<int> sellUnit, Nullable<int> sellUnitDate, Nullable<double> priceIssue)
        {
            try
            {
                var objFetch = CurrentCtxDbo.PreviewAutomaticIOFlowFundInputOutputFlow( num,  profitSharingDate,  profitRate, endDate, buyUnit,  buyUnitDate,  cycle,  NAV,  numUnitsInvested,  priceRevocation,  sellUnit,  sellUnitDate,  priceIssue).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<PreviewAutomaticManualFlowsCapitalIncreasesInputOutputFlow_Result> PreviewAutomaticManualFlowsCapitalIncreasesInputOutputFlow(int sdate, double val)
        {
            try
            {
                var objFetch = CurrentCtxDbo.PreviewAutomaticManualFlowsCapitalIncreasesInputOutputFlow(sdate, val).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<PreviewAutomaticManualFlowsOutputCostsInputOutputFlow_Result> PreviewAutomaticManualFlowsOutputCostsInputOutputFlow(int sdate, double val)
        {
            try
            {
                var objFetch = CurrentCtxDbo.PreviewAutomaticManualFlowsOutputCostsInputOutputFlow(sdate, val).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<PreviewAutomaticDebtBondsInputOutputFlowCycle_Result> PreviewAutomaticDebtBondsInputOutputFlowCycle(string symbol, int sdate, int edate, double val)
        {
            try
            {
                var objFetch = CurrentCtxDbo.PreviewAutomaticDebtBondsInputOutputFlowCycle(symbol, sdate, edate, val).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<PreviewAutomaticFundDebtBondsInputOutputFlowCycle_Result> PreviewAutomaticFundDebtBondsInputOutputFlowCycle(string symbol, int sdate, int edate, double val,int fundId)
        {
            try
            {
                var objFetch = CurrentCtxFund.PreviewAutomaticFundDebtBondsInputOutputFlowCycle(symbol, sdate, edate, val,fundId).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }






        public List<PreviewAutomaticFutureDebtBondsInputOutputFlow_Result> PreviewAutomaticFutureDebtBondsInputOutputFlow(int sdate, int edate, int cycle, double val, double initialCapital, double ipoFee, double marketMakingFee)
        {
            try
            {
                var objFetch = CurrentCtxDbo.PreviewAutomaticFutureDebtBondsInputOutputFlow(sdate, edate, cycle, val, initialCapital, ipoFee, marketMakingFee).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<PreviewAutomaticCapitalBondsInputOutputFlow_Result> PreviewAutomaticCapitalBondsInputOutputFlow(double outputIpoFee, int dateInputsIpoFee, double inputIpoFee, int dateOfReturnObligation, double ipoFee, int ipoDate, double holdingFee, int holdingFeeDate, double advice, int adviceDate, double marketMakingFee, int marketMakingFeeDate, int cycle)
        {
            try
            {
                var objFetch = CurrentCtxDbo.PreviewAutomaticCapitalBondsInputOutputFlow(outputIpoFee, dateInputsIpoFee, inputIpoFee, dateOfReturnObligation, ipoFee, ipoDate, holdingFee, holdingFeeDate, advice, adviceDate, marketMakingFee, marketMakingFeeDate, cycle).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<PreviewRemoveInputOutputFlow_Result> PreviewRemoveInputOutputFlow(int startDate, int endDate, int type, int start, int lenght)
        {
            try
            {
                var objFetch = CurrentCtxDbo.PreviewRemoveInputOutputFlow(startDate, endDate,type, start, lenght).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<PreviewAutomaticBondIssuancesInputOutputFlow_Result> PreviewAutomaticBondIssuancesInputOutputFlow(int sdate, int edate, int cycle, double val, double initialCapital, double ipoFee, double marketMakingFeeFirstYear, double marketMakingFeeOtherYear)
        {
            try
            {
                var objFetch = CurrentCtxDbo.PreviewAutomaticBondIssuancesInputOutputFlow(sdate, edate, cycle, val, initialCapital, ipoFee, marketMakingFeeFirstYear, marketMakingFeeOtherYear).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<PreviewAutomaticAdditionalContractFeesBuyInputOutputFlow_Result> PreviewAutomaticAdditionalContractFeesBuyInputOutputFlow(int sdate, int edate, double addition, double totalValue)
        {
            try
            {
                var objFetch = CurrentCtxDbo.PreviewAutomaticAdditionalContractFeesBuyInputOutputFlow(sdate, edate, addition, totalValue).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<PreviewAutomaticAdditionalContractFeesSellInputOutputFlow_Result> PreviewAutomaticAdditionalContractFeesSellInputOutputFlow(int sdate,int edate, double addition, double totalValue)
        {
            try
            {
                var objFetch = CurrentCtxDbo.PreviewAutomaticAdditionalContractFeesSellInputOutputFlow(sdate,edate ,addition, totalValue).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<PreviewAutomaticBuySharesFundIOFlow_Result> PreviewAutomaticBuySharesFundIOFlow(int Pdate, double Price, long Num)
        {
            try
            {
                var objFetch = CurrentCtxFund.PreviewAutomaticBuySharesFundIOFlow(Pdate, Price, Num).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<PreviewAutomaticSellSharesFundIOFlow_Result> PreviewAutomaticSellSharesFundIOFlow(int Pdate, double Price, long Num)
        {
            try
            {
                var objFetch = CurrentCtxFund.PreviewAutomaticSellSharesFundIOFlow(Pdate, Price, Num).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<PreviewAutomaticShareProfitFundIOFlow_Result> PreviewAutomaticShareProfitFundIOFlow(int Pdate, double Profit, long Num)
        {
            try
            {
                var objFetch = CurrentCtxFund.PreviewAutomaticShareProfitFundIOFlow(Pdate, Profit, Num).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }













        public List<PreviewAutomaticTaxAndInsuranceInputOutputFlowCycle_Result> PreviewAutomaticTaxAndInsuranceInputOutputFlowCycle(int sdate, int edate, double val)
        {
            try
            {
                var objFetch = CurrentCtxDbo.PreviewAutomaticTaxAndInsuranceInputOutputFlowCycle(sdate, edate, val).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<PreviewAutomaticFundSellsInputOutputFlow_Result> PreviewAutomaticFundSellInputOutputFlow(double num, double interest, int sdate, int edate)
        {
            try
            {
                var objFetch = CurrentCtxDbo.PreviewAutomaticFundSellsInputOutputFlow(sdate, edate, num, interest).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public List<GetInputOutputFlows_Result> GetInputOutputFlows(int startDate, int endDate, int type)
        {
            try
            {
                var objFetch = CurrentCtxDbo.GetInputOutputFlows(startDate, endDate, type).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<GetFundInputOutputFlows_Result> GetFundsInputOutputFlows(int startDate, int endDate, int type, int FundId)
        {
            try
            {
                var objFetch = CurrentCtxFund.GetFundInputOutputFlows(startDate, endDate, type, FundId).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public List<GetVoucherByDateType_Result> GetVoucherByDateType(int pDate, int Type)
        {
            try
            {
                var objFetch = CurrentCtxDbo.GetVoucherByDateType(pDate, Type).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        //public List<GetVoucherByDateType_Result> GetVoucherByDateType(int pDate, int Type,int FundId)
        //{
        //    try
        //    {
        //        var objFetch = CurrentCtxFund.(pDate, Type).ToList();
        //        return objFetch;
        //    }
        //    catch (Exception ex)
        //    {
        //        return null;
        //    }
        //}




        public List<GetInputOutputFlowByDateType_Result> GetInputOutputFlowByDateType(int Type, int pDate)
        {
            try
            {
                var objFetch = CurrentCtxDbo.GetInputOutputFlowByDateType(Type, pDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<GetInputOutputFlowGenerates_Result> GetInputOutputFlowGenerates(int start, int length, string searchValue, int startDate, int endDate)
        {
            try
            {
                var objFetch = CurrentCtxDbo.GetInputOutputFlowGenerates(startDate, endDate, 0, int.MaxValue).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetLiquidityGap_Result> GetLiquidityGap(int startDate, int endDate, int type)
        {
            try
            {
                var objFetch = CurrentCtxDbo.GetLiquidityGap(startDate, endDate, type).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<GetLiquidityGapWithNums_Result> GetLiquidityGapWithNums(int startDate, int endDate, string strData, int type)
        {
            try
            {
                CurrentCtxDbo.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxDbo.GetLiquidityGapWithNums(startDate, endDate, strData, type).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetFundLiquidityGapWithNums_Result> GetFundLiquidityGapWithNums(int startDate, int endDate, string strData, int type)
        {
            try
            {
                CurrentCtxDbo.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxFund.GetFundLiquidityGapWithNums(startDate, endDate, strData, type).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }






        public List<GetSymbolCouponsByFilter_Result> GetSymbolCouponsByFilter(string Symbol, int StartDate, int EndDate)
        {
            try
            {
                CurrentCtxDbo.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxDbo.GetSymbolCouponsByFilter(Symbol, StartDate, EndDate).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetSymbolCoupons_Result> GetSymbolCoupons(string Symbol, string SymbolDebt)
        {
            try
            {
                CurrentCtxDbo.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxDbo.GetSymbolCoupons(Symbol, SymbolDebt).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetPositionCoupons_Result> GetPositionCoupons(string Symbol)
        {
            try
            {
                CurrentCtxDbo.Database.CommandTimeout = 1200;
                var objFetch = CurrentCtxDbo.GetPositionCoupons(Symbol).ToList();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }






        public List<GetEtemadFunds_Result> GetEtemadFunds(int start, int length, string searchValue, int startDate, int endDate, string Name, string nationalId)
        {
            try
            {
                var objFetch = CurrentCtxDbo.GetEtemadFunds(nationalId, Name, startDate, endDate, 0, int.MaxValue).ToList();
                //List<GetEtemadFunds_Result> objFetchSorted = new List<GetEtemadFunds_Result>();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetTalaFunds_Result> GetTalaFunds(int start, int length, string searchValue, int startDate, int endDate, string Name, string nationalId)
        {
            try
            {
                var objFetch = CurrentCtxDbo.GetTalaFunds(nationalId, Name, startDate, endDate, 0, int.MaxValue).ToList();
                //List<GetEtemadFunds_Result> objFetchSorted = new List<GetEtemadFunds_Result>();
                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }







        public List<FileType> GetFileType()
        {
            try
            {
                var objFetch = CurrentCtxDbo.FileTypes.ToList();
                //List<GetEtemadFunds_Result> objFetchSorted = new List<GetEtemadFunds_Result>();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public List<GetRooyeshFunds_Result> GetRooyeshFunds(int start, int length, string searchValue, int startDate, int endDate, string Name, string nationalId)
        {
            try
            {
                var objFetch = CurrentCtxDbo.GetRooyeshFunds(nationalId, Name, startDate, endDate, 0, int.MaxValue).ToList();
                //List<GetEtemadFunds_Result> objFetchSorted = new List<GetEtemadFunds_Result>();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<GetFiles_Result> GetFiles(string name, int start, int end, int FileType, string UserAcc)
        {
            try
            {
                var objFetch = CurrentCtxDbo.GetFiles(name, FileType, UserAcc, start, end, 0, int.MaxValue).ToList();
                //List<GetEtemadFunds_Result> objFetchSorted = new List<GetEtemadFunds_Result>();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }





        public List<GetServatFunds_Result> GetServatFunds(int start, int length, string searchValue, int startDate, int endDate, string Name, string nationalId)
        {
            try
            {
                var objFetch = CurrentCtxDbo.GetServatFunds(nationalId, Name, startDate, endDate, 0, int.MaxValue).ToList();
                //List<GetEtemadFunds_Result> objFetchSorted = new List<GetEtemadFunds_Result>();

                return objFetch;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public BuySellAccountingCode GetBuySellAccountingCode(int id)
        {
            try
            {
                return CurrentCtxDbo.BuySellAccountingCodes.FirstOrDefault(t => t.Id == id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public AssetClass GetAssetClassesById(int id)
        {
            try
            {
                return CurrentCtxRisk.AssetClasses.FirstOrDefault(c=>c.Id == id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public FutureDebtBond GetFutureDebtBond(Guid id)
        {
            try
            {
                return CurrentCtxDbo.FutureDebtBonds.FirstOrDefault(t => t.Id == id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public CapitalBond GetCapitalBonds(Guid id)
        {
            try
            {
                return CurrentCtxDbo.CapitalBonds.FirstOrDefault(t => t.Id == id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public BondIssuance GetBondIssuance(Guid id)
        {
            try
            {
                return CurrentCtxDbo.BondIssuances.FirstOrDefault(t => t.Id == id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public AdditionalContractFee GetAdditionalContractFee(Guid id)
        {
            try
            {
                return CurrentCtxDbo.AdditionalContractFees.FirstOrDefault(t => t.Id == id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public FundBuySellShare GetFundBuySellShare(Guid id)
        {
            try
            {
                return CurrentCtxFund.FundBuySellShares.FirstOrDefault(t => t.Id == id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

          public FundSharesProfit GetFundSharesProfit(Guid id)
        {
            try
            {
                return CurrentCtxFund.FundSharesProfits.FirstOrDefault(t => t.Id == id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public CapitalSufficiency GetCapitalSufficiencies(int id)
        {
            try
            {
                return CurrentCtxDbo.CapitalSufficiencies.FirstOrDefault(t => t.Id == id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public Deposit GetDepositById(Guid id)
        {
            try
            {
                return CurrentCtxDbo.Deposits.FirstOrDefault(t => t.Id == id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }
           public InflowsLowOccurrence GetInflowsLowOccurrencesById(Guid id)
        {
            try
            {
                return CurrentCtxDbo.InflowsLowOccurrences.FirstOrDefault(t => t.Id == id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public OtherFundUnit GetOtherFundUnitById(int id)
        {
            try
            {
                return CurrentCtxDbo.OtherFundUnits.FirstOrDefault(t => t.Id == id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }






        public Permission GetPermissionsByUsername(string  username)
        {
            try
            {
                var res1 = CurrentCtxUsr.Permissions.FirstOrDefault(t => t.UserName == username);
                return res1;
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public IOFlowFund GetIOFlowFundById(Guid id)
        {
            try
            {
                return CurrentCtxDbo.IOFlowFunds.FirstOrDefault(t => t.Id == id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public DebtBond GetDebtBondsById(Guid id)
        {
            try
            {
                return CurrentCtxDbo.DebtBonds.FirstOrDefault(t => t.Id == id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }



      

        public FundDebtBond GetFundDebtBondsById(Guid id, int fundId)
        {
            try
            {
                return CurrentCtxFund.FundDebtBonds.FirstOrDefault(t => t.Id == id && t.FundId==fundId);
            }
            catch (Exception ex)
            {
                return null;
            }
        }




        public Symbol GetDebtSymbolById(int id)
        {
            try
            {
                return CurrentCtxDebt.Symbols.FirstOrDefault(t => t.Id == id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public CurrentTaxAndCost GetCurrentTaxAndCostById(Guid id)
        {
            try
            {
                return CurrentCtxDbo.CurrentTaxAndCosts.FirstOrDefault(t => t.Id == id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public FundSell GetCurrentFundSell(Guid id)
        {
            try
            {
                return CurrentCtxDbo.FundSells.FirstOrDefault(t => t.Id == id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }






        public long GetLastValueTaxAndInsurance(int sdate)
        {
            try
            {
                var obj = CurrentCtxDbo.GetIOFlowTypeLastValueByDate((int)IOFlowTypes.Out_TaxAndInsurance, sdate).FirstOrDefault();
                if (obj != null) return (long)(obj.Val ?? 0);
                return 0;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }


        public ManualFlow GetCapitalIncrease(Guid id)
        {
            try
            {
                return CurrentCtxDbo.ManualFlows.FirstOrDefault(t => t.Id == id);
            }
            catch (Exception ex)
            {
                return null;
            }
        }





    }
}