﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Web;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.Models;

namespace Sanay.Lotus.Erm.DataAccess.Helper
{
    public partial class LinqHelper
    {


        public int UpdateBuySellAccountingCode(BuySellAccountingCode obj)
        {
            try
            {
                CurrentCtxDbo.BuySellAccountingCodes.AddOrUpdate(obj);
                CurrentCtxDbo.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        public int UpdateCapitalsufficiency(CapitalSufficiency obj)
        {
            try
            {
                CurrentCtxDbo.CapitalSufficiencies.AddOrUpdate(obj);
                CurrentCtxDbo.SaveChanges();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw;
            }

        }


    }
}