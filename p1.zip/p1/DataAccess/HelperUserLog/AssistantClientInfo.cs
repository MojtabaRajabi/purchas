﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Web;
using Sanay.Library.DataAccess;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Enum;

namespace Sanay.Lotus.Erm.DataAccess.HelperUserLog
{
    public class AssistantClientInfo
    {

        public static void RegisterClientInfo(HttpContextBase htc,string username,UserStatus ls)
        {
            var sql = new LinqHelper();
            var x = htc.Request.Url.Host.Contains("localhost");
            
            var obj = new ClientInfo()
            {
                UserName = username,
                HostName = htc.Request.Url.Host,
                Ip = htc.Request.ServerVariables["REMOTE_ADDR"], //UserHostAddress,
                Browser = htc.Request.Browser.Browser,
                MacAddress =  ( from nic in NetworkInterface.GetAllNetworkInterfaces()
                                where nic.OperationalStatus == OperationalStatus.Up
                                select nic.GetPhysicalAddress().ToString()
                            ).FirstOrDefault(),
                OS = htc.Request.UserAgent,
                TimeStamp = HttpContext.Current.Timestamp,
                RegDate = Assistant.TodayDateInt(),
                RegTime = Assistant.TimeNowInt(),
                Statuse =(int)ls,
            };

            sql.InsertClientInfo(obj);
        }




       

    }
}