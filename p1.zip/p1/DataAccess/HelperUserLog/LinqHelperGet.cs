﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Ajax.Utilities;
using Sanay.Library.DataAccess;
using Sanay.Lotus.Erm.Lib.Enum;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Core.Objects;

namespace Sanay.Lotus.Erm.DataAccess.Helper
{
    public partial class LinqHelper
    {


        public List<GetlogsByFilter_Result> GetlogsByFilter(int serviceType, int logType, int statusType, int startDate, int endDate, int minRow, int maxRow)
        {
            try
            {
                var objFetch = CurrentCtxUserLog.GetlogsByFilter(serviceType, logType, statusType,
                    startDate, endDate, "%%", minRow, maxRow).ToList();
                return objFetch;

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetEventsByFilter_Result> GetEventsByFilter(string userName, string url,string FirstSegments, int startDate, int endDate, int startTime, int endTime,int minRow,int maxRow)
        {
            try
            {
                var objFetch = CurrentCtxUserLog.GetEventsByFilter(
                    userName, url, FirstSegments, startDate, endDate, startTime, endTime, minRow, maxRow).ToList();
                return objFetch;
                
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GetUsersDailyEvents_Result> GetUsersDailyEvents(int Pdate)
        {
            try
            {
                var objFetch = CurrentCtxUserLog.GetUsersDailyEvents(Pdate).ToList();
                return objFetch;

            }
            catch (Exception ex)
            {
                return null;
            }
        }



    }
}