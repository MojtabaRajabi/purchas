﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sanay.Lotus.Erm.Models;
using System.Data.Entity.Migrations;


namespace Sanay.Lotus.Erm.DataAccess.Helper
{
    public partial class LinqHelper
    {


        public void AddUserEvent(Event obj)
        {
            try
            {
                CurrentCtxUserLog.Events.AddOrUpdate(obj);
                CurrentCtxUserLog.SaveChanges();
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public void InsertClientInfo(ClientInfo ci)
        {
            try
            {
                CurrentCtxUserLog.ClientInfos.AddOrUpdate(ci);
                CurrentCtxUserLog.SaveChanges();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        internal IEnumerable<GetSumFundTrades_Result> GetSumFundTrades(int v1, int v2, int v3)
        {
            throw new NotImplementedException();
        }
    }
}