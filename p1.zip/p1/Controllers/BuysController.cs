﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Data.Entity.Infrastructure;
using Sanay.Lotus.Erm.Lib.Dto;

using System.Web.Mvc;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Enum;
using Stimulsoft.Report;


namespace Sanay.Lotus.Erm.Controllers
{
    public class BuysController : Controller
    {
        // GET: Buys

        [Authorize]
        public ActionResult Index()

        {

            return View();
        }

        [Authorize]
        public ActionResult AddBuy()
        {
            return View();
        }


        [Authorize]
        public ActionResult LoadData()
        {
            try
            {
                
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var symbol = Request.Form.GetValues("symbol").FirstOrDefault();
                var account = Request.Form.GetValues("account").FirstOrDefault();
                var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault();


                using (var sql = new LinqHelper())
                {

                    var result = sql.GetBuySells(start.ToValidMsgInt(), length.ToValidMsgInt(), searchValue,(int)TradeType.Buy, symbol.ToValidMsgString(),  account.ToValidString(),  startDate.ToValidMsgDate(),  endDate.ToValidMsgDate());

                    int recordsTotal = 0;
                    if (result.Count > 0)
                        recordsTotal = result.FirstOrDefault().TotalRow ?? 0;

                    var recordsFiltered = recordsTotal;
                
                    //Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = result
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }



        [HttpGet]
        public JsonResult GetSymbols(string term)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetBuySellsSymbol()
                        .Select(x => new
                        {
                            Id = x.Id,
                            Text = x.Symbol
                        }).ToList();

                    //list.Add(new {Id = -1, Text = "همه"});
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }



        [HttpGet]
        public JsonResult GetAccounts(string term)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetBuySellsAccount()
                        .Select(x => new
                        {
                            Id = x.Id,
                            Text = x.Account
                        }).ToList();
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult GetBrokers(string term)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetBrokers()
                        .Select(x => new
                        {
                            Id = x.Id,
                            Text = x.BrokerCode
                        }).ToList();
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }




        [HttpPost]
        public ActionResult RegisterBuy(BuySell obj)
        {
            using (var sql = new LinqHelper())
            {
                //obj.BuyTotal = obj.BuyTotal.Replace(",", "");
                //obj.BuyFee = obj.BuyFee.Replace(",", "");
                //obj.BuyInterest = obj.BuyInterest.Replace(",", "");
                //obj.BuyTotalAndFee = obj.BuyTotalAndFee.Replace(",", "");
                //obj.SellTotal = obj.SellTotal.Replace(",", "");
                //obj.SellFee = obj.SellFee.Replace(",", "");
                //obj.SellInterest = obj.SellInterest.Replace(",", "");
                //obj.SellTotalAndFee = obj.SellTotalAndFee.Replace(",", "");
                var result = sql.AddBuy(obj);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "AccountingCode" }, JsonRequestBehavior.AllowGet);


            }
        }




    }
}