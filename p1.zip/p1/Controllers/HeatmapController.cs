﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Globalization;
using System.Web.Security;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dic;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Models;
using Sanay.Library.Utility;

namespace Sanay.Lotus.Erm.Controllers
{
    public class HeatmapController : Controller
    {
        // GET: AccountingCode
        [Authorize]

        public ActionResult Index()
        {
            return View();
        }
        [Authorize]
        public ActionResult Add()
        {
            return View();
        }


        [Authorize]
        public ActionResult AddAssetClassType(int Id)
        {
            ViewBag.AssetClassId = Id;
            return View();
        }

        public ActionResult AddDetail(int Id)
        {
            ViewBag.AssetClassId = Id;
            ViewBag.RootId = Request.QueryString["RootId"];
            return View();
        }

  public ActionResult HeatmapDetailes(int Id)
        {
            ViewBag.AssetClassId = Id;
            var result = new LinqHelper().GetAssetClassTypeDetailesById(Id);
            @ViewBag.AssetTitle = result.Name;
            ViewBag.RootId = Request.QueryString["RootId"];
            return View();
        }


        public ActionResult HeatmapTypeDetailes(int Id)
        {

            ViewBag.AssetClassId = Id;
            //ViewBag.MainId = Request.QueryString["MainId"];
            var result = new LinqHelper().GetAssetClasseById(Id);
            @ViewBag.AssetTitle = result.Name;
            return View();
        }




        [HttpPost]
        [Authorize]
        public JsonResult Delete(int Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteHeatMap(Id);
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }


        [HttpPost]
        [Authorize]
        public JsonResult DeleteAssetClassTypeDetailes(int Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteAssetClassTypeDetailes(Id);
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }
        


        [HttpPost]
        [Authorize]
        public JsonResult DeleteDetail(int Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteHeatMapDetailes(Id);
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }



        [HttpGet]
        [Authorize]
        public ActionResult Edit(int Id)
        {
            try
            {
                using (var sql2 = new LinqHelper())
                {
                    LinqHelper sql = new LinqHelper();
                    var result = sql.GetAssetClassesById(Id);
                    return View(result);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }




        [Authorize]
        public ActionResult LoadData()
        {
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //var startDate = Request.Form.GetValues("startDate").FirstOrDefault().ToValidMsgDate();
            //var endDate = Request.Form.GetValues("endDate").FirstOrDefault().ToValidMsgDate();

            //if (endDate == 0) endDate = int.MaxValue;
            try
            {
                using (var sql = new LinqHelper())
                {

                    var User = Assistant.CurrentUser();
                    var result = sql.GetHeatmap(User).ToList();

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    //switch (sortColumn)
                    //{
                    //    case "AccountNumber":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.AccountNumber).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.AccountNumber).ToList();
                    //        break;
                    //    case "Bank":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.Bank).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.Bank).ToList();
                    //        break;
                    //    case "Rate":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.Rate).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.Rate).ToList();
                    //        break;
                    //    case "PayDate":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.PayDate).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.PayDate).ToList();
                    //        break;
                    //    case "Deposit1":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.Deposit1).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.Deposit1).ToList();
                    //        break;
                    //    case "Blocked":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.Blocked).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.Blocked).ToList();
                    //        break;
                    //    case "StartDate":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.StartDate).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.StartDate).ToList();
                    //        break;
                    //    case "MaturityDate":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.MaturityDate).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.MaturityDate).ToList();
                    //        break;
                    //}

                    //paging Data
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();

                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }




        [Authorize]
        public ActionResult LoadDataAssetClassTypeDetailes(int AssetClassId)
        {
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var User = Assistant.CurrentUser();
                    var result = sql.GetAssetClassTypeDetailes(AssetClassId).ToList();

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();

                    //paging Data
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();

                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }




        [Authorize]
        public ActionResult LoadDetailesData()
        {
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //var startDate = Request.Form.GetValues("startDate").FirstOrDefault().ToValidMsgDate();
            var Id2 = Request.Form.GetValues("Id").FirstOrDefault().ToValidMsgDate();

            //if (endDate == 0) endDate = int.MaxValue;
            try
            {
                using (var sql = new LinqHelper())
                {
                    var User = Assistant.CurrentUser();
                    var result = sql.GetHeatMapDetailes(Id2,User).ToList();

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();

                    //paging Data
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();

                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }





        [HttpPost]
        [Authorize]
        public ActionResult Register(AssetClass obj)
        {
            using (var sql = new LinqHelper())
            {
                obj.User = Assistant.CurrentUser();
                var result = sql.InsertHeatMap(obj);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        [Authorize]
        public ActionResult RegisterAssetClassType(AssetClassTypeDetaile obj)
        {
            using (var sql = new LinqHelper())
            {
                obj.RegUser = Assistant.CurrentUser();
                var result = sql.InsertAssetClassTypeDetaile(obj);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        


        [HttpPost]
        [Authorize]
        public ActionResult Update(string Id,string Name)
        {
            using (var sql = new LinqHelper())
            {
                var obj = sql.GetAssetClassesById(Id.TryParseInt32());
                obj.Name = Name;
                sql.UpdateAssetClass(obj);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        [Authorize]
        public ActionResult RegisterDetail(AssetClassDetaile obj)
        {
            using (var sql = new LinqHelper())
            {

                obj.Average = (obj.Impact + obj.likelihood + obj.Vulnerability + obj.SpeedOfOnset) / 4;
                obj.WeightedAverage = (obj.Average * obj.Weight/100);
                obj.RegUser = Assistant.CurrentUser();


                var result = sql.InsertHeatMapDetailes(obj);

                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }









    }
} 