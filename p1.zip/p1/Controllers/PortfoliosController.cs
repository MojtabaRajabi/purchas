﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.Lib.Dto;

namespace Sanay.Lotus.Erm.Controllers
{
    [Authorize]
    public class PortfoliosController : Controller
    {
        // GET: Portfolios
        public ActionResult Index()
        {
            return RedirectToAction("Portfolio");
            //return View();
        }

        public ActionResult Portfolio()
        {
            return View();
        }

        [HttpPost]
        public ActionResult LoadPortfolioData()
        {
            using (var sql = new LinqHelper())
            {
                try
                {
                    int recordsTotal = 0;

                    var portfoliosObjs = sql.GetPortfolio(Assistant.CurrentUser());
                    recordsTotal = portfoliosObjs.Count;
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = portfoliosObjs
                    });

                }
                catch (Exception ex)
                {
                    return Json(new { recordsTotal = 0, data = "" });
                }
            }
        }

        [HttpPost]
        public ActionResult AddPortfolio(string title, string startDate, string endDate, string managerFee, string reinvestmentRate, string bankFee)
        {

            if (string.IsNullOrEmpty(title))
                return Json(new { Result = "ERROR", Records = "0" }, JsonRequestBehavior.AllowGet);

            using (var sql = new LinqHelper())
            {
                try
                {

                    //check title
                    var portfolio = sql.GetPortfolio(Assistant.CurrentUser());

                    var obj = new Portfolio()
                    {
                        Title = title,
                        StartDate = startDate.TryParseInt32(),
                        EndDate = endDate.TryParseInt32(),
                        ManagerFee = managerFee.Replace(",", "").TryParseDecimal(),
                        ReinvestmentRate = reinvestmentRate.Replace(",", "").TryParseDouble(),
                        UserName = Assistant.CurrentUser(),
                        BankFee = bankFee.TryParseDouble(),
                    };

                    if (portfolio.Count() == 0)
                    {
                        var portfolioId = sql.InsertPortfolio(obj);
                        return Json(new { Success = true }, JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        obj.Id = portfolio.FirstOrDefault().Id;
                        sql.UpdatePortfolios(obj);
                        return Json(new { Success = true }, JsonRequestBehavior.AllowGet);
                    }

                }
                catch (Exception ex)
                {
                    return Json(new { Success = false }, JsonRequestBehavior.AllowGet);
                }
            }
        }
        [HttpPost]
        public ActionResult DeletePortfolio(int Id)
        {

            using (var sql = new LinqHelper())
            {
                //check is Portfolio for CurrentUser
                var UserName = sql.GetPortfolioById(Id).FirstOrDefault().UserName;
                if (UserName == Assistant.CurrentUser())
                {
                    try
                    {
                        sql.DeletePortfolio(Id);
                        return Json(new { Success = true }, behavior: JsonRequestBehavior.AllowGet);
                    }
                    catch (Exception ex)
                    {
                        return Json(new { Success = false }, behavior: JsonRequestBehavior.AllowGet);
                    }
                }
            }
            return Json(new { Success = false }, behavior: JsonRequestBehavior.AllowGet);
        }

        public ActionResult PortfolioBonds(int? Id, string PortfolioTitle)
        {
            ViewBag.PortfolioTitle = PortfolioTitle;
            ViewBag.Id = Id;
            return View();
        }

        [HttpPost]
        public ActionResult LoadPortfolioBondsData()
        {
            using (var sql = new LinqHelper())
            {
                try
                {
                    //check
                    var PortfolioId = Request.Form.GetValues("Id").FirstOrDefault().TryParseInt32();
                    var objP = sql.GetPortfolioById(PortfolioId).ToList() ;

                    var UserName = objP.Count > 0 ? objP.FirstOrDefault().UserName : "";
                                    
                    if (UserName == Assistant.CurrentUser())
                    {
                        int recordsTotal = 0;
                        var Objs = sql.GetPortfolioBonds(PortfolioId);
                        recordsTotal = Objs.Count;
                        return Json(new
                        {
                            recordsTotal = Objs.Count,
                            data = Objs
                        });
                    }
                    else
                        return Json(new { recordsTotal = 0, data = "" });
                }
                catch (Exception ex)
                {
                    return Json(new { recordsTotal = 0, data = "" });
                }
            }

        }

        public ActionResult AddPortfolioBonds(string portfolioId, string symbolId, string symbolNumber, string symbolEndRate)
        {
            using (var sql = new LinqHelper())
            {
                try
                {
                    var UserName = sql.GetPortfolioById(portfolioId.TryParseInt32()).FirstOrDefault().UserName;

                    //check
                    var Obj = sql.GetPortfolioBonds(portfolioId.TryParseInt32())
                    .Where(c => c.SymbolId == symbolId.TryParseInt32()).ToList();

                    if (UserName != Assistant.CurrentUser() || Obj.Count > 0
                        || string.IsNullOrEmpty(portfolioId) || string.IsNullOrEmpty(symbolId) || symbolId == "0"
                        || string.IsNullOrEmpty(symbolNumber) || string.IsNullOrEmpty(symbolEndRate))
                    {
                        return Json(new { Success = false }, JsonRequestBehavior.AllowGet);
                    }

                    var obj = new PortfolioBond()
                    {
                        SymbolId = symbolId.TryParseInt32(),
                        SymbolNumber = symbolNumber.ToValidMsgInt(),
                        PortfolioId = portfolioId.TryParseInt32(),
                        RegDate = Assistant.TodayDateInt(),
                        RegTime = Assistant.TimeNowInt(),
                        SymbolEndRate = symbolEndRate.ToValidMsgdecimal(),

                    };

                    sql.InsertPortfolioBonds(obj);

                    return Json(new { Success = true }, JsonRequestBehavior.AllowGet);

                }
                catch (Exception ex)
                {
                    return Json(new { Success = false }, JsonRequestBehavior.AllowGet);

                }
            }

        }

        public ActionResult DeletePortfolioBonds(int Id)
        {
            using (var sql = new LinqHelper())
            {
                try
                {
                    //check is PortfolioBonds for CurrentUser
                    PortfolioBond Obj = sql.GetPortfolioBondsT(Id).FirstOrDefault();
                    string userName = sql.GetPortfolioById((int)Obj.PortfolioId).FirstOrDefault().UserName;
                    if (userName == Assistant.CurrentUser())
                    {
                        sql.DeletePortfolioBonds(Obj);

                        return Json(new { Success = true }, behavior: JsonRequestBehavior.AllowGet);
                    }
                    else
                        return Json(new { Success = false }, behavior: JsonRequestBehavior.AllowGet);
                }
                catch (Exception ex)
                {
                    return Json(new { Success = false }, behavior: JsonRequestBehavior.AllowGet);
                }
            }
        }

        public ActionResult PortfolioDeposits(int? Id, string PortfolioTitle)
        {
            ViewBag.PortfolioTitle = PortfolioTitle;
            ViewBag.Id = Id;

            return View();
        }

        public ActionResult LoadPortfolioDepositsData()
        {
            using (var sql = new LinqHelper())
            {
                try
                {
                    //check
                    var PortfolioId = Request.Form.GetValues("Id").FirstOrDefault().TryParseInt32();
                    var objP = sql.GetPortfolioById(PortfolioId).ToList();

                    var UserName = objP.Count > 0 ? objP.FirstOrDefault().UserName : "";

                    if (UserName == Assistant.CurrentUser())
                    {
                        int recordsTotal = 0;
                        var Objs = sql.GetPortfolioDeposits(PortfolioId);
                        recordsTotal = Objs.Count;
                        return Json(new
                        {
                            recordsTotal = Objs.Count,
                            data = Objs
                        });
                    }
                    else
                        return Json(new{recordsTotal = 0,data = ""});
                    
                }
                catch (Exception ex)
                {
                    return Json(new { recordsTotal = 0, data = "" });
                }
            }

        }

        public ActionResult AddPortfolioDeposits(string portfolioId, string title, string profitRate, string amount)
        {
            using (var sql = new LinqHelper())
            {
                try
                {
                    var UserName = sql.GetPortfolioById(portfolioId.TryParseInt32()).FirstOrDefault().UserName;

                    //check
                    var Obj = sql.GetPortfolioDeposits(portfolioId.TryParseInt32())
                    .Where(c => c.Title == title).ToList();

                    if (UserName != Assistant.CurrentUser() || Obj.Count > 0
                        || string.IsNullOrEmpty(portfolioId) || string.IsNullOrEmpty(title))

                    {
                        return Json(new { Success = false }, JsonRequestBehavior.AllowGet);
                    }

                    var obj = new PortfolioDeposit()
                    {
                        Title = title,
                        ProfitRate = profitRate.Replace(",", "").TryParseDouble(),
                        PortfolioId = portfolioId.TryParseInt32(),
                        Amount = amount.Replace(",", "").TryParseDouble(),

                    };

                    sql.InsertPortfolioDeposits(obj);

                    return Json(new { Success = true }, JsonRequestBehavior.AllowGet);

                }
                catch (Exception ex)
                {
                    return Json(new { Success = false }, JsonRequestBehavior.AllowGet);

                }
            }

        }

        public ActionResult DeletePortfolioDeposits(int Id)
        {
            using (var sql = new LinqHelper())
            {
                try
                {
                    //check is PortfolioBonds for CurrentUser
                    PortfolioDeposit Obj = sql.GetPortfolioDepositsT(Id).FirstOrDefault();
                    string userName = sql.GetPortfolioById((int)Obj.PortfolioId).FirstOrDefault().UserName;
                    if (userName == Assistant.CurrentUser())
                    {
                        sql.DeletePortfolioDeposits(Obj);

                        return Json(new { Success = true }, behavior: JsonRequestBehavior.AllowGet);
                    }
                    else
                        return Json(new { Success = false }, behavior: JsonRequestBehavior.AllowGet);
                }
                catch (Exception ex)
                {
                    return Json(new { Success = false }, behavior: JsonRequestBehavior.AllowGet);
                }
            }

        }


        public ActionResult PortfolioBoard()
        {

            try
            {
                using (var sql = new LinqHelper())
                {
                    var objP = sql.GetPortfolio(Assistant.CurrentUser()).ToList();
                    if (objP.Count > 0)
                    {
                         var obj = objP.FirstOrDefault();
                        ViewBag.Id = obj.Id;
                        ViewBag.StartDate = Assistant.DateToDisplayMode(obj.StartDate);
                        ViewBag.EndDate = Assistant.DateToDisplayMode(obj.EndDate);
                    }
                    else
                    {
                        ViewBag.Id = -1;
                        ViewBag.StartDate = "";
                        ViewBag.EndDate = "";
                    }


                }
            }
            catch
            {

            }
            return View();
        }

        public ActionResult SumPortfolioBonds(string portfolioId)
        {
            using (var sql = new LinqHelper())
            {
                try
                {
                    int id = portfolioId.TryParseInt32();
                    var objP = sql.GetPortfolioById(id).FirstOrDefault();
                    var userName = objP.UserName;

                    //check
                    if (userName == Assistant.CurrentUser())
                    {
                        var obj = sql.GetPortfolio(Assistant.CurrentUser());

                        var objPB = sql.GetPortfolioBonds(id);

                        var objResult = new SumPortfolioDetails()
                        {
                            SumNumber = objPB.Sum(c => c.SymbolNumber),
                            SumTotal = objPB.Sum(c => c.TotalAmount),
                            SumWeightBonds = objPB.Sum(c => c.BondsWeight),
                            SumEfficiencyWeighing = objPB.Sum(c => c.EfficiencyWeighing),
                            SumEfficiencyWeighingWithManagerFee =
                                (double)objPB.Sum(c => c.EfficiencyWeighing) - (double)(objP.ManagerFee),
                        };

                        return Json(objResult, JsonRequestBehavior.AllowGet);

                    }
                    else
                        return Json("", JsonRequestBehavior.AllowGet);
                }
                catch (Exception ex)
                {
                    return Json("", JsonRequestBehavior.AllowGet);
                }
            }
        }


        public ActionResult SumPortfolioDeposits(string portfolioId)
        {
            using (var sql = new LinqHelper())
            {

                try
                {
                    int id = portfolioId.TryParseInt32();
                    var objP = sql.GetPortfolioById(id).FirstOrDefault();
                    var userName = objP.UserName;

                    //check
                    if (userName == Assistant.CurrentUser())
                    {
                        var obj = sql.GetPortfolio(Assistant.CurrentUser());

                        var objPD = sql.GetPortfolioDeposits(id);

                        var objResult = new SumPortfolioDetails()
                        {
                            SumTotal = (decimal?)objPD.Sum(c => c.Amount),
                            SumWeightBonds = objPD.Sum(c => c.DepositWeight),
                            SumEfficiencyWeighing = objPD.Sum(c => c.EfficiencyWeighing),
                            SumEfficiencyWeighingWithManagerFee = (double)objPD.Sum(c => c.EfficiencyWeighing),
                        };

                        return Json(objResult, JsonRequestBehavior.AllowGet);

                    }
                    else
                        return Json("", JsonRequestBehavior.AllowGet);
                }
                catch (Exception ex)
                {
                    return Json("", JsonRequestBehavior.AllowGet);
                }

            }
        }
        [HttpGet]
        public JsonResult GetSymbols()
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetSymbols()
                        .Select(x => new
                        {
                            Id = x.Id,
                            Text = x.Symbol
                        }).ToList();


                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }
    }
}