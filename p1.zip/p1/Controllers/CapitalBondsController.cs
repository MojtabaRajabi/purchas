﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Web.Security;
using OfficeOpenXml.FormulaParsing.Excel.Functions.Text;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dic;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Models;
using Sanay.Library.Utility;
using Stimulsoft.Report.Components;

namespace Sanay.Lotus.Erm.Controllers
{
    public class CapitalBondsController : Controller
    {
        // GET: AccountingCode
        [Authorize]

        public ActionResult Index()
        {
            return View();
        }
        [Authorize]
        public ActionResult Add()
        {
            return View();
        }



        [HttpGet]
        [Authorize]
        public ActionResult Edit(string Id)
        {
            try
            {
                using (var sql2 = new LinqHelper())
                {

                    LinqHelper sql = new LinqHelper();
                    var result = sql.GetCapitalBonds(Guid.Parse(Id));

                    List<Role> objs = new List<Role>();
                    objs.Add(new Role() { Id = 1, Title = " 1 ماهه" });
                    objs.Add(new Role() { Id = 3, Title = " 3 ماهه" });
                    objs.Add(new Role() { Id = 6, Title = " 6 ماهه" });


                    ViewBag.Cycle = new SelectList(objs, "Id", "Title", result.Cycle);

                    return View(result);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        [Authorize]
        public JsonResult Delete(string Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    sql.DeleteCapitalBonds(Guid.Parse(Id));
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }

        [Authorize]
        public ActionResult LoadData()
        {

            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            var startDate = Request.Form.GetValues("startDate").FirstOrDefault().ToValidMsgDate();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault().ToValidMsgDate();

            if (endDate == 0) endDate = int.MaxValue;
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetCapitalBonds().OrderBy(c => c.Id).ToList();
                    if (startDate != 0)
                    {
                         result = sql.GetCapitalBonds().Where(c => (c.DateInputsIpoFee >= startDate) ).OrderBy(c => c.Id).ToList();
                    }

                    if (endDate != 0)
                    {
                         result = sql.GetCapitalBonds().Where(c => (c.DateInputsIpoFee <= endDate)).OrderBy(c => c.Id).ToList();
                    }

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {
                        case "Title":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Title).ToList();
                            else
                                result = result.OrderByDescending(p => p.Title).ToList();
                            break;
                        case "OutputIpoFee":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.OutputIpoFee).ToList();
                            else
                                result = result.OrderByDescending(p => p.OutputIpoFee).ToList();
                            break;
                        case "DateInputsIpoFee":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.DateInputsIpoFee).ToList();
                            else
                                result = result.OrderByDescending(p => p.DateInputsIpoFee).ToList();
                            break;
                        case "InputIpoFee":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.InputIpoFee).ToList();
                            else
                                result = result.OrderByDescending(p => p.InputIpoFee).ToList();
                            break;
                        case "DateOfReturnObligation":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.DateOfReturnObligation).ToList();
                            else
                                result = result.OrderByDescending(p => p.DateOfReturnObligation).ToList();
                            break;
                        case "IpoFee":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.IpoFee).ToList();
                            else
                                result = result.OrderByDescending(p => p.IpoFee).ToList();
                            break;
                        case "IpoDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.IpoDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.IpoDate).ToList();
                            break;
                        case "HoldingFee":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.HoldingFee).ToList();
                            else
                                result = result.OrderByDescending(p => p.HoldingFee).ToList();
                            break;
                        case "HoldingFeeDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.HoldingFeeDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.HoldingFeeDate).ToList();
                            break;
                        case "Advice":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Advice).ToList();
                            else
                                result = result.OrderByDescending(p => p.Advice).ToList();
                            break;
                        case "AdviceDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.AdviceDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.AdviceDate).ToList();
                            break;
                        case "MarketMakingFee":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.MarketMakingFee).ToList();
                            else
                                result = result.OrderByDescending(p => p.MarketMakingFee).ToList();
                            break;
                        case "MarketMakingFeeDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.MarketMakingFeeDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.MarketMakingFeeDate).ToList();
                            break;
                        case "Cycle":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Cycle).ToList();
                            else
                                result = result.OrderByDescending(p => p.Cycle).ToList();
                            break;
                    }

                    //paging Data
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();

                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [HttpPost]
        [Authorize]
        public ActionResult Register(CapitalBond obj)
        {
            using (var sql = new LinqHelper())
            {
                obj.RegUser = Assistant.CurrentUser();
                obj.RegDate = Assistant.TodayDateInt();
                obj.RegTime = Assistant.TimeNowInt();
                var result = sql.InsertCapitalBond(obj);
                sql.AutomaticCapitalBondsInputOutputFlow(result);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        [Authorize]
        public ActionResult PreviewIOFlow(
          string OutputIpoFee 
        , string DateInputsIpoFee 
        , string InputIpoFee 
        , string DateOfReturnObligation 
        , string IpoFee 
        , string IpoDate 
        , string HoldingFee 
        , string HoldingFeeDate 
        , string Advice 
        , string AdviceDate 
        , string MarketMakingFee 
        , string MarketMakingFeeDate 
        , string Cycle
            )
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.PreviewAutomaticCapitalBondsInputOutputFlow(
                           OutputIpoFee.ToValidMsgdouble()
                        ,  DateInputsIpoFee.ToValidMsgDate()
                        ,  InputIpoFee.ToValidMsgdouble()
                        ,  DateOfReturnObligation.ToValidMsgDate()
                        ,  IpoFee.ToValidMsgdouble()
                        ,  IpoDate.ToValidMsgDate()
                        ,  HoldingFee.ToValidMsgdouble()
                        ,  HoldingFeeDate.ToValidMsgDate()
                        ,  Advice.ToValidMsgdouble()
                        ,  AdviceDate.ToValidMsgDate()
                        ,  MarketMakingFee.ToValidMsgdouble()
                        ,  MarketMakingFeeDate.ToValidMsgDate()
                        ,  Cycle.TryParseInt32()
                        );
                    return Json(new
                    {
                        data = result
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        [HttpPost]
        public ActionResult Update(CapitalBond obj)
        {
            using (var sql = new LinqHelper())
            {

                obj.RegUser = Assistant.CurrentUser();
                obj.RegDate = Assistant.TodayDateInt();
                obj.RegTime = Assistant.TimeNowInt();
                var item = sql.GetCapitalBonds(obj.Id);
                if (item != null)
                {
                    sql.DeleteCapitalBonds(obj.Id);
                    var result = sql.InsertCapitalBond(obj);
                    sql.AutomaticCapitalBondsInputOutputFlow(result);
                    //var result = sql.UpdateFutureDebtBond(obj);
                }
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);


            }
        }


    }
}