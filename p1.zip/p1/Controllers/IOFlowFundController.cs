﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Globalization;
using System.Web.Security;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dic;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Models;
using Sanay.Library.Utility;

namespace Sanay.Lotus.Erm.Controllers
{
    public class IOFlowFundController : Controller
    {
        // GET: AccountingCode
        [Authorize]

        public ActionResult Index()
        {
            return View();
        }
        [Authorize]
        public ActionResult Add()
        {
            return View();
        }

    

        [HttpGet]
        [Authorize]
        public ActionResult Edit(Guid Id)
        {
            try
            {
                using (var sql2 = new LinqHelper())
                {

                    LinqHelper sql = new LinqHelper();
                    var result = sql.GetIOFlowFundById(Id);
                    ViewBag.Id = result.Id;

                    List<Role> objs = new List<Role>();
                    objs.Add(new Role() { Id = 1, Title = " 1 ماهه" });
                    objs.Add(new Role() { Id = 2, Title = " 2 ماهه" });
                    objs.Add(new Role() { Id = 3, Title = " 3 ماهه" });
                    objs.Add(new Role() { Id = 4, Title = " 4 ماهه" });
                    objs.Add(new Role() { Id = 5, Title = " 5 ماهه" });
                    objs.Add(new Role() { Id = 6, Title = " 6 ماهه" });
                    objs.Add(new Role() { Id = 7, Title = " 7 ماهه" });
                    objs.Add(new Role() { Id = 8, Title = " 8 ماهه" });
                    objs.Add(new Role() { Id = 9, Title = " 9 ماهه" });
                    objs.Add(new Role() { Id = 10, Title = " 10 ماهه" });
                    objs.Add(new Role() { Id = 11, Title = " 11 ماهه" });
                    objs.Add(new Role() { Id = 12, Title = " 12 ماهه" });

                    ViewBag.Cycle = new SelectList(objs, "Id", "Title", result.Cycle);

                    return View(result);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        [Authorize]
        public JsonResult Delete(Guid Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteIOFlowFunds(Id);
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }
        
        [Authorize]
        public ActionResult LoadData()
        {
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            var startDate = Request.Form.GetValues("startDate").FirstOrDefault().ToValidMsgDate();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault().ToValidMsgDate();

            if (endDate == 0) endDate = int.MaxValue;
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetIOFlowFund()
                        .Where(c=>c.EndDate>= startDate && c.EndDate<=endDate)
                        .OrderBy(c=>c.Id).ToList();
                    
                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {
                        case "Name":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Name).ToList();
                            else
                                result = result.OrderByDescending(p => p.Name).ToList();
                            break;
                        case "Num":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Num).ToList();
                            else
                                result = result.OrderByDescending(p => p.Num).ToList();
                            break;
                        case "Cycle":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Cycle).ToList();
                            else
                                result = result.OrderByDescending(p => p.Cycle).ToList();
                            break;
                        case "ProfitSharingDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.ProfitSharingDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.ProfitSharingDate).ToList();
                            break;
                        case "ProfitRate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.ProfitRate).ToList();
                            else
                                result = result.OrderByDescending(p => p.ProfitRate).ToList();
                            break;
                     
                        case "EndDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.EndDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.EndDate).ToList();
                            break;
                        case "BuyUnit":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.BuyUnit).ToList();
                            else
                                result = result.OrderByDescending(p => p.BuyUnit).ToList();
                            break;
                        case "BuyUnitDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.BuyUnitDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.BuyUnitDate).ToList();
                            break;
                     
                    }

                    //paging Data
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();

                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [HttpPost]
        [Authorize]
        public ActionResult Register(IOFlowFund obj)
        {
            using (var sql = new LinqHelper())
            {
                obj.RegUser = Assistant.CurrentUser();
                obj.RegDate = Assistant.TodayDateInt();
                obj.RegTime = Assistant.TimeNowInt();

                var result = sql.InsertIOFlowFund(obj);

                sql.AutoGenerateIOFlowFund(result);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }

 

        [HttpPost]
        [Authorize]
        public ActionResult PreviewIOFlow(string Name
                                         , string Num
                                         , string ProfitSharingDate
                                         , string ProfitRate
                                         , string EndDate
                                         , string BuyUnit
                                         , string BuyUnitDate
                                         , string Cycle
                                         , string NAV
                                         , string NumUnitsInvested
                                         , string PriceRevocation
                                         , string SellUnit
                                         , string SellUnitDate
                                         , string PriceIssue

            )
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.PreviewAutomaticIOFlowFundInputOutputFlowCycle(
                                                                                     Num.ToValidMsglong()
                                                                                    , ProfitSharingDate.ToValidMsgInt()
                                                                                    , ProfitRate.ToValidMsgInt()
                                                                                    , EndDate.ToValidMsgDate()
                                                                                    , BuyUnit.ToValidMsgInt()
                                                                                    , BuyUnitDate.ToValidMsgInt()
                                                                                    , Cycle.ToValidMsgInt()
                                                                                    , NAV.ToValidMsglong()
                                                                                    , NumUnitsInvested.ToValidMsgInt()
                                                                                    , PriceRevocation.ToValidMsgInt()
                                                                                    , SellUnit.ToValidMsgInt()
                                                                                    , SellUnitDate.ToValidMsgInt()
                                                                                    , PriceIssue.ToValidMsgInt()
                                                                                    

                        
                         );
                    result = result == null ? new List<PreviewAutomaticIOFlowFundInputOutputFlow_Result>() : result;
                    return Json(new
                    {
                        data =result
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        [HttpPost]
        public ActionResult Update(IOFlowFund obj)
        {
            using (var sql = new LinqHelper())
            {
                obj.RegUser = Assistant.CurrentUser();
                obj.RegDate = Assistant.TodayDateInt();
                obj.RegTime = Assistant.TimeNowInt();

                var item =sql.GetIOFlowFundById(obj.Id);
                if (item != null)
                {
                    sql.DeleteIOFlowFunds(obj.Id);
                    var result = sql.InsertIOFlowFund(obj);
                    sql.AutoGenerateIOFlowFund(result);
                }
                //var result = sql.UpdateDeposit(obj);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "AccountingCode" }, JsonRequestBehavior.AllowGet);
            }
        }





    }
} 