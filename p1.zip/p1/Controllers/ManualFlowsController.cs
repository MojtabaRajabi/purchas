﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Web.Security;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dic;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Models;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.Lib.Enum;

namespace Sanay.Lotus.Erm.Controllers
{
    public class ManualFlowsController : Controller
    {

        // GET: AccountingCode
        [Authorize]
        public ActionResult Index()
        {
            return View();
        }

        [Authorize]
        public ActionResult OutputCosts()
        {
            return View();
        }
        [Authorize]
        public ActionResult Add(int Type)
        {
            ViewBag.Message = Type;
            ViewBag.type = Type;
            switch (Type)
            {
                case (int)ManualFlowType.CapitalIncreases:
                    ViewBag.Title = " افزایش سرمایه ";
                    ViewBag.link = "/ManualFlows";
                    ViewBag.AddLink = "/ManualFlows/Add?Type=1";

                    break;
                case (int)ManualFlowType.OutputCosts:
                    ViewBag.Title = "  سایر هزینه‌های خروجی ";
                    ViewBag.link = "/ManualFlows/OutputCosts";
                    ViewBag.AddLink = "/ManualFlows/Add?Type=2";

                    break;
                default:
                    ViewBag.Title = "";
                    break;
            }
            
            return View();
        }
    


        [HttpPost]
        [Authorize]
        public ActionResult Edit(ManualFlow std)
        {

            return RedirectToAction("Index");
        }


        [HttpPost]
        [Authorize]
        public JsonResult Delete(string Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteManualFlows(Guid.Parse(Id));

                  

                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }





        [Authorize]
        public ActionResult LoadData()
        {
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            var startDate = Request.Form.GetValues("startDate").FirstOrDefault().ToValidMsgDate();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetCapitalIncreases().Where(c => c.ApplyDate >= startDate && c.ApplyDate <= endDate).ToList(); ;

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {
                        case "Val":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Val).ToList();
                            else
                                result = result.OrderByDescending(p => p.Val).ToList();
                            break;
                        case "Description":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Description).ToList();
                            else
                                result = result.OrderByDescending(p => p.Description).ToList();
                            break;
                        case "ApplyDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.ApplyDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.ApplyDate).ToList();
                            break;
                      
                    }

                    //paging Data
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();


                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }
        [Authorize]
        public ActionResult LoadOutputCostsData()
        {
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            var startDate = Request.Form.GetValues("startDate").FirstOrDefault().ToValidMsgDate();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault().ToValidMsgDate();

            if (endDate == 0) endDate = int.MaxValue;
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetOutputCosts().Where(c => c.ApplyDate >= startDate && c.ApplyDate <= endDate).ToList();

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {
                        case "Val":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Val).ToList();
                            else
                                result = result.OrderByDescending(p => p.Val).ToList();
                            break;
                        case "Description":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Description).ToList();
                            else
                                result = result.OrderByDescending(p => p.Description).ToList();
                            break;
                        case "ApplyDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.ApplyDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.ApplyDate).ToList();
                            break;
                      
                    }

                    //paging Data
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();

                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }
         

        [HttpGet]
        [Authorize]
        public ActionResult Edit(string Id,int TypeId)
        {
            try
            {
                ViewBag.type = TypeId;
                switch (TypeId)
                {
                    case (int)ManualFlowType.CapitalIncreases:
                        ViewBag.Title = " افزایش سرمایه ";
                        break;
                    case (int)ManualFlowType.OutputCosts:
                        ViewBag.Title = " هزینه های خروجی غیرقابل پیش بینی ";
                        break;
                    default:
                        ViewBag.Title = "";
                        break;
                }

                using (var sql2 = new LinqHelper())
                {
                  
                    LinqHelper sql = new LinqHelper();
                    var result = sql.GetCapitalIncrease(Guid.Parse(Id));
                    //Role department = await db.Departments.FindAsync(id);
                                     
                    return View(result);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost, ActionName("Edit")]
        [Authorize]
        public ActionResult EditPost(string id)
        {


            if (id == null)
            {
                // return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            LinqHelper sql = new LinqHelper();
            var CapitalInc = sql.GetCapitalIncrease(Guid.Parse(id));

            //if (TryUpdateModel(Code, "",
            //    new string[] { "FirstName", "LastName", "Role", "Email", "Mobile" }))
            //{
            try
            {
                sql.UpdateManualFlow(CapitalInc);
                //db.SaveChanges();
                return RedirectToAction("Admin");
            }
            catch (RetryLimitExceededException /* dex */)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");
            }
            //}
            // return View(studentToUpdate);
            return View();

        }


         



        [HttpPost]
        [Authorize]
        public ActionResult Register(ManualFlow obj)
        {
            using (var sql = new LinqHelper())
            {
             
                obj.RegDate = Convert.ToInt32(Assistant.MiladiToShamsi(Assistant.TodayDateIntMiladi()));
                obj.RegTime = Assistant.TimeNowInt();
                obj.RegUser = Assistant.CurrentUser();

                // return Json(login.RegisterUser(register), JsonRequestBehavior.AllowGet);
                var result = sql.InsertManualFlow(obj);
                switch (obj.TypeId)
                {
                    case (int)ManualFlowType.CapitalIncreases:
                        sql.AutomaticManualFlowsCapitalIncreasesInputOutputFlow(result);
                        break;
                    case (int)ManualFlowType.OutputCosts:
                        sql.AutomaticManualFlowsOutputCostsInputOutputFlow(result);
                        break;
                }
                

                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        [Authorize]
        public ActionResult PreviewIOFlow(string TypeId, string Val, string ApplyDate)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    switch (TypeId.TryParseInt32())
                    {
                        case (int)ManualFlowType.CapitalIncreases:
                            var result = sql.PreviewAutomaticManualFlowsCapitalIncreasesInputOutputFlow(ApplyDate.ToValidMsgDate(), Val.ToValidMsgdouble()).ToList();
                            return Json(new { data = result });
                        case (int)ManualFlowType.OutputCosts:
                            var result2 = sql.PreviewAutomaticManualFlowsOutputCostsInputOutputFlow(ApplyDate.ToValidMsgDate(), Val.ToValidMsgdouble()).ToList();
                            return Json(new { data = result2 });
                    }

                    return Json(new{data = ""});
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }



        [HttpPost]
        public ActionResult Update(ManualFlow obj)
        {
            using (var sql = new LinqHelper())
            {
                obj.RegDate = Convert.ToInt32(Assistant.MiladiToShamsi(Assistant.TodayDateIntMiladi()));
                obj.RegTime = Assistant.TimeNowInt();
                obj.RegUser = Assistant.CurrentUser();

                //sql.UpdateManualFlow(obj);
             
                switch (obj.TypeId)
                {
                    case (int)ManualFlowType.CapitalIncreases:
                        var item = sql.GetManualFlowById(obj.Id);
                        if (item != null)
                        {
                            sql.RemoveManualFlowsCapitalIncreases(obj.Id);
                            var result1 = sql.InsertManualFlow(obj);
                            sql.AutomaticManualFlowsCapitalIncreasesInputOutputFlow(result1);
                        }
                        break;
                    case (int)ManualFlowType.OutputCosts:
                         item = sql.GetManualFlowById(obj.Id);
                        if (item != null)
                        {
                            sql.RemoveManualFlowsOutputCosts(obj.Id);
                            var result2 = sql.InsertManualFlow(obj);
                            sql.AutomaticManualFlowsOutputCostsInputOutputFlow(result2);
                        }
                        break;
                }

                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "UpdateCapitalIncreases" }, JsonRequestBehavior.AllowGet);


            }
        }


    }
}