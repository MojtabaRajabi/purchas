﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OfficeOpenXml;
using Sanay.Library.Utility;
using System.Web.Routing;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dto;
using OfficeOpenXml;

namespace Sanay.Lotus.Erm.Controllers
{
    public class FilesController : Controller
    {
        [Authorize]
        public ActionResult Index(string Username)
        {
            if (Username == null) { ViewBag.Username = "همه"; } else { ViewBag.Username = Username; }
            return View();
        }

        [Authorize]
        public ActionResult LoadData()
        {
            try
            {
                // SqlHelper sql = new SqlHelper();
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form
                    .GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]")
                    .FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var startDate = Request.Form.GetValues("StartDate").FirstOrDefault();
                var endDate = Request.Form.GetValues("EndDate").FirstOrDefault();
                var name = Request.Form.GetValues("Name").FirstOrDefault();
                var FileType = Request.Form.GetValues("FileType").FirstOrDefault();
                var UserAcc = Request.Form.GetValues("UserAcc").FirstOrDefault();

                if (UserAcc == "همه") { UserAcc = "%%"; }



                using (var sql = new LinqHelper())
                {

                    var result = sql.GetFiles(name.ToValidMsgStringWithPresentage(), 
                                             start.ToValidMsgDate(),
                                             endDate.ToValidMsgDate(),
                                             FileType.ToValidMsgInt(),
                                             UserAcc);


                    //Paging Size (10,20,50,100)  
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;

                    // Getting all Customer data  
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    //Paging   
                    var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [HttpGet]
        public JsonResult GetUsers()
        {

            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetUserAcc()
                        .Select(x => new
                        {
                            Id = x.UserName,
                            Text = x.FullName
                        }).ToList();

                    //list.Add(new {Id = -1, Text = "همه"});
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }


        [HttpGet]
        public JsonResult GetFileType()
        {

            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetFileType()
                        .Select(x => new
                        {
                            Id = x.Id,
                            Text = x.Title
                        }).ToList();

                    //list.Add(new {Id = -1, Text = "همه"});
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }
     

        [Authorize]
        public void DownloadFile(int id)
        {
            using (var sql = new LinqHelper())
            {
                var result = sql.GetFileById(id);
                if(result==null)return;
                using (var memoryStream = new MemoryStream(result.Binary))
                {
                    //Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    //here i have set filname as Students.xlsx
                    Response.AddHeader("content-disposition", "attachment;  filename=" + result.Name +"-"+ result.Id + "(" + result.RegDate +"-"+ result.Sender + ")"+ result.Extension );

                    memoryStream.WriteTo(Response.OutputStream);
                    Response.Flush();
                    Response.End();
                    Response.Clear();
                }
            }
     
           
        }


    





    }
}