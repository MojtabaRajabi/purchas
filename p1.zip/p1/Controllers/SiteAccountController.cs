﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using System.Web.Security;
using System.Web.UI;
using MVCPersianCaptcha.Models;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.DataAccess.HelperUserLog;
using Sanay.Lotus.Erm.Lib.Dic;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Lib.Enum;
using Sanay.Lotus.Erm.Models;



namespace Sanay.Lotus.Erm.Controllers
{
    public class SiteAccountController : Controller
    {


         // GET: SiteAccount
         //[AllowAnonymous]
        public ActionResult Index()
        {
            return RedirectToAction("Login");
        }

        [AllowAnonymous]
        public ActionResult Main(string userName)
        {
            if (userName != null)//todo : have secure problem
            {
                using (var sql = new LinqHelper())
                {
                    //UserAccount emp = sql.GetCurrentUser(userName);
                    //ViewBag.Employee = emp;
                    return Redirect("/admin");
                }
            }
            else
            {
                return RedirectToAction("Login");
            }
        }


        [AllowAnonymous]
        public ActionResult Login()
        {
            System.Web.HttpContext.Current.Session["Captcha@@"] = 0;


            return View();
        }


        [HttpPost, ValidateCaptchaAttribute, ValidateAntiForgeryToken]
        public ActionResult Index(LogOnModel model)
        {
            if (!ModelState.IsValid) return View(model);

            TempData["message"] = "کد امنیتی را به درستی وارد کرده اید";

            return View(new LogOnModel { UserName = "", CaptchaInputText = "" });
        }
        [AllowAnonymous]
        [NoBrowserCache]
        [OutputCache(Location = OutputCacheLocation.None, NoStore = true, Duration = 0, VaryByParam = "None")]
        public CaptchaImageResult CaptchaImage(string rndDate)
        {

            return new CaptchaImageResult();
        }


         

        [AllowAnonymous]
        public ActionResult Register()
        {
            return View();
        }


        [AllowAnonymous]
        public ActionResult LogOut()
        {
            this.ControllerContext.HttpContext.Response.Cookies.Remove("cookierisk@@");
            Session.Abandon();
            Session.Clear();
            Session.RemoveAll();
            System.Web.Security.FormsAuthentication.SignOut();
            FormsAuthentication.SignOut();


            return RedirectToAction("Login");
        }




        [HttpPost, ValidateCaptchaAttribute, AllowAnonymous]
        public ActionResult CheckLogin( LogOnModel model)
        {
            UserAccount emp = new UserAccount();

            emp.UserName = model.UserName;
            emp.Password = model.Password;
            var controlCap = Convert.ToInt32(System.Web.HttpContext.Current.Session["Captcha@@"]);

            if (ModelState.IsValid || controlCap == 0)
            {
                System.Web.HttpContext.Current.Session["Captcha@@"] = 2;

                LinqHelper login = new LinqHelper();
                var result = login.CheckLogin(emp);
                if (result != null)
                {
                    FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(1,
                        result.UserName,
                        DateTime.Now,
                        DateTime.Now.AddMinutes(30), // value of time out property
                        false, // Value of IsPersistent property
                               //result.Role.ToString()+","+ result.FirstName,
                        result.Role.ToString(),
                        FormsAuthentication.FormsCookiePath);

                    // Encrypt the ticket.
                    string encTicket = FormsAuthentication.Encrypt(ticket);

                    // Create the cookie.
                    this.ControllerContext.HttpContext.Response.Cookies.Add(new HttpCookie(FormsAuthentication.FormsCookieName, encTicket));

                    //FormsAuthentication.SetAuthCookie(emp.UserName, false);

                    //if (!Roles.IsUserInRole(emp.UserName, result.Role.ToString()))
                    //{
                    //    Roles.AddUserToRole(emp.UserName, result.Role.ToString());
                    //}

                    //Response.ContentType = "text/html";
                    //Response.Charset = "UTF-8";
                    //Response.Cookies["cookie"].Expires = DateTime.Now.AddDays(-1);
                    //Response.Cookies["FullName"].Value = result.FullName;
                       
                    HttpCookie cookie = new HttpCookie("cookierisk@@");
                    cookie.Expires = DateTime.Now.AddDays(3);
                    cookie.Values.Add("FullName", Server.UrlEncode(result.FullName));
                    cookie.Values.Add("CountFile", Server.UrlEncode(result.CountFile.ToString()));
                    Response.Cookies.Add(cookie);


                    var sql = new LinqHelper();
                    var userPermissions = sql.GetPermissionsByUsername(result.UserName);
                    if (userPermissions == null)
                    {
                        Session.Abandon();
                        Session.Clear();
                        Session.RemoveAll();
                        System.Web.Security.FormsAuthentication.SignOut();
                        FormsAuthentication.SignOut();
                        return Json(new MessageResponse { Success = false, Message = "خطای مجوز - مجوزهای کاربر تعریف نشده است", ReturnUrl = "" });
                    }
                    string permissionsJson = new JavaScriptSerializer().Serialize(userPermissions);
                    cookie.Values.Add("UserPermissions@@", Server.UrlEncode(Assistant.EncryptString(permissionsJson, result.UserName)));



                    Response.Cookies.Add(cookie);
                    AssistantClientInfo.RegisterClientInfo(HttpContext, result.UserName, UserStatus.Login);
                    return Json(new MessageResponse { Success = true, Message = result.Role.ToString(), ReturnUrl = SiteUrl.SiteUrls[result.Role ?? 0] });
                }
                else
                {
                    AssistantClientInfo.RegisterClientInfo(HttpContext, emp.UserName, UserStatus.LoginError);
                }
            }
            else
            {

                return Json(new MessageResponse { Success = false, Message = "CaptchaErr", ReturnUrl = "" });
            }

            return Json(new MessageResponse { Success = false, Message = "", ReturnUrl = "" });

        }



    }
}