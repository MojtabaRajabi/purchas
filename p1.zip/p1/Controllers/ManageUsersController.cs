﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Models;
 

namespace Sanay.Lotus.Erm.Controllers
{
    public class ManageUsersController : Controller
    {
        // GET: ManageUserse
        [Authorize]
        public ActionResult Index()
        {
            return View();
        }
        [Authorize]
        public ActionResult Users()
        {
            return View(); 
        }

        [HttpGet]
        [Authorize]
        public ActionResult EditPermissions(string Username)
        {
            try
            {

                using (var sql2 = new LinqHelper())
                {
                    LinqHelper sql = new LinqHelper();
                    var result = sql.GetPermissionsByUsername(Username);
                    if (result != null)
                    {
                        ViewBag.IsCompany = result.IsCompany;
                        ViewBag.IsDebtBoard = result.IsDebtBoard;
                        ViewBag.IsFinancial = result.IsFinancial;
                        ViewBag.IsFund = result.IsFund;
                        ViewBag.IsSetting = result.IsSetting;
                        ViewBag.IsRisk = result.IsRisk;
                        ViewBag.IsHeatmap = result.IsHeatmap;
                    }
                    ViewBag.UserName = Username;

                    return View(result);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Username, ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }






        [HttpPost]
        [Authorize]
        public ActionResult RegisterUser(User obj)
        {
            using (var sql = new LinqHelper())
            {
                //obj.Password = obj.Password;//Assistant.EncryptString(obj.Password + obj.UserName + Assistant.TodayDateInt());
                obj.Password = Assistant.EncryptString(obj.Password + obj.UserName + Assistant.TodayDateInt());
                obj.RegDate = Assistant.TodayDateInt();
                obj.RegTime = Assistant.TimeNowInt();
                obj.StatusId = 1;
                var result = sql.InsertUser(obj);
                return Json(new MessageResponse { Success = true, Message = result.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


       

        [HttpPost]
        [Authorize]
        public ActionResult Edit(UserAccount std)
        {
            return RedirectToAction("Users");
        }


        //---------------------------------------------------------------------
        [Authorize]
        public ActionResult LoadData()
        {
            try
            {
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form
                    .GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]")
                    .FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();


                using (var sql = new LinqHelper())
                {
                    var result = sql.GetUsersByFilter();

                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {
                        case "UserName":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.UserName).ToList();
                            else
                                result = result.OrderByDescending(p => p.UserName).ToList();
                            break;
                        case "FirstName":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.FirstName).ToList();
                            else
                                result = result.OrderByDescending(p => p.FirstName).ToList();
                            break;
                        case "LastName":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.LastName).ToList();
                            else
                                result = result.OrderByDescending(p => p.LastName).ToList();
                            break;
                        case "Email":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Email).ToList();
                            else
                                result = result.OrderByDescending(p => p.Email).ToList();
                            break;
                        case "_Role":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p._Role).ToList();
                            else
                                result = result.OrderByDescending(p => p._Role).ToList();
                            break;
                        case "RegDateString":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.RegDateString).ToList();
                            else
                                result = result.OrderByDescending(p => p.RegDateString).ToList();
                            break;
                        case "RegTimeString":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.RegTimeString).ToList();
                            else
                                result = result.OrderByDescending(p => p.RegTimeString).ToList();
                            break;

                        case "Elapsed":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Elapsed).ToList();
                            else
                                result = result.OrderByDescending(p => p.Elapsed).ToList();
                            break;

                    }



                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging 
                    List<Lib.Dto.UserAcc> data = new List<Lib.Dto.UserAcc>();
                    //data = result.Skip(skip).Take(pageSize).ToList();
                    for (int i = 0; i <= result.Count - 1; i++)
                    {
                        UserAcc obj = new UserAcc();
                        obj.Id = i;
                        obj.FirstName = result[i].FirstName;
                        obj.LastName = result[i].LastName;
                        obj.UserName = result[i].UserName;
                        //obj.Password = result[i].Password;
                        obj.Email = result[i].Email;
                        obj.Mobile = result[i].Mobile;
                        obj.Role = result[i].Role;
                        obj._Role = result[i]._Role;
                        obj.StatusId = result[i].StatusId;
                        obj.RegDateString = result[i].RegDateString;
                        obj.RegTimeString = result[i].RegTimeString;
                        obj.Elapsed = result[i].Elapsed;
                        data.Add(obj);
                    }
                    data = data.Skip(skip).Take(pageSize).ToList();

                    //Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [HttpGet]
        [Authorize]
        public ActionResult Edit(string id)
        {
            try
            {
                var username = id;
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetUserByUsername(username);
                    //Role department = await db.Departments.FindAsync(id);
                    List<Role> objs = new List<Role>();
                    objs.Add(new Role() { Id = 1, Title = "admin" });
                    objs.Add(new Role() { Id = 2, Title = "user" });

                    ViewBag.Role = new SelectList(objs, "Id", "Title", result.Role);
                    return View(result);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Authorize]
        public ActionResult UpdateUserAccount(User obj)
        {
            using (var sql = new LinqHelper())
            {
                var user = sql.GetUserByUsername(obj.UserName);
                user.FirstName = obj.FirstName;
                user.LastName = obj.LastName;
                user.UserName = obj.UserName;
                user.Email = obj.Email;
                user.Mobile = obj.Mobile;
                user.Role = obj.Role;
                user.StatusId = obj.StatusId;
                var result = sql.UpdateUserAcc(user);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "ManageUser" }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        [Authorize]
        public ActionResult UpdatePermissions(Permission obj)
        {
            using (var sql = new LinqHelper())
            {

                //var permission = sql.GetPermissionsByUsername(obj.UserName);
                //permission.IsCompany = obj.IsCompany;
                //permission.IsDebtBoard = obj.IsDebtBoard;
                //permission.IsFinancial = obj.IsFinancial;
                //permission.IsFund = obj.IsFund;
                //permission.IsSetting = obj.IsSetting;

                var result = sql.UpdatePermission(obj);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "ManageUser" }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        [Authorize]
        public JsonResult Delete_User(string Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteUser(Id);
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }


        [HttpPost]
        [Authorize]
        public JsonResult ResetPassword(string userName)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var user = sql.GetUserByUsername(userName);
                    user.Password = Assistant.EncryptString(userName + userName + user.UserName + user.RegDate);
                    user.StatusId = 2;
                    sql.UpdateUserAcc(user);
                    return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = false, Message = "خطا", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        [Authorize]
        public JsonResult GetUserInfo()
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetUserInfo(Assistant.CurrentUser());
                    return Json(new
                    {
                        Success = true,
                        Result = result,
                        ReturnUrl = "",
                    });
                }
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    Success = false,
                    Result = "",
                    ReturnUrl = "",
                });
            }

        }


        [HttpPost]
        public JsonResult LoadEventsChart(string Holder)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var TodayDate = Assistant.TodayDateInt();
                    var lastWeekDate = Assistant.LastWeek();
                    var result = sql.GetEventsByFilter("%%", "%%", "%%", lastWeekDate, TodayDate, 0, 0, 0, int.MaxValue).ToList();
                    var list = result.ToList().GroupBy(info => new {
                                                                                                info.UserName,
                                                                                                info.RegDate,})
                       .Select(group => new
                       {
                           Metric = group.Key,
                           UserName = group.First().UserName,
                           RegDate=group.First()._CreateDate,
                           Count = group.Count()
                       }).ToList();


                    list=list.OrderBy(c => c.RegDate).ToList();
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }






        [HttpPost]
        public JsonResult LoadHourlyUserEventsChart(string PDate)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var date=Assistant.TodayDateInt();
                    if (PDate != null)
                          date = PDate.ToValidMsgDate();

                     var result = sql.GetUsersDailyEvents(date).ToList();


                 
                     return Json(result, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }


    }
}