﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.Lib.Dto;

namespace Sanay.Lotus.Erm.Controllers
{
    [ Authorize]
    public class FundDividendsController : Controller
    {
        // GET: FundDividends
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult AddDividends()
        {
            return View();
        }

        [HttpPost]
        public ActionResult RegisterDividends(FundDividend obj)
        {
            using (var sql = new LinqHelper())
            {
                obj.RegUser = Assistant.CurrentUser();
                obj.RegDate = Assistant.TodayDateInt();
                obj.RegTime = Assistant.TimeNowInt();

                var result = sql.InsertFundDividends(obj);
                sql.AutomaticDividendsFundIOFlowCycle(result, (int)obj.FundId);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public ActionResult EditDividends(Guid Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetFundDividendById(Id);
                    return View(result);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        public ActionResult UpdateDividends(FundDividend obj)
        {
            using (var sql = new LinqHelper())
            {
                obj.RegUser = Assistant.CurrentUser();
                obj.RegDate = Assistant.TodayDateInt();
                obj.RegTime = Assistant.TimeNowInt();

                var item = sql.GetFundDividendById(obj.Id);
                if (item != null)
                {
                    sql.DeleteFundDividends(obj.Id, (int)obj.FundId);
                    var result = sql.InsertFundDividends(obj);
                    sql.AutomaticDividendsFundIOFlowCycle(result, (int)obj.FundId);
                }
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "AccountingCode" }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult DeleteDividends(Guid Id, int fundId)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteFundDividends(Id, fundId);
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }

        public ActionResult LoadData()
        {
            //return null;
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            //var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            var startDate = Request.Form.GetValues("startDate").FirstOrDefault().ToValidMsgDate();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault().ToValidMsgDate();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault().ToValidMsgInt();

            if (endDate == 0) endDate = int.MaxValue;
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetFundDividendByFundId(fundId).Where(c => c.InterestDate >= startDate && c.InterestDate <= endDate).OrderBy(c => c.Id).ToList();

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {
                        case "InterestDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.InterestDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.InterestDate).ToList();
                            break;
                        case "InterestRate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.InterestRate).ToList();
                            else
                                result = result.OrderByDescending(p => p.InterestRate).ToList();
                            break;
                        case "Nav":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Nav).ToList();
                            else
                                result = result.OrderByDescending(p => p.Nav).ToList();
                            break;
                        case "IssueCount":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.IssueCount).ToList();
                            else
                                result = result.OrderByDescending(p => p.IssueCount).ToList();
                            break;
                    }

                    //paging Data
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();

                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        [HttpPost]
        public ActionResult PreviewIOFlow(string InterestRate, string Nav, string InterestDate)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.PreviewAutomaticFundDividendsInputOutputFlowCycle(InterestRate.ToValidMsgdouble(), Nav.ToValidMsgdouble(), InterestDate.ToValidMsgInt());
                    return Json(new
                    {
                        data = result
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        [HttpPost]
        public ActionResult GetLastData(string date, string FundId)
        {
            using (var sql = new LinqHelper())
            {
                var nav = sql.GetLastNavByDate(date.ToValidMsgInt(),FundId.ToValidMsgInt());
                var data = new {nav= nav==null?"": nav._SaleValue,
                    IssueCount = nav==null?"":nav._IssuedUnitCount ,
                    date = nav == null ? "" : nav._Date
                };

                return Json(data, JsonRequestBehavior.AllowGet);
            }    
        }
    }
}