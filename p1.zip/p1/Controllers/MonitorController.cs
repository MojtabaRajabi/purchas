﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Library.Utility;

namespace Sanay.Lotus.Erm.Controllers
{
    public class MonitorController : Controller
    {
        // GET: Monitor
        public ActionResult Index()
        {
            return View();
        }

        [Authorize]
        public ActionResult LoadData()
        {
            try
            {

                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                //var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                //var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                //var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var serviceType = Request.Form.GetValues("serviceType").FirstOrDefault();
                var logType = Request.Form.GetValues("logType").FirstOrDefault();
                var statusType = Request.Form.GetValues("statusType").FirstOrDefault();
                var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetlogsByFilter(serviceType.ToValidMsgInt(), logType.ToValidMsgInt()
                        , statusType.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), start.ToValidMsgInt(), length.ToValidMsgInt());

                    int recordsTotal = 0;
                    if (result.Count > 0)
                        recordsTotal = result.FirstOrDefault().TotalRow ?? 0;

                    var recordsFiltered = recordsTotal;

                    //Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = result
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}