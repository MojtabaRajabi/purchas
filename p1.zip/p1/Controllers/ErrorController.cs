﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Sanay.Lotus.Erm.Controllers
{
    public class ErrorController : Controller
    {
        // GET: Error
        [AllowAnonymous]
        public ActionResult Index()
        {
            return View();
        }



        // GET: Error
        [AllowAnonymous]
        public ActionResult Suspended()
        {
            return View();
        }

    }
}