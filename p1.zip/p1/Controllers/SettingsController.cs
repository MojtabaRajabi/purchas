﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Lib.Enum;


namespace Sanay.Lotus.Erm.Controllers
{
    public class SettingsController : Controller
    {
        // GET: AccountingCode
        [Authorize]
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult FundCheck(int? Date)
        {

            ViewBag.Pdate = Date;
            return View();
        }
        [Authorize]
        public ActionResult AddBroker()
        {
            return View();
        }
        public ActionResult AddSymbol()
        {
            return View();
        }
        public ActionResult DataCheck()
        {
            ViewBag.Date = Assistant.TodayDateBySlash();



            return View();
        }



        [HttpPost]
        [Authorize]
        public JsonResult DeleteSymbol(int Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteSymbol(Id);
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }


        [Authorize]
        public ActionResult LoadFundChecking()
        {
            try
            {
                // SqlHelper sql = new SqlHelper();
                //var draw = Request.Form.GetValues("draw").FirstOrDefault();
                //var start = Request.Form.GetValues("start").FirstOrDefault();
                ////var length = Request.Form.GetValues("length").FirstOrDefault();
                //var sortColumn = Request.Form
                //    .GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]")
                //    .FirstOrDefault();
                //var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
              //  var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var Pdate = Request.Form.GetValues("Pdate").FirstOrDefault();
                

                using (var sql = new LinqHelper())
                {
                    var result = sql.CheckFundData(Pdate.ToValidMsgInt()).OrderBy(c=>c.FundId).ToList();


                    //Paging Size (10,20,50,100)  
                   // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;

                    // Getting all Customer data  
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    //Paging   
                    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    var data = customerData.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        //draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }





        [HttpPost]
        [Authorize]
        public JsonResult DeleteBroker(int Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteBroker(Id);
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }
        [Authorize]
        public ActionResult LoadSymbolsData()
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetBuySellsSymbol();

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [Authorize]
        public ActionResult LoadBrokersData()
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetBuySellsBroker();

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }



        [HttpPost]
        [Authorize]
        public ActionResult RegisterSymbol(BuySellsSymbol obj)
        {
            using (var sql = new LinqHelper())
            {
                //obj.BuyTotal = obj.BuyTotal.Replace(",", "");
                //obj.BuyFee = obj.BuyFee.Replace(",", "");
                //obj.BuyInterest = obj.BuyInterest.Replace(",", "");
                //obj.BuyTotalAndFee = obj.BuyTotalAndFee.Replace(",", "");
                //obj.SellTotal = obj.SellTotal.Replace(",", "");
                //obj.SellFee = obj.SellFee.Replace(",", "");
                //obj.SellInterest = obj.SellInterest.Replace(",", "");
                //obj.SellTotalAndFee = obj.SellTotalAndFee.Replace(",", "");

                // return Json(login.RegisterUser(register), JsonRequestBehavior.AllowGet);
                var result = sql.InsertSymbol(obj);

                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Authorize]
        public ActionResult RegisterBroker(BuySellsBroker obj)
        {
            using (var sql = new LinqHelper())
            {
                //obj.BuyTotal = obj.BuyTotal.Replace(",", "");
                //obj.BuyFee = obj.BuyFee.Replace(",", "");
                //obj.BuyInterest = obj.BuyInterest.Replace(",", "");
                //obj.BuyTotalAndFee = obj.BuyTotalAndFee.Replace(",", "");
                //obj.SellTotal = obj.SellTotal.Replace(",", "");
                //obj.SellFee = obj.SellFee.Replace(",", "");
                //obj.SellInterest = obj.SellInterest.Replace(",", "");
                //obj.SellTotalAndFee = obj.SellTotalAndFee.Replace(",", "");

                // return Json(login.RegisterUser(register), JsonRequestBehavior.AllowGet);
                var result = sql.InsertBroker(obj);

                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        [Authorize]
        public JsonResult LoadDataAnalysis(string Date)
        {
            using (var sql = new LinqHelper())
            {
                var MiladiDate = Assistant.ShamsiToMiladi(Date.ToValidMsgDate());

                var result = sql.LoadDataAnalysis(MiladiDate);
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }



    }
}