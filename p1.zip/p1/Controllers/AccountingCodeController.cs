﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Web.Security;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dic;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Models;

namespace Sanay.Lotus.Erm.Controllers
{
    public class AccountingCodeController : Controller
    {
        // GET: AccountingCode
        [Authorize]

        public ActionResult Index() 
        {
            return View();
        }
        [Authorize]
        public ActionResult AddAccountingCode()
        {
            return View();
        }

        [HttpPost]
        [Authorize]
        public ActionResult EditCode(BuySellAccountingCode std)
        {
            return RedirectToAction("Index");
        }



        [HttpGet]
        [Authorize]
        public ActionResult Edit_Code(int Id)
        {
            int DefultVal = 0;
            try
            {

                using (var sql2 = new LinqHelper())
                {
                    var list = sql2.GetPillar().Select(x => new
                    {
                        Id = x.RowNum,
                        Text = x.Pillar
                    }).ToList();

                    LinqHelper sql = new LinqHelper();
                    var result = sql.GetBuySellAccountingCode(Id);
                    //Role department = await db.Departments.FindAsync(id);
                    foreach (var item in list)
                    {
                        if (item.Text.Contains(result.Pillar))
                        {
                            DefultVal = Convert.ToInt32(item.Id);
                        }
                    }

                    List<Pillar> objs = new List<Pillar>();

                    for (int i = 0; i <= list.Count - 1; i++)
                    {
                        objs.Add(new Pillar() { Id = (int)list[i].Id, Title = list[i].Text });

                    }

                    if (objs == null)
                    {
                        return HttpNotFound();
                    }
                    ViewBag.Pillar = new SelectList(objs, "Id", "Title", DefultVal);
                    ViewBag.PillCap = result.Pillar;
                    return View(result);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost, ActionName("Edit_Code")]
        [Authorize]
        public ActionResult Edit_CodePost(int id)
        {


            if (id == null)
            {
                // return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            LinqHelper sql = new LinqHelper();
            var Code = sql.GetBuySellAccountingCode(id);

            //if (TryUpdateModel(Code, "",
            //    new string[] { "FirstName", "LastName", "Role", "Email", "Mobile" }))
            //{
            try
            {
                sql.UpdateCode(Code);
                //db.SaveChanges();
                return RedirectToAction("Admin");
            }
            catch (RetryLimitExceededException /* dex */)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");
            }
            //}
            // return View(studentToUpdate);
            return View();

        }




        [HttpPost]
        [Authorize]
        public JsonResult Delete_Code(int Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.Delete_Code(Id);
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }


        [HttpGet]
        public JsonResult GetPillar(string term)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetPillar()
                        .Select(x => new
                        {
                            Id = x.Pillar,
                            Text = x.PillarDescription
                        }).ToList();

                    //list.Add(new {Id = -1, Text = "همه"});
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }


        [Authorize]
        public ActionResult LoadData()
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetBuySellAccountingCode();

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }




        [HttpPost]
        [AllowAnonymous]
        public ActionResult CheckPillar(string pillar)
        {
            LinqHelper db = new LinqHelper();
            var result = db.BuySellAccountingCode().Where(c => c.Pillar == pillar && c.IsObsolete != true);
            if (result.Count() == 0)
            {
                return Json(new MessageResponse { Success = true, Message = "مجاز", ReturnUrl = "" });
            }
            return Json(new MessageResponse { Success = false, Message = "بدليل تکراري بودن قابل ثبت نيست", ReturnUrl = "" });
        }


        [HttpPost]
        [Authorize]
        public ActionResult RegisterAccountingCode(BuySellAccountingCode obj)
        {
            using (var sql = new LinqHelper())
            {

                obj.IsObsolete = false;
                var result = sql.InsertBuySellAccountingCode(obj);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public ActionResult UpdateAccountingCode(BuySellAccountingCode obj)
        {
            using (var sql = new LinqHelper())
            {
                obj.Id = obj.Id;
                obj.IsObsolete = false;
                obj.Code   = string.IsNullOrEmpty(obj.Code)? obj.Code: obj.Code.Replace(",", "");
                obj.CodeD4 = string.IsNullOrEmpty(obj.CodeD4) ? obj.CodeD4 : obj.CodeD4.Replace(",", "");  
                obj.CodeD5 = string.IsNullOrEmpty(obj.CodeD5) ? obj.CodeD5 : obj.CodeD5.Replace(",", "");  
                obj.CodeD6 = string.IsNullOrEmpty(obj.CodeD6) ? obj.CodeD6 : obj.CodeD6.Replace(",", ""); 
             
                obj.CodeInterest   = string.IsNullOrEmpty(obj.CodeInterest) ? obj.CodeInterest : obj.CodeInterest.Replace(",", "");  
                obj.CodeInterestD4 = string.IsNullOrEmpty(obj.CodeInterestD4) ? obj.CodeInterestD4 : obj.CodeInterestD4.Replace(",", ""); 
                obj.CodeInterestD5 = string.IsNullOrEmpty(obj.CodeInterestD5) ? obj.CodeInterestD5 : obj.CodeInterestD5.Replace(",", "");  
                obj.CodeInterestD6 = string.IsNullOrEmpty(obj.CodeInterestD6) ? obj.CodeInterestD6 : obj.CodeInterestD6.Replace(",", ""); 

                obj.CodeFee   = string.IsNullOrEmpty(obj.CodeFee) ? obj.CodeFee : obj.CodeFee.Replace(",", "");  
                obj.CodeFeeD4 = string.IsNullOrEmpty(obj.CodeFeeD4) ? obj.CodeFeeD4 : obj.CodeFeeD4.Replace(",", "");  
                obj.CodeFeeD5 = string.IsNullOrEmpty(obj.CodeFeeD5) ? obj.CodeFeeD5 : obj.CodeFeeD5.Replace(",", ""); 
                obj.CodeFeeD6 = string.IsNullOrEmpty(obj.CodeFeeD6) ? obj.CodeFeeD6 : obj.CodeFeeD6.Replace(",", "");  

                obj.CodeProfit   = string.IsNullOrEmpty(obj.CodeProfit) ? obj.CodeProfit : obj.CodeProfit.Replace(",", ""); 
                obj.CodeProfitD4 = string.IsNullOrEmpty(obj.CodeProfitD4) ? obj.CodeProfitD4 : obj.CodeProfitD4.Replace(",", "");  
                obj.CodeProfitD5 = string.IsNullOrEmpty(obj.CodeProfitD5) ? obj.CodeProfitD5 : obj.CodeProfitD5.Replace(",", "");  
                obj.CodeProfitD6 = string.IsNullOrEmpty(obj.CodeProfitD6) ? obj.CodeProfitD6 : obj.CodeProfitD6.Replace(",", "");  

                var result = sql.UpdateBuySellAccountingCode(obj);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "AccountingCode" }, JsonRequestBehavior.AllowGet);


            }
        }


    }
}