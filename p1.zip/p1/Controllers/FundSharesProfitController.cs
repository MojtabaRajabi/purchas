﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Web.Security;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dic;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Models;
using Sanay.Library.Utility;

namespace Sanay.Lotus.Erm.Controllers
{
    public class FundSharesProfitController : Controller
    {
        // GET: AccountingCode
        [Authorize]

        public ActionResult Index()
        {
            return View();
        }
        [Authorize]
        public ActionResult Add()
        {
            using (var sql = new LinqHelper())
            {
                List<Company> list = sql.GetCoSymbols().ToList();
              

                ViewBag.list = list;
              

            }


            return View();
        }

    

        [HttpGet]
        [Authorize]
        public ActionResult Edit(string Id)
        {
            try
            {
                ViewBag.Id = Id;
                using (var sql2 = new LinqHelper())
                {

                    LinqHelper sql = new LinqHelper();
                    var result = sql.GetFundSharesProfit(Guid.Parse(Id));
 
                    return View(result);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }
      




        [HttpPost]
        [Authorize]
        public JsonResult Delete(string Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteFundSharesProfits(Guid.Parse(Id));
                     
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }
        
        [Authorize]
        public ActionResult LoadData()
        {
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            var startDate = Request.Form.GetValues("startDate").FirstOrDefault().ToValidMsgDate();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault().ToValidMsgDate();

            if (endDate == 0) endDate = int.MaxValue;
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetFundSharesProfits().Where(c => c.Pdate >= startDate && c.Pdate <= endDate).OrderBy(c=>c.Id).ToList();

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    //switch (sortColumn)
                    //{
                    //    case "IsBuy":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.IsBuy).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.IsBuy).ToList();
                    //        break;
                    //    case "BondName":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.BondName).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.BondName).ToList();
                    //        break;
                    //    case "CustomerName":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.CustomerName).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.CustomerName).ToList();
                    //        break;
                    //    case "StartDate":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.StartDate).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.StartDate).ToList();
                    //        break;
                    //    case "EndDate":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.EndDate).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.EndDate).ToList();
                    //        break;
                    //    case "Addition":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.Addition).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.Addition).ToList();
                    //        break;
                    //    case "TotalValue":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.TotalValue).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.TotalValue).ToList();
                    //        break;
                    //    case "NominalValue":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.NominalValue).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.NominalValue).ToList();
                    //        break;
                    //}

                    //paging Data
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();

                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [HttpPost]
        [Authorize]
        public ActionResult Register(FundSharesProfit obj)
        {
            using (var sql = new LinqHelper())
            {
                obj.RegUser = Assistant.CurrentUser();
                obj.RegDate = Convert.ToInt32(Assistant.MiladiToShamsi(Assistant.TodayDateIntMiladi()));
                obj.RegTime = Assistant.TimeNowInt();
                obj.FundId = 1;
                var result = sql.InsertFundSharesProfits(obj);
                    sql.AutomaticSharesProfitFundIOFlow(result,1);
               
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        [Authorize]
        public ActionResult PreviewIOFlow( string Pdate  , string Profit, string Num)
        {
            try
            {
                using (var sql = new LinqHelper())
                {

                 
                        var result = sql.PreviewAutomaticShareProfitFundIOFlow(Pdate.ToValidMsgDate(), Profit.ToValidMsgdouble(), Num.ToValidMsglong());
                        return Json(new { data = result });
                 
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        [HttpPost]
        public ActionResult Update(FundSharesProfit obj)
        {
            using (var sql = new LinqHelper())
            {

                obj.RegUser = Assistant.CurrentUser();
                obj.RegDate = Convert.ToInt32(Assistant.MiladiToShamsi(Assistant.TodayDateIntMiladi()));
                obj.RegTime = Assistant.TimeNowInt();
                obj.FundId = 1;

                // var result = sql.UpdateAdditionalContractFee(obj);

                var item = sql.GetFundSharesProfit(obj.Id);

               
                    if (item != null)
                    {
                        sql.RemoveFundSharesProfit(obj.Id,1);
                        var result = sql.InsertFundSharesProfits(obj);
                        sql.AutomaticSharesProfitFundIOFlow(result,1);
                    }
              

                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "AccountingCode" }, JsonRequestBehavior.AllowGet);

            }
        }


    }
}