﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Web.Security;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dic;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Models;
using Sanay.Library.Utility;

namespace Sanay.Lotus.Erm.Controllers
{
    public class AdditionalContractFeesController : Controller
    {
        // GET: AccountingCode
        [Authorize]

        public ActionResult Index()
        {
            return View();
        }
        [Authorize]
        public ActionResult Add()
        {
            return View();
        }

    

        [HttpGet]
        [Authorize]
        public ActionResult Edit(string Id)
        {
            try
            {
                ViewBag.Id = Id;
                using (var sql2 = new LinqHelper())
                {

                    LinqHelper sql = new LinqHelper();
                    var result = sql.GetAdditionalContractFee(Guid.Parse(Id));


                    List<BuySellState > objs = new List<BuySellState>();
                    objs.Add(new BuySellState() { Id = 1, Title = "خرید" });
                    objs.Add(new BuySellState() { Id = 0, Title = "فروش" });

                    ViewBag._IsBuyInt = new SelectList(objs, "Id", "Title", result._IsBuyInt);



                    return View(result);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        [Authorize]
        public JsonResult DeleteAdditionalContractFees(string Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteAdditionalContractFee(Guid.Parse(Id));

                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }
        
        [Authorize]
        public ActionResult LoadData()
        {
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            var startDate = Request.Form.GetValues("startDate").FirstOrDefault().ToValidMsgDate();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault().ToValidMsgDate();

            if (endDate == 0) endDate = int.MaxValue;
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetAdditionalContractFee().Where(c => c.StartDate >= startDate && c.StartDate <= endDate).OrderBy(c=>c.Id).ToList();

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {
                        case "IsBuy":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.IsBuy).ToList();
                            else
                                result = result.OrderByDescending(p => p.IsBuy).ToList();
                            break;
                        case "BondName":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.BondName).ToList();
                            else
                                result = result.OrderByDescending(p => p.BondName).ToList();
                            break;
                        case "CustomerName":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.CustomerName).ToList();
                            else
                                result = result.OrderByDescending(p => p.CustomerName).ToList();
                            break;
                        case "StartDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.StartDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.StartDate).ToList();
                            break;
                        case "EndDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.EndDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.EndDate).ToList();
                            break;
                        case "Addition":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Addition).ToList();
                            else
                                result = result.OrderByDescending(p => p.Addition).ToList();
                            break;
                        case "TotalValue":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.TotalValue).ToList();
                            else
                                result = result.OrderByDescending(p => p.TotalValue).ToList();
                            break;
                        case "NominalValue":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.NominalValue).ToList();
                            else
                                result = result.OrderByDescending(p => p.NominalValue).ToList();
                            break;
                    }

                    //paging Data
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();

                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [HttpPost]
        [Authorize]
        public ActionResult RegisterAdditionalContractFees(AdditionalContractFee obj)
        {
            using (var sql = new LinqHelper())
            {
                obj.RegUser = Assistant.CurrentUser();
                obj.RegDate = Convert.ToInt32(Assistant.MiladiToShamsi(Assistant.TodayDateIntMiladi()));
                obj.RegTime = Assistant.TimeNowInt();
                var result = sql.InsertAdditionalContractFee(obj);
                if (obj.IsBuy == true)
                {
                    sql.AutomaticAdditionalContractFeesBuyInputOutputFlow(result);
                }
                else
                {
                    sql.AutomaticAdditionalContractFeesSellInputOutputFlow(result);
                }
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        [Authorize]
        public ActionResult PreviewIOFlow(string isBuy, string StartDate, string EndDate, string Addition, string TotalValue, string Redeem) //string NominalValue
        {
            try
            {
                using (var sql = new LinqHelper())
                {

                    if (isBuy.TryParseBoolean())
                    {
                        var result = sql.PreviewAutomaticAdditionalContractFeesBuyInputOutputFlow(StartDate.ToValidMsgDate(), EndDate.ToValidMsgDate(), Addition.ToValidMsgdouble(), TotalValue.ToValidMsgdouble());
                        return Json(new { data = result });
                    }
                    else
                    {
                        var result = sql.PreviewAutomaticAdditionalContractFeesSellInputOutputFlow(StartDate.ToValidMsgDate(), EndDate.ToValidMsgDate(), Addition.ToValidMsgdouble(), TotalValue.ToValidMsgdouble());
                        return Json(new { data = result });
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        [HttpPost]
        public ActionResult UpdateAdditionalContractFees(AdditionalContractFee obj)
        {
            using (var sql = new LinqHelper())
            {

                obj.RegUser = Assistant.CurrentUser();
                obj.RegDate = Convert.ToInt32(Assistant.MiladiToShamsi(Assistant.TodayDateIntMiladi()));
                obj.RegTime = Assistant.TimeNowInt();

                // var result = sql.UpdateAdditionalContractFee(obj);
                if (obj.IsBuy == true)
                {
                    var item = sql.GetAdditionalContractFee(obj.Id);
                    if (item != null)
                    {
                        sql.RemoveAdditionalContractFeesBuy(obj.Id);
                        var result = sql.InsertAdditionalContractFee(obj);
                        sql.AutomaticAdditionalContractFeesBuyInputOutputFlow(result);
                    }
                }
                else
                {
                    var item = sql.GetAdditionalContractFee(obj.Id);
                    if (item != null)
                    {
                        sql.RemoveAdditionalContractFeesSell(obj.Id);
                        var result = sql.InsertAdditionalContractFee(obj);
                        sql.AutomaticAdditionalContractFeesSellInputOutputFlow(result);
                    }
                }

                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "AccountingCode" }, JsonRequestBehavior.AllowGet);

            }
        }


    }
}