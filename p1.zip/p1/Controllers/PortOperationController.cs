﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Sanay.Lotus.Erm.Controllers
{
    public class PortOperationController : Controller
    {
        // GET: PortOperation
        public ActionResult Index()
        {
            return View();
        }
    }
}