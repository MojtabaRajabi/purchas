﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sanay.Lotus.Erm.DataAccess.Helper;

namespace Sanay.Lotus.Erm.Controllers
{
    public class HomeController : Controller
    {
        [AllowAnonymous]
        public ActionResult Index()
        {
            return View();
        }

        //[AllowAnonymous]
        //public JsonResult About()
        //{
        //    var x = new BestLimitRepository().Read();
        //    return Json(x, JsonRequestBehavior.AllowGet);
        //}
        [AllowAnonymous]
        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }




    }
}