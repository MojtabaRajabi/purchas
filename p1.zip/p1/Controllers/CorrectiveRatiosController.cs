﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.Lib.Dto;

namespace Sanay.Lotus.Erm.Controllers
{
    [Authorize]
    public class CorrectiveRatiosController : Controller
    {
       

        // GET: CorrectiveRatios
        public ActionResult Index()
        {
            using (var sql = new LinqHelper())
            {
                string[] Ratios = new string[44];
                var lastCR = sql.GetLastCorrectiveRatioInfos();
                if (lastCR.Count <=0)
                {
                    ViewBag.Ratios = Ratios;
                    return View();
                }

                //fetch data          
                
                //نسبتهای کفایت سرمایه
                Ratios[0] = "0.71";
                Ratios[1] = "6.24";
                Ratios[2] = ValidDoubleToString(GetLastCRValueById(lastCR,21)/ GetLastCRValueById(lastCR, 4));
                Ratios[3] = ValidDoubleToString(GetLastCRValueById(lastCR, 39) / GetLastCRValueById(lastCR, 4));

                //نسبتهای کیفیت دارایی
                Ratios[4] = ValidDoubleToString(GetLastCRValueById(lastCR,7) / GetLastCRValueById(lastCR,2)*100)+"%";
                Ratios[5] = "-";
                Ratios[6] = "-";
                Ratios[7] = "-";
                Ratios[8] = "-";
                Ratios[9] = "-";
                Ratios[10] = "-";
                Ratios[11] = "-";
                Ratios[12] = "-";
                Ratios[13] = "-";

                //نسبتهای مدیریتی
               // Ratios[14] = ValidDoubleToString(GetLastCRValueById(lastCR, 19) / GetLastCRValueById(lastCR, 4)*100)+"%"; 
                Ratios[15] = ValidDoubleToString(GetLastCRValueById(lastCR, 11) / GetLastCRValueById(lastCR, 12)); 
                Ratios[16] = ValidDoubleToString(GetLastCRValueById(lastCR, 8) / GetLastCRValueById(lastCR, 18)); 
                Ratios[17] = ValidDoubleToString(GetLastCRValueById(lastCR, 13) / GetLastCRValueById(lastCR, 18)); 
                Ratios[18] = ValidDoubleToString(GetLastCRValueById(lastCR, 19) / GetLastCRValueById(lastCR, 16)); 
                Ratios[19] = ValidDoubleToString(GetLastCRValueById(lastCR, 30) / GetLastCRValueById(lastCR, 21)*100)+"%"; 
                Ratios[20] = ValidDoubleToString(GetLastCRValueById(lastCR, 17) / GetLastCRValueById(lastCR, 11)*100)+"%"; 
                Ratios[21] = "-";
                Ratios[22] = "-";
                Ratios[23] = "-";
                Ratios[24] = "-";

                //نسبتهای سودآوری
                //Ratios[25] = ValidDoubleToString(GetLastCRValueById(lastCR, 19) / GetLastCRValueById(lastCR, 42)); 
                Ratios[26] = ValidDoubleToString(GetLastCRValueById(lastCR, 19) / GetLastCRValueById(lastCR, 4)*100)+"%"; 
                Ratios[27] = ValidDoubleToString(GetLastCRValueById(lastCR, 20) / GetLastCRValueById(lastCR, 21)); 
                //Ratios[28] = ValidDoubleToString(GetLastCRValueById(lastCR, 12) / GetLastCRValueById(lastCR, 4)*100) + "%"; 
                //Ratios[29] = ValidDoubleToString(1 - GetLastCRValueById(lastCR, 12) / GetLastCRValueById(lastCR, 4)*100) + "%";

                //نسبتهای نقدینگی
                //Ratios[30] = Math.Round(GetLastCRValueById(lastCR, 52) / GetLastCRValueById(lastCR, 42), 3);
                //Ratios[31] = Math.Round(GetLastCRValueById(lastCR, 57) / GetLastCRValueById(lastCR, 42), 3);
                //Ratios[32] = Math.Round(GetLastCRValueById(lastCR, 61) / GetLastCRValueById(lastCR, 42), 3);
                Ratios[33] = "-";
                Ratios[34] = "-";
                Ratios[35] = "-";
                //Ratios[36] = Math.Round(GetLastCRValueById(lastCR, 21) / GetLastCRValueById(lastCR, 52), 3);
                //Ratios[37] = Math.Round(GetLastCRValueById(lastCR, 26) / GetLastCRValueById(lastCR, 52), 3);
                Ratios[38] = "-";
                Ratios[39] = "-";
                Ratios[40] = "-";
                Ratios[41] = "-";
                Ratios[42] = "-";
                Ratios[43] = "-";

                ViewBag.Ratios = Ratios;

                var temp = lastCR.FirstOrDefault();
                ViewBag.Comment =   Assistant.GetMonthNameByMonthNoFa((int)temp.CorrectiveRatioMonth) + " ماه" + temp.CorrectiveRatioYear+ " - دوره" + temp.CorrectiveRatioCycle + " ماهه  ";

                return View();/*RedirectToAction("AddCorrectiveRatios");*/ //
            }
        }

        [HttpPost]
        public ActionResult LoadDataGroupCorrectiveRatios()
        {
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            //var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            //var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();

            using (var sql = new LinqHelper())
            {
                var result = sql.GetGroupCorrectiveRatioInfos().OrderByDescending(c => c.CorrectiveRatioYear).ThenBy(c => c.CorrectiveRatioMonth).ToList();

                //paging Data
                int pageSize = length != null ? Convert.ToInt32(length) : 0;
                int skip = start != null ? Convert.ToInt32(start) : 0;
                int recordsTotal = 0;
                var customerData = result;
                recordsTotal = customerData.Count();
                var data = customerData.Skip(skip).Take(pageSize).ToList();
                //Returning Json Data  
                return Json(new
                {
                    recordsFiltered = recordsTotal,
                    recordsTotal = recordsTotal,
                    data = result
                });
            }
        }

        public ActionResult AddCorrectiveRatios(string year, string month, string cycle)
        {
            ViewBag.year = year;
            ViewBag.month = month;
            ViewBag.cycle = cycle;

            return View();
        }

        [HttpPost]
        public ActionResult LoadDataCorrectiveRatios(int year, int month, int cycle)
        {
            using (var sql = new LinqHelper())
            {
                var result = sql.GetCorrectiveRatioInfos(year, month, cycle).ToList();
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public ActionResult RegisterCorrectiveRatios(List<CorrectiveRatioInfo> listCorrectiveRatio)
        {
            if (listCorrectiveRatio == null)
                return Json(new MessageResponse { Success = false, Message = "داده ای برای ثبت وجود ندارد", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);

            using (var sql = new LinqHelper())
            {
                var obj = listCorrectiveRatio.FirstOrDefault();
                var oldCorrectiveRatios = sql.GetCorrectiveRatioInfos((int)obj.CorrectiveRatioYear, (int)obj.CorrectiveRatioMonth, (int)obj.CorrectiveRatioCycle).ToList();
                foreach (var item in listCorrectiveRatio)
                {

                    item.RegUser = Assistant.CurrentUser();
                    item.RegDate = Assistant.TodayDateInt();
                    item.RegTime = Assistant.TimeNowInt();

                    var oldCorrectiveRatio = oldCorrectiveRatios.Where(c => c.CorrectiveRatioId == item.CorrectiveRatioId).FirstOrDefault();
                    if (oldCorrectiveRatio != null)
                    {
                        item.Id = oldCorrectiveRatio.Id;
                        sql.UpdateCorrectiveRatioInfo(item);
                    }
                    else
                    {
                        sql.InsertCorrectiveRatioInfo(item);
                    }
                }
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }

        private double GetLastCRValueById(List<GetLastCorrectiveRatioInfos_Result> list, int id)
        {
            var value = list.Where(c => c.CorrectiveRatioId == id).Select(c => c.CorrectiveRatioValue).FirstOrDefault();
           
            return value==null?0:(double)value;
        }
        private string ValidDoubleToString(double num)
        {
            string str = Math.Round(num,2).ToString();
            if (Double.IsNaN(num) || Double.IsInfinity(num))
                str = "-";

            return str;
        }


    }
}