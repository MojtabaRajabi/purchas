﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Web.Security;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dic;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Models;
using Sanay.Library.Utility;
using System.IO;
using System.Data;
using ExcelDataReader;


namespace Sanay.Lotus.Erm.Controllers
{
    public class WeekTradesController : Controller
    {

        public static bool isFirstDetail;
        public static bool isFirstTotal;
        public static bool isFirstBestTrades;



        // GET: AccountingCode
        [Authorize]

        public ActionResult Index(string weekDate)
        {

            isFirstDetail = true;
            isFirstTotal = true;
            isFirstBestTrades = true;

            var d = DateTime.Today.AddDays(-5);
            var dint = Assistant.DateToInt(d);
            var dslash = Assistant.DateToDisplayMode(dint);

            if (weekDate != null)
            {
                dslash = weekDate;
            }
            ViewBag.todayDate = Convert.ToString(dslash);


            return View();
        }

        [Authorize]

        public ActionResult TradesChart()
        {

            ViewBag.startDate = Assistant.DateToDisplayMode(Assistant.Last3Months());

            ViewBag.endDate = Assistant.TodayDateBySlash();


            return View();
        }




        [Authorize]
        public ActionResult LoadWeekTradesDetail()
        {
            try
            {

                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();

                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var nDays = Request.Form.GetValues("Days").FirstOrDefault();
                var minValue = Request.Form.GetValues("Value").FirstOrDefault();
                var weekDate = Request.Form.GetValues("weekDate").FirstOrDefault();
                var chSymbol = Request.Form.GetValues("chSymbol").FirstOrDefault();
                var Fields = Request.Form.GetValues("fields").FirstOrDefault();

                using (var db = new LinqHelper())
                {

                    minValue = minValue.Replace(",", "");

                    var ChSelected = false;
                    if (chSymbol == "1")
                        ChSelected = true;

                    var Ppdate = Convert.ToString(Assistant.ShamsiToMiladi(Convert.ToInt32(weekDate.ToValidMsgDate())));

                    if (db.CheckHasWeek(Convert.ToInt32(Ppdate)).FirstOrDefault() > 0)
                    {
                        var hasFilter = 0;
                        if (minValue != "0" || nDays != "0" || ChSelected)
                        {
                            hasFilter = 1;
                        }
                        if (minValue == "") minValue = "0";
                        var hasSelect = ChSelected ? 1 : 0;

                        List<GetWeekTradeDetailsByFilter_Result> data = new List<GetWeekTradeDetailsByFilter_Result>();
                        data.Clear();
                        var FilteredData = db.GetUserFilterWeekTradeDetailes(Assistant.CurrentUser(), Assistant.ShamsiToMiladi(weekDate.ToValidMsgDate()));


                        if (isFirstDetail == true && FilteredData.Count() > 0)
                        {
                            isFirstDetail = false;
                            for (int i = 0; i <= FilteredData.Count() - 1; i++)
                            {
                                data.Add(new GetWeekTradeDetailsByFilter_Result()
                                {
                                    Id = FilteredData[i].Id,
                                    DayToMaturity = FilteredData[i].DayToMaturity,
                                    WeekTradeId = FilteredData[i].WeekTradeId,
                                    InsCode = FilteredData[i].InsCode,
                                    Symbol = FilteredData[i].Symbol,
                                    CostTrade0 = FilteredData[i].CostTrade0,
                                    ClosingPrice0 = FilteredData[i].ClosingPrice0,
                                    CostTrade1 = FilteredData[i].CostTrade1,
                                    ClosingPrice1 = FilteredData[i].ClosingPrice1,
                                    CostTrade2 = FilteredData[i].CostTrade2,
                                    ClosingPrice2 = FilteredData[i].ClosingPrice2,
                                    CostTrade3 = FilteredData[i].CostTrade3,
                                    ClosingPrice3 = FilteredData[i].ClosingPrice3,
                                    CostTrade4 = FilteredData[i].CostTrade4,
                                    ClosingPrice4 = FilteredData[i].ClosingPrice4,
                                    Totalvalue = FilteredData[i].Totalvalue,
                                    Average = FilteredData[i].Average,
                                    WeightTrads = FilteredData[i].WeightTrads,
                                    EfficiencyTrads = FilteredData[i].EfficiencyTrads,
                                    NomEfficiencyTrads = FilteredData[i].NomEfficiencyTrads,
                                    EfficiencyRhythmic = FilteredData[i].EfficiencyRhythmic,
                                    Treasury = FilteredData[i].Treasury,
                                    NonTreasury = FilteredData[i].NonTreasury
                                });

                            }
                        }
                        else
                        {
                            data = db.GetWeekTradeDetailsByFilter(Ppdate, hasFilter, Convert.ToInt32(nDays), Convert.ToDouble(minValue), Fields, hasSelect);
                        }
                        //Total record count.
                        int totalRecords = 14;

                        List<GetWeekTradeDetailsByFilter_Result> sortedList = new List<GetWeekTradeDetailsByFilter_Result>();


                        if (sortColumnDir == "asc")
                        {
                            switch (sortColumn)
                            {
                                case "Symbol":
                                    sortedList = data.OrderBy(x => x.Symbol).ToList();
                                    break;
                                case "_CostTrade0":
                                    sortedList = data.OrderBy(x => x.CostTrade0).ToList();
                                    break;
                                case "_ClosingPrice0":
                                    sortedList = data.OrderBy(x => x.ClosingPrice0).ToList();
                                    break;
                                case "_CostTrade1":
                                    sortedList = data.OrderBy(x => x.CostTrade1).ToList();
                                    break;
                                case "_ClosingPrice1":
                                    sortedList = data.OrderBy(x => x.ClosingPrice1).ToList();
                                    break;
                                case "_CostTrade2":
                                    sortedList = data.OrderBy(x => x.CostTrade2).ToList();
                                    break;
                                case "_ClosingPrice2":
                                    sortedList = data.OrderBy(x => x.ClosingPrice2).ToList();
                                    break;
                                case "_CostTrade3":
                                    sortedList = data.OrderBy(x => x.CostTrade3).ToList();
                                    break;
                                case "_ClosingPrice3":
                                    sortedList = data.OrderBy(x => x.ClosingPrice3).ToList();
                                    break;
                                case "_CostTrade4":
                                    sortedList = data.OrderBy(x => x.CostTrade4).ToList();
                                    break;
                                case "_ClosingPrice4":
                                    sortedList = data.OrderBy(x => x.ClosingPrice4).ToList();
                                    break;
                                case "_Totalvalue":
                                    sortedList = data.OrderBy(x => x.Totalvalue).ToList();
                                    break;
                                case "_Average":
                                    sortedList = data.OrderBy(x => x.Average).ToList();
                                    break;
                                case "_WeightTrads":
                                    sortedList = data.OrderBy(x => x.WeightTrads).ToList();
                                    break;
                                case "_NomEfficiencyTrads":
                                    sortedList = data.OrderBy(x => x.NomEfficiencyTrads).ToList();
                                    break;
                                case "_EfficiencyTrads":
                                    sortedList = data.OrderBy(x => x.EfficiencyTrads).ToList();
                                    break;
                                case "_EfficiencyRhythmic":

                                    sortedList = data.OrderBy(x => x.EfficiencyRhythmic).ToList();
                                    break;
                                case "_Treasury":
                                    sortedList = data.OrderBy(x => x.Treasury).ToList();
                                    break;
                                case "_NonTreasury":
                                    sortedList = data.OrderBy(x => x.NonTreasury).ToList();
                                    break;

                                default:
                                    sortedList = data;
                                    break;
                            }
                        }
                        else
                        {
                            switch (sortColumn)
                            {
                                case "Symbol":
                                    sortedList = data.OrderByDescending(x => x.Symbol).ToList();
                                    break;
                                case "_CostTrade0":
                                    sortedList = data.OrderByDescending(x => x.CostTrade0).ToList();
                                    break;
                                case "_ClosingPrice0":
                                    sortedList = data.OrderByDescending(x => x.ClosingPrice0).ToList();
                                    break;
                                case "_CostTrade1":
                                    sortedList = data.OrderByDescending(x => x.CostTrade1).ToList();
                                    break;
                                case "_ClosingPrice1":
                                    sortedList = data.OrderByDescending(x => x.ClosingPrice1).ToList();
                                    break;
                                case "_CostTrade2":
                                    sortedList = data.OrderByDescending(x => x.CostTrade2).ToList();
                                    break;
                                case "_ClosingPrice2":
                                    sortedList = data.OrderByDescending(x => x.ClosingPrice2).ToList();
                                    break;
                                case "_CostTrade3":
                                    sortedList = data.OrderByDescending(x => x.CostTrade3).ToList();
                                    break;
                                case "_ClosingPrice3":
                                    sortedList = data.OrderByDescending(x => x.ClosingPrice3).ToList();
                                    break;
                                case "_CostTrade4":
                                    sortedList = data.OrderByDescending(x => x.CostTrade4).ToList();
                                    break;
                                case "_ClosingPrice4":
                                    sortedList = data.OrderByDescending(x => x.ClosingPrice4).ToList();
                                    break;
                                case "_Totalvalue":
                                    sortedList = data.OrderByDescending(x => x.Totalvalue).ToList();
                                    break;
                                case "_Average":
                                    sortedList = data.OrderByDescending(x => x.Average).ToList();
                                    break;
                                case "_WeightTrads":
                                    sortedList = data.OrderByDescending(x => x.WeightTrads).ToList();
                                    break;
                                case "_NomEfficiencyTrads":
                                    sortedList = data.OrderByDescending(x => x.NomEfficiencyTrads).ToList();
                                    break;
                                case "_EfficiencyTrads":
                                    sortedList = data.OrderByDescending(x => x.EfficiencyTrads).ToList();
                                    break;
                                case "_EfficiencyRhythmic":

                                    sortedList = data.OrderByDescending(x => x.EfficiencyRhythmic).ToList();
                                    break;
                                case "_Treasury":
                                    sortedList = data.OrderByDescending(x => x.Treasury).ToList();
                                    break;
                                case "_NonTreasury":
                                    sortedList = data.OrderByDescending(x => x.NonTreasury).ToList();
                                    break;

                                default:
                                    sortedList = data;
                                    break;
                            }
                        }



                        // Verification.
                        if (!string.IsNullOrEmpty(searchValue) &&
                        !string.IsNullOrWhiteSpace(searchValue))
                        {

                        }

                        // Filter record count.
                        int recFilter = 14;

                        return Json(new
                        {
                            draw = draw,
                            recordsFiltered = totalRecords,
                            recordsTotal = recFilter,
                            data = sortedList
                        });
                    }
                    else
                        return Json(new
                        {
                            data = 123
                        });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }




        [HttpPost]
        [Authorize]
        public ActionResult GetWeekTrades(string weekDate, string totalvalue, string Nday, string Fields, string chSymbol)
        {
            using (var sql = new LinqHelper())
            {
                totalvalue = totalvalue.Replace(",", "");
                var ChSelected = false;
                if (chSymbol == "1")
                    ChSelected = true;

                var Ppdate = Convert.ToString(Assistant.ShamsiToMiladi(weekDate.ToValidMsgDate()));
                var hasFilter = 0;
                if (totalvalue != "0" || Nday != "0" || ChSelected)
                {
                    hasFilter = 1;
                }
                var hasSelect = ChSelected ? 1 : 0;
                if (totalvalue == "") totalvalue = "0";
                var data = new GetWeekTradesByFilter_Result();

                var FilteredTotal = sql.GetUserFilterWeekTrade(Assistant.CurrentUser(), Assistant.ShamsiToMiladi(weekDate.ToValidMsgDate()));

                if (isFirstTotal == true && FilteredTotal != null)
                {
                    isFirstTotal = false;

                    data.Id = 1;
                    data.StartWeek = FilteredTotal.WeekDate;
                    data.EndWeek = FilteredTotal.WeekDate;
                    data.SumWeightTrads = FilteredTotal.SumWeightTrads;
                    data.SumEfficiencyTrads = FilteredTotal.SumEfficiencyTrads;
                    data.SumAverage = FilteredTotal.SumAverage;
                    data.SumEfficiencyRhythmic = FilteredTotal.SumEfficiencyRhythmic;
                    data.SumYtmEfficiencyRhythmic = FilteredTotal.SumYtmEfficiencyRhythmic;
                    data.SumTreasury = FilteredTotal.SumTreasury;
                    data.SumNonTreasury = FilteredTotal.SumNonTreasury;
                    data.SumYtmTreasury = FilteredTotal.SumYtmTreasury;
                    data.SumYtmNonTreasury = FilteredTotal.SumYtmNonTreasury;
                    data.SumTotalvalue = FilteredTotal.SumTotalvalue;
                }
                else
                {
                    data = sql.GetWeekTradesbyFilter(Convert.ToInt32(Ppdate), hasFilter, Convert.ToInt32(Nday),
                Convert.ToDouble(totalvalue), Fields.Replace("'", ""), hasSelect);
                    data.Id = 0;
                }
                if (data != null)
                {
                    var persianDate = Assistant.MiladiToShamsi(Convert.ToInt32(data.EndWeek));
                    var strdate = persianDate.TryToDateMode();

                    data._EndWeek = strdate;
                }


                //list.Add(new {Id = -1, Text = "همه"});
                return Json(data, JsonRequestBehavior.AllowGet);

                //return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }



        [Authorize]
        public ActionResult LoadWeekBestSymbols()
        {
            try
            {

                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                //var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();

                //var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var nDays = Request.Form.GetValues("Days").FirstOrDefault();
                var minValue = Request.Form.GetValues("Value").FirstOrDefault();
                var weekDate = Request.Form.GetValues("weekDate").FirstOrDefault();
                var chSymbol = Request.Form.GetValues("chSymbol").FirstOrDefault();
                var Fields = Request.Form.GetValues("fields").FirstOrDefault();


                using (var db = new LinqHelper())
                {

                    minValue = minValue.Replace(",", "");

                    var ChSelected = false;
                    if (chSymbol == "1")
                        ChSelected = true;


                    List<GetWeekTradeDetailsByFilter_Result> data = new List<GetWeekTradeDetailsByFilter_Result>();
                    List<GetWeekTradeDetailsByFilter_Result> GlobalList = new List<GetWeekTradeDetailsByFilter_Result>();
                    GlobalList.Clear();
                    var Ppdate = Convert.ToString(Assistant.ShamsiToMiladi(weekDate.ToValidMsgDate()));

                    if (db.CheckHasWeek(Convert.ToInt32(Ppdate)).FirstOrDefault() > 0)
                    {
                        var hasFilter = 0;
                        if (minValue != "0" || nDays != "0" || ChSelected)
                        {
                            hasFilter = 1;
                        }

                        var hasSelect = ChSelected ? 1 : 0;
                        if (minValue == "") minValue = "0";


                        var FilteredData = db.GetUserFilterWeekTradeDetailes(Assistant.CurrentUser(), Assistant.ShamsiToMiladi(weekDate.ToValidMsgDate()));


                        if (isFirstBestTrades == true && FilteredData.Count() > 0)
                        {
                            isFirstBestTrades = false;
                            for (int i = 0; i <= FilteredData.Count() - 1; i++)
                            {
                                GlobalList.Add(new GetWeekTradeDetailsByFilter_Result()
                                {
                                    Id = FilteredData[i].Id,
                                    DayToMaturity = FilteredData[i].DayToMaturity,
                                    WeekTradeId = FilteredData[i].WeekTradeId,
                                    InsCode = FilteredData[i].InsCode,
                                    Symbol = FilteredData[i].Symbol,
                                    CostTrade0 = FilteredData[i].CostTrade0,
                                    ClosingPrice0 = FilteredData[i].ClosingPrice0,
                                    CostTrade1 = FilteredData[i].CostTrade1,
                                    ClosingPrice1 = FilteredData[i].ClosingPrice1,
                                    CostTrade2 = FilteredData[i].CostTrade2,
                                    ClosingPrice2 = FilteredData[i].ClosingPrice2,
                                    CostTrade3 = FilteredData[i].CostTrade3,
                                    ClosingPrice3 = FilteredData[i].ClosingPrice3,
                                    CostTrade4 = FilteredData[i].CostTrade4,
                                    ClosingPrice4 = FilteredData[i].ClosingPrice4,
                                    Totalvalue = FilteredData[i].Totalvalue,
                                    Average = FilteredData[i].Average,
                                    WeightTrads = FilteredData[i].WeightTrads,
                                    EfficiencyTrads = FilteredData[i].EfficiencyTrads,
                                    NomEfficiencyTrads = FilteredData[i].NomEfficiencyTrads,
                                    EfficiencyRhythmic = FilteredData[i].EfficiencyRhythmic,
                                    Treasury = FilteredData[i].Treasury,
                                    NonTreasury = FilteredData[i].NonTreasury
                                });

                            }
                        }
                        else
                        {
                            GlobalList = db.GetWeekTradeDetailsByFilter(Ppdate, hasFilter, Convert.ToInt32(nDays), Convert.ToDouble(minValue), Fields.Replace("'", ""), hasSelect);
                        }

                        //var GlobalList = db.GetWeekTradeDetailsByFilter(Ppdate, hasFilter, Convert.ToInt32(Nday), Convert.ToDouble(totalvalue), Fields.Replace("'", ""), hasSelect);


                        var sortedList = GlobalList.OrderByDescending(x => x.Totalvalue).ToList();
                        if (sortedList.Count > 10)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                data.Add(sortedList[i]);
                            }
                        }
                        else
                        {
                            for (int i = 0; i < sortedList.Count; i++)
                            {
                                data.Add(sortedList[i]);
                            }
                        }
                    }

                    var totalRecords = 0;
                    var recFilter = 0;
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = totalRecords,
                        recordsTotal = recFilter,
                        data = data
                    });









                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }



        [HttpPost]
        [Authorize]
        public ActionResult Normalize(string Records, string pDate)
        {
            using (var db = new LinqHelper())
            {
                var User = Assistant.CurrentUser();
                var Date = Assistant.ShamsiToMiladi(pDate.ToValidMsgDate());
                var result = db.InsertUserFilterWeekTradeDetail(User, Records, Date);
                //list.Add(new {Id = -1, Text = "همه"});
                return Json(result, JsonRequestBehavior.AllowGet);
                //return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Authorize]
        public ActionResult DeleteNormalize(string pDate)
        {
            using (var db = new LinqHelper())
            {
                var User = Assistant.CurrentUser();
                var Date = Assistant.ShamsiToMiladi(pDate.ToValidMsgDate());
                var result = db.DeleteUserFilterWeekTradeDetail(User, Date);
                //list.Add(new {Id = -1, Text = "همه"});
                return Json(result, JsonRequestBehavior.AllowGet);
                //return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        public JsonResult LoadWeekTradesChart(string startDate, string endDate)
        {
            try
            {
                using (var sql = new LinqHelper())
                {

                   var result =
                   sql.GetWeekTrades(Assistant.ShamsiToMiladi(startDate.ToValidMsgDate()),
                                     Assistant.ShamsiToMiladi(endDate.ToValidMsgDate())).OrderBy(c => c.StartWeek);
                    var list = result.ToList()
                        .Select(x => new
                        {
                            YTM = x.SumYtmEfficiencyRhythmic,
                            NYTM = x.SumEfficiencyRhythmic,
                            weekDate = Assistant.MiladiToShamsiWithSlash((int)x.StartWeek)
                        }).ToList();
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult LoadNormalizeWeekTradesChart(string startDate, string endDate)
        {
            try
            {
                using (var sql = new LinqHelper())
                {

                    var result =
                    sql.GetUserFilterWeekTradeList(Assistant.CurrentUser(), Assistant.ShamsiToMiladi(startDate.ToValidMsgDate()),
                                      Assistant.ShamsiToMiladi(endDate.ToValidMsgDate())).OrderBy(c => c.WeekDate);
                    var list = result.ToList()
                        .Select(x => new
                        {
                            YTM = x.SumYtmEfficiencyRhythmic,
                            NYTM = x.SumEfficiencyRhythmic,
                            weekDate = Assistant.MiladiToShamsiWithSlash((int)x.WeekDate)
                        }).ToList();
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }





















    }
}