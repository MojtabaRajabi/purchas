﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.IO;
using System.Web.Security;
using ExcelDataReader;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dic;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Models;
using Sanay.Library.Utility;

namespace Sanay.Lotus.Erm.Controllers
{
    public class CapitalSufficienciesController : Controller
    {
        // GET: AccountingCode
        [Authorize]

        public ActionResult Index()
        {
            return View();
        }
        [Authorize]
        public ActionResult Add()
        {
            return View();
        }


        [Authorize]
        public ActionResult ImportExcel()
        {
            return View();
        }

        [Authorize]
        public FileResult Download()
        {
            string path = Server.MapPath("~/App_Data/Files");
            string fileName = Path.GetFileName("CapitalSufficiencies.xlsx");
            string fullPath = Path.Combine(path, fileName);
            return File(fullPath, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "CapitalSufficiencies.xlsx");
        }




        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ImportExcel(HttpPostedFileBase upload, string IO)
        {
            // اعتبار سنجی فایل آپلود شده
            if (upload != null && upload.ContentLength > 0 && (upload.FileName.EndsWith(".xls") || upload.FileName.EndsWith(".xlsx")))
            {
                Stream stream = upload.InputStream;

                using (MemoryStream ms = new MemoryStream())
                {
                    stream.CopyTo(ms);
                    var data = ms.ToArray();

                    IExcelDataReader reader = ExcelReaderFactory.CreateReader(stream);
                    DataSet result = reader.AsDataSet(new ExcelDataSetConfiguration()
                    {
                        ConfigureDataTable = (tableReader) => new ExcelDataTableConfiguration()
                        {
                            UseHeaderRow = false
                        }
                    });
                    var datatable = result.Tables[0];
                    var colHeader1 = datatable.Rows[0][0].ToString();
                    var colHeader2 = datatable.Rows[0][1].ToString();

                    if (reader.FieldCount == 14 && colHeader1 == "دارایی جاری" && colHeader2 == "دارایی غیر جاری")
                    {
                        DataAccess.File fileObj = new DataAccess.File();
                        using (var sql = new LinqHelper())
                        {

                            fileObj.Name = Path.GetFileNameWithoutExtension(upload.FileName);
                            fileObj.Extension = Path.GetExtension(upload.FileName);
                            fileObj.Size = data.Length;
                            fileObj.Sender = Assistant.CurrentUser();
                            fileObj.StatusId = 1;
                            fileObj.RegDate = Convert.ToInt32(Assistant.MiladiToShamsi(Assistant.TodayDateIntMiladi()));
                            fileObj.RegTime = Assistant.TimeNowInt();
                            fileObj.Binary = data;
                            fileObj.FileTypeId = Convert.ToInt32(IO);
                            var res = sql.InsertPosition(fileObj);

                            List<CapitalSufficiency> list = datatable.AsEnumerable().Skip(1)
                                .Select(row => new CapitalSufficiency()
                                {
                                    C_CurrentAssets  = (row.Field<double>(0)),
                                    C_NonCurrentAssets = (row.Field<double>(1)) ,
                                    C_TotalAssets = (row.Field<double>(2)) ,
                                    C_CurrentDebts = (row.Field<double>(3)) ,
                                    C_NonCurrentDebts = (row.Field<double>(4)) ,
                                    C_TotalDebt = (row.Field<double>(5)) ,
                                    C_TotalCommitments = (row.Field<double>(6)) ,
                                    D_CurrentAssets = (row.Field<double>(7)) ,
                                    D_NonCurrentAssets = (row.Field<double>(8)) ,
                                    D_TotalAssets = (row.Field<double>(9)) ,
                                    D_CurrentDebts = (row.Field<double>(10)) ,
                                    D_NonCurrentDebts = (row.Field<double>(11)) ,
                                    D_TotalDebt = (row.Field<double>(12)) ,
                                    D_TotalCommitments = (row.Field<double>(13)) ,
                                    RegDate  =Assistant.TodayDateInt(),
                                    RegTime  =Assistant.TimeNowInt(),
                                    RegUser=Assistant.CurrentUser()}).ToList();

                            foreach (var item in list)
                            {
                                sql.InsertCapitalSufficiency(item);
                            }
                        }
                        reader.Close();
                        return View(datatable);
                    }
                }
            }

            ModelState.AddModelError("File", "خطایی رخ داده! فایل مورد نظر با فایل استاندارد همخوانی ندارد ...! ");
            return View();
        }

        [HttpGet]
        [Authorize]
        public ActionResult Edit(int Id)
        {
            try
            {
                using (var sql2 = new LinqHelper())
                {

                    LinqHelper sql = new LinqHelper();
                    var result = sql.GetCapitalSufficiencies(Id);
                    return View(result);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        [Authorize] 
        public JsonResult DeleteCapitalSufficiencies(int Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.Delete_CapitalSufficiencies(Id);
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }
        
        [Authorize]
        public ActionResult LoadData()
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetCapitalSufficiencies().OrderBy(c=>c.Id);

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [HttpPost]
        [Authorize]
        public ActionResult RegisterCapitalSufficiencies(CapitalSufficiency obj)
        {
            using (var sql = new LinqHelper())
            {
                obj.RegUser = Assistant.CurrentUser();
                obj.RegDate = Convert.ToInt32(Assistant.MiladiToShamsi(Assistant.TodayDateIntMiladi()));
                obj.RegTime = Assistant.TimeNowInt();
                var result = sql.InsertCapitalsufficiency(obj);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public ActionResult UpdateCapitalSufficiencies(CapitalSufficiency obj)
        {
            using (var sql = new LinqHelper())
            {

                obj.RegUser = Assistant.CurrentUser();
                obj.RegDate = Convert.ToInt32(Assistant.MiladiToShamsi(Assistant.TodayDateIntMiladi()));
                obj.RegTime = Assistant.TimeNowInt();

                var result = sql.UpdateCapitalsufficiency(obj);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "AccountingCode" }, JsonRequestBehavior.AllowGet);


            }
        }


    }
}