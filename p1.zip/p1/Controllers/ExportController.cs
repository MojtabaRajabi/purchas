﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OfficeOpenXml;
using Sanay.Library.Utility;
using System.Web.Routing;
using OfficeOpenXml.FormulaParsing.Excel.Functions.DateTime;
using OfficeOpenXml.Style;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Lib.Enum;

namespace Sanay.Lotus.Erm.Controllers
{
    public class ExportController : Controller
    {
        // GET: Export
        public ActionResult Index()
        {
            return View();
        }


        [Authorize]
        public void IOFlowGenerateFile(int id)
        {
            List<GetInputOutputFlowCycleById_Result> data = new List<GetInputOutputFlowCycleById_Result>();
            var lq = new LinqHelper();
            data = lq.GetIOFlowGenerateFileById(id).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].LoadFromCollection(data, true);

            workSheet.Cells[1, 1].Value = "رديف";
            workSheet.Cells[1, 2].Value = "تارخ ميلادي";
            workSheet.Cells[1, 3].Value = "تاريخ شمسي";
            workSheet.Cells[1, 4].Value = "مقدار";

            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=IOFlows" + id + "-" + Assistant.TodayDateInt() + ".xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }

        }


        [Authorize]
        public void IOFlowGenerateExcelFile(string IOFlowCycles, string StartDate, string EndDate, string Value)
        {
            List<GetInputOutputFlowCycle_Result> data = new List<GetInputOutputFlowCycle_Result>();
            var lq = new LinqHelper();
            data = lq.GetInputOutputFlowCycle(IOFlowCycles.ToValidMsgInt(), StartDate.ToValidMsgDate(), EndDate.ToValidMsgDate(), Value.ToValidMsgdouble()).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].LoadFromCollection(data, true);

            //workSheet.Cells[1, 1].Value = "رديف";
            //workSheet.Cells[1, 2].Value = "تارخ ميلادي";
            workSheet.Cells[1, 1].Value = "تاریخ";
            workSheet.Cells[1, 2].Value = "مبلغ";

            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=IOFlows" + IOFlowCycles + "-" + StartDate + "-" + Assistant.TodayDateInt() + ".xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }

        }


        [Authorize]
        public void SymbolPriceDetailes(string Symbol)
        {
            //List<GetHistoricalSymbolPriceBySymbol_Result> data = new List<GetHistoricalSymbolPriceBySymbol_Result>();
            var lq = new LinqHelper();
            var data = lq.GetSymbolHistoricalPriceBySymbol(Symbol).Select(s => new
            {
                DatePrice = s.DatePrice,
                SymbolPrice = s.SymbolPrice,
                SymbolAdjPrice = s.SymbolNAdjPrice,

                Indicator = s.Indicator

            }).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].LoadFromCollection(data, true);

            workSheet.Cells[1, 1].Value = "تارخ قیمت  ";
            workSheet.Cells[1, 2].Value = "قیمت تعدیلی نماد";
            workSheet.Cells[1, 3].Value = "قیمت نماد";
            workSheet.Cells[1, 4].Value = "قیمت شاخص";


            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=جزئیات قیمت نماد " + Symbol + "-" + Assistant.TodayDateInt() + ".xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }

        }






        [Authorize]
        public void ExportAdjustedTradesAllDaysByCompanyId()
        {

            var companyId = Request.QueryString.GetValues("companyId").FirstOrDefault();
            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            List<GetAdjustedTradesAllDaysByCompanyId_Result> data = new List<GetAdjustedTradesAllDaysByCompanyId_Result>();
            var lq = new LinqHelper();
            data = lq.GetAdjustedTradesAllDaysByCompanyId(companyId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate()).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.Cells[1, 1].LoadFromCollection(data, true);
            workSheet.View.RightToLeft = true;

            workSheet.Cells[1, 1].Value = "رديف";
            workSheet.Cells[1, 2].Value = "تاریخ";
            workSheet.Cells[1, 3].Value = "قیمت";
            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=AdjustedTradesAllDays_" + companyId + "_" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }

        [Authorize]
        public void ExportCouponProfit()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            List<GetCouponProfitSymbols_Result> data = new List<GetCouponProfitSymbols_Result>();
            var lq = new LinqHelper();
            data = lq.GetCouponProfitSymbols(startDate.ToValidMsgDate(), endDate.ToValidMsgDate()).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.Cells[1, 1].LoadFromCollection(data, true);
            workSheet.View.RightToLeft = true;

            workSheet.Cells[1, 1].Value = "رديف";
            workSheet.Cells[1, 2].Value = "نماد";
            workSheet.Cells[1, 3].Value = "تعداد تحت تاثیر";
            workSheet.Cells[1, 4].Value = "تعداد کوپن تحت تاثیر";
            workSheet.Cells[1, 5].Value = "سود نگهداشت";
            workSheet.Cells[1, 6].Value = "تاریخ آغاز";
            workSheet.Cells[1, 7].Value = "تاریخ پایان";

            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=CouponProfit" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }


        [Authorize]
        public void ExportListSymbolsFund()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();
            //List<GetLastFundPortfoliosByDate_Result> data = new List<GetLastFundPortfoliosByDate_Result>();
            var lq = new LinqHelper();
            //data = lq.GetCouponProfitSymbols(startDate.ToValidMsgDate(), int.MaxValue).ToList();
            var data = lq.GetLastFundPortfoliosByDate(fundId.TryParseInt32(), startDate.ToValidMsgDate())
                  .Select(s => new
                  {
                      row = s.Id,
                      fundName = s.Name,
                      Instrument = s.Instrument,
                      Count = s.Count,
                      Price = s.Price,
                      Date = s._Date,
                      MarketName = s.MarketName
                  }).ToList();


            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.Cells[1, 1].LoadFromCollection(data, true);
            workSheet.View.RightToLeft = true;

            workSheet.Cells[1, 1].Value = "ردیف";
            workSheet.Cells[1, 2].Value = "نام";
            workSheet.Cells[1, 3].Value = "نماد";
            workSheet.Cells[1, 4].Value = "تعداد";
            workSheet.Cells[1, 5].Value = "قیمت";
            workSheet.Cells[1, 6].Value = "تاریخ";
            workSheet.Cells[1, 7].Value = "کد بازار";

            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=خروجی پرتفوی " + getFundName(fundId.ToString()) + Assistant.TodayDateInt() + "(" + startDate + "-" + fundId + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }


        [Authorize]
        public void ExportSymbolPriceGapsCalculations()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var SymbolId = Request.QueryString.GetValues("Symbol").FirstOrDefault();


            //var miladiStartDate = Assistant.ShamsiToMiladi(startDate.ToValidMsgInt());
            //var miladiEndDate = Assistant.ShamsiToMiladi(endDate.ToValidMsgInt());
            var StartDate = startDate.ToValidMsgInt();
            var EndDate = endDate.ToValidMsgInt();

            //List<GetHistoricalAllSymbolPrice_Result> data = new List<GetHistoricalAllSymbolPrice_Result>();
            var lq = new LinqHelper();
            var data = lq.GetSymbolPriceGapCalculations(StartDate, EndDate, SymbolId.ToValidMsgInt())
                   .Select(s => new
                   {
                       CoTSESymbol = s.DatePrice,
                       DatePrice = s.Indicator,
                       ChangesCount = s.SymbolPrice,
                       SymbolPrice = s.BackDateFlag,
                       retPrice = s.retPrice,
                       RetBackDate = s.RetBackDate
                       ,
                       SymbolNAdjPrice = s.SymbolNAdjPrice

                   }).ToList();


            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.Cells[1, 1].LoadFromCollection(data, true);
            workSheet.View.RightToLeft = true;

            workSheet.Cells[1, 1].Value = "Dates";
            workSheet.Cells[1, 2].Value = "Price_Benchmark";
            workSheet.Cells[1, 3].Value = "Price_Target";
            workSheet.Cells[1, 4].Value = "BackDate_Flag";
            workSheet.Cells[1, 5].Value = "ret_Benchmark";
            workSheet.Cells[1, 6].Value = "ret_Target";
            workSheet.Cells[1, 7].Value = "تعدیل شده";


            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=گپ های قیمتی " + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }



        [Authorize]
        public void ExportSymbolVaR()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var SymbolId = Request.QueryString.GetValues("Symbol").FirstOrDefault();


            //var miladiStartDate = Assistant.ShamsiToMiladi(startDate.ToValidMsgInt());
            //var miladiEndDate = Assistant.ShamsiToMiladi(endDate.ToValidMsgInt());
            var StartDate = startDate.ToValidMsgInt();
            var EndDate = endDate.ToValidMsgInt();

            List<CalculateSymbolVAR_Result> data = new List<CalculateSymbolVAR_Result>();
            var lq = new LinqHelper();
            data = lq.GetSymbolVaR(StartDate, EndDate, SymbolId.ToValidMsgInt()).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.Cells[1, 1].LoadFromCollection(data, true);
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].Value = "Symbol";

            workSheet.Cells[1, 2].Value = "VaR Historical";
            workSheet.Cells[1, 3].Value = "VaR Parametric ";
            workSheet.Cells[1, 4].Value = "VaR Monte-Carlo";

            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=SymbolVaRCalculations" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }



        [Authorize]
        public void ExportAllSymbolsVaR()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var SymbolId = Request.QueryString.GetValues("Symbol").FirstOrDefault();

            var HasCheck = Request.QueryString.GetValues("HasCheck").FirstOrDefault();
            var fields = Request.QueryString.GetValues("fields").FirstOrDefault();

            //var miladiStartDate = Assistant.ShamsiToMiladi(startDate.ToValidMsgInt());
            //var miladiEndDate = Assistant.ShamsiToMiladi(endDate.ToValidMsgInt());
            var StartDate = startDate.ToValidMsgInt();
            var EndDate = endDate.ToValidMsgInt();

            List<CalculateSymbolVAR_Result> data = new List<CalculateSymbolVAR_Result>();
            var lq = new LinqHelper();

            var result = lq.GetSymbolHistoricalPrice("", HasCheck.ToValidMsgInt(), fields);

            foreach (var item in result)
            {

                var res = lq.GetSymbolVaR(StartDate, EndDate, (int)item.SymbolId).FirstOrDefault();
                if (res != null) { data.Add(res); }
            }



            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.Cells[1, 1].LoadFromCollection(data, true);
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].Value = "Symbol";
            workSheet.Cells[1, 2].Value = "VaR Historical";
            workSheet.Cells[1, 3].Value = "VaR Parametric ";
            workSheet.Cells[1, 4].Value = "VaR Monte-Carlo";

            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=ارزش در معرض ریسک "  + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }



        [Authorize]
        public void ExportPortfolioVarByYield()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();

            var chVar = Request.QueryString.GetValues("chVar").FirstOrDefault();

            //var miladiStartDate = Assistant.ShamsiToMiladi(startDate.ToValidMsgInt());
            //var miladiEndDate = Assistant.ShamsiToMiladi(endDate.ToValidMsgInt());
            var StartDate = startDate.ToValidMsgInt();
            var EndDate = endDate.ToValidMsgInt();

            List<CalcPortfolioVarByYield_Result> data = new List<CalcPortfolioVarByYield_Result>();
            var lq = new LinqHelper();



            var Value = lq.GetFundLastValue(fundId.ToValidMsgInt());


            if (chVar.ToValidMsgInt() != -1)
            {
                var result = lq.CalculatePortfolioYieldVAR(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt(), chVar.ToValidMsgInt());
                //result[0].VaR1 = result[0].VaR1 * Value;
                //result[0].VaR2 = result[0].VaR2 * Value;
                //result[0].VarMonteCarlo = result[0].VarMonteCarlo * Value;
                result.Add(new CalcPortfolioVarByYield_Result { VaR1 = result[0].VaR1 * Value, VaR2 = result[0].VaR2 * Value, VarMonteCarlo = result[0].VarMonteCarlo * Value });

                ExcelPackage excel = new ExcelPackage();
                var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
                workSheet.Cells[1, 1].LoadFromCollection(result, true);
                workSheet.View.RightToLeft = true;
                workSheet.Cells[1, 1].Value = " ردیف";
                workSheet.Cells[1, 2].Value = "VaR Historical";
                workSheet.Cells[1, 3].Value = "VaR Parametric";
                workSheet.Cells[1, 4].Value = "VaR Monte-Carlo";
                workSheet.Cells[2, 1].Value = "درصد";
                workSheet.Cells[3, 1].Value = "ارزش";

                using (var memoryStream = new MemoryStream())
                {
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    //here i have set filname as Students.xlsx
                    Response.AddHeader("content-disposition", "attachment;  filename=ارزش در معرض ریسک " +getFundName(fundId.ToString())+ Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                    excel.SaveAs(memoryStream);

                    memoryStream.WriteTo(Response.OutputStream);
                    Response.Flush();
                    Response.End();
                    Response.Clear();
                }

            }
            else
            {
                var result = lq.CalculatePortfolioYieldVAR(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt(), 1);
                var result2 = lq.CalculatePortfolioYieldVAR(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt(), 5);
                var result3 = lq.CalculatePortfolioYieldVAR(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt(), 21);
                var result4 = lq.CalculatePortfolioYieldVAR(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt(), 63);
                var result5 = lq.CalculatePortfolioYieldVAR(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt(), 126);

                result.Add(new CalcPortfolioVarByYield_Result { VaR1 = result[0].VaR1 * Value, VaR2 = result[0].VaR2 * Value, VarMonteCarlo = result[0].VarMonteCarlo * Value });
                result2.Add(new CalcPortfolioVarByYield_Result { VaR1 = result2[0].VaR1 * Value, VaR2 = result2[0].VaR2 * Value, VarMonteCarlo = result2[0].VarMonteCarlo * Value });
                result3.Add(new CalcPortfolioVarByYield_Result { VaR1 = result3[0].VaR1 * Value, VaR2 = result3[0].VaR2 * Value, VarMonteCarlo = result3[0].VarMonteCarlo * Value });
                result4.Add(new CalcPortfolioVarByYield_Result { VaR1 = result4[0].VaR1 * Value, VaR2 = result4[0].VaR2 * Value, VarMonteCarlo = result4[0].VarMonteCarlo * Value });
                result5.Add(new CalcPortfolioVarByYield_Result { VaR1 = result5[0].VaR1 * Value, VaR2 = result5[0].VaR2 * Value, VarMonteCarlo = result5[0].VarMonteCarlo * Value });


                //result[0].VaR1 = result[0].VaR1 * Value;
                //result[0].VaR2 = result[0].VaR2 * Value;
                //result[0].VarMonteCarlo = result[0].VarMonteCarlo * Value;

                //result2[0].VaR1 = result2[0].VaR1 * Value;
                //result2[0].VaR2 = result2[0].VaR2 * Value;
                //result2[0].VarMonteCarlo = result2[0].VarMonteCarlo * Value;

                //result3[0].VaR1 = result3[0].VaR1 * Value;
                //result3[0].VaR2 = result3[0].VaR2 * Value;
                //result3[0].VarMonteCarlo = result3[0].VarMonteCarlo * Value;

                //result4[0].VaR1 = result4[0].VaR1 * Value;
                //result4[0].VaR2 = result4[0].VaR2 * Value;
                //result4[0].VarMonteCarlo = result4[0].VarMonteCarlo * Value;

                //result5[0].VaR1 = result5[0].VaR1 * Value;
                //result5[0].VaR2 = result5[0].VaR2 * Value;
                //result5[0].VarMonteCarlo = result5[0].VarMonteCarlo * Value;



                ExcelPackage excel = new ExcelPackage();
                var workSheet = excel.Workbook.Worksheets.Add("روزانه");
                workSheet.Cells[1, 1].LoadFromCollection(result, true);
                workSheet.View.RightToLeft = true;
                workSheet.Cells[1, 1].Value = " ردیف";
                workSheet.Cells[1, 2].Value = "VaR Historical";
                workSheet.Cells[1, 3].Value = "VaR Parametric";
                workSheet.Cells[1, 4].Value = "VaR Monte-Carlo";
                workSheet.Cells[2, 1].Value = "درصد";
                workSheet.Cells[3, 1].Value = "ارزش";

                var workSheet2 = excel.Workbook.Worksheets.Add("هفتگی");
                workSheet2.Cells[1, 1].LoadFromCollection(result2, true);
                workSheet2.View.RightToLeft = true;
                workSheet2.Cells[1, 1].Value = " ردیف";
                workSheet2.Cells[1, 2].Value = "VaR Historical";
                workSheet2.Cells[1, 3].Value = "VaR Parametric";
                workSheet2.Cells[1, 4].Value = "VaR Monte-Carlo";
                workSheet2.Cells[2, 1].Value = "درصد";
                workSheet2.Cells[3, 1].Value = "ارزش";

                var workSheet3 = excel.Workbook.Worksheets.Add("ماهانه");
                workSheet3.Cells[1, 1].LoadFromCollection(result3, true);
                workSheet3.View.RightToLeft = true;
                workSheet3.Cells[1, 1].Value = " ردیف";
                workSheet3.Cells[1, 2].Value = "VaR Historical";
                workSheet3.Cells[1, 3].Value = "VaR Parametric";
                workSheet3.Cells[1, 4].Value = "VaR Monte-Carlo";
                workSheet3.Cells[2, 1].Value = "درصد";
                workSheet3.Cells[3, 1].Value = "ارزش";

                var workSheet4 = excel.Workbook.Worksheets.Add("فصلی");
                workSheet4.Cells[1, 1].LoadFromCollection(result4, true);
                workSheet4.View.RightToLeft = true;
                workSheet4.Cells[1, 1].Value = " ردیف";
                workSheet4.Cells[1, 2].Value = "VaR Historical";
                workSheet4.Cells[1, 3].Value = "VaR Parametric";
                workSheet4.Cells[1, 4].Value = "VaR Monte-Carlo";
                workSheet4.Cells[2, 1].Value = "درصد";
                workSheet4.Cells[3, 1].Value = "ارزش";

                var workSheet5 = excel.Workbook.Worksheets.Add("شش ماهه");
                workSheet5.Cells[1, 1].LoadFromCollection(result5, true);
                workSheet5.View.RightToLeft = true;
                workSheet5.Cells[1, 1].Value = " ردیف";
                workSheet5.Cells[1, 2].Value = "VaR Historical";
                workSheet5.Cells[1, 3].Value = "VaR Parametric";
                workSheet5.Cells[1, 4].Value = "VaR Monte-Carlo";
                workSheet5.Cells[2, 1].Value = "درصد";
                workSheet5.Cells[3, 1].Value = "ارزش";




                using (var memoryStream = new MemoryStream())
                {
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    //here i have set filname as Students.xlsx
                    Response.AddHeader("content-disposition", "attachment;   filename=ارزش در معرض ریسک " + getFundName(fundId.ToString()) + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                    excel.SaveAs(memoryStream);

                    memoryStream.WriteTo(Response.OutputStream);
                    Response.Flush();
                    Response.End();
                    Response.Clear();
                }






            }


        }







        [Authorize]
        public void ExportPortfolioVar()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();
            var valPeriod = Request.QueryString.GetValues("valPeriod").FirstOrDefault();

            //var miladiStartDate = Assistant.ShamsiToMiladi(startDate.ToValidMsgInt());
            //var miladiEndDate = Assistant.ShamsiToMiladi(endDate.ToValidMsgInt());

            var lq = new LinqHelper();
            if (valPeriod.TryParseInt32() != -1)
            {
                var data = lq.CalculateSemiSTDV2(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), valPeriod.ToValidMsgInt()).ToList();
                ExcelPackage excel = new ExcelPackage();
                var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
                workSheet.Cells[1, 1].LoadFromCollection(data, true);
                workSheet.View.RightToLeft = true;
                workSheet.Cells[1, 1].Value = " انحراف معیار";
                workSheet.Cells[1, 2].Value = "نیم انحراف معیار";


                using (var memoryStream = new MemoryStream())
                {
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    //here i have set filname as Students.xlsx
                    Response.AddHeader("content-disposition", "attachment;  filename= معیارهای پراکندگی "+ getFundName(fundId.ToString()) + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                    excel.SaveAs(memoryStream);

                    memoryStream.WriteTo(Response.OutputStream);
                    Response.Flush();
                    Response.End();
                    Response.Clear();
                }

            }
            else
            {

                var result = lq.CalculateSemiSTDV2(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Daily).ToList();
                var result2 = lq.CalculateSemiSTDV2(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Weekly).ToList();
                var result3 = lq.CalculateSemiSTDV2(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Monthly).ToList();
                var result4 = lq.CalculateSemiSTDV2(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Seasonal).ToList();
                var result5 = lq.CalculateSemiSTDV2(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Months6).ToList();
                var result6 = lq.CalculateSemiSTDV2(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Yearly).ToList();

                result[0]._Title = " روزانه ";
                result2[0]._Title = " هفتگی ";
                result3[0]._Title = " ماهانه ";
                result4[0]._Title = " فصلی ";
                result5[0]._Title = " شش ماهه";
                result6[0]._Title = "سالانه";

                result.AddRange(result2);
                result.AddRange(result3);
                result.AddRange(result4);
                result.AddRange(result5);
                result.AddRange(result6);

                var  res=result.Select(s => new
                {

                    STDEVH =  s.STDEVC
                    ,
                    STDEVC = s.STDEVH
                }).ToList();

                //var data_1 = lq.CalculateSemiSTDV2All(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate()).ToList();
                ExcelPackage excel = new ExcelPackage();
                var workSheet_1 = excel.Workbook.Worksheets.Add("همه");
                workSheet_1.Cells[1, 1].LoadFromCollection(res, true);
                workSheet_1.View.RightToLeft = true;
                workSheet_1.Cells[1, 1].Value = "انحراف معیارروزانه";
                workSheet_1.Cells[1, 2].Value = "نیم انحراف معیار روزانه";

                //workSheet_1.Cells[1, 3].Value = "انحراف معیارهفتگی";
                //workSheet_1.Cells[1, 4].Value = "نیم انحراف معیارهفتگی";

                //workSheet_1.Cells[1, 5].Value = "انحراف معیارماهانه";
                //workSheet_1.Cells[1, 6].Value = "نیم انحراف معیارماهانه";

                //workSheet_1.Cells[1, 7].Value = "انحراف معیار3 ماه";
                //workSheet_1.Cells[1, 8].Value = "نیم انحراف معیار3 ماه";

                //workSheet_1.Cells[1, 9].Value = "انحراف معیار6 ماه";
                //workSheet_1.Cells[1, 10].Value = "نیم انحراف معیار6 ماه";

                //workSheet_1.Cells[1, 11].Value = "انحراف معیاریکسال";
                //workSheet_1.Cells[1, 12].Value = "نیم انحراف معیاریکسال";

                using (var memoryStream = new MemoryStream())
                {
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    //here i have set filname as Students.xlsx
                    Response.AddHeader("content-disposition", "attachment; filename= معیارهای پراکندگی " + getFundName(fundId.ToString()) + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                    excel.SaveAs(memoryStream);

                    memoryStream.WriteTo(Response.OutputStream);
                    Response.Flush();
                    Response.End();
                    Response.Clear();
                }

            }


        }


        [Authorize]
        public void ExportSymbolVariance()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var SymbolId = Request.QueryString.GetValues("SymbolId").FirstOrDefault();

            //var miladiStartDate = Assistant.ShamsiToMiladi(startDate.ToValidMsgInt());
            //var miladiEndDate = Assistant.ShamsiToMiladi(endDate.ToValidMsgInt());

            var lq = new LinqHelper();

            var data = lq.CalculateSymbolSemiSTDV2(SymbolId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate())
                .Select(s => new
                {
                    STDEVC = s.STDEVC
                    ,
                    STDEVH = s.STDEVH
                    ,
                    STDEVCw = s.STDEVC * Math.Sqrt(5)
                    ,
                    STDEVHw = s.STDEVH * Math.Sqrt(5)
                    ,
                    STDEVCm = s.STDEVC * Math.Sqrt(21)
                    ,
                    STDEVHm = s.STDEVH * Math.Sqrt(21)
                    ,
                    STDEVC3m = s.STDEVC * Math.Sqrt(63)
                    ,
                    STDEVH3m = s.STDEVH * Math.Sqrt(63)
                    ,
                    STDEVC6m = s.STDEVC * Math.Sqrt(126)
                    ,
                    STDEVH6m = s.STDEVH * Math.Sqrt(126)
                    ,
                    STDEVCy = s.STDEVC * Math.Sqrt(252)
                    ,
                    STDEVHy = s.STDEVH * Math.Sqrt(252)
                }).ToList();




            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.Cells[1, 1].LoadFromCollection(data, true);
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].Value = "انحراف معیارروزانه";
            workSheet.Cells[1, 2].Value = "نیم انحراف معیار روزانه";

            workSheet.Cells[1, 3].Value = "انحراف معیارهفتگی";
            workSheet.Cells[1, 4].Value = "نیم انحراف معیارهفتگی";

            workSheet.Cells[1, 5].Value = "انحراف معیارماهانه";
            workSheet.Cells[1, 6].Value = "نیم انحراف معیارماهانه";

            workSheet.Cells[1, 7].Value = "انحراف معیار3 ماه";
            workSheet.Cells[1, 8].Value = "نیم انحراف معیار3 ماه";

            workSheet.Cells[1, 9].Value = "انحراف معیار6 ماه";
            workSheet.Cells[1, 10].Value = "نیم انحراف معیار6 ماه";

            workSheet.Cells[1, 11].Value = "انحراف معیاریکسال";
            workSheet.Cells[1, 12].Value = "نیم انحراف معیاریکسال";


            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename= معیارهای پراکندگی " + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }


        [Authorize]
        public void ExportDaysRequiredForSale()
        {
            var Percent = Request.QueryString.GetValues("Percent").FirstOrDefault();
            var Period = Request.QueryString.GetValues("Period").FirstOrDefault();
            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();
            var PDate = Request.QueryString.GetValues("PDate").FirstOrDefault();

            using (var lq = new LinqHelper())
            {


                List<GetSymbolDaysRequiredSale_Result> list = new List<GetSymbolDaysRequiredSale_Result>();

                var listSymbols = lq.GetLastFundPortfoliosByDate(fundId.TryParseInt32(), PDate.ToValidMsgDate());

                var res = listSymbols.GroupBy(d => d.Instrument)
                                            .Select(
                                                g => new GetLastFundPortfoliosByDate_Result
                                                {
                                                    Instrument = g.First().Instrument

                                                }).ToList();


                var endDate = PDate.ToValidMsgDate();
                var startDate = 0;
                if (Period == "1")
                    startDate = Assistant.LastWeekFromDate((Assistant.ShamsiToMiladyDate(PDate.ToValidMsgDate()).TryParseDateTime()));
                else if (Period == "2")
                    startDate = Assistant.LastMonthFromDate((Assistant.ShamsiToMiladyDate(PDate.ToValidMsgDate()).TryParseDateTime()));
                else if (Period == "3")
                    startDate = Assistant.Last2MonthFromDate((Assistant.ShamsiToMiladyDate(PDate.ToValidMsgDate()).TryParseDateTime()));
                else if (Period == "4")
                    startDate = Assistant.Last3MonthFromDate((Assistant.ShamsiToMiladyDate(PDate.ToValidMsgDate()).TryParseDateTime()));
                else if (Period == "5")
                    startDate = Assistant.Last6MonthFromDate((Assistant.ShamsiToMiladyDate(PDate.ToValidMsgDate()).TryParseDateTime()));
                else if (Period == "6")
                    startDate = Assistant.LastYearFromDate((Assistant.ShamsiToMiladyDate(PDate.ToValidMsgDate()).TryParseDateTime()));





                foreach (var item in res)
                {
                    var result = lq.GetSymbolDaysRequiredSale(fundId.ToValidMsgInt(), item.Instrument,
                    Period.ToValidMsgInt(), Percent.ToValidMsgdouble() / 100, startDate, endDate).FirstOrDefault();
                    result.Symbol = item.Instrument;
                    list.Add(result);


                }

                 

                var finalResult = list
                        .Select(x => new
                        {
                            Symbol = x.Symbol,
                            StartDateInt = x._StartDateInt,
                            EndDateInt = x._EndDateInt,
                            ExistingStocks = x._ExistingStocks,
                            AverageStocksTraded = x._AverageStocksTraded,
                            CalResult = x._CalResult,
                        }).ToList();



                ExcelPackage excel = new ExcelPackage();
                var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
                workSheet.Cells[1, 1].LoadFromCollection(finalResult, true);
                workSheet.View.RightToLeft = true;
                workSheet.Cells[1, 1].Value = "نماد";
                workSheet.Cells[1, 2].Value = "تاریخ شروع";

                workSheet.Cells[1, 3].Value = "تاریخ پایان";
                workSheet.Cells[1, 4].Value = "تعداد سهام موجود در صندوق";

                workSheet.Cells[1, 5].Value = "متوسط تعداد سهام های معامله شده";
                workSheet.Cells[1, 6].Value = "نسبت تعداد روزها";



                using (var memoryStream = new MemoryStream())
                {
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    //here i have set filname as Students.xlsx
                    Response.AddHeader("content-disposition", "attachment;  filename= تعداد روز های لازم برای فروش "+ getFundName(fundId.ToString()) + Assistant.TodayDateInt() + "(" + fundId + "-" + PDate + ").xlsx");
                    excel.SaveAs(memoryStream);

                    memoryStream.WriteTo(Response.OutputStream);
                    Response.Flush();
                    Response.End();
                    Response.Clear();
                }



            }

        }















        [Authorize]
        public void ExportPortfolioYieldAll()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var ValState = Request.QueryString.GetValues("ValState").FirstOrDefault();
            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();

            var lq = new LinqHelper();
            var start = startDate.ToValidMsgDate();
            var end = endDate.ToValidMsgDate();

            ExcelPackage excel = new ExcelPackage();

            var startDay = start;
            var startweek = start;
            var startMonth = start;
            var startSeason = start;
            var start6Month = start;


            if (ValState == "-1")
            {
                var data_Daily = lq.GetPortfolioYield(fundId.ToValidMsgInt(), startDay, end, (int)YieldCycle.Daily)
                    .Select(x => new
                    {
                        RowNumber = x.RowNumber,
                        DatePrice = x.DatePrice,
                        StartValue = x.StartValue,
                        EndValue = x.EndValue,
                        SumBuys = x.SumBuys,
                        SumSales = x.SumSales,
                        SumProfit = x._SumProfit,
                        ProtfolioYield = x.ProtfolioYield,
                    }).ToList();

                var data_Weekly = lq.GetPortfolioYield(fundId.ToValidMsgInt(), startweek, end, (int)YieldCycle.Weekly).Select(x => new
                {
                    RowNumber = x.RowNumber,
                    DatePrice = x.DatePrice,
                    StartValue = x.StartValue,
                    EndValue = x.EndValue,
                    SumBuys = x.SumBuys,
                    SumSales = x.SumSales,
                    SumProfit = x._SumProfit,
                    ProtfolioYield = x.ProtfolioYield,
                }).ToList();
                var data_Monthly = lq.GetPortfolioYield(fundId.ToValidMsgInt(), startMonth, end, (int)YieldCycle.Monthly).Select(x => new
                {
                    RowNumber = x.RowNumber,
                    DatePrice = x.DatePrice,
                    StartValue = x.StartValue,
                    EndValue = x.EndValue,
                    SumBuys = x.SumBuys,
                    SumSales = x.SumSales,
                    SumProfit = x._SumProfit,
                    ProtfolioYield = x.ProtfolioYield,
                }).ToList();
                var data_Seasonal = lq.GetPortfolioYield(fundId.ToValidMsgInt(), startSeason, end, (int)YieldCycle.Seasonal).Select(x => new
                {
                    RowNumber = x.RowNumber,
                    DatePrice = x.DatePrice,
                    StartValue = x.StartValue,
                    EndValue = x.EndValue,
                    SumBuys = x.SumBuys,
                    SumSales = x.SumSales,
                    SumProfit = x._SumProfit,
                    ProtfolioYield = x.ProtfolioYield,
                }).ToList();
                var data_Months6 = lq.GetPortfolioYield(fundId.ToValidMsgInt(), start6Month, end, (int)YieldCycle.Months6).Select(x => new
                {
                    RowNumber = x.RowNumber,
                    DatePrice = x.DatePrice,
                    StartValue = x.StartValue,
                    EndValue = x.EndValue,
                    SumBuys = x.SumBuys,
                    SumSales = x.SumSales,
                    SumProfit = x._SumProfit,
                    ProtfolioYield = x.ProtfolioYield,
                }).ToList();
                var data_Yearly = lq.GetPortfolioYield(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Yearly).Select(x => new
                {
                    RowNumber = x.RowNumber,
                    DatePrice = x.DatePrice,
                    StartValue = x.StartValue,
                    EndValue = x.EndValue,
                    SumBuys = x.SumBuys,
                    SumSales = x.SumSales,
                    SumProfit = x._SumProfit,
                    ProtfolioYield = x.ProtfolioYield,
                }).ToList();

                var workSheet_Daily = excel.Workbook.Worksheets.Add("روزانه");
                workSheet_Daily.Cells[1, 1].LoadFromCollection(data_Daily, true);
                workSheet_Daily.View.RightToLeft = true;
                workSheet_Daily.Cells[1, 1].Value = "ردیف";
                workSheet_Daily.Cells[1, 2].Value = "تاریخ";
                workSheet_Daily.Cells[1, 3].Value = "ارزش آغاز دوره";
                workSheet_Daily.Cells[1, 4].Value = "ارزش پایان دوره";
                workSheet_Daily.Cells[1, 5].Value = "مجموع خرید";
                workSheet_Daily.Cells[1, 6].Value = "مجموع فروش";
                workSheet_Daily.Cells[1, 7].Value = "مجموع سود";
                workSheet_Daily.Cells[1, 8].Value = "بازدهی صندوق";


                var workSheet_Weekly = excel.Workbook.Worksheets.Add("هفتگی");
                workSheet_Weekly.Cells[1, 1].LoadFromCollection(data_Weekly, true);
                workSheet_Weekly.View.RightToLeft = true;
                workSheet_Weekly.Cells[1, 1].Value = "ردیف";
                workSheet_Weekly.Cells[1, 2].Value = "تاریخ";
                workSheet_Weekly.Cells[1, 3].Value = "ارزش آغاز دوره";
                workSheet_Weekly.Cells[1, 4].Value = "ارزش پایان دوره";
                workSheet_Weekly.Cells[1, 5].Value = "مجموع خرید";
                workSheet_Weekly.Cells[1, 6].Value = "مجموع فروش";
                workSheet_Weekly.Cells[1, 7].Value = "مجموع سود";
                workSheet_Weekly.Cells[1, 8].Value = "بازدهی صندوق";

                var workSheet_Monthly = excel.Workbook.Worksheets.Add("ماهانه");
                workSheet_Monthly.Cells[1, 1].LoadFromCollection(data_Monthly, true);
                workSheet_Monthly.View.RightToLeft = true;
                workSheet_Monthly.Cells[1, 1].Value = "ردیف";
                workSheet_Monthly.Cells[1, 2].Value = "تاریخ";
                workSheet_Monthly.Cells[1, 3].Value = "ارزش آغاز دوره";
                workSheet_Monthly.Cells[1, 4].Value = "ارزش پایان دوره";
                workSheet_Monthly.Cells[1, 5].Value = "مجموع خرید";
                workSheet_Monthly.Cells[1, 6].Value = "مجموع فروش";
                workSheet_Monthly.Cells[1, 7].Value = "مجموع سود";
                workSheet_Monthly.Cells[1, 8].Value = "بازدهی صندوق";


                var workSheet_Seasonal = excel.Workbook.Worksheets.Add("فصلی");
                workSheet_Seasonal.Cells[1, 1].LoadFromCollection(data_Seasonal, true);
                workSheet_Seasonal.View.RightToLeft = true;
                workSheet_Seasonal.Cells[1, 1].Value = "ردیف";
                workSheet_Seasonal.Cells[1, 2].Value = "تاریخ";
                workSheet_Seasonal.Cells[1, 3].Value = "ارزش آغاز دوره";
                workSheet_Seasonal.Cells[1, 4].Value = "ارزش پایان دوره";
                workSheet_Seasonal.Cells[1, 5].Value = "مجموع خرید";
                workSheet_Seasonal.Cells[1, 6].Value = "مجموع فروش";
                workSheet_Seasonal.Cells[1, 7].Value = "مجموع سود";
                workSheet_Seasonal.Cells[1, 8].Value = "بازدهی صندوق";

                var workSheet_Months6 = excel.Workbook.Worksheets.Add("6 ماه");
                workSheet_Months6.Cells[1, 1].LoadFromCollection(data_Months6, true);
                workSheet_Months6.View.RightToLeft = true;
                workSheet_Months6.Cells[1, 1].Value = "ردیف";
                workSheet_Months6.Cells[1, 2].Value = "تاریخ";
                workSheet_Months6.Cells[1, 3].Value = "ارزش آغاز دوره";
                workSheet_Months6.Cells[1, 4].Value = "ارزش پایان دوره";
                workSheet_Months6.Cells[1, 5].Value = "مجموع خرید";
                workSheet_Months6.Cells[1, 6].Value = "مجموع فروش";
                workSheet_Months6.Cells[1, 7].Value = "مجموع سود";
                workSheet_Months6.Cells[1, 8].Value = "بازدهی صندوق";

                var workSheet_Yearly = excel.Workbook.Worksheets.Add("سالیانه");
                workSheet_Yearly.Cells[1, 1].LoadFromCollection(data_Yearly, true);
                workSheet_Yearly.View.RightToLeft = true;
                workSheet_Yearly.Cells[1, 1].Value = "ردیف";
                workSheet_Yearly.Cells[1, 2].Value = "تاریخ";
                workSheet_Yearly.Cells[1, 3].Value = "ارزش آغاز دوره";
                workSheet_Yearly.Cells[1, 4].Value = "ارزش پایان دوره";
                workSheet_Yearly.Cells[1, 5].Value = "مجموع خرید";
                workSheet_Yearly.Cells[1, 6].Value = "مجموع فروش";
                workSheet_Yearly.Cells[1, 7].Value = "مجموع سود";
                workSheet_Yearly.Cells[1, 8].Value = "بازدهی صندوق";
            }
            else
            {

                if (ValState == "1")
                {
                    var data_Daily = lq.GetPortfolioYield(fundId.ToValidMsgInt(), startDay, end, (int)YieldCycle.Daily).ToList();
                    var workSheet_Daily = excel.Workbook.Worksheets.Add("روزانه");
                    workSheet_Daily.Cells[1, 1].LoadFromCollection(data_Daily, true);
                    workSheet_Daily.View.RightToLeft = true;
                    workSheet_Daily.Cells[1, 1].Value = "ردیف";
                    workSheet_Daily.Cells[1, 2].Value = "تاریخ";
                    workSheet_Daily.Cells[1, 3].Value = "ارزش آغاز دوره";
                    workSheet_Daily.Cells[1, 4].Value = "ارزش پایان دوره";
                    workSheet_Daily.Cells[1, 5].Value = "مجموع خرید";
                    workSheet_Daily.Cells[1, 6].Value = "مجموع فروش";
                    workSheet_Daily.Cells[1, 7].Value = "مجموع سود";
                    workSheet_Daily.Cells[1, 8].Value = "بازدهی صندوق";
                }
                if (ValState == "5")
                {
                    var data_Weekly = lq.GetPortfolioYield(fundId.ToValidMsgInt(), startweek, end, (int)YieldCycle.Weekly).ToList();
                    var workSheet_Weekly = excel.Workbook.Worksheets.Add("هفتگی");
                    workSheet_Weekly.Cells[1, 1].LoadFromCollection(data_Weekly, true);
                    workSheet_Weekly.View.RightToLeft = true;
                    workSheet_Weekly.Cells[1, 1].Value = "ردیف";
                    workSheet_Weekly.Cells[1, 2].Value = "تاریخ";
                    workSheet_Weekly.Cells[1, 3].Value = "ارزش آغاز دوره";
                    workSheet_Weekly.Cells[1, 4].Value = "ارزش پایان دوره";
                    workSheet_Weekly.Cells[1, 5].Value = "مجموع خرید";
                    workSheet_Weekly.Cells[1, 6].Value = "مجموع فروش";
                    workSheet_Weekly.Cells[1, 7].Value = "مجموع سود";
                    workSheet_Weekly.Cells[1, 8].Value = "بازدهی صندوق";
                }
                if (ValState == "21")
                {
                    var data_Monthly = lq.GetPortfolioYield(fundId.ToValidMsgInt(), startMonth, end, (int)YieldCycle.Monthly).ToList();
                    var workSheet_Monthly = excel.Workbook.Worksheets.Add("ماهانه");
                    workSheet_Monthly.Cells[1, 1].LoadFromCollection(data_Monthly, true);
                    workSheet_Monthly.View.RightToLeft = true;
                    workSheet_Monthly.Cells[1, 1].Value = "ردیف";
                    workSheet_Monthly.Cells[1, 2].Value = "تاریخ";
                    workSheet_Monthly.Cells[1, 3].Value = "ارزش آغاز دوره";
                    workSheet_Monthly.Cells[1, 4].Value = "ارزش پایان دوره";
                    workSheet_Monthly.Cells[1, 5].Value = "مجموع خرید";
                    workSheet_Monthly.Cells[1, 6].Value = "مجموع فروش";
                    workSheet_Monthly.Cells[1, 7].Value = "مجموع سود";
                    workSheet_Monthly.Cells[1, 8].Value = "بازدهی صندوق";
                }
                if (ValState == "63")
                {
                    var data_Seasonal = lq.GetPortfolioYield(fundId.ToValidMsgInt(), startSeason, end, (int)YieldCycle.Seasonal).ToList();
                    var workSheet_Seasonal = excel.Workbook.Worksheets.Add("فصلی");
                    workSheet_Seasonal.Cells[1, 1].LoadFromCollection(data_Seasonal, true);
                    workSheet_Seasonal.View.RightToLeft = true;
                    workSheet_Seasonal.Cells[1, 1].Value = "ردیف";
                    workSheet_Seasonal.Cells[1, 2].Value = "تاریخ";
                    workSheet_Seasonal.Cells[1, 3].Value = "ارزش آغاز دوره";
                    workSheet_Seasonal.Cells[1, 4].Value = "ارزش پایان دوره";
                    workSheet_Seasonal.Cells[1, 5].Value = "مجموع خرید";
                    workSheet_Seasonal.Cells[1, 6].Value = "مجموع فروش";
                    workSheet_Seasonal.Cells[1, 7].Value = "مجموع سود";
                    workSheet_Seasonal.Cells[1, 8].Value = "بازدهی صندوق";
                }
                if (ValState == "126")
                {
                    var data_Months6 = lq.GetPortfolioYield(fundId.ToValidMsgInt(), start6Month, end, (int)YieldCycle.Months6).ToList();
                    var workSheet_Months6 = excel.Workbook.Worksheets.Add("6 ماه");
                    workSheet_Months6.Cells[1, 1].LoadFromCollection(data_Months6, true);
                    workSheet_Months6.View.RightToLeft = true;
                    workSheet_Months6.Cells[1, 1].Value = "ردیف";
                    workSheet_Months6.Cells[1, 2].Value = "تاریخ";
                    workSheet_Months6.Cells[1, 3].Value = "ارزش آغاز دوره";
                    workSheet_Months6.Cells[1, 4].Value = "ارزش پایان دوره";
                    workSheet_Months6.Cells[1, 5].Value = "مجموع خرید";
                    workSheet_Months6.Cells[1, 6].Value = "مجموع فروش";
                    workSheet_Months6.Cells[1, 7].Value = "مجموع سود";
                    workSheet_Months6.Cells[1, 8].Value = "بازدهی صندوق";
                }

                if (ValState == "252")
                {
                    var data_Yearly = lq.GetPortfolioYield(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Yearly).ToList();
                    var workSheet_Yearly = excel.Workbook.Worksheets.Add("سالیانه");
                    workSheet_Yearly.Cells[1, 1].LoadFromCollection(data_Yearly, true);
                    workSheet_Yearly.View.RightToLeft = true;
                    workSheet_Yearly.Cells[1, 1].Value = "ردیف";
                    workSheet_Yearly.Cells[1, 2].Value = "تاریخ";
                    workSheet_Yearly.Cells[1, 3].Value = "ارزش آغاز دوره";
                    workSheet_Yearly.Cells[1, 4].Value = "ارزش پایان دوره";
                    workSheet_Yearly.Cells[1, 5].Value = "مجموع خرید";
                    workSheet_Yearly.Cells[1, 6].Value = "مجموع فروش";
                    workSheet_Yearly.Cells[1, 7].Value = "مجموع سود";
                    workSheet_Yearly.Cells[1, 8].Value = "بازدهی صندوق";
                }


            }




            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename= بازدهی پرتفوی " + getFundName(fundId.ToString()) + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }




        [Authorize]
        public void ExportPortfolioYieldAllNAdjPrice()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var ValState = Request.QueryString.GetValues("ValState").FirstOrDefault();
            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();

            var lq = new LinqHelper();
            var start = startDate.ToValidMsgDate();
            var end = endDate.ToValidMsgDate();

            ExcelPackage excel = new ExcelPackage();

            var startDay = start;
            var startweek = start;
            var startMonth = start;
            var startSeason = start;
            var start6Month = start;


            if (ValState == "-1")
            {
                var data_Daily = lq.CalculateFundYieldNAdjPrice(fundId.ToValidMsgInt(), startDay, end, (int)YieldCycle.Daily).ToList();
                var data_Weekly = lq.CalculateFundYieldNAdjPrice(fundId.ToValidMsgInt(), startweek, end, (int)YieldCycle.Weekly).ToList();
                var data_Monthly = lq.CalculateFundYieldNAdjPrice(fundId.ToValidMsgInt(), startMonth, end, (int)YieldCycle.Monthly).ToList();
                var data_Seasonal = lq.CalculateFundYieldNAdjPrice(fundId.ToValidMsgInt(), startSeason, end, (int)YieldCycle.Seasonal).ToList();
                var data_Months6 = lq.CalculateFundYieldNAdjPrice(fundId.ToValidMsgInt(), start6Month, end, (int)YieldCycle.Months6).ToList();
                var data_Yearly = lq.CalculateFundYieldNAdjPrice(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Yearly).ToList();

                var workSheet_Daily = excel.Workbook.Worksheets.Add("روزانه");
                workSheet_Daily.Cells[1, 1].LoadFromCollection(data_Daily, true);
                workSheet_Daily.View.RightToLeft = true;
                workSheet_Daily.Cells[1, 1].Value = "ردیف";
                workSheet_Daily.Cells[1, 2].Value = "تاریخ";
                workSheet_Daily.Cells[1, 3].Value = "ارزش آغاز دوره";
                workSheet_Daily.Cells[1, 4].Value = "ارزش پایان دوره";
                workSheet_Daily.Cells[1, 5].Value = "مجموع خرید";
                workSheet_Daily.Cells[1, 6].Value = "مجموع فروش";
                workSheet_Daily.Cells[1, 7].Value = "مجموع سود";
                workSheet_Daily.Cells[1, 8].Value = "بازدهی صندوق";


                var workSheet_Weekly = excel.Workbook.Worksheets.Add("هفتگی");
                workSheet_Weekly.Cells[1, 1].LoadFromCollection(data_Weekly, true);
                workSheet_Weekly.View.RightToLeft = true;
                workSheet_Weekly.Cells[1, 1].Value = "ردیف";
                workSheet_Weekly.Cells[1, 2].Value = "تاریخ";
                workSheet_Weekly.Cells[1, 3].Value = "ارزش آغاز دوره";
                workSheet_Weekly.Cells[1, 4].Value = "ارزش پایان دوره";
                workSheet_Weekly.Cells[1, 5].Value = "مجموع خرید";
                workSheet_Weekly.Cells[1, 6].Value = "مجموع فروش";
                workSheet_Weekly.Cells[1, 7].Value = "مجموع سود";
                workSheet_Weekly.Cells[1, 8].Value = "بازدهی صندوق";

                var workSheet_Monthly = excel.Workbook.Worksheets.Add("ماهانه");
                workSheet_Monthly.Cells[1, 1].LoadFromCollection(data_Monthly, true);
                workSheet_Monthly.View.RightToLeft = true;
                workSheet_Monthly.Cells[1, 1].Value = "ردیف";
                workSheet_Monthly.Cells[1, 2].Value = "تاریخ";
                workSheet_Monthly.Cells[1, 3].Value = "ارزش آغاز دوره";
                workSheet_Monthly.Cells[1, 4].Value = "ارزش پایان دوره";
                workSheet_Monthly.Cells[1, 5].Value = "مجموع خرید";
                workSheet_Monthly.Cells[1, 6].Value = "مجموع فروش";
                workSheet_Monthly.Cells[1, 7].Value = "مجموع سود";
                workSheet_Monthly.Cells[1, 8].Value = "بازدهی صندوق";


                var workSheet_Seasonal = excel.Workbook.Worksheets.Add("فصلی");
                workSheet_Seasonal.Cells[1, 1].LoadFromCollection(data_Seasonal, true);
                workSheet_Seasonal.View.RightToLeft = true;
                workSheet_Seasonal.Cells[1, 1].Value = "ردیف";
                workSheet_Seasonal.Cells[1, 2].Value = "تاریخ";
                workSheet_Seasonal.Cells[1, 3].Value = "ارزش آغاز دوره";
                workSheet_Seasonal.Cells[1, 4].Value = "ارزش پایان دوره";
                workSheet_Seasonal.Cells[1, 5].Value = "مجموع خرید";
                workSheet_Seasonal.Cells[1, 6].Value = "مجموع فروش";
                workSheet_Seasonal.Cells[1, 7].Value = "مجموع سود";
                workSheet_Seasonal.Cells[1, 8].Value = "بازدهی صندوق";

                var workSheet_Months6 = excel.Workbook.Worksheets.Add("6 ماه");
                workSheet_Months6.Cells[1, 1].LoadFromCollection(data_Months6, true);
                workSheet_Months6.View.RightToLeft = true;
                workSheet_Months6.Cells[1, 1].Value = "ردیف";
                workSheet_Months6.Cells[1, 2].Value = "تاریخ";
                workSheet_Months6.Cells[1, 3].Value = "ارزش آغاز دوره";
                workSheet_Months6.Cells[1, 4].Value = "ارزش پایان دوره";
                workSheet_Months6.Cells[1, 5].Value = "مجموع خرید";
                workSheet_Months6.Cells[1, 6].Value = "مجموع فروش";
                workSheet_Months6.Cells[1, 7].Value = "مجموع سود";
                workSheet_Months6.Cells[1, 8].Value = "بازدهی صندوق";

                var workSheet_Yearly = excel.Workbook.Worksheets.Add("سالیانه");
                workSheet_Yearly.Cells[1, 1].LoadFromCollection(data_Yearly, true);
                workSheet_Yearly.View.RightToLeft = true;
                workSheet_Yearly.Cells[1, 1].Value = "ردیف";
                workSheet_Yearly.Cells[1, 2].Value = "تاریخ";
                workSheet_Yearly.Cells[1, 3].Value = "ارزش آغاز دوره";
                workSheet_Yearly.Cells[1, 4].Value = "ارزش پایان دوره";
                workSheet_Yearly.Cells[1, 5].Value = "مجموع خرید";
                workSheet_Yearly.Cells[1, 6].Value = "مجموع فروش";
                workSheet_Yearly.Cells[1, 7].Value = "مجموع سود";
                workSheet_Yearly.Cells[1, 8].Value = "بازدهی صندوق";
            }
            else
            {

                if (ValState == "1")
                {
                    var data_Daily = lq.GetPortfolioYield(fundId.ToValidMsgInt(), startDay, end, (int)YieldCycle.Daily).ToList();
                    var workSheet_Daily = excel.Workbook.Worksheets.Add("روزانه");
                    workSheet_Daily.Cells[1, 1].LoadFromCollection(data_Daily, true);
                    workSheet_Daily.View.RightToLeft = true;
                    workSheet_Daily.Cells[1, 1].Value = "ردیف";
                    workSheet_Daily.Cells[1, 2].Value = "تاریخ";
                    workSheet_Daily.Cells[1, 3].Value = "ارزش آغاز دوره";
                    workSheet_Daily.Cells[1, 4].Value = "ارزش پایان دوره";
                    workSheet_Daily.Cells[1, 5].Value = "مجموع خرید";
                    workSheet_Daily.Cells[1, 6].Value = "مجموع فروش";
                    workSheet_Daily.Cells[1, 7].Value = "مجموع سود";
                    workSheet_Daily.Cells[1, 8].Value = "بازدهی صندوق";
                }
                if (ValState == "5")
                {
                    var data_Weekly = lq.GetPortfolioYield(fundId.ToValidMsgInt(), startweek, end, (int)YieldCycle.Weekly).ToList();
                    var workSheet_Weekly = excel.Workbook.Worksheets.Add("هفتگی");
                    workSheet_Weekly.Cells[1, 1].LoadFromCollection(data_Weekly, true);
                    workSheet_Weekly.View.RightToLeft = true;
                    workSheet_Weekly.Cells[1, 1].Value = "ردیف";
                    workSheet_Weekly.Cells[1, 2].Value = "تاریخ";
                    workSheet_Weekly.Cells[1, 3].Value = "ارزش آغاز دوره";
                    workSheet_Weekly.Cells[1, 4].Value = "ارزش پایان دوره";
                    workSheet_Weekly.Cells[1, 5].Value = "مجموع خرید";
                    workSheet_Weekly.Cells[1, 6].Value = "مجموع فروش";
                    workSheet_Weekly.Cells[1, 7].Value = "مجموع سود";
                    workSheet_Weekly.Cells[1, 8].Value = "بازدهی صندوق";
                }
                if (ValState == "21")
                {
                    var data_Monthly = lq.GetPortfolioYield(fundId.ToValidMsgInt(), startMonth, end, (int)YieldCycle.Monthly).ToList();
                    var workSheet_Monthly = excel.Workbook.Worksheets.Add("ماهانه");
                    workSheet_Monthly.Cells[1, 1].LoadFromCollection(data_Monthly, true);
                    workSheet_Monthly.View.RightToLeft = true;
                    workSheet_Monthly.Cells[1, 1].Value = "ردیف";
                    workSheet_Monthly.Cells[1, 2].Value = "تاریخ";
                    workSheet_Monthly.Cells[1, 3].Value = "ارزش آغاز دوره";
                    workSheet_Monthly.Cells[1, 4].Value = "ارزش پایان دوره";
                    workSheet_Monthly.Cells[1, 5].Value = "مجموع خرید";
                    workSheet_Monthly.Cells[1, 6].Value = "مجموع فروش";
                    workSheet_Monthly.Cells[1, 7].Value = "مجموع سود";
                    workSheet_Monthly.Cells[1, 8].Value = "بازدهی صندوق";
                }
                if (ValState == "63")
                {
                    var data_Seasonal = lq.GetPortfolioYield(fundId.ToValidMsgInt(), startSeason, end, (int)YieldCycle.Seasonal).ToList();
                    var workSheet_Seasonal = excel.Workbook.Worksheets.Add("فصلی");
                    workSheet_Seasonal.Cells[1, 1].LoadFromCollection(data_Seasonal, true);
                    workSheet_Seasonal.View.RightToLeft = true;
                    workSheet_Seasonal.Cells[1, 1].Value = "ردیف";
                    workSheet_Seasonal.Cells[1, 2].Value = "تاریخ";
                    workSheet_Seasonal.Cells[1, 3].Value = "ارزش آغاز دوره";
                    workSheet_Seasonal.Cells[1, 4].Value = "ارزش پایان دوره";
                    workSheet_Seasonal.Cells[1, 5].Value = "مجموع خرید";
                    workSheet_Seasonal.Cells[1, 6].Value = "مجموع فروش";
                    workSheet_Seasonal.Cells[1, 7].Value = "مجموع سود";
                    workSheet_Seasonal.Cells[1, 8].Value = "بازدهی صندوق";
                }
                if (ValState == "126")
                {
                    var data_Months6 = lq.GetPortfolioYield(fundId.ToValidMsgInt(), start6Month, end, (int)YieldCycle.Months6).ToList();
                    var workSheet_Months6 = excel.Workbook.Worksheets.Add("6 ماه");
                    workSheet_Months6.Cells[1, 1].LoadFromCollection(data_Months6, true);
                    workSheet_Months6.View.RightToLeft = true;
                    workSheet_Months6.Cells[1, 1].Value = "ردیف";
                    workSheet_Months6.Cells[1, 2].Value = "تاریخ";
                    workSheet_Months6.Cells[1, 3].Value = "ارزش آغاز دوره";
                    workSheet_Months6.Cells[1, 4].Value = "ارزش پایان دوره";
                    workSheet_Months6.Cells[1, 5].Value = "مجموع خرید";
                    workSheet_Months6.Cells[1, 6].Value = "مجموع فروش";
                    workSheet_Months6.Cells[1, 7].Value = "مجموع سود";
                    workSheet_Months6.Cells[1, 8].Value = "بازدهی صندوق";
                }

                if (ValState == "252")
                {
                    var data_Yearly = lq.GetPortfolioYield(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Yearly).ToList();
                    var workSheet_Yearly = excel.Workbook.Worksheets.Add("سالیانه");
                    workSheet_Yearly.Cells[1, 1].LoadFromCollection(data_Yearly, true);
                    workSheet_Yearly.View.RightToLeft = true;
                    workSheet_Yearly.Cells[1, 1].Value = "ردیف";
                    workSheet_Yearly.Cells[1, 2].Value = "تاریخ";
                    workSheet_Yearly.Cells[1, 3].Value = "ارزش آغاز دوره";
                    workSheet_Yearly.Cells[1, 4].Value = "ارزش پایان دوره";
                    workSheet_Yearly.Cells[1, 5].Value = "مجموع خرید";
                    workSheet_Yearly.Cells[1, 6].Value = "مجموع فروش";
                    workSheet_Yearly.Cells[1, 7].Value = "مجموع سود";
                    workSheet_Yearly.Cells[1, 8].Value = "بازدهی صندوق";
                }


            }




            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename= بازدهی پرتفوی " + getFundName(fundId.ToString()) + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }







        [Authorize]
        public void ExportPortfolioYieldAllAdjPrice()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var ValState = Request.QueryString.GetValues("ValState").FirstOrDefault();
            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();

            var lq = new LinqHelper();
            var start = startDate.ToValidMsgDate();
            var end = endDate.ToValidMsgDate();

            ExcelPackage excel = new ExcelPackage();

            var startDay = start;
            var startweek = start;
            var startMonth = start;
            var startSeason = start;
            var start6Month = start;


            if (ValState == "-1")
            {
                var data_Daily = lq.CalculateFundYieldSimplePrice(fundId.ToValidMsgInt(), startDay, end, (int)YieldCycle.Daily).Select(x => new
                {
                    RowNumber = x.RowNumber,
                    DatePrice = x.DatePrice,
                    StartValue = x.StartValue,
                    EndValue = x.EndValue,
                    SumBuys = x.SumBuys,
                    SumSales = x.SumSales,
                    SumProfit = x._SumProfit,
                    ProtfolioYield = x.ProtfolioYield,
                }).ToList();
                var data_Weekly = lq.CalculateFundYieldSimplePrice(fundId.ToValidMsgInt(), startweek, end, (int)YieldCycle.Weekly).Select(x => new
                {
                    RowNumber = x.RowNumber,
                    DatePrice = x.DatePrice,
                    StartValue = x.StartValue,
                    EndValue = x.EndValue,
                    SumBuys = x.SumBuys,
                    SumSales = x.SumSales,
                    SumProfit = x._SumProfit,
                    ProtfolioYield = x.ProtfolioYield,
                }).ToList();
                var data_Monthly = lq.CalculateFundYieldSimplePrice(fundId.ToValidMsgInt(), startMonth, end, (int)YieldCycle.Monthly).Select(x => new
                {
                    RowNumber = x.RowNumber,
                    DatePrice = x.DatePrice,
                    StartValue = x.StartValue,
                    EndValue = x.EndValue,
                    SumBuys = x.SumBuys,
                    SumSales = x.SumSales,
                    SumProfit = x._SumProfit,
                    ProtfolioYield = x.ProtfolioYield,
                }).ToList();
                var data_Seasonal = lq.CalculateFundYieldSimplePrice(fundId.ToValidMsgInt(), startSeason, end, (int)YieldCycle.Seasonal).Select(x => new
                {
                    RowNumber = x.RowNumber,
                    DatePrice = x.DatePrice,
                    StartValue = x.StartValue,
                    EndValue = x.EndValue,
                    SumBuys = x.SumBuys,
                    SumSales = x.SumSales,
                    SumProfit = x._SumProfit,
                    ProtfolioYield = x.ProtfolioYield,
                }).ToList();
                var data_Months6 = lq.CalculateFundYieldSimplePrice(fundId.ToValidMsgInt(), start6Month, end, (int)YieldCycle.Months6).Select(x => new
                {
                    RowNumber = x.RowNumber,
                    DatePrice = x.DatePrice,
                    StartValue = x.StartValue,
                    EndValue = x.EndValue,
                    SumBuys = x.SumBuys,
                    SumSales = x.SumSales,
                    SumProfit = x._SumProfit,
                    ProtfolioYield = x.ProtfolioYield,
                }).ToList();
                var data_Yearly = lq.CalculateFundYieldSimplePrice(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Yearly).Select(x => new
                {
                    RowNumber = x.RowNumber,
                    DatePrice = x.DatePrice,
                    StartValue = x.StartValue,
                    EndValue = x.EndValue,
                    SumBuys = x.SumBuys,
                    SumSales = x.SumSales,
                    SumProfit = x._SumProfit,
                    ProtfolioYield = x.ProtfolioYield,
                }).ToList();

                var workSheet_Daily = excel.Workbook.Worksheets.Add("روزانه");
                workSheet_Daily.Cells[1, 1].LoadFromCollection(data_Daily, true);
                workSheet_Daily.View.RightToLeft = true;
                workSheet_Daily.Cells[1, 1].Value = "ردیف";
                workSheet_Daily.Cells[1, 2].Value = "تاریخ";
                workSheet_Daily.Cells[1, 3].Value = "ارزش آغاز دوره";
                workSheet_Daily.Cells[1, 4].Value = "ارزش پایان دوره";
                workSheet_Daily.Cells[1, 5].Value = "مجموع خرید";
                workSheet_Daily.Cells[1, 6].Value = "مجموع فروش";
                workSheet_Daily.Cells[1, 7].Value = "مجموع سود";
                workSheet_Daily.Cells[1, 8].Value = "بازدهی صندوق";


                var workSheet_Weekly = excel.Workbook.Worksheets.Add("هفتگی");
                workSheet_Weekly.Cells[1, 1].LoadFromCollection(data_Weekly, true);
                workSheet_Weekly.View.RightToLeft = true;
                workSheet_Weekly.Cells[1, 1].Value = "ردیف";
                workSheet_Weekly.Cells[1, 2].Value = "تاریخ";
                workSheet_Weekly.Cells[1, 3].Value = "ارزش آغاز دوره";
                workSheet_Weekly.Cells[1, 4].Value = "ارزش پایان دوره";
                workSheet_Weekly.Cells[1, 5].Value = "مجموع خرید";
                workSheet_Weekly.Cells[1, 6].Value = "مجموع فروش";
                workSheet_Weekly.Cells[1, 7].Value = "مجموع سود";
                workSheet_Weekly.Cells[1, 8].Value = "بازدهی صندوق";

                var workSheet_Monthly = excel.Workbook.Worksheets.Add("ماهانه");
                workSheet_Monthly.Cells[1, 1].LoadFromCollection(data_Monthly, true);
                workSheet_Monthly.View.RightToLeft = true;
                workSheet_Monthly.Cells[1, 1].Value = "ردیف";
                workSheet_Monthly.Cells[1, 2].Value = "تاریخ";
                workSheet_Monthly.Cells[1, 3].Value = "ارزش آغاز دوره";
                workSheet_Monthly.Cells[1, 4].Value = "ارزش پایان دوره";
                workSheet_Monthly.Cells[1, 5].Value = "مجموع خرید";
                workSheet_Monthly.Cells[1, 6].Value = "مجموع فروش";
                workSheet_Monthly.Cells[1, 7].Value = "مجموع سود";
                workSheet_Monthly.Cells[1, 8].Value = "بازدهی صندوق";


                var workSheet_Seasonal = excel.Workbook.Worksheets.Add("فصلی");
                workSheet_Seasonal.Cells[1, 1].LoadFromCollection(data_Seasonal, true);
                workSheet_Seasonal.View.RightToLeft = true;
                workSheet_Seasonal.Cells[1, 1].Value = "ردیف";
                workSheet_Seasonal.Cells[1, 2].Value = "تاریخ";
                workSheet_Seasonal.Cells[1, 3].Value = "ارزش آغاز دوره";
                workSheet_Seasonal.Cells[1, 4].Value = "ارزش پایان دوره";
                workSheet_Seasonal.Cells[1, 5].Value = "مجموع خرید";
                workSheet_Seasonal.Cells[1, 6].Value = "مجموع فروش";
                workSheet_Seasonal.Cells[1, 7].Value = "مجموع سود";
                workSheet_Seasonal.Cells[1, 8].Value = "بازدهی صندوق";

                var workSheet_Months6 = excel.Workbook.Worksheets.Add("6 ماه");
                workSheet_Months6.Cells[1, 1].LoadFromCollection(data_Months6, true);
                workSheet_Months6.View.RightToLeft = true;
                workSheet_Months6.Cells[1, 1].Value = "ردیف";
                workSheet_Months6.Cells[1, 2].Value = "تاریخ";
                workSheet_Months6.Cells[1, 3].Value = "ارزش آغاز دوره";
                workSheet_Months6.Cells[1, 4].Value = "ارزش پایان دوره";
                workSheet_Months6.Cells[1, 5].Value = "مجموع خرید";
                workSheet_Months6.Cells[1, 6].Value = "مجموع فروش";
                workSheet_Months6.Cells[1, 7].Value = "مجموع سود";
                workSheet_Months6.Cells[1, 8].Value = "بازدهی صندوق";

                var workSheet_Yearly = excel.Workbook.Worksheets.Add("سالیانه");
                workSheet_Yearly.Cells[1, 1].LoadFromCollection(data_Yearly, true);
                workSheet_Yearly.View.RightToLeft = true;
                workSheet_Yearly.Cells[1, 1].Value = "ردیف";
                workSheet_Yearly.Cells[1, 2].Value = "تاریخ";
                workSheet_Yearly.Cells[1, 3].Value = "ارزش آغاز دوره";
                workSheet_Yearly.Cells[1, 4].Value = "ارزش پایان دوره";
                workSheet_Yearly.Cells[1, 5].Value = "مجموع خرید";
                workSheet_Yearly.Cells[1, 6].Value = "مجموع فروش";
                workSheet_Yearly.Cells[1, 7].Value = "مجموع سود";
                workSheet_Yearly.Cells[1, 8].Value = "بازدهی صندوق";
            }
            else
            {

                if (ValState == "1")
                {
                    var data_Daily = lq.CalculateFundYieldSimplePrice(fundId.ToValidMsgInt(), startDay, end, (int)YieldCycle.Daily).ToList();
                    var workSheet_Daily = excel.Workbook.Worksheets.Add("روزانه");
                    workSheet_Daily.Cells[1, 1].LoadFromCollection(data_Daily, true);
                    workSheet_Daily.View.RightToLeft = true;
                    workSheet_Daily.Cells[1, 1].Value = "ردیف";
                    workSheet_Daily.Cells[1, 2].Value = "تاریخ";
                    workSheet_Daily.Cells[1, 3].Value = "ارزش آغاز دوره";
                    workSheet_Daily.Cells[1, 4].Value = "ارزش پایان دوره";
                    workSheet_Daily.Cells[1, 5].Value = "مجموع خرید";
                    workSheet_Daily.Cells[1, 6].Value = "مجموع فروش";
                    workSheet_Daily.Cells[1, 7].Value = "مجموع سود";
                    workSheet_Daily.Cells[1, 8].Value = "بازدهی صندوق";
                }
                if (ValState == "5")
                {
                    var data_Weekly = lq.CalculateFundYieldSimplePrice(fundId.ToValidMsgInt(), startweek, end, (int)YieldCycle.Weekly).ToList();
                    var workSheet_Weekly = excel.Workbook.Worksheets.Add("هفتگی");
                    workSheet_Weekly.Cells[1, 1].LoadFromCollection(data_Weekly, true);
                    workSheet_Weekly.View.RightToLeft = true;
                    workSheet_Weekly.Cells[1, 1].Value = "ردیف";
                    workSheet_Weekly.Cells[1, 2].Value = "تاریخ";
                    workSheet_Weekly.Cells[1, 3].Value = "ارزش آغاز دوره";
                    workSheet_Weekly.Cells[1, 4].Value = "ارزش پایان دوره";
                    workSheet_Weekly.Cells[1, 5].Value = "مجموع خرید";
                    workSheet_Weekly.Cells[1, 6].Value = "مجموع فروش";
                    workSheet_Weekly.Cells[1, 7].Value = "مجموع سود";
                    workSheet_Weekly.Cells[1, 8].Value = "بازدهی صندوق";
                }
                if (ValState == "21")
                {
                    var data_Monthly = lq.CalculateFundYieldSimplePrice(fundId.ToValidMsgInt(), startMonth, end, (int)YieldCycle.Monthly).ToList();
                    var workSheet_Monthly = excel.Workbook.Worksheets.Add("ماهانه");
                    workSheet_Monthly.Cells[1, 1].LoadFromCollection(data_Monthly, true);
                    workSheet_Monthly.View.RightToLeft = true;
                    workSheet_Monthly.Cells[1, 1].Value = "ردیف";
                    workSheet_Monthly.Cells[1, 2].Value = "تاریخ";
                    workSheet_Monthly.Cells[1, 3].Value = "ارزش آغاز دوره";
                    workSheet_Monthly.Cells[1, 4].Value = "ارزش پایان دوره";
                    workSheet_Monthly.Cells[1, 5].Value = "مجموع خرید";
                    workSheet_Monthly.Cells[1, 6].Value = "مجموع فروش";
                    workSheet_Monthly.Cells[1, 7].Value = "مجموع سود";
                    workSheet_Monthly.Cells[1, 8].Value = "بازدهی صندوق";
                }
                if (ValState == "63")
                {
                    var data_Seasonal = lq.CalculateFundYieldSimplePrice(fundId.ToValidMsgInt(), startSeason, end, (int)YieldCycle.Seasonal).ToList();
                    var workSheet_Seasonal = excel.Workbook.Worksheets.Add("فصلی");
                    workSheet_Seasonal.Cells[1, 1].LoadFromCollection(data_Seasonal, true);
                    workSheet_Seasonal.View.RightToLeft = true;
                    workSheet_Seasonal.Cells[1, 1].Value = "ردیف";
                    workSheet_Seasonal.Cells[1, 2].Value = "تاریخ";
                    workSheet_Seasonal.Cells[1, 3].Value = "ارزش آغاز دوره";
                    workSheet_Seasonal.Cells[1, 4].Value = "ارزش پایان دوره";
                    workSheet_Seasonal.Cells[1, 5].Value = "مجموع خرید";
                    workSheet_Seasonal.Cells[1, 6].Value = "مجموع فروش";
                    workSheet_Seasonal.Cells[1, 7].Value = "مجموع سود";
                    workSheet_Seasonal.Cells[1, 8].Value = "بازدهی صندوق";
                }
                if (ValState == "126")
                {
                    var data_Months6 = lq.CalculateFundYieldSimplePrice(fundId.ToValidMsgInt(), start6Month, end, (int)YieldCycle.Months6).ToList();
                    var workSheet_Months6 = excel.Workbook.Worksheets.Add("6 ماه");
                    workSheet_Months6.Cells[1, 1].LoadFromCollection(data_Months6, true);
                    workSheet_Months6.View.RightToLeft = true;
                    workSheet_Months6.Cells[1, 1].Value = "ردیف";
                    workSheet_Months6.Cells[1, 2].Value = "تاریخ";
                    workSheet_Months6.Cells[1, 3].Value = "ارزش آغاز دوره";
                    workSheet_Months6.Cells[1, 4].Value = "ارزش پایان دوره";
                    workSheet_Months6.Cells[1, 5].Value = "مجموع خرید";
                    workSheet_Months6.Cells[1, 6].Value = "مجموع فروش";
                    workSheet_Months6.Cells[1, 7].Value = "مجموع سود";
                    workSheet_Months6.Cells[1, 8].Value = "بازدهی صندوق";
                }

                if (ValState == "252")
                {
                    var data_Yearly = lq.CalculateFundYieldSimplePrice(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Yearly).ToList();
                    var workSheet_Yearly = excel.Workbook.Worksheets.Add("سالیانه");
                    workSheet_Yearly.Cells[1, 1].LoadFromCollection(data_Yearly, true);
                    workSheet_Yearly.View.RightToLeft = true;
                    workSheet_Yearly.Cells[1, 1].Value = "ردیف";
                    workSheet_Yearly.Cells[1, 2].Value = "تاریخ";
                    workSheet_Yearly.Cells[1, 3].Value = "ارزش آغاز دوره";
                    workSheet_Yearly.Cells[1, 4].Value = "ارزش پایان دوره";
                    workSheet_Yearly.Cells[1, 5].Value = "مجموع خرید";
                    workSheet_Yearly.Cells[1, 6].Value = "مجموع فروش";
                    workSheet_Yearly.Cells[1, 7].Value = "مجموع سود";
                    workSheet_Yearly.Cells[1, 8].Value = "بازدهی صندوق";
                }


            }




            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename= بازدهی پرتفوی "+ getFundName(fundId.ToString()) + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }






























        [Authorize]
        public void ExportYieldRanking()
        {

            //var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();

            var lq = new LinqHelper();
            //var start = startDate.ToValidMsgDate();
            var end = endDate.ToValidMsgDate();

            ExcelPackage excel = new ExcelPackage();


            var result = lq.GetPortfolioYieldRanking(end, fundId.ToValidMsgInt()).ToList();


            var data_Daily = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Daily").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
            var data_Weekly = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Weekly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
            var data_Monthly = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Monthly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
            var data_Seasonal = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Seasonaly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
            var data_Months6 = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "6Monthly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
            var data_Yearly = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Yearly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();

            var workSheet_Daily = excel.Workbook.Worksheets.Add("روزانه");
            workSheet_Daily.Cells[1, 1].LoadFromCollection(data_Daily, true);
            workSheet_Daily.View.RightToLeft = true;
            workSheet_Daily.Cells[1, 1].Value = "نماد";
            workSheet_Daily.Cells[1, 2].Value = "تاریخ";
            workSheet_Daily.Cells[1, 3].Value = "بازدهی ";



            var workSheet_Weekly = excel.Workbook.Worksheets.Add("هفتگی");
            workSheet_Weekly.Cells[1, 1].LoadFromCollection(data_Weekly, true);
            workSheet_Weekly.View.RightToLeft = true;
            workSheet_Weekly.Cells[1, 1].Value = "نماد";
            workSheet_Weekly.Cells[1, 2].Value = "تاریخ";
            workSheet_Weekly.Cells[1, 3].Value = "بازدهی ";

            var workSheet_Monthly = excel.Workbook.Worksheets.Add("ماهانه");
            workSheet_Monthly.Cells[1, 1].LoadFromCollection(data_Monthly, true);
            workSheet_Monthly.View.RightToLeft = true;
            workSheet_Monthly.Cells[1, 1].Value = "نماد";
            workSheet_Monthly.Cells[1, 2].Value = "تاریخ";
            workSheet_Monthly.Cells[1, 3].Value = "بازدهی ";


            var workSheet_Seasonal = excel.Workbook.Worksheets.Add("فصلی");
            workSheet_Seasonal.Cells[1, 1].LoadFromCollection(data_Seasonal, true);
            workSheet_Seasonal.View.RightToLeft = true;
            workSheet_Seasonal.Cells[1, 1].Value = "نماد";
            workSheet_Seasonal.Cells[1, 2].Value = "تاریخ";
            workSheet_Seasonal.Cells[1, 3].Value = "بازدهی ";

            var workSheet_Months6 = excel.Workbook.Worksheets.Add("6 ماه");
            workSheet_Months6.Cells[1, 1].LoadFromCollection(data_Months6, true);
            workSheet_Months6.View.RightToLeft = true;
            workSheet_Months6.Cells[1, 1].Value = "نماد";
            workSheet_Months6.Cells[1, 2].Value = "تاریخ";
            workSheet_Months6.Cells[1, 3].Value = "بازدهی ";


            var workSheet_Yearly = excel.Workbook.Worksheets.Add("سالیانه");
            workSheet_Yearly.Cells[1, 1].LoadFromCollection(data_Yearly, true);
            workSheet_Yearly.View.RightToLeft = true;
            workSheet_Yearly.Cells[1, 1].Value = "نماد";
            workSheet_Yearly.Cells[1, 2].Value = "تاریخ";
            workSheet_Yearly.Cells[1, 3].Value = "بازدهی ";






            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename= رتبه بندی بازدهی " + getFundName(fundId.ToString()) + Assistant.TodayDateInt() + "(" + endDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }



        [Authorize]
        public void ExportSymbolYield()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var ValState = Request.QueryString.GetValues("ValState").FirstOrDefault();
            var SymbolId = Request.QueryString.GetValues("SymbolId").FirstOrDefault();

            var lq = new LinqHelper();
            var start = startDate.ToValidMsgDate();
            var end = endDate.ToValidMsgDate();

            ExcelPackage excel = new ExcelPackage();



            if (ValState == "-1")
            {
                var data_Daily = lq.GetSymbolYield(SymbolId.ToValidMsgInt(), start, end, (int)YieldCycle.Daily).Select(s => new
                {
                    RowNumber = s.RowNumber,
                    DatePrice = s.DatePrice,
                    Symbolret = s.Symbolret,
                }).ToList();
                var data_Weekly = lq.GetSymbolYield(SymbolId.ToValidMsgInt(), start, end, (int)YieldCycle.Weekly).Select(s => new
                {
                    RowNumber = s.RowNumber,
                    DatePrice = s.DatePrice,
                    Symbolret = s.Symbolret,
                }).ToList();
                var data_Monthly = lq.GetSymbolYield(SymbolId.ToValidMsgInt(), start, end, (int)YieldCycle.Monthly).Select(s => new
                {
                    RowNumber = s.RowNumber,
                    DatePrice = s.DatePrice,
                    Symbolret = s.Symbolret,
                }).ToList();
                var data_Seasonal = lq.GetSymbolYield(SymbolId.ToValidMsgInt(), start, end, (int)YieldCycle.Seasonal).Select(s => new
                {
                    RowNumber = s.RowNumber,
                    DatePrice = s.DatePrice,
                    Symbolret = s.Symbolret,
                }).ToList();
                var data_Months6 = lq.GetSymbolYield(SymbolId.ToValidMsgInt(), start, end, (int)YieldCycle.Months6).Select(s => new
                {
                    RowNumber = s.RowNumber,
                    DatePrice = s.DatePrice,
                    Symbolret = s.Symbolret,
                }).ToList();
                var data_Yearly = lq.GetSymbolYield(SymbolId.ToValidMsgInt(), start, end, (int)YieldCycle.Yearly).Select(s => new
                {
                    RowNumber = s.RowNumber,
                    DatePrice = s.DatePrice,
                    Symbolret = s.Symbolret,
                }).ToList();

                var workSheet_Daily = excel.Workbook.Worksheets.Add("روزانه");
                workSheet_Daily.Cells[1, 1].LoadFromCollection(data_Daily, true);
                workSheet_Daily.View.RightToLeft = true;
                workSheet_Daily.Cells[1, 1].Value = "ردیف";
                workSheet_Daily.Cells[1, 2].Value = "تاریخ";
                workSheet_Daily.Cells[1, 3].Value = "بازدهی  ";


                var workSheet_Weekly = excel.Workbook.Worksheets.Add("هفتگی");
                workSheet_Weekly.Cells[1, 1].LoadFromCollection(data_Weekly, true);
                workSheet_Weekly.View.RightToLeft = true;
                workSheet_Weekly.Cells[1, 1].Value = "ردیف";
                workSheet_Weekly.Cells[1, 2].Value = "تاریخ";
                workSheet_Weekly.Cells[1, 3].Value = "بازدهی  ";


                var workSheet_Monthly = excel.Workbook.Worksheets.Add("ماهانه");
                workSheet_Monthly.Cells[1, 1].LoadFromCollection(data_Monthly, true);
                workSheet_Monthly.View.RightToLeft = true;
                workSheet_Monthly.Cells[1, 1].Value = "ردیف";
                workSheet_Monthly.Cells[1, 2].Value = "تاریخ";
                workSheet_Monthly.Cells[1, 3].Value = "بازدهی  ";


                var workSheet_Seasonal = excel.Workbook.Worksheets.Add("فصلی");
                workSheet_Seasonal.Cells[1, 1].LoadFromCollection(data_Seasonal, true);
                workSheet_Seasonal.View.RightToLeft = true;
                workSheet_Seasonal.Cells[1, 1].Value = "ردیف";
                workSheet_Seasonal.Cells[1, 2].Value = "تاریخ";
                workSheet_Seasonal.Cells[1, 3].Value = "بازدهی  ";

                var workSheet_Months6 = excel.Workbook.Worksheets.Add("6 ماه");
                workSheet_Months6.Cells[1, 1].LoadFromCollection(data_Months6, true);
                workSheet_Months6.View.RightToLeft = true;
                workSheet_Months6.Cells[1, 1].Value = "ردیف";
                workSheet_Months6.Cells[1, 2].Value = "تاریخ";
                workSheet_Months6.Cells[1, 3].Value = "بازدهی  ";

                var workSheet_Yearly = excel.Workbook.Worksheets.Add("سالیانه");
                workSheet_Yearly.Cells[1, 1].LoadFromCollection(data_Yearly, true);
                workSheet_Yearly.View.RightToLeft = true;
                workSheet_Yearly.Cells[1, 1].Value = "ردیف";
                workSheet_Yearly.Cells[1, 2].Value = "تاریخ";
                workSheet_Yearly.Cells[1, 3].Value = "بازدهی  ";
            }
            else
            {

                if (ValState == "1")
                {
                    var data_Daily = lq.GetSymbolYield(SymbolId.ToValidMsgInt(), start, end, (int)YieldCycle.Daily).Select(s => new
                    {
                        RowNumber = s.RowNumber,
                        DatePrice = s.DatePrice,
                        Symbolret = s.Symbolret,
                    }).ToList();
                    var workSheet_Daily = excel.Workbook.Worksheets.Add("روزانه");
                    workSheet_Daily.Cells[1, 1].LoadFromCollection(data_Daily, true);
                    workSheet_Daily.View.RightToLeft = true;
                    workSheet_Daily.Cells[1, 1].Value = "ردیف";
                    workSheet_Daily.Cells[1, 2].Value = "تاریخ";
                    workSheet_Daily.Cells[1, 3].Value = "بازدهی  ";
                }
                if (ValState == "5")
                {
                    var data_Weekly = lq.GetSymbolYield(SymbolId.ToValidMsgInt(), start, end, (int)YieldCycle.Weekly).Select(s => new
                    {
                        RowNumber = s.RowNumber,
                        DatePrice = s.DatePrice,
                        Symbolret = s.Symbolret,
                    }).ToList();
                    var workSheet_Weekly = excel.Workbook.Worksheets.Add("هفتگی");
                    workSheet_Weekly.Cells[1, 1].LoadFromCollection(data_Weekly, true);
                    workSheet_Weekly.View.RightToLeft = true;
                    workSheet_Weekly.Cells[1, 1].Value = "ردیف";
                    workSheet_Weekly.Cells[1, 2].Value = "تاریخ";
                    workSheet_Weekly.Cells[1, 3].Value = "بازدهی  ";
                }
                if (ValState == "21")
                {
                    var data_Monthly = lq.GetSymbolYield(SymbolId.ToValidMsgInt(), start, end, (int)YieldCycle.Monthly).Select(s => new
                    {
                        RowNumber = s.RowNumber,
                        DatePrice = s.DatePrice,
                        Symbolret = s.Symbolret,
                    }).ToList();
                    var workSheet_Monthly = excel.Workbook.Worksheets.Add("ماهانه");
                    workSheet_Monthly.Cells[1, 1].LoadFromCollection(data_Monthly, true);
                    workSheet_Monthly.View.RightToLeft = true;
                    workSheet_Monthly.Cells[1, 1].Value = "ردیف";
                    workSheet_Monthly.Cells[1, 2].Value = "تاریخ";
                    workSheet_Monthly.Cells[1, 3].Value = "بازدهی  ";
                }
                if (ValState == "63")
                {
                    var data_Seasonal = lq.GetSymbolYield(SymbolId.ToValidMsgInt(), start, end, (int)YieldCycle.Seasonal).Select(s => new
                    {
                        RowNumber = s.RowNumber,
                        DatePrice = s.DatePrice,
                        Symbolret = s.Symbolret,
                    }).ToList();
                    var workSheet_Seasonal = excel.Workbook.Worksheets.Add("فصلی");
                    workSheet_Seasonal.Cells[1, 1].LoadFromCollection(data_Seasonal, true);
                    workSheet_Seasonal.View.RightToLeft = true;
                    workSheet_Seasonal.Cells[1, 1].Value = "ردیف";
                    workSheet_Seasonal.Cells[1, 2].Value = "تاریخ";
                    workSheet_Seasonal.Cells[1, 3].Value = "بازدهی  ";
                }
                if (ValState == "126")
                {
                    var data_Months6 = lq.GetSymbolYield(SymbolId.ToValidMsgInt(), start, end, (int)YieldCycle.Months6).Select(s => new
                    {
                        RowNumber = s.RowNumber,
                        DatePrice = s.DatePrice,
                        Symbolret = s.Symbolret,
                    }).ToList();
                    var workSheet_Months6 = excel.Workbook.Worksheets.Add("6 ماه");
                    workSheet_Months6.Cells[1, 1].LoadFromCollection(data_Months6, true);
                    workSheet_Months6.View.RightToLeft = true;
                    workSheet_Months6.Cells[1, 1].Value = "ردیف";
                    workSheet_Months6.Cells[1, 2].Value = "تاریخ";
                    workSheet_Months6.Cells[1, 3].Value = "بازدهی  ";
                }

                if (ValState == "252")
                {
                    var data_Yearly = lq.GetSymbolYield(SymbolId.ToValidMsgInt(), start, end, (int)YieldCycle.Yearly).Select(s => new
                    {
                        RowNumber = s.RowNumber,
                        DatePrice = s.DatePrice,
                        Symbolret = s.Symbolret,
                    }).ToList();
                    var workSheet_Yearly = excel.Workbook.Worksheets.Add("سالیانه");
                    workSheet_Yearly.Cells[1, 1].LoadFromCollection(data_Yearly, true);
                    workSheet_Yearly.View.RightToLeft = true;
                    workSheet_Yearly.Cells[1, 1].Value = "ردیف";
                    workSheet_Yearly.Cells[1, 2].Value = "تاریخ";
                    workSheet_Yearly.Cells[1, 3].Value = "بازدهی  ";
                }
            }

            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename= بازدهی نماد" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }





















        [Authorize]
        public void ExportPortfolioYield()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var ValState = Request.QueryString.GetValues("ValState").FirstOrDefault();
            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();

            var lq = new LinqHelper();

            var start = startDate.ToValidMsgDate();

            var end = endDate.ToValidMsgDate();

            var data = lq.GetPortfolioYield(fundId.ToValidMsgInt(), start, end, ValState.ToValidMsgInt()).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("بازدهی صندوق");
            workSheet.Cells[1, 1].LoadFromCollection(data, true);
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].Value = "ردیف";
            workSheet.Cells[1, 2].Value = "تاریخ";
            workSheet.Cells[1, 3].Value = "ارزش آغاز دوره";
            workSheet.Cells[1, 4].Value = "ارزش پایان دوره";
            workSheet.Cells[1, 5].Value = "مجموع خرید";
            workSheet.Cells[1, 6].Value = "مجموع فروش";
            workSheet.Cells[1, 7].Value = "مجموع سود";
            workSheet.Cells[1, 8].Value = "بازدهی صندوق";

            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename= PortfolioYield" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }

        [Authorize]
        public void ExportPortfolioYieldRawData()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var ValState = Request.QueryString.GetValues("ValState").FirstOrDefault();
            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();

            var lq = new LinqHelper();

            var start = startDate.ToValidMsgDate();
            var end = endDate.ToValidMsgDate();





            var Buys = lq.CalculateFundYieldRawDataSumBuys(fundId.ToValidMsgInt(), start, end, ValState.ToValidMsgInt())
                 .Select(s => new
                 {
                     CoTSESymbol = s.CoTSESymbol,
                     DatePrice = s.DatePrice,
                     ChangesCount = s.ChangesCount,
                     SymbolPrice = s.SymbolPrice
                 }).ToList();
            var Sales = lq.CalculateFundYieldRawDataSumSales(fundId.ToValidMsgInt(), start, end, ValState.ToValidMsgInt()).Select(s => new
            {
                CoTSESymbol = s.CoTSESymbol,
                DatePrice = s.DatePrice,
                ChangesCount = s.ChangesCount,
                SymbolPrice = s.SymbolPrice
            }).ToList();
            var Value = lq.CalculateFundYieldRawDataValue(fundId.ToValidMsgInt(), start, end, ValState.ToValidMsgInt()).Select(s => new
            {
                CoTSESymbol = s.CoTSESymbol,
                DatePrice = s.DatePrice,
                Count = s.Count,
                SymbolPrice = s.SymbolPrice
            }).ToList();
            var profits = lq.CalculateFundYieldRawDataSumProfits(fundId.ToValidMsgInt(), start, end, ValState.ToValidMsgInt()).Select(s => new
            {
                FundId = s.FundId,
                DatePrice = s.DatePrice,
                Value = s.Value,
                COMMENTS = s.COMMENTS
            }).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("خریدها  ");
            workSheet.Cells[1, 1].LoadFromCollection(Buys, true);
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].Value = "نماد";
            workSheet.Cells[1, 2].Value = "تاریخ";
            workSheet.Cells[1, 3].Value = "تعداد    ";
            workSheet.Cells[1, 4].Value = "قیمت    ";

            var workSheet2 = excel.Workbook.Worksheets.Add("  فروش ها");
            workSheet2.Cells[1, 1].LoadFromCollection(Sales, true);
            workSheet2.View.RightToLeft = true;
            workSheet2.Cells[1, 1].Value = "نماد";
            workSheet2.Cells[1, 2].Value = "تاریخ";
            workSheet2.Cells[1, 3].Value = "تعداد";
            workSheet2.Cells[1, 4].Value = "قیمت";


            var workSheet3 = excel.Workbook.Worksheets.Add("دارایی ها  ");
            workSheet3.Cells[1, 1].LoadFromCollection(Value, true);
            workSheet3.View.RightToLeft = true;
            workSheet3.Cells[1, 1].Value = "نماد";
            workSheet3.Cells[1, 2].Value = "تاریخ";
            workSheet3.Cells[1, 3].Value = "تعداد";
            workSheet3.Cells[1, 4].Value = "قیمت";

            var workSheet4 = excel.Workbook.Worksheets.Add(" سود ها  ");
            workSheet4.Cells[1, 1].LoadFromCollection(profits, true);
            workSheet4.View.RightToLeft = true;
            workSheet4.Cells[1, 1].Value = "صندوق";
            workSheet4.Cells[1, 2].Value = "تاریخ";
            workSheet4.Cells[1, 3].Value = "ارزش";
            workSheet4.Cells[1, 4].Value = "توضیح";







            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename= دیتای خام بازدهی " + getFundName(fundId.ToString()) + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }


        [Authorize]
        public void ExportPortfolioYieldRawDataNAdjPrice()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var ValState = Request.QueryString.GetValues("ValState").FirstOrDefault();
            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();

            var lq = new LinqHelper();

            var start = startDate.ToValidMsgDate();
            var end = endDate.ToValidMsgDate();





            var Buys = lq.CalculateFundYieldRawDataSumBuysNAdjPrice(fundId.ToValidMsgInt(), start, end, ValState.ToValidMsgInt())
                 .Select(s => new
                 {
                     CoTSESymbol = s.CoTSESymbol,
                     DatePrice = s.DatePrice,
                     ChangesCount = s.ChangesCount,
                     SymbolPrice = s.SymbolPrice
                 }).ToList();
            var Sales = lq.CalculateFundYieldRawDataSumSalesNAdjPrice(fundId.ToValidMsgInt(), start, end, ValState.ToValidMsgInt()).Select(s => new
            {
                CoTSESymbol = s.CoTSESymbol,
                DatePrice = s.DatePrice,
                ChangesCount = s.ChangesCount,
                SymbolPrice = s.SymbolPrice
            }).ToList();
            var Value = lq.CalculateFundYieldRawDataValueNAdjPrice(fundId.ToValidMsgInt(), start, end, ValState.ToValidMsgInt()).Select(s => new
            {
                CoTSESymbol = s.CoTSESymbol,
                DatePrice = s.DatePrice,
                Count = s.Count,
                SymbolPrice = s.SymbolNAdjPrice
            }).ToList();
            //var profits = lq.CalculateFundYieldRawDataSumProfits(fundId.ToValidMsgInt(), start, end, ValState.ToValidMsgInt()).Select(s => new
            //{
            //    FundId = s.FundId,
            //    DatePrice = s.DatePrice,
            //    Value = s.Value,
            //    COMMENTS = s.COMMENTS
            //}).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("خریدها  ");
            workSheet.Cells[1, 1].LoadFromCollection(Buys, true);
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].Value = "نماد";
            workSheet.Cells[1, 2].Value = "تاریخ";
            workSheet.Cells[1, 3].Value = "تعداد    ";
            workSheet.Cells[1, 4].Value = "قیمت    ";

            var workSheet2 = excel.Workbook.Worksheets.Add("  فروش ها");
            workSheet2.Cells[1, 1].LoadFromCollection(Sales, true);
            workSheet2.View.RightToLeft = true;
            workSheet2.Cells[1, 1].Value = "نماد";
            workSheet2.Cells[1, 2].Value = "تاریخ";
            workSheet2.Cells[1, 3].Value = "تعداد";
            workSheet2.Cells[1, 4].Value = "قیمت";


            var workSheet3 = excel.Workbook.Worksheets.Add("دارایی ها  ");
            workSheet3.Cells[1, 1].LoadFromCollection(Value, true);
            workSheet3.View.RightToLeft = true;
            workSheet3.Cells[1, 1].Value = "نماد";
            workSheet3.Cells[1, 2].Value = "تاریخ";
            workSheet3.Cells[1, 3].Value = "تعداد";
            workSheet3.Cells[1, 4].Value = "قیمت";

            //var workSheet4 = excel.Workbook.Worksheets.Add(" سود ها  ");
            //workSheet4.Cells[1, 1].LoadFromCollection(profits, true);
            //workSheet4.View.RightToLeft = true;
            //workSheet4.Cells[1, 1].Value = "صندوق";
            //workSheet4.Cells[1, 2].Value = "تاریخ";
            //workSheet4.Cells[1, 3].Value = "ارزش";
            //workSheet4.Cells[1, 4].Value = "توضیح";

            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename= دیتای خام بازدهی پرتفوی " + getFundName(fundId.ToString()) + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }

        //-------------------------------------------------------------------------------------------------------------


        [Authorize]
        public void ExportPortfolioYieldRawDataAdjPrice()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var ValState = Request.QueryString.GetValues("ValState").FirstOrDefault();
            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();

            var lq = new LinqHelper();

            var start = startDate.ToValidMsgDate();
            var end = endDate.ToValidMsgDate();





            var Buys = lq.CalculateFundYieldRawDataSumBuysSimplePrice(fundId.ToValidMsgInt(), start, end, ValState.ToValidMsgInt())
                 .Select(s => new
                 {
                     CoTSESymbol = s.CoTSESymbol,
                     DatePrice = s.DatePrice,
                     ChangesCount = s.ChangesCount,
                     SymbolPrice = s.SymbolPrice
                 }).ToList();
            var Sales = lq.CalculateFundYieldRawDataSumSalesSimplePrice(fundId.ToValidMsgInt(), start, end, ValState.ToValidMsgInt()).Select(s => new
            {
                CoTSESymbol = s.CoTSESymbol,
                DatePrice = s.DatePrice,
                ChangesCount = s.ChangesCount,
                SymbolPrice = s.SymbolPrice
            }).ToList();
            var Value = lq.CalculateFundYieldRawDataValueSimplePrice(fundId.ToValidMsgInt(), start, end, ValState.ToValidMsgInt()).Select(s => new
            {
                CoTSESymbol = s.CoTSESymbol,
                DatePrice = s.DatePrice,
                Count = s.Count,
                SymbolPrice = s.SimplePrice
            }).ToList();
            var profits = lq.CalculateFundYieldRawDataSumProfits(fundId.ToValidMsgInt(), start, end, ValState.ToValidMsgInt()).Select(s => new
            {
                FundId = s.FundId,
                DatePrice = s.DatePrice,
                Value = s.Value,
                COMMENTS = s.COMMENTS
            }).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("خریدها  ");
            workSheet.Cells[1, 1].LoadFromCollection(Buys, true);
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].Value = "نماد";
            workSheet.Cells[1, 2].Value = "تاریخ";
            workSheet.Cells[1, 3].Value = "تعداد    ";
            workSheet.Cells[1, 4].Value = "قیمت    ";

            var workSheet2 = excel.Workbook.Worksheets.Add("  فروش ها");
            workSheet2.Cells[1, 1].LoadFromCollection(Sales, true);
            workSheet2.View.RightToLeft = true;
            workSheet2.Cells[1, 1].Value = "نماد";
            workSheet2.Cells[1, 2].Value = "تاریخ";
            workSheet2.Cells[1, 3].Value = "تعداد";
            workSheet2.Cells[1, 4].Value = "قیمت";


            var workSheet3 = excel.Workbook.Worksheets.Add("دارایی ها  ");
            workSheet3.Cells[1, 1].LoadFromCollection(Value, true);
            workSheet3.View.RightToLeft = true;
            workSheet3.Cells[1, 1].Value = "نماد";
            workSheet3.Cells[1, 2].Value = "تاریخ";
            workSheet3.Cells[1, 3].Value = "تعداد";
            workSheet3.Cells[1, 4].Value = "قیمت";

            var workSheet4 = excel.Workbook.Worksheets.Add(" سود ها  ");
            workSheet4.Cells[1, 1].LoadFromCollection(profits, true);
            workSheet4.View.RightToLeft = true;
            workSheet4.Cells[1, 1].Value = "صندوق";
            workSheet4.Cells[1, 2].Value = "تاریخ";
            workSheet4.Cells[1, 3].Value = "ارزش";
            workSheet4.Cells[1, 4].Value = "توضیح";

            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename= دیتای خام بازدهی پرتفوی " + getFundName(fundId.ToString()) + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }



        //-------------------------------------------------------------------------------------------------------------














        [Authorize]
        public void ExportPortfolioYieldRawDataAll()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var ValState = Request.QueryString.GetValues("ValState").FirstOrDefault();
            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();

            var lq = new LinqHelper();

            var start = startDate.ToValidMsgDate();
            var end = endDate.ToValidMsgDate();



            var Buys_Daily = lq.CalculateFundYieldRawDataSumBuys(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Daily)
                 .Select(s => new
                 {
                     CoTSESymbol = s.CoTSESymbol,
                     DatePrice = s.DatePrice,
                     ChangesCount = s.ChangesCount,
                     SymbolPrice = s.SymbolPrice
                 }).ToList();
            var Sales_Daily = lq.CalculateFundYieldRawDataSumSales(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Daily).Select(s => new
            {
                CoTSESymbol = s.CoTSESymbol,
                DatePrice = s.DatePrice,
                ChangesCount = s.ChangesCount,
                SymbolPrice = s.SymbolPrice
            }).ToList();
            var Value_Daily = lq.CalculateFundYieldRawDataValue(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Daily).Select(s => new
            {
                CoTSESymbol = s.CoTSESymbol,
                DatePrice = s.DatePrice,
                Count = s.Count,
                SymbolPrice = s.SymbolPrice
            }).ToList();
            var profits_Daily = lq.CalculateFundYieldRawDataSumProfits(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Daily).Select(s => new
            {
                FundId = s.FundId,
                DatePrice = s.DatePrice,
                Value = s.Value,
                COMMENTS = s.COMMENTS
            }).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet_Daily = excel.Workbook.Worksheets.Add(" روزانه_خریدها");
            workSheet_Daily.Cells[1, 1].LoadFromCollection(Buys_Daily, true);
            workSheet_Daily.View.RightToLeft = true;
            workSheet_Daily.Cells[1, 1].Value = "نماد";
            workSheet_Daily.Cells[1, 2].Value = "تاریخ";
            workSheet_Daily.Cells[1, 3].Value = "تعداد    ";
            workSheet_Daily.Cells[1, 4].Value = "قیمت    ";

            var workSheet2_Daily = excel.Workbook.Worksheets.Add("روزانه_فروش ها");
            workSheet2_Daily.Cells[1, 1].LoadFromCollection(Sales_Daily, true);
            workSheet2_Daily.View.RightToLeft = true;
            workSheet2_Daily.Cells[1, 1].Value = "نماد";
            workSheet2_Daily.Cells[1, 2].Value = "تاریخ";
            workSheet2_Daily.Cells[1, 3].Value = "تعداد";
            workSheet2_Daily.Cells[1, 4].Value = "قیمت";


            var workSheet3_Daily = excel.Workbook.Worksheets.Add("روزانه_دارایی ها");
            workSheet3_Daily.Cells[1, 1].LoadFromCollection(Value_Daily, true);
            workSheet3_Daily.View.RightToLeft = true;
            workSheet3_Daily.Cells[1, 1].Value = "نماد";
            workSheet3_Daily.Cells[1, 2].Value = "تاریخ";
            workSheet3_Daily.Cells[1, 3].Value = "تعداد";
            workSheet3_Daily.Cells[1, 4].Value = "قیمت";

            var workSheet4_Daily = excel.Workbook.Worksheets.Add("روزانه_سود ها");
            workSheet4_Daily.Cells[1, 1].LoadFromCollection(profits_Daily, true);
            workSheet4_Daily.View.RightToLeft = true;
            workSheet4_Daily.Cells[1, 1].Value = "صندوق";
            workSheet4_Daily.Cells[1, 2].Value = "تاریخ";
            workSheet4_Daily.Cells[1, 3].Value = "ارزش";
            workSheet4_Daily.Cells[1, 4].Value = "توضیح";



            var Buys_Weekly = lq.CalculateFundYieldRawDataSumBuys(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Weekly)
             .Select(s => new
             {
                 CoTSESymbol = s.CoTSESymbol,
                 DatePrice = s.DatePrice,
                 ChangesCount = s.ChangesCount,
                 SymbolPrice = s.SymbolPrice
             }).ToList();
            var Sales_Weekly = lq.CalculateFundYieldRawDataSumSales(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Weekly).Select(s => new
            {
                CoTSESymbol = s.CoTSESymbol,
                DatePrice = s.DatePrice,
                ChangesCount = s.ChangesCount,
                SymbolPrice = s.SymbolPrice
            }).ToList();
            var Value_Weekly = lq.CalculateFundYieldRawDataValue(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Weekly).Select(s => new
            {
                CoTSESymbol = s.CoTSESymbol,
                DatePrice = s.DatePrice,
                Count = s.Count,
                SymbolPrice = s.SymbolPrice
            }).ToList();
            var profits_Weekly = lq.CalculateFundYieldRawDataSumProfits(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Weekly).Select(s => new
            {
                FundId = s.FundId,
                DatePrice = s.DatePrice,
                Value = s.Value,
                COMMENTS = s.COMMENTS
            }).ToList();


            var workSheet_Weekly = excel.Workbook.Worksheets.Add("هفتگی_خریدها");
            workSheet_Weekly.Cells[1, 1].LoadFromCollection(Buys_Weekly, true);
            workSheet_Weekly.View.RightToLeft = true;
            workSheet_Weekly.Cells[1, 1].Value = "نماد";
            workSheet_Weekly.Cells[1, 2].Value = "تاریخ";
            workSheet_Weekly.Cells[1, 3].Value = "تعداد    ";
            workSheet_Weekly.Cells[1, 4].Value = "قیمت    ";

            var workSheet2_Weekly = excel.Workbook.Worksheets.Add("هفتگی_فروش ها");
            workSheet2_Weekly.Cells[1, 1].LoadFromCollection(Sales_Weekly, true);
            workSheet2_Weekly.View.RightToLeft = true;
            workSheet2_Weekly.Cells[1, 1].Value = "نماد";
            workSheet2_Weekly.Cells[1, 2].Value = "تاریخ";
            workSheet2_Weekly.Cells[1, 3].Value = "تعداد";
            workSheet2_Weekly.Cells[1, 4].Value = "قیمت";


            var workSheet3_Weekly = excel.Workbook.Worksheets.Add("هفتگی_دارایی ها");
            workSheet3_Weekly.Cells[1, 1].LoadFromCollection(Value_Weekly, true);
            workSheet3_Weekly.View.RightToLeft = true;
            workSheet3_Weekly.Cells[1, 1].Value = "نماد";
            workSheet3_Weekly.Cells[1, 2].Value = "تاریخ";
            workSheet3_Weekly.Cells[1, 3].Value = "تعداد";
            workSheet3_Weekly.Cells[1, 4].Value = "قیمت";

            var workSheet4_Weekly = excel.Workbook.Worksheets.Add("هفتگی_سود ها");
            workSheet4_Weekly.Cells[1, 1].LoadFromCollection(profits_Weekly, true);
            workSheet4_Weekly.View.RightToLeft = true;
            workSheet4_Weekly.Cells[1, 1].Value = "صندوق";
            workSheet4_Weekly.Cells[1, 2].Value = "تاریخ";
            workSheet4_Weekly.Cells[1, 3].Value = "ارزش";
            workSheet4_Weekly.Cells[1, 4].Value = "توضیح";



            var Buys_Monthly = lq.CalculateFundYieldRawDataSumBuys(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Monthly)
       .Select(s => new
       {
           CoTSESymbol = s.CoTSESymbol,
           DatePrice = s.DatePrice,
           ChangesCount = s.ChangesCount,
           SymbolPrice = s.SymbolPrice
       }).ToList();
            var Sales_Monthly = lq.CalculateFundYieldRawDataSumSales(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Monthly).Select(s => new
            {
                CoTSESymbol = s.CoTSESymbol,
                DatePrice = s.DatePrice,
                ChangesCount = s.ChangesCount,
                SymbolPrice = s.SymbolPrice
            }).ToList();
            var Value_Monthly = lq.CalculateFundYieldRawDataValue(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Monthly).Select(s => new
            {
                CoTSESymbol = s.CoTSESymbol,
                DatePrice = s.DatePrice,
                Count = s.Count,
                SymbolPrice = s.SymbolPrice
            }).ToList();
            var profits_Monthly = lq.CalculateFundYieldRawDataSumProfits(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Monthly).Select(s => new
            {
                FundId = s.FundId,
                DatePrice = s.DatePrice,
                Value = s.Value,
                COMMENTS = s.COMMENTS
            }).ToList();


            var workSheet_Monthly = excel.Workbook.Worksheets.Add("ماهانه_خریدها");
            workSheet_Monthly.Cells[1, 1].LoadFromCollection(Buys_Monthly, true);
            workSheet_Monthly.View.RightToLeft = true;
            workSheet_Monthly.Cells[1, 1].Value = "نماد";
            workSheet_Monthly.Cells[1, 2].Value = "تاریخ";
            workSheet_Monthly.Cells[1, 3].Value = "تعداد    ";
            workSheet_Monthly.Cells[1, 4].Value = "قیمت    ";

            var workSheet2_Monthly = excel.Workbook.Worksheets.Add("ماهانه_فروش ها");
            workSheet2_Monthly.Cells[1, 1].LoadFromCollection(Sales_Monthly, true);
            workSheet2_Monthly.View.RightToLeft = true;
            workSheet2_Monthly.Cells[1, 1].Value = "نماد";
            workSheet2_Monthly.Cells[1, 2].Value = "تاریخ";
            workSheet2_Monthly.Cells[1, 3].Value = "تعداد";
            workSheet2_Monthly.Cells[1, 4].Value = "قیمت";


            var workSheet3_Monthly = excel.Workbook.Worksheets.Add("ماهانه_دارایی ها");
            workSheet3_Monthly.Cells[1, 1].LoadFromCollection(Value_Monthly, true);
            workSheet3_Monthly.View.RightToLeft = true;
            workSheet3_Monthly.Cells[1, 1].Value = "نماد";
            workSheet3_Monthly.Cells[1, 2].Value = "تاریخ";
            workSheet3_Monthly.Cells[1, 3].Value = "تعداد";
            workSheet3_Monthly.Cells[1, 4].Value = "قیمت";

            var workSheet4_Monthly = excel.Workbook.Worksheets.Add("ماهانه_سود ها");
            workSheet4_Monthly.Cells[1, 1].LoadFromCollection(profits_Monthly, true);
            workSheet4_Monthly.View.RightToLeft = true;
            workSheet4_Monthly.Cells[1, 1].Value = "صندوق";
            workSheet4_Monthly.Cells[1, 2].Value = "تاریخ";
            workSheet4_Monthly.Cells[1, 3].Value = "ارزش";
            workSheet4_Monthly.Cells[1, 4].Value = "توضیح";




            var Buys_Seasonal = lq.CalculateFundYieldRawDataSumBuys(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Seasonal)
       .Select(s => new
       {
           CoTSESymbol = s.CoTSESymbol,
           DatePrice = s.DatePrice,
           ChangesCount = s.ChangesCount,
           SymbolPrice = s.SymbolPrice
       }).ToList();
            var Sales_Seasonal = lq.CalculateFundYieldRawDataSumSales(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Seasonal).Select(s => new
            {
                CoTSESymbol = s.CoTSESymbol,
                DatePrice = s.DatePrice,
                ChangesCount = s.ChangesCount,
                SymbolPrice = s.SymbolPrice
            }).ToList();
            var Value_Seasonal = lq.CalculateFundYieldRawDataValue(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Seasonal).Select(s => new
            {
                CoTSESymbol = s.CoTSESymbol,
                DatePrice = s.DatePrice,
                Count = s.Count,
                SymbolPrice = s.SymbolPrice
            }).ToList();
            var profits_Seasonal = lq.CalculateFundYieldRawDataSumProfits(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Seasonal).Select(s => new
            {
                FundId = s.FundId,
                DatePrice = s.DatePrice,
                Value = s.Value,
                COMMENTS = s.COMMENTS
            }).ToList();


            var workSheet_Seasonal = excel.Workbook.Worksheets.Add("فصلی_خریدها");
            workSheet_Seasonal.Cells[1, 1].LoadFromCollection(Buys_Seasonal, true);
            workSheet_Seasonal.View.RightToLeft = true;
            workSheet_Seasonal.Cells[1, 1].Value = "نماد";
            workSheet_Seasonal.Cells[1, 2].Value = "تاریخ";
            workSheet_Seasonal.Cells[1, 3].Value = "تعداد    ";
            workSheet_Seasonal.Cells[1, 4].Value = "قیمت    ";

            var workSheet2_Seasonal = excel.Workbook.Worksheets.Add("فصلی_فروش ها");
            workSheet2_Seasonal.Cells[1, 1].LoadFromCollection(Sales_Seasonal, true);
            workSheet2_Seasonal.View.RightToLeft = true;
            workSheet2_Seasonal.Cells[1, 1].Value = "نماد";
            workSheet2_Seasonal.Cells[1, 2].Value = "تاریخ";
            workSheet2_Seasonal.Cells[1, 3].Value = "تعداد";
            workSheet2_Seasonal.Cells[1, 4].Value = "قیمت";


            var workSheet3_Seasonal = excel.Workbook.Worksheets.Add("فصلی_دارایی ها");
            workSheet3_Seasonal.Cells[1, 1].LoadFromCollection(Value_Seasonal, true);
            workSheet3_Seasonal.View.RightToLeft = true;
            workSheet3_Seasonal.Cells[1, 1].Value = "نماد";
            workSheet3_Seasonal.Cells[1, 2].Value = "تاریخ";
            workSheet3_Seasonal.Cells[1, 3].Value = "تعداد";
            workSheet3_Seasonal.Cells[1, 4].Value = "قیمت";

            var workSheet4_Seasonal = excel.Workbook.Worksheets.Add("فصلی_سود ها");
            workSheet4_Seasonal.Cells[1, 1].LoadFromCollection(profits_Seasonal, true);
            workSheet4_Seasonal.View.RightToLeft = true;
            workSheet4_Seasonal.Cells[1, 1].Value = "صندوق";
            workSheet4_Seasonal.Cells[1, 2].Value = "تاریخ";
            workSheet4_Seasonal.Cells[1, 3].Value = "ارزش";
            workSheet4_Seasonal.Cells[1, 4].Value = "توضیح";




            var Buys_Months6 = lq.CalculateFundYieldRawDataSumBuys(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Months6)
            .Select(s => new
            {
                CoTSESymbol = s.CoTSESymbol,
                DatePrice = s.DatePrice,
                ChangesCount = s.ChangesCount,
                SymbolPrice = s.SymbolPrice
            }).ToList();
            var Sales_Months6 = lq.CalculateFundYieldRawDataSumSales(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Months6).Select(s => new
            {
                CoTSESymbol = s.CoTSESymbol,
                DatePrice = s.DatePrice,
                ChangesCount = s.ChangesCount,
                SymbolPrice = s.SymbolPrice
            }).ToList();
            var Value_Months6 = lq.CalculateFundYieldRawDataValue(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Months6).Select(s => new
            {
                CoTSESymbol = s.CoTSESymbol,
                DatePrice = s.DatePrice,
                Count = s.Count,
                SymbolPrice = s.SymbolPrice
            }).ToList();
            var profits_Months6 = lq.CalculateFundYieldRawDataSumProfits(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Months6).Select(s => new
            {
                FundId = s.FundId,
                DatePrice = s.DatePrice,
                Value = s.Value,
                COMMENTS = s.COMMENTS
            }).ToList();


            var workSheet_Months6 = excel.Workbook.Worksheets.Add("شش ماه_خریدها");
            workSheet_Months6.Cells[1, 1].LoadFromCollection(Buys_Months6, true);
            workSheet_Months6.View.RightToLeft = true;
            workSheet_Months6.Cells[1, 1].Value = "نماد";
            workSheet_Months6.Cells[1, 2].Value = "تاریخ";
            workSheet_Months6.Cells[1, 3].Value = "تعداد    ";
            workSheet_Months6.Cells[1, 4].Value = "قیمت    ";

            var workSheet2_Months6 = excel.Workbook.Worksheets.Add("شش ماه_فروش ها");
            workSheet2_Months6.Cells[1, 1].LoadFromCollection(Sales_Months6, true);
            workSheet2_Months6.View.RightToLeft = true;
            workSheet2_Months6.Cells[1, 1].Value = "نماد";
            workSheet2_Months6.Cells[1, 2].Value = "تاریخ";
            workSheet2_Months6.Cells[1, 3].Value = "تعداد";
            workSheet2_Months6.Cells[1, 4].Value = "قیمت";


            var workSheet3_Months6 = excel.Workbook.Worksheets.Add("شش ماه_دارایی ها");
            workSheet3_Months6.Cells[1, 1].LoadFromCollection(Value_Months6, true);
            workSheet3_Months6.View.RightToLeft = true;
            workSheet3_Months6.Cells[1, 1].Value = "نماد";
            workSheet3_Months6.Cells[1, 2].Value = "تاریخ";
            workSheet3_Months6.Cells[1, 3].Value = "تعداد";
            workSheet3_Months6.Cells[1, 4].Value = "قیمت";

            var workSheet4_Months6 = excel.Workbook.Worksheets.Add("شش ماه_سود ها");
            workSheet4_Months6.Cells[1, 1].LoadFromCollection(profits_Months6, true);
            workSheet4_Months6.View.RightToLeft = true;
            workSheet4_Months6.Cells[1, 1].Value = "صندوق";
            workSheet4_Months6.Cells[1, 2].Value = "تاریخ";
            workSheet4_Months6.Cells[1, 3].Value = "ارزش";
            workSheet4_Months6.Cells[1, 4].Value = "توضیح";


            var Buys_Yearly = lq.CalculateFundYieldRawDataSumBuys(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Yearly)
            .Select(s => new
            {
                CoTSESymbol = s.CoTSESymbol,
                DatePrice = s.DatePrice,
                ChangesCount = s.ChangesCount,
                SymbolPrice = s.SymbolPrice
            }).ToList();
            var Sales_Yearly = lq.CalculateFundYieldRawDataSumSales(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Yearly).Select(s => new
            {
                CoTSESymbol = s.CoTSESymbol,
                DatePrice = s.DatePrice,
                ChangesCount = s.ChangesCount,
                SymbolPrice = s.SymbolPrice
            }).ToList();
            var Value_Yearly = lq.CalculateFundYieldRawDataValue(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Yearly).Select(s => new
            {
                CoTSESymbol = s.CoTSESymbol,
                DatePrice = s.DatePrice,
                Count = s.Count,
                SymbolPrice = s.SymbolPrice
            }).ToList();
            var profits_Yearly = lq.CalculateFundYieldRawDataSumProfits(fundId.ToValidMsgInt(), start, end, (int)YieldCycle.Yearly).Select(s => new
            {
                FundId = s.FundId,
                DatePrice = s.DatePrice,
                Value = s.Value,
                COMMENTS = s.COMMENTS
            }).ToList();


            var workSheet_Yearly = excel.Workbook.Worksheets.Add(" سالیانه_خریدها");
            workSheet_Yearly.Cells[1, 1].LoadFromCollection(Buys_Yearly, true);
            workSheet_Yearly.View.RightToLeft = true;
            workSheet_Yearly.Cells[1, 1].Value = "نماد";
            workSheet_Yearly.Cells[1, 2].Value = "تاریخ";
            workSheet_Yearly.Cells[1, 3].Value = "تعداد    ";
            workSheet_Yearly.Cells[1, 4].Value = "قیمت    ";

            var workSheet2_Yearly = excel.Workbook.Worksheets.Add("سالیانه_فروش ها");
            workSheet2_Yearly.Cells[1, 1].LoadFromCollection(Sales_Yearly, true);
            workSheet2_Yearly.View.RightToLeft = true;
            workSheet2_Yearly.Cells[1, 1].Value = "نماد";
            workSheet2_Yearly.Cells[1, 2].Value = "تاریخ";
            workSheet2_Yearly.Cells[1, 3].Value = "تعداد";
            workSheet2_Yearly.Cells[1, 4].Value = "قیمت";


            var workSheet3_Yearly = excel.Workbook.Worksheets.Add("سالیانه_دارایی ها");
            workSheet3_Yearly.Cells[1, 1].LoadFromCollection(Value_Yearly, true);
            workSheet3_Yearly.View.RightToLeft = true;
            workSheet3_Yearly.Cells[1, 1].Value = "نماد";
            workSheet3_Yearly.Cells[1, 2].Value = "تاریخ";
            workSheet3_Yearly.Cells[1, 3].Value = "تعداد";
            workSheet3_Yearly.Cells[1, 4].Value = "قیمت";

            var workSheet4_Yearly = excel.Workbook.Worksheets.Add("سالیانه_سود ها");
            workSheet4_Yearly.Cells[1, 1].LoadFromCollection(profits_Yearly, true);
            workSheet4_Yearly.View.RightToLeft = true;
            workSheet4_Yearly.Cells[1, 1].Value = "صندوق";
            workSheet4_Yearly.Cells[1, 2].Value = "تاریخ";
            workSheet4_Yearly.Cells[1, 3].Value = "ارزش";
            workSheet4_Yearly.Cells[1, 4].Value = "توضیح";




            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename= PortfolioYieldRawDataAll" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }







        [Authorize]
        public void ExportSavedAllSymbolsVaR()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var SymbolId = Request.QueryString.GetValues("Symbol").FirstOrDefault();

            var HasCheck = Request.QueryString.GetValues("HasCheck").FirstOrDefault();
            var fields = Request.QueryString.GetValues("fields").FirstOrDefault();
            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();
            var IsPortfolio = Request.QueryString.GetValues("IsPortfolio").FirstOrDefault();

            //var miladiStartDate = Assistant.ShamsiToMiladi(startDate.ToValidMsgInt());
            //var miladiEndDate = Assistant.ShamsiToMiladi(endDate.ToValidMsgInt());
            var StartDate = startDate.ToValidMsgInt();
            var EndDate = endDate.ToValidMsgInt();

            List<CalcPortfolioVAR_Result> data = new List<CalcPortfolioVAR_Result>();
            List<CalcPortfolioWeeklyVAR_Result> data2 = new List<CalcPortfolioWeeklyVAR_Result>();
            List<CalcPortfolioMonthlyVAR_Result> data3 = new List<CalcPortfolioMonthlyVAR_Result>();

            var lq = new LinqHelper();

            var result = lq.GetPortfolioVAR(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), HasCheck.ToValidMsgInt(), fields, fundId.ToValidMsgInt()).ToList();
            var result2 = lq.CalcPortfolioWeeklyVAR(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), HasCheck.ToValidMsgInt(), fields, fundId.ToValidMsgInt()).ToList();
            var result3 = lq.CalcPortfolioMonthlyVAR(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), HasCheck.ToValidMsgInt(), fields, fundId.ToValidMsgInt()).ToList();



            data = result;

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("VaR روزانه");
            workSheet.Cells[1, 1].LoadFromCollection(data, true);
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].Value = "";
            workSheet.Cells[1, 2].Value = "Symbol";
            workSheet.Cells[1, 3].Value = "VaR Historical";
            workSheet.Cells[1, 4].Value = "VaR Parametric";
            workSheet.Cells[1, 5].Value = "VaR Monte-Carlo";
            workSheet.Cells[1, 6].Value = "VaR Historical";
            workSheet.Cells[1, 7].Value = "VaR Parametric";
            workSheet.Cells[1, 8].Value = "VaR Monte-Carlo";

            data2 = result2;
            var workSheet2 = excel.Workbook.Worksheets.Add("VaR هفتگی");
            workSheet2.Cells[1, 1].LoadFromCollection(data2, true);
            workSheet2.View.RightToLeft = true;
            workSheet2.Cells[1, 1].Value = "";
            workSheet2.Cells[1, 2].Value = "Symbol";
            workSheet2.Cells[1, 3].Value = "VaR Historical";
            workSheet2.Cells[1, 4].Value = "VaR Parametric";
            workSheet2.Cells[1, 5].Value = "VaR Monte-Carlo";
            workSheet2.Cells[1, 6].Value = "VaR Historical";
            workSheet2.Cells[1, 7].Value = "VaR Parametric";
            workSheet2.Cells[1, 8].Value = "VaR Monte-Carlo";



            data3 = result3;
            var workSheet3 = excel.Workbook.Worksheets.Add("VaR ماهانه");
            workSheet3.Cells[1, 1].LoadFromCollection(data3, true);
            workSheet3.View.RightToLeft = true;
            workSheet3.Cells[1, 1].Value = "";
            workSheet3.Cells[1, 2].Value = "Symbol";
            workSheet3.Cells[1, 3].Value = "VaR Historical";
            workSheet3.Cells[1, 4].Value = "VaR Parametric";
            workSheet3.Cells[1, 5].Value = "VaR Monte-Carlo";
            workSheet3.Cells[1, 6].Value = "VaR Historical";
            workSheet3.Cells[1, 7].Value = "VaR Parametric";
            workSheet3.Cells[1, 8].Value = "VaR Monte-Carlo";



            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=AllSymbolVaRCalculations" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }


        [Authorize]
        public void ExportSymbolsVaRV2()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var SymbolId = Request.QueryString.GetValues("Symbol").FirstOrDefault();
            var chVar = Request.QueryString.GetValues("chVar").FirstOrDefault();

            //var HasCheck = Request.QueryString.GetValues("HasCheck").FirstOrDefault();
            //var fields = Request.QueryString.GetValues("fields").FirstOrDefault();
            //var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();
            //var IsPortfolio = Request.QueryString.GetValues("IsPortfolio").FirstOrDefault();

            //var miladiStartDate = Assistant.ShamsiToMiladi(startDate.ToValidMsgInt());
            //var miladiEndDate = Assistant.ShamsiToMiladi(endDate.ToValidMsgInt());
            var StartDate = startDate.ToValidMsgInt();
            var EndDate = endDate.ToValidMsgInt();


            var lq = new LinqHelper();

            if (chVar.ToValidMsgInt() != -1)
            {
                var result = lq.CalcSymbolVARV2(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), chVar.ToValidMsgInt(), SymbolId.ToValidMsgInt()).ToList();

                ExcelPackage excel = new ExcelPackage();
                var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
                workSheet.Cells[1, 1].LoadFromCollection(result, true);
                workSheet.View.RightToLeft = true;
                workSheet.Cells[1, 1].Value = "VaR Historical";
                workSheet.Cells[1, 2].Value = "VaR Parametric";
                workSheet.Cells[1, 3].Value = "VaR Monte-Carlo";

                using (var memoryStream = new MemoryStream())
                {
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    //here i have set filname as Students.xlsx
                    Response.AddHeader("content-disposition", "attachment;  filename=ارزش در معرض ریسک نماد" + SymbolId + "-" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                    excel.SaveAs(memoryStream);

                    memoryStream.WriteTo(Response.OutputStream);
                    Response.Flush();
                    Response.End();
                    Response.Clear();
                }

            }
            else
            {
                var result = lq.CalcSymbolVARV2(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), 1, SymbolId.ToValidMsgInt()).ToList();
                var result2 = lq.CalcSymbolVARV2(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), 5, SymbolId.ToValidMsgInt()).ToList();
                var result3 = lq.CalcSymbolVARV2(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), 21, SymbolId.ToValidMsgInt()).ToList();
                var result4 = lq.CalcSymbolVARV2(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), 63, SymbolId.ToValidMsgInt()).ToList();
                var result5 = lq.CalcSymbolVARV2(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), 126, SymbolId.ToValidMsgInt()).ToList();
                var result6 = lq.CalcSymbolVARV2(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), 252, SymbolId.ToValidMsgInt()).ToList();


                ExcelPackage excel = new ExcelPackage();
                var workSheet = excel.Workbook.Worksheets.Add("روزانه");
                workSheet.Cells[1, 1].LoadFromCollection(result, true);
                workSheet.View.RightToLeft = true;
                workSheet.Cells[1, 2].Value = "VaR Historical";
                workSheet.Cells[1, 3].Value = "VaR Parametric";
                workSheet.Cells[1, 4].Value = "VaR Monte-Carlo";


                var workSheet2 = excel.Workbook.Worksheets.Add("هفتگی");
                workSheet2.Cells[1, 1].LoadFromCollection(result2, true);
                workSheet2.View.RightToLeft = true;
                workSheet2.Cells[1, 2].Value = "VaR Historical";
                workSheet2.Cells[1, 3].Value = "VaR Parametric";
                workSheet2.Cells[1, 4].Value = "VaR Monte-Carlo";


                var workSheet3 = excel.Workbook.Worksheets.Add("ماهانه");
                workSheet3.Cells[1, 1].LoadFromCollection(result3, true);
                workSheet3.View.RightToLeft = true;
                workSheet3.Cells[1, 2].Value = "VaR Historical";
                workSheet3.Cells[1, 3].Value = "VaR Parametric";
                workSheet3.Cells[1, 4].Value = "VaR Monte-Carlo";


                var workSheet4 = excel.Workbook.Worksheets.Add("فصلی");
                workSheet4.Cells[1, 1].LoadFromCollection(result4, true);
                workSheet4.View.RightToLeft = true;
                workSheet4.Cells[1, 2].Value = "VaR Historical";
                workSheet4.Cells[1, 3].Value = "VaR Parametric";
                workSheet4.Cells[1, 4].Value = "VaR Monte-Carlo";


                var workSheet5 = excel.Workbook.Worksheets.Add("شش ماهه");
                workSheet5.Cells[1, 1].LoadFromCollection(result5, true);
                workSheet5.View.RightToLeft = true;
                workSheet5.Cells[1, 2].Value = "VaR Historical";
                workSheet5.Cells[1, 3].Value = "VaR Parametric";
                workSheet5.Cells[1, 4].Value = "VaR Monte-Carlo";

                var workSheet6 = excel.Workbook.Worksheets.Add("سالانه ");
                workSheet6.Cells[1, 1].LoadFromCollection(result6, true);
                workSheet6.View.RightToLeft = true;
                workSheet6.Cells[1, 2].Value = "VaR Historical";
                workSheet6.Cells[1, 3].Value = "VaR Parametric";
                workSheet6.Cells[1, 4].Value = "VaR Monte-Carlo";

                using (var memoryStream = new MemoryStream())
                {
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    //here i have set filname as Students.xlsx
                    Response.AddHeader("content-disposition", "attachment;  filename=SymbolVarCalculation" + SymbolId + "-" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                    excel.SaveAs(memoryStream);

                    memoryStream.WriteTo(Response.OutputStream);
                    Response.Flush();
                    Response.End();
                    Response.Clear();
                }



            }
            //    var result = lq.CalcSymbolVARV2(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), 1, SymbolId.ToValidMsgInt()).ToList();
            //var result2 = lq.CalcSymbolVARV2(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), 5, SymbolId.ToValidMsgInt()).ToList();
            //var result3 = lq.CalcSymbolVARV2(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), 21, SymbolId.ToValidMsgInt()).ToList();



            //var data = result;

            //ExcelPackage excel = new ExcelPackage();
            //var workSheet = excel.Workbook.Worksheets.Add("VaR روزانه");
            //workSheet.Cells[1, 1].LoadFromCollection(data, true);
            //workSheet.View.RightToLeft = true;
            //workSheet.Cells[1, 1].Value = "Symbol";
            //workSheet.Cells[1, 2].Value = "VaR Historical";
            //workSheet.Cells[1, 3].Value = "VaR Parametric";
            //workSheet.Cells[1, 4].Value = "VaR Monte-Carlo";

            //var data2 = result2;
            //var workSheet2 = excel.Workbook.Worksheets.Add("VaR هفتگی");
            //workSheet2.Cells[1, 1].LoadFromCollection(data2, true);
            //workSheet2.View.RightToLeft = true;
            //workSheet2.Cells[1, 1].Value = "Symbol";
            //workSheet2.Cells[1, 2].Value = "VaR Historical";
            //workSheet2.Cells[1, 3].Value = "VaR Parametric";
            //workSheet2.Cells[1, 4].Value = "VaR Monte-Carlo";

            //var data3 = result3;
            //var workSheet3 = excel.Workbook.Worksheets.Add("VaR ماهانه");
            //workSheet3.Cells[1, 1].LoadFromCollection(data3, true);
            //workSheet3.View.RightToLeft = true;
            //workSheet3.Cells[1, 1].Value = "Symbol";
            //workSheet3.Cells[1, 2].Value = "VaR Historical";
            //workSheet3.Cells[1, 3].Value = "VaR Parametric";
            //workSheet3.Cells[1, 4].Value = "VaR Monte-Carlo";


        }



        [Authorize]
        public void ExportVaRRanking()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();

            //var HasCheck = Request.QueryString.GetValues("HasCheck").FirstOrDefault();
            //var fields = Request.QueryString.GetValues("fields").FirstOrDefault();
            //var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();
            //var IsPortfolio = Request.QueryString.GetValues("IsPortfolio").FirstOrDefault();

            //var miladiStartDate = Assistant.ShamsiToMiladi(startDate.ToValidMsgInt());
            //var miladiEndDate = Assistant.ShamsiToMiladi(endDate.ToValidMsgInt());
            var StartDate = startDate.ToValidMsgInt();
            var EndDate = endDate.ToValidMsgInt();


            var lq = new LinqHelper();

            var result = lq.GetPortfolioVaRRanking(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate()).ToList();

            var Daily = result.OrderBy(c => c.VaR1).Where(c => c.DateStr == "Daily").Select(s => new { Symbol = s.Symbol, VaR1 = s.VaR1, VaR2 = s.VaR2, VarMonteCarlo = s.VarMonteCarlo, }).ToList();
            var Weekly = result.OrderBy(c => c.VaR1).Where(c => c.DateStr == "Weekly").Select(s => new { Symbol = s.Symbol, VaR1 = s.VaR1, VaR2 = s.VaR2, VarMonteCarlo = s.VarMonteCarlo, }).ToList();
            var Monthly = result.OrderBy(c => c.VaR1).Where(c => c.DateStr == "Monthly").Select(s => new { Symbol = s.Symbol, VaR1 = s.VaR1, VaR2 = s.VaR2, VarMonteCarlo = s.VarMonteCarlo, }).ToList();
            var Seasonaly = result.OrderBy(c => c.VaR1).Where(c => c.DateStr == "Seasonaly").Select(s => new { Symbol = s.Symbol, VaR1 = s.VaR1, VaR2 = s.VaR2, VarMonteCarlo = s.VarMonteCarlo, }).ToList();
            var Monthly6 = result.OrderBy(c => c.VaR1).Where(c => c.DateStr == "6Monthly").Select(s => new { Symbol = s.Symbol, VaR1 = s.VaR1, VaR2 = s.VaR2, VarMonteCarlo = s.VarMonteCarlo, }).ToList();
            var Yearly = result.OrderBy(c => c.VaR1).Where(c => c.DateStr == "Yearly").Select(s => new { Symbol = s.Symbol, VaR1 = s.VaR1, VaR2 = s.VaR2, VarMonteCarlo = s.VarMonteCarlo, }).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("VaR روزانه");
            workSheet.Cells[1, 1].LoadFromCollection(Daily, true);
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].Value = "Symbol";
            workSheet.Cells[1, 2].Value = "VaR Historical";
            workSheet.Cells[1, 3].Value = "VaR Parametric";
            workSheet.Cells[1, 4].Value = "VaR Monte-Carlo";

            var workSheet2 = excel.Workbook.Worksheets.Add("VaR هفتگی");
            workSheet2.Cells[1, 1].LoadFromCollection(Weekly, true);
            workSheet2.View.RightToLeft = true;
            workSheet2.Cells[1, 1].Value = "Symbol";
            workSheet2.Cells[1, 2].Value = "VaR Historical";
            workSheet2.Cells[1, 3].Value = "VaR Parametric";
            workSheet2.Cells[1, 4].Value = "VaR Monte-Carlo";

            var workSheet3 = excel.Workbook.Worksheets.Add("VaR ماهانه");
            workSheet3.Cells[1, 1].LoadFromCollection(Monthly, true);
            workSheet3.View.RightToLeft = true;
            workSheet3.Cells[1, 1].Value = "Symbol";
            workSheet3.Cells[1, 2].Value = "VaR Historical";
            workSheet3.Cells[1, 3].Value = "VaR Parametric";
            workSheet3.Cells[1, 4].Value = "VaR Monte-Carlo";
            var workSheet4 = excel.Workbook.Worksheets.Add("VaR فصلی");
            workSheet4.Cells[1, 1].LoadFromCollection(Seasonaly, true);
            workSheet4.View.RightToLeft = true;
            workSheet4.Cells[1, 1].Value = "Symbol";
            workSheet4.Cells[1, 2].Value = "VaR Historical";
            workSheet4.Cells[1, 3].Value = "VaR Parametric";
            workSheet4.Cells[1, 4].Value = "VaR Monte-Carlo";
            var workSheet5 = excel.Workbook.Worksheets.Add("VaR شش ماهه");
            workSheet5.Cells[1, 1].LoadFromCollection(Monthly6, true);
            workSheet5.View.RightToLeft = true;
            workSheet5.Cells[1, 1].Value = "Symbol";
            workSheet5.Cells[1, 2].Value = "VaR Historical";
            workSheet5.Cells[1, 3].Value = "VaR Parametric";
            workSheet5.Cells[1, 4].Value = "VaR Monte-Carlo";

            var workSheet6 = excel.Workbook.Worksheets.Add("VaR سالانه");
            workSheet6.Cells[1, 1].LoadFromCollection(Yearly, true);
            workSheet6.View.RightToLeft = true;
            workSheet6.Cells[1, 1].Value = "Symbol";
            workSheet6.Cells[1, 2].Value = "VaR Historical";
            workSheet6.Cells[1, 3].Value = "VaR Parametric";
            workSheet6.Cells[1, 4].Value = "VaR Monte-Carlo";
            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=رتبه بندی ارزش در معرض ریسک " + getFundName(fundId.ToString()) + "-" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }






        [Authorize]
        public void ExportVarianceRanking()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();

            //var HasCheck = Request.QueryString.GetValues("HasCheck").FirstOrDefault();
            //var fields = Request.QueryString.GetValues("fields").FirstOrDefault();
            //var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();
            //var IsPortfolio = Request.QueryString.GetValues("IsPortfolio").FirstOrDefault();

            //var miladiStartDate = Assistant.ShamsiToMiladi(startDate.ToValidMsgInt());
            //var miladiEndDate = Assistant.ShamsiToMiladi(endDate.ToValidMsgInt());
            var StartDate = startDate.ToValidMsgInt();
            var EndDate = endDate.ToValidMsgInt();


            var lq = new LinqHelper();

            var result = lq.GetPortfolioSemiSTDRanking(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt())
                .Select(s => new
                {
                    Symbol = s.Symbol,
                    STDEVH_1 = s.STDEVH_1,
                    STDEVC_1 = s.STDEVC_1,
                    STDEVH_5 = s.STDEVH_5,
                    STDEVC_5 = s.STDEVC_5,
                    STDEVH_21 = s.STDEVH_21,
                    STDEVC_21 = s.STDEVC_21,
                    STDEVH_63 = s.STDEVH_63,
                    STDEVC_63 = s.STDEVC_63,
                    STDEVH_126 = s.STDEVH_126,
                    STDEVC_126 = s.STDEVC_126,
                    STDEVH_252 = s.STDEVH_252,
                    STDEVC_252 = s.STDEVC_252

                }).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add(" معیار های پراکندگی");
            workSheet.Cells[1, 1].LoadFromCollection(result, true);
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].Value = "نماد";
            workSheet.Cells[1, 2].Value = "نیم انحراف معیار روزانه";
            workSheet.Cells[1, 3].Value = " انحراف معیار روزانه";
            workSheet.Cells[1, 4].Value = "نیم انحراف معیار هفتگی";
            workSheet.Cells[1, 5].Value = " انحراف معیار هفتگی";
            workSheet.Cells[1, 6].Value = "نیم انحراف معیار ماهانه";
            workSheet.Cells[1, 7].Value = " انحراف معیار ماهانه";
            workSheet.Cells[1, 8].Value = "نیم انحراف معیار فصلی";
            workSheet.Cells[1, 9].Value = " انحراف معیار فصلی";
            workSheet.Cells[1, 10].Value = "نیم انحراف معیار شش ماهه";
            workSheet.Cells[1, 11].Value = " انحراف معیار شش ماهه";
            workSheet.Cells[1, 12].Value = "نیم انحراف معیار سالانه";
            workSheet.Cells[1, 13].Value = " انحراف معیار سالانه";

            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename= رتبه بندی معیار های پراکندگی " + getFundName(fundId.ToString()) + "-" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }


        [Authorize]
        public void ExportStdevRanking()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();

            //var HasCheck = Request.QueryString.GetValues("HasCheck").FirstOrDefault();
            //var fields = Request.QueryString.GetValues("fields").FirstOrDefault();
            //var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();
            //var IsPortfolio = Request.QueryString.GetValues("IsPortfolio").FirstOrDefault();

            //var miladiStartDate = Assistant.ShamsiToMiladi(startDate.ToValidMsgInt());
            //var miladiEndDate = Assistant.ShamsiToMiladi(endDate.ToValidMsgInt());
            var StartDate = startDate.ToValidMsgInt();
            var EndDate = endDate.ToValidMsgInt();


            var lq = new LinqHelper();

            var result = lq.GetPortfolioTrackingErrorRanking(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt())
                .Select(s => new
                {
                    Symbol = s.Symbol
                                    ,
                    TrackingError = s.TrackingError
                }).ToList();



            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add(" خطای ردیابی ");
            workSheet.Cells[1, 1].LoadFromCollection(result, true);
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].Value = "نماد";
            workSheet.Cells[1, 2].Value = "خطای ردیابی ";


            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=رتبه بندی خطای ردیابی " + getFundName(fundId.ToString()) + "-" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }


        [Authorize]
        public void ExportBetaRanking()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();

            //var HasCheck = Request.QueryString.GetValues("HasCheck").FirstOrDefault();
            //var fields = Request.QueryString.GetValues("fields").FirstOrDefault();
            //var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();
            //var IsPortfolio = Request.QueryString.GetValues("IsPortfolio").FirstOrDefault();

            //var miladiStartDate = Assistant.ShamsiToMiladi(startDate.ToValidMsgInt());
            //var miladiEndDate = Assistant.ShamsiToMiladi(endDate.ToValidMsgInt());
            var StartDate = startDate.ToValidMsgInt();
            var EndDate = endDate.ToValidMsgInt();


            var lq = new LinqHelper();

            var result = lq.GetPortfolioBetaRanking(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt()).Select(s => new { Symbol = s.Symbol, Beta = s.Beta, }).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("ضریب بتا");
            workSheet.Cells[1, 1].LoadFromCollection(result, true);
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].Value = "نماد";
            workSheet.Cells[1, 2].Value = "بتا";


            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=رتبه بندی ضریب بتا " + getFundName(fundId.ToString()) + "-" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }

        [Authorize]
        public void ExportPerformanceEvaluationRanking()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();
            var Percent = Request.QueryString.GetValues("Percent").FirstOrDefault();

            //var HasCheck = Request.QueryString.GetValues("HasCheck").FirstOrDefault();
            //var fields = Request.QueryString.GetValues("fields").FirstOrDefault();
            //var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();
            //var IsPortfolio = Request.QueryString.GetValues("IsPortfolio").FirstOrDefault();

            //var miladiStartDate = Assistant.ShamsiToMiladi(startDate.ToValidMsgInt());
            //var miladiEndDate = Assistant.ShamsiToMiladi(endDate.ToValidMsgInt());
            var StartDate = startDate.ToValidMsgInt();
            var EndDate = endDate.ToValidMsgInt();


            var lq = new LinqHelper();

            var result = lq.GetPortfolioPerformanceEvaluationRanking(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt(), Percent.ToValidMsgdouble())
                .Select(s => new
                {
                    Symbol = s.Symbol,
                    IndexVAR = s.IndexVAR,
                    PortVAR = s.PortVAR,
                    IndexSTDEV = s.IndexSTDEV,
                    PortSTDEV = s.PortSTDEV,
                    PortHalfSTDEV = s.PortHalfSTDEV,
                    COV = s.COV,
                    Beta = s.Beta,
                    NoneRiskRate = s.NoneRiskRate,
                    PortfolioTotalYield = s.PortfolioTotalYield,
                    IndexTotalYield = s.IndexTotalYield,
                    CAPMYield = s.CAPMYield,
                    Trainer = s.Trainer,
                    Sharp = s.Sharp,
                    Sortino = s.Sortino,
                    Jensen = s.Jensen
                }).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("ارزیابی عملکرد  ");
            workSheet.Cells[1, 1].LoadFromCollection(result, true);
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].Value = "نماد";
            workSheet.Cells[1, 2].Value = "واریانس شاخص";
            workSheet.Cells[1, 3].Value = "واریانس پرتفوی";
            workSheet.Cells[1, 4].Value = "انحراف معیار شاخص";
            workSheet.Cells[1, 5].Value = "انحراف معیار پرتفوی";
            workSheet.Cells[1, 6].Value = "نیم انحراف معیار پرتفوی";
            workSheet.Cells[1, 7].Value = "کوواریانس";
            workSheet.Cells[1, 8].Value = "بتا";
            workSheet.Cells[1, 9].Value = "نرخ بدون ریسک برای دوره مورد نظر";
            workSheet.Cells[1, 10].Value = "بازدهی کل دوره صندوق";
            workSheet.Cells[1, 11].Value = "بازدهی کل دوره شاخص ";
            workSheet.Cells[1, 12].Value = "بازدهی با CAPM";
            workSheet.Cells[1, 13].Value = "نسبت ترینر";
            workSheet.Cells[1, 14].Value = "نسبت شارپ";
            workSheet.Cells[1, 15].Value = "نسبت سورتینو";
            workSheet.Cells[1, 16].Value = "معیار جنسن";


            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=رتبه بندی ارزیابی عملکرد " + getFundName(fundId.ToString()) + "-" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }








        [Authorize]
        public void ExportSymbolBetaV2()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var SymbolId = Request.QueryString.GetValues("Symbol").FirstOrDefault();

            //var HasCheck = Request.QueryString.GetValues("HasCheck").FirstOrDefault();
            //var fields = Request.QueryString.GetValues("fields").FirstOrDefault();
            //var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();
            //var IsPortfolio = Request.QueryString.GetValues("IsPortfolio").FirstOrDefault();

            //var miladiStartDate = Assistant.ShamsiToMiladi(startDate.ToValidMsgInt());
            //var miladiEndDate = Assistant.ShamsiToMiladi(endDate.ToValidMsgInt());
            var StartDate = startDate.ToValidMsgInt();
            var EndDate = endDate.ToValidMsgInt();


            var lq = new LinqHelper();
            var data = lq.GetSymbolBeta(SymbolId.ToValidMsgInt(), startDate.ToValidMsgInt(), endDate.ToValidMsgInt());

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Beta");
            workSheet.View.RightToLeft = true;

            workSheet.Cells[1, 1].LoadFromCollection(data, true);
            workSheet.Cells[1, 1].Value = "نیم انحراف معیار ";
            workSheet.Cells[1, 2].Value = "انحراف معیار ";
            workSheet.Cells[1, 3].Value = "کوواریانس";
            workSheet.Cells[1, 4].Value = "بتا";


            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=ضریب بتا نماد" + SymbolId + "-" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }














        [Authorize]
        public void ExportPortfolioPrice()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();
            var InterVal = Request.QueryString.GetValues("InterVal").FirstOrDefault();
            var StartDate = startDate.ToValidMsgInt();
            var EndDate = endDate.ToValidMsgInt();

            List<GetHistoricalSymbolPriceBySymbol_Result> data = new List<GetHistoricalSymbolPriceBySymbol_Result>();
            var lq = new LinqHelper();

            var SymbolWeights = lq.GetLastFundPortfoliosByDate(fundId.ToValidMsgInt(), endDate.ToValidMsgDate());

            SymbolWeights = SymbolWeights.GroupBy(d => d.Instrument)
                                            .Select(
                                                g => new GetLastFundPortfoliosByDate_Result
                                                {
                                                    Id = g.First().Id,
                                                       //CoID = g.First().CoID,
                                                       Name = g.First().Name,
                                                    Instrument = g.First().Instrument,
                                                       //IsRight = g.First().IsRight,
                                                       Count = g.Sum(s => s.Count),
                                                    Price = g.First().Price,
                                                    MarketValue = g.First().MarketValue,
                                                    PDate = g.First().PDate,
                                                    FundId = g.First().FundId,
                                                    RegDate = g.First().RegDate,
                                                    RegTime = g.First().RegTime,
                                                    MarketName = g.First().MarketName,
                                                    SymbolId = g.First().SymbolId,
                                                    LastTradeDate = g.First().LastTradeDate,
                                                    Weight = g.First().Weight,
                                                    TotalValue = g.First().TotalValue,
                                                       //Ownership = g.First().Ownership,
                                                   }).ToList();





            ExcelPackage excel = new ExcelPackage();



            if (InterVal != "-1")
            {



                var res1 = lq.CalculatePortfolioYieldForVaRRawDataSymbols(startDate.ToValidMsgDate()
                                                                        , endDate.ToValidMsgInt()
                                                                        , fundId.ToValidMsgInt()
                                                                        , InterVal.ToValidMsgInt());

                var distinctSymbol = res1.OrderBy(c => c.Symbol).Select(a => a.Symbol).Distinct().ToList();

                //var distinctSymbol = res1.GroupBy(c => c.Symbol).Select(x => new
                //{
                //    CurrencyName = x.Key.CurrencyName,
                //    DestinationCountry = x.Key.DestinationCountry,
                //    SumAmount = x.Sum(c => c.NewAmount)
                //}).ToList();



                var result = res1.OrderByDescending(c => c.DatePrice).ToList();

                var i = 2;
                var j = 2;
                var Row = 0;
                var workSheet = excel.Workbook.Worksheets.Add("اطلاعات پرتفوی");
                workSheet.View.RightToLeft = true;

                foreach (var item in distinctSymbol)
                {
                    var query = result.Where(c => c.Symbol == item).OrderByDescending(c => c.DatePrice).ToList();
                    if (query != null)
                    {
                        var SumCountList = SymbolWeights.Where(c => c.Instrument == item).Select(a => a.Count).ToList();
                        var SumCount = SumCountList.Sum();

                        workSheet.Cells[2, i].LoadFromCollection(query.Select(a => a.SymbolPrice.ToString()), true);
                        workSheet.Cells[1, i].Value = item;
                        //workSheet.Cells[2, i].Value = SymbolWeights.Where(c => c.Instrument == item).Select(a => a.Count).FirstOrDefault();
                        workSheet.Cells[2, i].Value = SumCount;
                        workSheet.Cells[2, 1].LoadFromCollection(query.Select(a => a.DatePrice.ToString()), true);
                        workSheet.Cells[2, 1].Value = "تعداد :";
                        workSheet.Cells[1, 1].Value = "نماد :";
                        Row = query.Count;
                        i++;
                    }
                    j++;
                }
                foreach (var cell in workSheet.Cells[2, 2, Row + 2, i - 1])
                {
                    if (cell.Value != "" && cell.Value != null)
                        cell.Value = Convert.ToDecimal(Convert.ToDouble(cell.Value));
                }
                workSheet.Cells[workSheet.Dimension.Address].AutoFitColumns();
                workSheet.Cells[2, 2, Row + 2, i - 1].Style.Numberformat.Format = "@";
                workSheet.Cells[2, 2, Row + 2, i - 1].Style.Numberformat.Format = "#,##0.00";


                //workSheet.Cells[2, 2, j + 100, i + 100].Value = Convert.ToDecimal(workSheet.Cells[2, 2, j + 100, i + 100].Value);

                i = 2;
                j = 2;
                var workSheet2 = excel.Workbook.Worksheets.Add("بازدهی سهام");
                workSheet2.View.RightToLeft = true;
                foreach (var item in distinctSymbol)
                {
                    var query = result.Where(c => c.Symbol == item).OrderByDescending(c => c.DatePrice).ToList();
                    if (query != null)
                    {
                        workSheet2.Cells[1, i].LoadFromCollection(query.Select(a => a.Symbolret.ToString()), true);
                        workSheet2.Cells[1, i].Value = item;
                        //workSheet2.Cells[2, i].Value = SymbolWeights.Where(c => c.Instrument == item).Select(a => a.Count).FirstOrDefault();
                        workSheet2.Cells[1, 1].LoadFromCollection(query.Select(a => a.DatePrice.ToString()), true);
                        //workSheet2.Cells[2, 1].Value = "وزن :";
                        workSheet2.Cells[1, 1].Value = "نماد :";

                        //workSheet.Cells["C4"].Style.Numberformat =;
                        //workSheet.Cells["C4"].Style.Numberformat = "###,##";

                        i++;
                    }
                    j++;
                }
                //workSheet2.Cells[2, 2, j + 100, i + 100].Style.Numberformat.Format = "0.0000";

                foreach (var cell in workSheet2.Cells[2, 2, Row + 2, i - 1])
                {
                    if (cell.Value != "" && cell.Value != null)
                        cell.Value = Convert.ToDecimal(Convert.ToDouble(cell.Value));
                }
                workSheet2.Cells[workSheet2.Dimension.Address].AutoFitColumns();
                workSheet2.Cells[2, 2, Row + 2, i - 1].Style.Numberformat.Format = "@";
                workSheet2.Cells[2, 2, Row + 2, i - 1].Style.Numberformat.Format = "#,##0.00000";

                i = 2;
                j = 2;
                var workSheet3 = excel.Workbook.Worksheets.Add("وزن");
                workSheet3.View.RightToLeft = true;
                foreach (var item in distinctSymbol)
                {
                    var query = result.Where(c => c.Symbol == item).OrderByDescending(c => c.DatePrice).ToList();
                    if (query != null)
                    {
                        workSheet3.Cells[1, i].LoadFromCollection(query.Select(a => a.SymbolWeight.ToString()), true);
                        workSheet3.Cells[1, i].Value = item;
                        //workSheet2.Cells[2, i].Value = SymbolWeights.Where(c => c.Instrument == item).Select(a => a.Count).FirstOrDefault();
                        workSheet3.Cells[1, 1].LoadFromCollection(query.Select(a => a.DatePrice.ToString()), true);
                        //workSheet2.Cells[2, 1].Value = "وزن :";
                        workSheet3.Cells[1, 1].Value = "نماد :";

                        //workSheet.Cells["C4"].Style.Numberformat =;
                        //workSheet.Cells["C4"].Style.Numberformat = "###,##";

                        i++;
                    }
                    j++;
                }
                //workSheet3.Cells[2, 2, j + 100, i + 100].Style.Numberformat.Format = "0.0000";

                foreach (var cell in workSheet3.Cells[2, 2, Row + 2, i - 1])
                {
                    if (cell.Value != "" && cell.Value != null)
                        cell.Value = Convert.ToDecimal(Convert.ToDouble(cell.Value));
                }
                workSheet3.Cells[workSheet3.Dimension.Address].AutoFitColumns();
                workSheet3.Cells[2, 2, Row + 2, i - 1].Style.Numberformat.Format = "@";
                workSheet3.Cells[2, 2, Row + 2, i - 1].Style.Numberformat.Format = "#,##0.00000";



                var res2 = lq.CalculatePortfolioYieldForVaRRawDataSymbolWeight(startDate.ToValidMsgDate()
                                                                                  , endDate.ToValidMsgInt()
                                                                                  , fundId.ToValidMsgInt()
                                                                                  , InterVal.ToValidMsgInt());
                var result2 = res2.OrderByDescending(c => c.DatePrice).ToList();




                //i = 2;
                //j = 2;
                //var workSheet4 = excel.Workbook.Worksheets.Add("وزن");
                //workSheet4.View.RightToLeft = true;
                //foreach (var item in distinctSymbol)
                //{
                //    var query = result2.Where(c => c.Symbol == item).OrderByDescending(c => c.DatePrice).ToList();
                //    if (query != null)
                //    {
                //        workSheet4.Cells[1, i].LoadFromCollection(query.Select(a => a.Symbolret.ToString()), true);
                //        workSheet4.Cells[1, i].Value = item;
                //        //workSheet2.Cells[2, i].Value = SymbolWeights.Where(c => c.Instrument == item).Select(a => a.Count).FirstOrDefault();
                //        workSheet4.Cells[1, 1].LoadFromCollection(query.Select(a => a.DatePrice.ToString()), true);
                //        //workSheet2.Cells[2, 1].Value = "وزن :";
                //        workSheet4.Cells[1, 1].Value = "نماد :";

                //        //workSheet.Cells["C4"].Style.Numberformat =;
                //        //workSheet.Cells["C4"].Style.Numberformat = "###,##";

                //        i++;
                //    }
                //    j++;
                //}
                //workSheet4.Cells[2, 2, j + 100, i + 100].Style.Numberformat.Format = "0.00000";


                //foreach (var cell in workSheet4.Cells[2, 2, Row + 2, i - 1])
                //{
                //    if (cell.Value != "")
                //        cell.Value = Convert.ToDecimal(Convert.ToDouble(cell.Value));
                //}
                //workSheet4.Cells[workSheet4.Dimension.Address].AutoFitColumns();
                //workSheet4.Cells[2, 2, Row + 2, i - 1].Style.Numberformat.Format = "@";
                //workSheet4.Cells[2, 2, Row + 2, i - 1].Style.Numberformat.Format = "#,##0.00000";



                var res3 = lq.CalculatePortfolioYieldForVaRRawDataDailyRet(startDate.ToValidMsgDate()
                                                                                           , endDate.ToValidMsgInt()
                                                                                           , fundId.ToValidMsgInt()
                                                                                           , InterVal.ToValidMsgInt()).Select(s => new
                                                                                           {
                                                                                               DatePrice = s.DatePrice,
                                                                                               Symbolret = s.Symbolret,
                                                                                           }).ToList(); ;

                var result3 = res3.OrderByDescending(c => c.DatePrice).ToList();




                var workSheet4 = excel.Workbook.Worksheets.Add("بازدهی روزانه");
                workSheet4.Cells[1, 1].LoadFromCollection(result3, true);
                workSheet4.View.RightToLeft = true;
                //workSheet.Cells[1, 1].Value = "cov";
                //workSheet4.Cells[2, 2, 5000, 2].Style.Numberformat.Format = "0.00000";

                workSheet4.Cells[2, 2, 5000, 2].Style.Numberformat.Format = "#,##0.00000";
                foreach (var cell in workSheet4.Cells[2, 2, 5000, 2])
                {
                    //cell.Value = Convert.ToDecimal(cell.Value);
                    if (cell.Value != "" && cell.Value != null)
                        cell.Value = Decimal.Parse(cell.Value.ToString(), System.Globalization.NumberStyles.Any);
                }



                workSheet4.Cells[1, 1].Value = "تاریخ";
                workSheet4.Cells[1, 2].Value = "بازدهی  ";

                var res4 = lq.CalculatePortfolioYieldForVaR(startDate.ToValidMsgDate()
                                                                                        , endDate.ToValidMsgInt()
                                                                                        , fundId.ToValidMsgInt()
                                                                                        , InterVal.ToValidMsgInt()).Select(s => new
                                                                                        {
                                                                                            DatePrice = s.DatePrice,
                                                                                            Symbolret = s.Symbolret,
                                                                                        }).ToList(); ; ;
                var result4 = res4.OrderByDescending(c => c.DatePrice).ToList();
                var workSheet5 = excel.Workbook.Worksheets.Add("بازدهی پرتفوی");
                workSheet5.Cells[1, 1].LoadFromCollection(result4, true);
                workSheet5.View.RightToLeft = true;
                //workSheet.Cells[1, 1].Value = "cov";

                //workSheet5.Cells[2, 2, 5000, 2].Style.Numberformat.Format = "0.00000";

                workSheet5.Cells[2, 2, 5000, 2].Style.Numberformat.Format = "#,##0.00000";
                foreach (var cell in workSheet5.Cells[2, 2, 5000, 2])
                {
                    //cell.Value = Convert.ToDecimal(cell.Value);
                    if (cell.Value != "" && cell.Value != null)
                        cell.Value = Decimal.Parse(cell.Value.ToString(), System.Globalization.NumberStyles.Any);
                }

                workSheet5.Cells[1, 1].Value = "تاریخ";
                workSheet5.Cells[1, 2].Value = "بازدهی  ";




            }
            else
            {




                var res1 = lq.CalculatePortfolioYieldForVaRRawDataSymbols(startDate.ToValidMsgDate()
                                                                        , endDate.ToValidMsgInt()
                                                                        , fundId.ToValidMsgInt()
                                                                        , (int)YieldCycle.Yearly);

                var distinctSymbol = res1.OrderBy(c => c.Symbol).Select(a => a.Symbol).Distinct().ToList();
                var result = res1.OrderByDescending(c => c.DatePrice).ToList();

                var i = 2;
                var j = 2;
                var Row = 0;
                var workSheet = excel.Workbook.Worksheets.Add("اطلاعات پرتفوی");
                workSheet.View.RightToLeft = true;

                foreach (var item in distinctSymbol)
                {
                    var query = result.Where(c => c.Symbol == item).OrderByDescending(c => c.DatePrice).ToList();
                    if (query != null)
                    {

                        var SumCountList = SymbolWeights.Where(c => c.Instrument == item).Select(a => a.Count).ToList();
                        var SumCount = SumCountList.Sum();

                        workSheet.Cells[2, i].LoadFromCollection(query.Select(a => a.SymbolPrice.ToString()), true);
                        workSheet.Cells[1, i].Value = item;
                        workSheet.Cells[2, i].Value = SumCount;
                        //workSheet.Cells[2, i].Value = SymbolWeights.Where(c => c.Instrument == item).Select(a => a.Count).FirstOrDefault();
                        workSheet.Cells[2, 1].LoadFromCollection(query.Select(a => a.DatePrice.ToString()), true);
                        workSheet.Cells[2, 1].Value = "تعداد :";
                        workSheet.Cells[1, 1].Value = "نماد :";
                        Row = query.Count;
                        i++;
                    }
                    j++;
                }
                foreach (var cell in workSheet.Cells[2, 2, Row + 2, i - 1])
                {
                    if (cell.Value != "" && cell.Value != null)
                        cell.Value = Convert.ToDecimal(Convert.ToDouble(cell.Value));
                }
                workSheet.Cells[workSheet.Dimension.Address].AutoFitColumns();
                workSheet.Cells[2, 2, Row + 2, i - 1].Style.Numberformat.Format = "@";
                workSheet.Cells[2, 2, Row + 2, i - 1].Style.Numberformat.Format = "#,##0.00";


                //workSheet.Cells[2, 2, j + 100, i + 100].Value = Convert.ToDecimal(workSheet.Cells[2, 2, j + 100, i + 100].Value);

                i = 2;
                j = 2;
                var workSheet2 = excel.Workbook.Worksheets.Add("بازدهی سهام");
                workSheet2.View.RightToLeft = true;
                foreach (var item in distinctSymbol)
                {
                    var query = result.Where(c => c.Symbol == item).OrderByDescending(c => c.DatePrice).ToList();
                    if (query != null)
                    {
                        workSheet2.Cells[1, i].LoadFromCollection(query.Select(a => a.Symbolret.ToString()), true);
                        workSheet2.Cells[1, i].Value = item;
                        //workSheet2.Cells[2, i].Value = SymbolWeights.Where(c => c.Instrument == item).Select(a => a.Count).FirstOrDefault();
                        workSheet2.Cells[1, 1].LoadFromCollection(query.Select(a => a.DatePrice.ToString()), true);
                        //workSheet2.Cells[2, 1].Value = "وزن :";
                        workSheet2.Cells[1, 1].Value = "نماد :";

                        //workSheet.Cells["C4"].Style.Numberformat =;
                        //workSheet.Cells["C4"].Style.Numberformat = "###,##";

                        i++;
                    }
                    j++;
                }
                //workSheet2.Cells[2, 2, j + 100, i + 100].Style.Numberformat.Format = "0.0000";

                foreach (var cell in workSheet2.Cells[2, 2, Row + 2, i - 1])
                {
                    if (cell.Value != "" && cell.Value != null)
                        cell.Value = Convert.ToDecimal(Convert.ToDouble(cell.Value));
                }
                workSheet2.Cells[workSheet2.Dimension.Address].AutoFitColumns();
                workSheet2.Cells[2, 2, Row + 2, i - 1].Style.Numberformat.Format = "@";
                workSheet2.Cells[2, 2, Row + 2, i - 1].Style.Numberformat.Format = "#,##0.00000";

                i = 2;
                j = 2;
                var workSheet3 = excel.Workbook.Worksheets.Add("وزن");
                workSheet3.View.RightToLeft = true;
                foreach (var item in distinctSymbol)
                {
                    var query = result.Where(c => c.Symbol == item).OrderByDescending(c => c.DatePrice).ToList();
                    if (query != null)
                    {
                        workSheet3.Cells[1, i].LoadFromCollection(query.Select(a => a.SymbolWeight.ToString()), true);
                        workSheet3.Cells[1, i].Value = item;
                        //workSheet2.Cells[2, i].Value = SymbolWeights.Where(c => c.Instrument == item).Select(a => a.Count).FirstOrDefault();
                        workSheet3.Cells[1, 1].LoadFromCollection(query.Select(a => a.DatePrice.ToString()), true);
                        //workSheet2.Cells[2, 1].Value = "وزن :";
                        workSheet3.Cells[1, 1].Value = "نماد :";

                        //workSheet.Cells["C4"].Style.Numberformat =;
                        //workSheet.Cells["C4"].Style.Numberformat = "###,##";

                        i++;
                    }
                    j++;
                }
                //workSheet3.Cells[2, 2, j + 100, i + 100].Style.Numberformat.Format = "0.0000";

                foreach (var cell in workSheet3.Cells[2, 2, Row + 2, i - 1])
                {
                    if (cell.Value != "" && cell.Value != null)
                        cell.Value = Convert.ToDecimal(Convert.ToDouble(cell.Value));
                }
                workSheet3.Cells[workSheet3.Dimension.Address].AutoFitColumns();
                workSheet3.Cells[2, 2, Row + 2, i - 1].Style.Numberformat.Format = "@";
                workSheet3.Cells[2, 2, Row + 2, i - 1].Style.Numberformat.Format = "#,##0.00000";



                var res2 = lq.CalculatePortfolioYieldForVaRRawDataSymbolWeight(startDate.ToValidMsgDate()
                                                                                  , endDate.ToValidMsgInt()
                                                                                  , fundId.ToValidMsgInt()
                                                                                  , (int)YieldCycle.Yearly);
                var result2 = res2.OrderByDescending(c => c.DatePrice).ToList();




                //i = 2;
                //j = 2;
                //var workSheet4 = excel.Workbook.Worksheets.Add("وزن");
                //workSheet4.View.RightToLeft = true;
                //foreach (var item in distinctSymbol)
                //{
                //    var query = result2.Where(c => c.Symbol == item).OrderByDescending(c => c.DatePrice).ToList();
                //    if (query != null)
                //    {
                //        workSheet4.Cells[1, i].LoadFromCollection(query.Select(a => a.Symbolret.ToString()), true);
                //        workSheet4.Cells[1, i].Value = item;
                //        //workSheet2.Cells[2, i].Value = SymbolWeights.Where(c => c.Instrument == item).Select(a => a.Count).FirstOrDefault();
                //        workSheet4.Cells[1, 1].LoadFromCollection(query.Select(a => a.DatePrice.ToString()), true);
                //        //workSheet2.Cells[2, 1].Value = "وزن :";
                //        workSheet4.Cells[1, 1].Value = "نماد :";

                //        //workSheet.Cells["C4"].Style.Numberformat =;
                //        //workSheet.Cells["C4"].Style.Numberformat = "###,##";

                //        i++;
                //    }
                //    j++;
                //}
                //workSheet4.Cells[2, 2, j + 100, i + 100].Style.Numberformat.Format = "0.00000";


                //foreach (var cell in workSheet4.Cells[2, 2, Row + 2, i - 1])
                //{
                //    if (cell.Value != "")
                //        cell.Value = Convert.ToDecimal(Convert.ToDouble(cell.Value));
                //}
                //workSheet4.Cells[workSheet4.Dimension.Address].AutoFitColumns();
                //workSheet4.Cells[2, 2, Row + 2, i - 1].Style.Numberformat.Format = "@";
                //workSheet4.Cells[2, 2, Row + 2, i - 1].Style.Numberformat.Format = "#,##0.00000";



                var res3 = lq.CalculatePortfolioYieldForVaRRawDataDailyRet(startDate.ToValidMsgDate()
                                                                                           , endDate.ToValidMsgInt()
                                                                                           , fundId.ToValidMsgInt()
                                                                                           , (int)YieldCycle.Yearly).Select(s => new
                                                                                           {
                                                                                               DatePrice = s.DatePrice,
                                                                                               Symbolret = s.Symbolret,
                                                                                           }).ToList(); ;

                var result3 = res3.OrderByDescending(c => c.DatePrice).ToList();




                var workSheet4 = excel.Workbook.Worksheets.Add("بازدهی روزانه");
                workSheet4.Cells[1, 1].LoadFromCollection(result3, true);
                workSheet4.View.RightToLeft = true;
                //workSheet.Cells[1, 1].Value = "cov";
                //workSheet4.Cells[2, 2, 5000, 2].Style.Numberformat.Format = "0.00000";

                workSheet4.Cells[2, 2, 5000, 2].Style.Numberformat.Format = "#,##0.00000";
                foreach (var cell in workSheet4.Cells[2, 2, 5000, 2])
                {
                    //cell.Value = Convert.ToDecimal(cell.Value);
                    if (cell.Value != "" && cell.Value != null)
                        cell.Value = Decimal.Parse(cell.Value.ToString(), System.Globalization.NumberStyles.Any);
                }



                workSheet4.Cells[1, 1].Value = "تاریخ";
                workSheet4.Cells[1, 2].Value = "بازدهی  ";

                var res41 = lq.CalculatePortfolioYieldForVaR(startDate.ToValidMsgDate()
                                                                                        , endDate.ToValidMsgInt()
                                                                                        , fundId.ToValidMsgInt()
                                                                                        , (int)YieldCycle.Daily).Select(s => new
                                                                                        {
                                                                                            DatePrice = s.DatePrice,
                                                                                            SymbolretDaily = s.Symbolret,
                                                                                        }).ToList();

                var res42 = lq.CalculatePortfolioYieldForVaR(startDate.ToValidMsgDate()
                                                                                      , endDate.ToValidMsgInt()
                                                                                      , fundId.ToValidMsgInt()
                                                                                      , (int)YieldCycle.Weekly).Select(s => new
                                                                                      {
                                                                                          DatePrice = s.DatePrice,
                                                                                          SymbolretWeekly = s.Symbolret,
                                                                                      }).ToList();

                var res43 = lq.CalculatePortfolioYieldForVaR(startDate.ToValidMsgDate()
                                                                                      , endDate.ToValidMsgInt()
                                                                                      , fundId.ToValidMsgInt()
                                                                                      , (int)YieldCycle.Monthly).Select(s => new
                                                                                      {
                                                                                          DatePrice = s.DatePrice,
                                                                                          SymbolretMonthly = s.Symbolret,
                                                                                      }).ToList();
                var res44 = lq.CalculatePortfolioYieldForVaR(startDate.ToValidMsgDate()
                                                                                      , endDate.ToValidMsgInt()
                                                                                      , fundId.ToValidMsgInt()
                                                                                      , (int)YieldCycle.Seasonal).Select(s => new
                                                                                      {
                                                                                          DatePrice = s.DatePrice,
                                                                                          SymbolretSeasonal = s.Symbolret,
                                                                                      }).ToList();
                var res45 = lq.CalculatePortfolioYieldForVaR(startDate.ToValidMsgDate()
                                                                                      , endDate.ToValidMsgInt()
                                                                                      , fundId.ToValidMsgInt()
                                                                                      , (int)YieldCycle.Months6).Select(s => new
                                                                                      {
                                                                                          DatePrice = s.DatePrice,
                                                                                          SymbolretMonths6 = s.Symbolret,
                                                                                      }).ToList();
                var res46 = lq.CalculatePortfolioYieldForVaR(startDate.ToValidMsgDate()
                                                                                      , endDate.ToValidMsgInt()
                                                                                      , fundId.ToValidMsgInt()
                                                                                      , (int)YieldCycle.Yearly).Select(s => new
                                                                                      {
                                                                                          DatePrice = s.DatePrice,
                                                                                          SymbolretYearly = s.Symbolret,
                                                                                      }).ToList();
                var result4 = from r1 in res41
                              join r2 in res42 on r1.DatePrice equals r2.DatePrice
                              join r3 in res43 on r1.DatePrice equals r3.DatePrice
                              join r4 in res44 on r1.DatePrice equals r4.DatePrice
                              join r5 in res45 on r1.DatePrice equals r5.DatePrice
                              join r6 in res46 on r1.DatePrice equals r6.DatePrice

                              select new
                              {
                                  DatePrice = r1.DatePrice,
                                  SymbolretDaily = r1.SymbolretDaily,
                                  SymbolretWeekly = r2.SymbolretWeekly,
                                  SymbolretMonthly = r3.SymbolretMonthly,
                                  SymbolretSeasonal = r4.SymbolretSeasonal,
                                  SymbolretMonths6 = r5.SymbolretMonths6,
                                  SymbolretYearly = r6.SymbolretYearly,
                              };

                result4 = result4.OrderByDescending(c => c.DatePrice).ToList();

                //var result4 = res4.OrderByDescending(c => c.DatePrice).ToList();



                var workSheet5 = excel.Workbook.Worksheets.Add("بازدهی پرتفوی");
                workSheet5.Cells[1, 1].LoadFromCollection(result4, true);
                workSheet5.View.RightToLeft = true;
                //workSheet.Cells[1, 1].Value = "cov";

                //workSheet5.Cells[2, 2, 5000, 2].Style.Numberformat.Format = "0.00000";

                workSheet5.Cells[2, 2, 5000, 2].Style.Numberformat.Format = "#,##0.00000";
                foreach (var cell in workSheet5.Cells[2, 2, 5000, 2])
                {
                    //cell.Value = Convert.ToDecimal(cell.Value);
                    if (cell.Value != "" && cell.Value != null)
                        cell.Value = Decimal.Parse(cell.Value.ToString(), System.Globalization.NumberStyles.Any);
                }

                workSheet5.Cells[1, 1].Value = "تاریخ";
                workSheet5.Cells[1, 2].Value = "بازدهی روزانه  ";
                workSheet5.Cells[1, 3].Value = "بازدهی هفتگی  ";
                workSheet5.Cells[1, 4].Value = "بازدهی ماهانه  ";
                workSheet5.Cells[1, 5].Value = "بازدهی فصلی  ";
                workSheet5.Cells[1, 6].Value = "بازدهی شش ماهه  ";
                workSheet5.Cells[1, 7].Value = "بازدهی سالیانه  ";




            }






            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=تاریخچه قیمت نمادهای " + getFundName(fundId.ToString()) + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }


        //[Authorize]
        //public void ExportPortfolioWeeklyVaR()
        //{

        //    var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
        //    var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
        //    var SymbolId = Request.QueryString.GetValues("Symbol").FirstOrDefault();

        //    var HasCheck = Request.QueryString.GetValues("HasCheck").FirstOrDefault();
        //    var fields = Request.QueryString.GetValues("fields").FirstOrDefault();

        //    //var miladiStartDate = Assistant.ShamsiToMiladi(startDate.ToValidMsgInt());
        //    //var miladiEndDate = Assistant.ShamsiToMiladi(endDate.ToValidMsgInt());
        //    var StartDate = startDate.ToValidMsgInt();
        //    var EndDate = endDate.ToValidMsgInt();

        //    List <CalcPortfolioWeeklyVAR_Result> data = new List<CalcPortfolioWeeklyVAR_Result>();
        //    var lq = new LinqHelper();

        //    var result = lq.CalcPortfolioWeeklyVAR(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), HasCheck.ToValidMsgInt(), fields).FirstOrDefault();

        //    //foreach (var item in result)
        //    //{

        //    //    var res = lq.GetFastSymbolVaR(StartDate, EndDate, (int)item.SymbolId).FirstOrDefault();
        //    //    if (res != null) {  }
        //    //}

        //    data.Add(result);

        //    ExcelPackage excel = new ExcelPackage();
        //    var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
        //    workSheet.Cells[1, 1].LoadFromCollection(data, true);
        //    workSheet.View.RightToLeft = true;
        //    workSheet.Cells[1, 1].Value = "VaR Exponential";
        //    workSheet.Cells[1, 2].Value = "VaR Exponential";
        //    workSheet.Cells[1, 3].Value = "VaR Monte-Carlo";


        //    using (var memoryStream = new MemoryStream())
        //    {
        //        Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        //        //here i have set filname as Students.xlsx
        //        Response.AddHeader("content-disposition", "attachment;  filename=PortfolioWeeklyVaR" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
        //        excel.SaveAs(memoryStream);

        //        memoryStream.WriteTo(Response.OutputStream);
        //        Response.Flush();
        //        Response.End();
        //        Response.Clear();
        //    }
        //}



        //[Authorize]
        //public void ExportPortfolioMonthlyVaR()
        //{

        //    var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
        //    var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
        //    var SymbolId = Request.QueryString.GetValues("Symbol").FirstOrDefault();

        //    var HasCheck = Request.QueryString.GetValues("HasCheck").FirstOrDefault();
        //    var fields = Request.QueryString.GetValues("fields").FirstOrDefault();

        //    //var miladiStartDate = Assistant.ShamsiToMiladi(startDate.ToValidMsgInt());
        //    //var miladiEndDate = Assistant.ShamsiToMiladi(endDate.ToValidMsgInt());
        //    var StartDate = startDate.ToValidMsgInt();
        //    var EndDate = endDate.ToValidMsgInt();

        //    List<CalcPortfolioMonthlyVAR_Result> data = new List<CalcPortfolioMonthlyVAR_Result>();
        //    var lq = new LinqHelper();

        //    var result = lq.CalcPortfolioMonthlyVAR(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), HasCheck.ToValidMsgInt(), fields).FirstOrDefault();

        //    //foreach (var item in result)
        //    //{

        //    //    var res = lq.GetFastSymbolVaR(StartDate, EndDate, (int)item.SymbolId).FirstOrDefault();
        //    //    if (res != null) {  }
        //    //}

        //    data.Add(result);

        //    ExcelPackage excel = new ExcelPackage();
        //    var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
        //    workSheet.Cells[1, 1].LoadFromCollection(data, true);
        //    workSheet.View.RightToLeft = true;
        //    workSheet.Cells[1, 1].Value = "VaR Exponential";
        //    workSheet.Cells[1, 2].Value = "VaR Exponential";
        //    workSheet.Cells[1, 3].Value = "VaR Monte-Carlo";


        //    using (var memoryStream = new MemoryStream())
        //    {
        //        Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        //        //here i have set filname as Students.xlsx
        //        Response.AddHeader("content-disposition", "attachment;  filename=PortfolioMonthlyVaR" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
        //        excel.SaveAs(memoryStream);

        //        memoryStream.WriteTo(Response.OutputStream);
        //        Response.Flush();
        //        Response.End();
        //        Response.Clear();
        //    }
        //}


        [Authorize]
        public void ExportAllSymbolsRiskMetrics()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var HasCheck = Request.QueryString.GetValues("HasCheck").FirstOrDefault();
            var fields = Request.QueryString.GetValues("fields").FirstOrDefault();

            //var miladiStartDate = Assistant.ShamsiToMiladi(startDate.ToValidMsgInt());
            //var miladiEndDate = Assistant.ShamsiToMiladi(endDate.ToValidMsgInt());
            var StartDate = startDate.ToValidMsgInt();
            var EndDate = endDate.ToValidMsgInt();

            var lq = new LinqHelper();
            var results = lq.GetSymbolsRiskMetrics(StartDate, EndDate, HasCheck.ToValidMsgInt(), fields).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.Cells[1, 1].LoadFromCollection(results, true);
            workSheet.View.RightToLeft = true;
            //workSheet.Cells[1, 1].Value = "cov";

            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=AllSymbolsRiskMetricsCalculations" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }


        [Authorize]
        public void ExportSavedAllSymbolsRiskMetrics()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var HasCheck = Request.QueryString.GetValues("HasCheck").FirstOrDefault();
            var fields = Request.QueryString.GetValues("fields").FirstOrDefault();

            //var miladiStartDate = Assistant.ShamsiToMiladi(startDate.ToValidMsgInt());
            //var miladiEndDate = Assistant.ShamsiToMiladi(endDate.ToValidMsgInt());
            var StartDate = startDate.ToValidMsgInt();
            var EndDate = endDate.ToValidMsgInt();

            var lq = new LinqHelper();
            var results = lq.GetSavedSymbolsRiskMetrics(StartDate, EndDate, HasCheck.ToValidMsgInt(), fields).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.Cells[1, 1].LoadFromCollection(results, true);
            workSheet.View.RightToLeft = true;
            //workSheet.Cells[1, 1].Value = "cov";



            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=AllSymbolsRiskMetricsCalculations" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }







        [Authorize]
        public void ExportAccountingBuys()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var symbol = Request.QueryString.GetValues("symbol").FirstOrDefault();
            var account = Request.QueryString.GetValues("account").FirstOrDefault();
            List<GetAccountingBuys_Result> data = new List<GetAccountingBuys_Result>();
            var lq = new LinqHelper();
            data = lq.GetAccountingBuys(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), symbol.ToValidString(), account.ToValidString()).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.View.RightToLeft = true;

            workSheet.Cells[1, 1].LoadFromCollection(data, true);
            workSheet.Cells[1, 1].Value = "رديف";
            workSheet.Cells[1, 2].Value = "تاريخ سند";
            workSheet.Cells[1, 3].Value = "شماره فرعي";
            workSheet.Cells[1, 4].Value = "شرح سند";
            workSheet.Cells[1, 5].Value = "رديف قلم";
            workSheet.Cells[1, 6].Value = "كدمعين";
            workSheet.Cells[1, 7].Value = "كدسطح4";
            workSheet.Cells[1, 8].Value = "كدسطح5";
            workSheet.Cells[1, 9].Value = "كدسطح6";
            workSheet.Cells[1, 10].Value = "شرح قلم";
            workSheet.Cells[1, 11].Value = "بدهكار";
            workSheet.Cells[1, 12].Value = "بستانكار";
            workSheet.Cells[1, 13].Value = "مبلغ ارز";
            workSheet.Cells[1, 14].Value = "نرخ ارز";
            workSheet.Cells[1, 15].Value = "ارز";
            workSheet.Cells[1, 16].Value = "ارزمبنا";
            workSheet.Cells[1, 17].Value = "نرخ تبديل ارز";
            workSheet.Cells[1, 18].Value = "شماره پيگيري";

            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename= سند خرید اوراق و واحد های صندوق های تحت بازارگردانی در تاریخ " + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }


        [Authorize]
        public void ExportPositionKardex()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var symbol = Request.QueryString.GetValues("symbol").FirstOrDefault();
            var account = Request.QueryString.GetValues("account").FirstOrDefault();
            List<GetPositionKardex_Result> data = new List<GetPositionKardex_Result>();
            var lq = new LinqHelper();
            data = lq.GetPositionKardex(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), symbol.ToValidString(), account.ToValidString()).ToList();
            if (data[0].Description == "-")
            {
                data[0].Description = "مانده اول دوره";
                data[0].Date = null;

            }

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.View.RightToLeft = true;

            workSheet.Cells[3, 1].LoadFromCollection(data, true);


            //border
            var range = workSheet.Cells["A2:AH" + (data.Count() + 3)];
            range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
            range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
            range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
            range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;

            //font
            range.Style.Font.Name = "B Zar";
            range.Style.Font.Bold = true; //Font should be bold
            range.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center; // Alignment is center
            range.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
            range.Style.Font.Size = 10;

            workSheet.Cells["A1:AH1"].Style.Font.Name = "B Zar";
            workSheet.Cells["A1:AH1"].Style.Font.Size = 18;
            workSheet.Cells["A1:AH1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

            //color
            range = workSheet.Cells["G2:M3"];
            range.Style.Fill.PatternType = ExcelFillStyle.Solid;
            range.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(216, 228, 188));

            range = workSheet.Cells["N2:T3"];
            range.Style.Fill.PatternType = ExcelFillStyle.Solid;
            range.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(252, 213, 180));

            range = workSheet.Cells["U2:W3"];
            range.Style.Fill.PatternType = ExcelFillStyle.Solid;
            range.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(204, 192, 218));

            range = workSheet.Cells["X2:Z3"];
            range.Style.Fill.PatternType = ExcelFillStyle.Solid;
            range.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(146, 208, 80));

            range = workSheet.Cells["AA2:AF3"];
            range.Style.Fill.PatternType = ExcelFillStyle.Solid;
            range.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(218, 238, 243));

            range = workSheet.Cells["AG2:AH3"];
            range.Style.Fill.PatternType = ExcelFillStyle.Solid;
            range.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(243, 243, 243));
            //merg
            workSheet.Cells["A1:AF1"].Merge = true;

            workSheet.Cells["B2:B3"].Merge = true;
            workSheet.Cells["A2:A3"].Merge = true;
            workSheet.Cells["G2:M2"].Merge = true;
            workSheet.Cells["N2:T2"].Merge = true;
            workSheet.Cells["V2:W2"].Merge = true;
            workSheet.Cells["X2:Z2"].Merge = true;
            workSheet.Cells["AA2:AF2"].Merge = true;
            workSheet.Cells["AG2:AH2"].Merge = true;

            workSheet.Row(2).Style.WrapText = true;
            workSheet.Row(3).Style.WrapText = true;

            //Width
            for (int i = 1; i <= 32; i++)
                workSheet.Column(i).Width = 15;
            workSheet.Column(2).Width = 70;

            //values
            workSheet.Cells["A1"].Value = " گزارش اوراق " + symbol + "-(" + account + ")";
            var nameCols = new[] { "تاریخ", "شرح", "وضعيت", "مانده", "بستانکار", "بدهکار" };
            for (int i = 0; i < nameCols.Length; i++)
            {
                workSheet.Cells[2, i + 1].Value = nameCols[i];
            }

            workSheet.Cells["G2"].Value = "خرید";
            workSheet.Cells["N2"].Value = "فروش";
            workSheet.Cells["U2"].Value = "سود(زیان) خرید";
            workSheet.Cells["V2"].Value = "سود(زیان) فروش";
            workSheet.Cells["X2"].Value = "سود دریافتی مستقیم";
            workSheet.Cells["AA2"].Value = "موجودی";
            workSheet.Cells["AG2"].Value = "سایر موارد";

            nameCols = new[] { "0", "0", "0"
                            , "بستانكار"
                            , "تعداد"
                            , "قیمت"
                            , "اصل مبلغ"
                            , " کارمزد خرید کارگزاری"
                            ,"اصل مبلغ بعلاوه کارمزد"
                            ,"خرید سود تضمین شده"
                            , "جمع صورتحساب خرید"
                            , "تعداد"
                            , "قیمت"
                            , "اصل مبلغ"
                            , "کارمزد فروش کارگزاری"
                            ,"مبلغ اصل منهای کارمزد"
                            , "فروش سود تضمین شده"
                            , "جمع صورتحساب فروش"
                            , "سود(زیان)خرید اصل اوراق"
                            , "سود(زیان) فروش اصل اوراق"
                            ,"سود تضمین شده کسب شده"
                            , "از محل مانده سود تضمین شده"
                            , "اضافه شده از محل نگهداشت اوراق"
                            , "جمع"
                            , "تعداد"
                            ,"بهای واحد-اصل"
                            , "سود تضمین شده واحد"
                            , "اصل مبلغ "
                            ,"مانده سود تضمین شده", "بهای تمام شده"
                            ,"بهای تمام شده فروش","سود تضمین شده بستانکار شده"
                            //,"اصل مبلغ2"
                            //,"اصل مبلغ3"
                     };

            for (int i = 0; i < nameCols.Length; i++)
            {
                workSheet.Cells[3, i + 3].Value = nameCols[i];
            }


            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=Kardex" + symbol + "(" + account + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }


        [Authorize]
        public void ExportBuys()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var symbol = Request.QueryString.GetValues("symbol").FirstOrDefault();
            var account = Request.QueryString.GetValues("account").FirstOrDefault();

            var lq = new LinqHelper();
            var data = lq.GetBuySells(0, int.MaxValue, "", (int)TradeType.Buy, symbol.ToValidMsgString(), account.ToValidString(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate()).
                Select(s => new
                {
                    Symbol = s.Symbol,
                    Account = s.Account,
                    TradeDate = s._TradeDate,
                    Shares = s._Shares,
                    Price = s._Price,
                    Value = s._Value,
                    BrokerName = s.BrokerName,
                    BrokerCode = s.BrokerCode,
                    BrokerFee = s._BrokerFee,
                    Tax = s.Tax,
                    Intrest = s.Intrest,
                    SettlementValue = s.SettlementValue,
                    SumAllFee = s.SumAllFee,
                    FundShare = s.FundShare,
                    CsdFee = s.CsdFee,
                    TseTmcFee = s.TseTmcFee,
                    RybFee = s.RybFee,
                    VatFee = s.VatFee,
                    VtsFee = s.VtsFee,
                    LegFee = s.LegFee,
                    SeoAccessRight = s.SeoAccessRight,
                    BourseFee = s.BourseFee,
                    Ticket = s.Ticket
                }).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.View.RightToLeft = true;

            workSheet.Cells[1, 1].LoadFromCollection(data, true);
            workSheet.Cells[1, 1].Value = "نماد";
            workSheet.Cells[1, 2].Value = "حساب کاربری";
            workSheet.Cells[1, 3].Value = "تاریخ معامله";
            workSheet.Cells[1, 4].Value = "تعداد";
            workSheet.Cells[1, 5].Value = "قیمت";
            workSheet.Cells[1, 6].Value = "ارزش";
            workSheet.Cells[1, 7].Value = "نام کارگزار";
            workSheet.Cells[1, 8].Value = "کد کارگزار";
            workSheet.Cells[1, 9].Value = "کارمزد کارگزار";

            workSheet.Cells[1, 10].Value = "Tax";
            workSheet.Cells[1, 11].Value = "Intrest";
            workSheet.Cells[1, 12].Value = "SettlementValue";
            workSheet.Cells[1, 13].Value = "SumAllFee";
            workSheet.Cells[1, 14].Value = "FundShare";
            workSheet.Cells[1, 15].Value = "CsdFee";
            workSheet.Cells[1, 16].Value = "TseTmcFee";
            workSheet.Cells[1, 17].Value = "RybFee";
            workSheet.Cells[1, 18].Value = "VatFee";
            workSheet.Cells[1, 19].Value = "LegFee";
            workSheet.Cells[1, 20].Value = "SeoAccessRight";
            workSheet.Cells[1, 20].Value = "BourseFee";
            workSheet.Cells[1, 20].Value = "Ticket";

            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename= خرید و فروش اوراق و واحد های صندوق های تحت بازارگردانی در تاریخ " + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }




        [Authorize]
        public void ExportSells()
        {
            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var symbol = Request.QueryString.GetValues("symbol").FirstOrDefault();
            var account = Request.QueryString.GetValues("account").FirstOrDefault();

            var lq = new LinqHelper();
            var data = lq.GetBuySells(0, int.MaxValue, "", (int)TradeType.Sell, symbol.ToValidMsgString(), account.ToValidString(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate())
                .Select(s => new
                {
                    Symbol = s.Symbol,
                    Account = s.Account,
                    TradeDate = s._TradeDate,
                    Shares = s._Shares,
                    Price = s._Price,
                    Value = s._Value,
                    BrokerName = s.BrokerName,
                    BrokerCode = s.BrokerCode,
                    BrokerFee = s._BrokerFee,
                    Tax = s.Tax,
                    Intrest = s.Intrest,
                    SettlementValue = s.SettlementValue,
                    SumAllFee = s.SumAllFee,
                    FundShare = s.FundShare,
                    CsdFee = s.CsdFee,
                    TseTmcFee = s.TseTmcFee,
                    RybFee = s.RybFee,
                    VatFee = s.VatFee,
                    VtsFee = s.VtsFee,
                    LegFee = s.LegFee,
                    SeoAccessRight = s.SeoAccessRight,
                    BourseFee = s.BourseFee,
                    Ticket = s.Ticket
                }).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].LoadFromCollection(data, true);

            workSheet.Cells[1, 1].Value = "نماد";
            workSheet.Cells[1, 2].Value = "حساب کاربری";
            workSheet.Cells[1, 3].Value = "تاریخ معامله";
            workSheet.Cells[1, 4].Value = "تعداد";
            workSheet.Cells[1, 5].Value = "قیمت";
            workSheet.Cells[1, 6].Value = "ارزش";
            workSheet.Cells[1, 7].Value = "نام کارگزار";
            workSheet.Cells[1, 8].Value = "کد کارگزار";
            workSheet.Cells[1, 9].Value = "کارمزد کارگزار";

            workSheet.Cells[1, 10].Value = "Tax";
            workSheet.Cells[1, 11].Value = "Intrest";
            workSheet.Cells[1, 12].Value = "SettlementValue";
            workSheet.Cells[1, 13].Value = "SumAllFee";
            workSheet.Cells[1, 14].Value = "FundShare";
            workSheet.Cells[1, 15].Value = "CsdFee";
            workSheet.Cells[1, 16].Value = "TseTmcFee";
            workSheet.Cells[1, 17].Value = "RybFee";
            workSheet.Cells[1, 18].Value = "VatFee";
            workSheet.Cells[1, 19].Value = "LegFee";
            workSheet.Cells[1, 20].Value = "SeoAccessRight";
            workSheet.Cells[1, 20].Value = "BourseFee";
            workSheet.Cells[1, 20].Value = "Ticket";

            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename= فروش اوراق و واحد های صندوق های تحت بازارگردانی در تاریخ " + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
            }
        }



        [Authorize]
        public void ExportSymbolBeta()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();

            var lq = new LinqHelper();
            var data = lq.GetPortfolioBeta(fundId.ToValidMsgInt(), startDate.ToValidMsgInt(), endDate.ToValidMsgInt());

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.View.RightToLeft = true;

            workSheet.Cells[1, 1].LoadFromCollection(data, true);
            //workSheet.Cells[1, 1].Value = "نیم انحراف معیار";
            //workSheet.Cells[1, 2].Value = "انحراف معیار";
            //workSheet.Cells[1, 3].Value = "کوواریانس";
            workSheet.Cells[1, 1].Value = "نیم انحراف معیار ";
            workSheet.Cells[1, 2].Value = "انحراف معیار ";
            workSheet.Cells[1, 3].Value = "کوواریانس";
            workSheet.Cells[1, 4].Value = "بتا";


            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=ضریب بتا " + getFundName(fundId.ToString()) + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }


        [Authorize]
        public void ExportPotfolioSTDEV()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();
            var lq = new LinqHelper();
            var data = lq.CalculatePortfolioTrackingError(fundId.ToValidMsgInt(), startDate.ToValidMsgInt(), endDate.ToValidMsgInt()).ToList();
            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].LoadFromCollection(data, true);
            workSheet.Cells[1, 1].Value = "خطای ردیابی";
            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=خطای ردیابی " + getFundName(fundId.ToString()) + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);
                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }



        [Authorize]
        public void ExportSymbolSTDEV()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var SymbolId = Request.QueryString.GetValues("SymbolId").FirstOrDefault();
            var lq = new LinqHelper();
            var data = lq.CalculateSymbolTrackingError(SymbolId.ToValidMsgInt(), startDate.ToValidMsgInt(), endDate.ToValidMsgInt()).ToList();
            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].LoadFromCollection(data, true);
            workSheet.Cells[1, 1].Value = "خطای ردیابی";
            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=خطای ردیابی نماد" + SymbolId + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);
                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }







        [Authorize]
        public void ExportPerformanceEvaluation()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();
            var Percent = Request.QueryString.GetValues("Percent").FirstOrDefault();

            var lq = new LinqHelper();
            var data = lq.CalculatePortfolioPerformanceEvaluation(fundId.ToValidMsgInt(), startDate.ToValidMsgInt(), endDate.ToValidMsgInt(), Percent.ToValidMsgdouble()).ToList();


            var data1 = data.Select(s => new
            {
                IndexVAR = s.IndexVAR,
                PortVAR = s.PortVAR,
                IndexSTDEV = s.IndexSTDEV,
                PortSTDEV = s.PortSTDEV,
                PortHalfSTDEV = s.PortHalfSTDEV,
                COV = s.COV,
                Beta = s.Beta,
                NoneRiskRate = s.NoneRiskRate,
                PortfolioTotalYield = s.PortfolioTotalYield,
                IndexTotalYield = s.IndexTotalYield,
                CAPMYield = s.CAPMYield,
            }).ToList(); ;

            var data2 = data.Select(s => new
            {
                Trainer = s.Trainer,
                Sharp = s.Sharp,
                Sortino = s.Sortino,
                Jensen = s.Jensen
            }).ToList(); ;


            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("ورودی نسبت ها");
            workSheet.View.RightToLeft = true;

            workSheet.Cells[1, 1].LoadFromCollection(data1, true);
            //workSheet.Cells[1, 1].Value = "نیم انحراف معیار";
            //workSheet.Cells[1, 2].Value = "انحراف معیار";
            //workSheet.Cells[1, 3].Value = "کوواریانس";
            workSheet.Cells[1, 1].Value = "واریانس شاخص";
            workSheet.Cells[1, 2].Value = "واریانس پرتفوی";
            workSheet.Cells[1, 3].Value = "انحراف معیار شاخص";
            workSheet.Cells[1, 4].Value = "انحراف معیار پرتفوی";
            workSheet.Cells[1, 5].Value = "نیم انحراف معیار پرتفوی";
            workSheet.Cells[1, 6].Value = "کوواریانس";
            workSheet.Cells[1, 7].Value = "بتا";
            //workSheet.Cells[1, 8].Value = "نرخ بدون ریسک";
            workSheet.Cells[1, 8].Value = "نرخ بدون ریسک برای دوره مورد نظر";
            workSheet.Cells[1, 9].Value = "بازدهی کل دوره صندوق";
            workSheet.Cells[1, 10].Value = "بازدهی کل دوره شاخص ";
            workSheet.Cells[1, 11].Value = "بازدهی با CAPM";


            var workSheet2 = excel.Workbook.Worksheets.Add("نسبتها");
            workSheet2.View.RightToLeft = true;
            workSheet2.Cells[1, 1].LoadFromCollection(data2, true);
            workSheet2.Cells[1, 1].Value = "نسبت ترینر";
            workSheet2.Cells[1, 2].Value = "نسبت شارپ";
            workSheet2.Cells[1, 3].Value = "نسبت سورتینو";
            workSheet2.Cells[1, 4].Value = "معیار جنسن";







            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=ارزیابی عملکرد پرتفوی " + getFundName(fundId.ToString()) + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }


        [Authorize]
        public void ExportSymbolPerformanceEvaluation()
        {
            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var SymbolId = Request.QueryString.GetValues("SymbolId").FirstOrDefault();
            var Percent = Request.QueryString.GetValues("Percent").FirstOrDefault();

            var lq = new LinqHelper();
            var data = lq.CalculateSymbolPerformanceEvaluation(SymbolId.ToValidMsgInt(), startDate.ToValidMsgInt(), endDate.ToValidMsgInt(), Percent.ToValidMsgdouble()).ToList();

            var data1 = data.Select(s => new
            {
                IndexVAR = s.IndexVAR,
                PortVAR = s.PortVAR,
                IndexSTDEV = s.IndexSTDEV,
                PortSTDEV = s.PortSTDEV,
                PortHalfSTDEV = s.PortHalfSTDEV,
                COV = s.COV,
                Beta = s.Beta,
                NoneRiskRate = s.NoneRiskRate,
                PortfolioTotalYield = s.PortfolioTotalYield,
                IndexTotalYield = s.IndexTotalYield,
                CAPMYield = s.CAPMYield,
            }).ToList(); ;

            var data2 = data.Select(s => new
            {
                Trainer = s.Trainer,
                Sharp = s.Sharp,
                Sortino = s.Sortino,
                Jensen = s.Jensen
            }).ToList(); ;

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("ورودی نسبت ها");
            workSheet.View.RightToLeft = true;

            workSheet.Cells[1, 1].LoadFromCollection(data1, true);
            //workSheet.Cells[1, 1].Value = "نیم انحراف معیار";
            //workSheet.Cells[1, 2].Value = "انحراف معیار";
            //workSheet.Cells[1, 3].Value = "کوواریانس";
            workSheet.Cells[1, 1].Value = "واریانس شاخص";
            workSheet.Cells[1, 2].Value = "واریانس نماد";
            workSheet.Cells[1, 3].Value = "انحراف معیار شاخص";
            workSheet.Cells[1, 4].Value = "انحراف معیار نماد";
            workSheet.Cells[1, 5].Value = "نیم انحراف معیار نماد";
            workSheet.Cells[1, 6].Value = "کوواریانس";
            workSheet.Cells[1, 7].Value = "بتا";
            //workSheet.Cells[1, 8].Value = "نرخ بدون ریسک";
            workSheet.Cells[1, 8].Value = "نرخ بدون ریسک برای دوره مورد نظر";
            workSheet.Cells[1, 9].Value = "بازدهی کل دوره صندوق";
            workSheet.Cells[1, 10].Value = "بازدهی کل دوره شاخص ";
            workSheet.Cells[1, 11].Value = "بازدهی با CAPM";

            var workSheet2 = excel.Workbook.Worksheets.Add("نسبتها");
            workSheet2.View.RightToLeft = true;
            workSheet2.Cells[1, 1].LoadFromCollection(data2, true);
            workSheet2.Cells[1, 1].Value = "نسبت ترینر";
            workSheet2.Cells[1, 2].Value = "نسبت شارپ";
            workSheet2.Cells[1, 3].Value = "نسبت سورتینو";
            workSheet2.Cells[1, 4].Value = "معیار جنسن";

            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=ارزیابی عملکرد نماد" + SymbolId + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }








        [Authorize]
        public void ExportAccountingSells()
        {
            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var symbol = Request.QueryString.GetValues("symbol").FirstOrDefault();
            var account = Request.QueryString.GetValues("account").FirstOrDefault();
            List<GetAccountingSells_Result> data = new List<GetAccountingSells_Result>();

            var lq = new LinqHelper();
            data = lq.GetAccountingSells(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), symbol.ToValidMsgString(), account.ToValidMsgString()).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].LoadFromCollection(data, true);

            workSheet.Cells[1, 1].Value = "رديف";
            workSheet.Cells[1, 2].Value = "تاريخ سند";
            workSheet.Cells[1, 3].Value = "شماره فرعي";
            workSheet.Cells[1, 4].Value = "شرح سند";
            workSheet.Cells[1, 5].Value = "رديف قلم";
            workSheet.Cells[1, 6].Value = "كدمعين";
            workSheet.Cells[1, 7].Value = "كدسطح4";
            workSheet.Cells[1, 8].Value = "كدسطح5";
            workSheet.Cells[1, 9].Value = "كدسطح6";
            workSheet.Cells[1, 10].Value = "شرح قلم";
            workSheet.Cells[1, 11].Value = "بدهكار";
            workSheet.Cells[1, 12].Value = "بستانكار";
            workSheet.Cells[1, 13].Value = "مبلغ ارز";
            workSheet.Cells[1, 14].Value = "نرخ ارز";
            workSheet.Cells[1, 15].Value = "ارز";
            workSheet.Cells[1, 16].Value = "ارزمبنا";
            workSheet.Cells[1, 17].Value = "نرخ تبديل ارز";
            workSheet.Cells[1, 18].Value = "شماره پيگيري";


            using (var memoryStream = new MemoryStream())
            {

                ////Write to file
                //var filename = @"REPORT_" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx";
                //var path = @"C:\temp\" + filename + ";";
                //memoryStream = File.Create(path);
                //memoryStream.Write(data, 0, data.Length);
                //memoryStream.Close();


                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename= سند فروش اوراق و واحد های صندوق های تحت بازارگردانی در تاریخ " + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);


                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
            }

        }

        [Authorize]
        public void ExportSellsAccounting()
        {
            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            List<GetSellsAccounting_Result> data = new List<GetSellsAccounting_Result>();

            var lq = new LinqHelper();
            data = lq.GetSellsAccounting(startDate.ToValidMsgDate(), endDate.ToValidMsgDate()).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].LoadFromCollection(data, true);

            workSheet.Cells[1, 1].Value = "رديف";
            workSheet.Cells[1, 2].Value = "تاريخ سند";
            workSheet.Cells[1, 3].Value = "شماره فرعي";
            workSheet.Cells[1, 4].Value = "شرح سند";
            workSheet.Cells[1, 5].Value = "رديف قلم";
            workSheet.Cells[1, 6].Value = "كدمعين";
            workSheet.Cells[1, 7].Value = "كدسطح4";
            workSheet.Cells[1, 8].Value = "كدسطح5";
            workSheet.Cells[1, 9].Value = "كدسطح6";
            workSheet.Cells[1, 10].Value = "شرح قلم";
            workSheet.Cells[1, 11].Value = "بدهكار";
            workSheet.Cells[1, 12].Value = "بستانكار";
            workSheet.Cells[1, 13].Value = "مبلغ ارز";
            workSheet.Cells[1, 14].Value = "نرخ ارز";
            workSheet.Cells[1, 15].Value = "ارز";
            workSheet.Cells[1, 16].Value = "ارزمبنا";
            workSheet.Cells[1, 17].Value = "نرخ تبديل ارز";
            workSheet.Cells[1, 18].Value = "شماره پيگيري";


            using (var memoryStream = new MemoryStream())
            {

                ////Write to file
                //var filename = @"REPORT_" + DateTime.Now.ToString("dd-MM-yyyy_hh-mm-ss") + ".xlsx";
                //var path = @"C:\temp\" + filename + ";";
                //memoryStream = File.Create(path);
                //memoryStream.Write(data, 0, data.Length);
                //memoryStream.Close();


                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=SellsAccounting" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);


                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
            }

        }


        [Authorize]
        public void ExportIOFlows()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            //List<GetInputOutputFlows_Result> data = new List<GetInputOutputFlows_Result>();
            var lq = new LinqHelper();
            var data = lq.GetInputOutputFlows(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)FlowTypes.All).Select(item => new InputOutputFlows
            {
                AffectDate = item.AffectDate,
                InputDeposit = item.InputDeposit,
                InputBondProfit = item.InputBondProfit,
                InputFundProfit = item.InputFundProfit,
                InputStockProfit = item.InputStockProfit,
                InputInvestmentSell = item.InputInvestmentSell,
                InputCapitalIncrease = item.InputCapitalIncrease,
                InputFundSell = item.InputFundSell,
                InputBondInput = item.InputBondInput,
                InputMarketMakingFee = item.InputMarketMakingFee,
                InputAcceptanceFee = item.InputAcceptanceFee,
                InputInitialCapital = item.InputInitialCapital,
                InputAdviceFee = item.InputAdviceFee,
                InputOtherIncome = item.InputOtherIncome,
                OutputDeposit = item.OutputDeposit,
                OutputInvestmentSellOverhead = item.OutputInvestmentSellOverhead,
                OutputInterestOverhead = item.OutputInterestOverhead,
                OutputInitialCapital = item.OutputInitialCapital,
                OutputStockAcceptance = item.OutputStockAcceptance,
                OutputBondOutput = item.OutputBondOutput,
                OutputProfitSharing = item.OutputProfitSharing,
                OutputOutputCost = item.OutputOutputCost,
                OutputTaxAndInsurance = item.OutputTaxAndInsurance,
                OutputFundBuy = item.OutputFundBuy,
                TotalInput = item.TotalInput,
                TotalOutput = item.TotalOutput,
                NetInputOutput = item.NetInputOutput,
                NetAcc = item.NetAcc,

            }).ToList();
            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.Cells[1, 1].LoadFromCollection(data, true);

            workSheet.Cells[1, 1].Value = "تاریخ";
            workSheet.Cells[1, 2].Value = "سپرده";
            workSheet.Cells[1, 3].Value = "درآمد بهره ای ناشی از اوراق تحت مالکیت-انتشار اوراق";
            workSheet.Cells[1, 4].Value = "درآمد ناشی از صندوقهای سرمایه گذاری";
            workSheet.Cells[1, 5].Value = "درآمد ناشی از سهام	";
            workSheet.Cells[1, 6].Value = "فروش سرمایه گذاری ها	";
            workSheet.Cells[1, 7].Value = "افزایش سرمایه";
            workSheet.Cells[1, 8].Value = "ابطال یا فروش	";
            workSheet.Cells[1, 9].Value = "جریان ورودی اوراق	";
            workSheet.Cells[1, 10].Value = "کارمزد بازارگردانی	";
            workSheet.Cells[1, 11].Value = "کارمزد پذیره نویسی	";
            workSheet.Cells[1, 12].Value = "تنخواه";
            workSheet.Cells[1, 13].Value = "درآمد ناشی از مشاوره	";
            workSheet.Cells[1, 14].Value = "درآمد ناشی از خدمات دیگر	";


            workSheet.Cells[1, 15].Value = "سپرده";
            workSheet.Cells[1, 16].Value = "سرک قراردادهای تعهدی فروش اوراق	";
            workSheet.Cells[1, 17].Value = "هزینه بهره	";
            workSheet.Cells[1, 18].Value = "تنخواه";
            workSheet.Cells[1, 19].Value = "پذیره نویسی سهام	";
            workSheet.Cells[1, 20].Value = "جریان خروجی اوراق	";
            workSheet.Cells[1, 21].Value = "تقسیم سود	";
            workSheet.Cells[1, 22].Value = "وجوه نقد خروجی ناشی از اتفاقات غیر قابل پیش بینی	";
            workSheet.Cells[1, 23].Value = "مالیات، بیمه و هزینه	";
            workSheet.Cells[1, 24].Value = "صدور یا خرید";
            workSheet.Cells[1, 25].Value = "جمع ورودی	";
            workSheet.Cells[1, 26].Value = "جمع خروجی 	";
            workSheet.Cells[1, 27].Value = "خالص وجه نقد	";
            workSheet.Cells[1, 28].Value = "وجه نقد فعلی";


            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=IOFlows" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }




        [Authorize]
        public void ExportFundTrades()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var FundId = Request.QueryString.GetValues("FundId").FirstOrDefault();
            var Group = Request.QueryString.GetValues("Group").FirstOrDefault();
            //List<GetInputOutputFlows_Result> data = new List<GetInputOutputFlows_Result>();
            var lq = new LinqHelper();
            var data = lq.GetSumFundTrades(FundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), Group.ToValidMsgInt(), 0).Select(item => new
            {
                Instrument = item.Instrument,
                ChangesCount = item.ChangesCount,
                SumPrice = item.SumPrice,
                Average = item.Average,
                //simpleAverage = item.simpleAverage,
                //State = item.State,
                _PDate = item.PDate,
            }).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.View.RightToLeft = true;

            workSheet.Cells[1, 1].LoadFromCollection(data, true);

            workSheet.Cells[1, 1].Value = "نماد";
            workSheet.Cells[1, 2].Value = "تعداد";
            workSheet.Cells[1, 3].Value = "ارزش";
            workSheet.Cells[1, 4].Value = "قیمت";
            //workSheet.Cells[1, 5].Value = "میانگین ساده 	";
            workSheet.Cells[1, 5].Value = "تاریخ	";




            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=FundTrades" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }



        [Authorize]
        public void ExportDebtBonds()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            //List<GetInputOutputFlows_Result> data = new List<GetInputOutputFlows_Result>();
            var lq = new LinqHelper();
            var data = lq.GetDebtBondswithClosing().Where(c => c.StartDate >= startDate.ToValidMsgDate() && c.StartDate <= endDate.ToValidMsgDate())
                        .OrderBy(c => c.StartDate).Select(item => new
                        {
                            Instrument = item.Symbol,
                            ChangesCount = item.Num,
                            SumPrice = item.StartDate,
                            Average = item.EndDate,
                            simpleAverage = item.ClosingPrice,

                            //State = item.State,
                        }).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.View.RightToLeft = true;

            workSheet.Cells[1, 1].LoadFromCollection(data, true);

            workSheet.Cells[1, 1].Value = "نماد";
            workSheet.Cells[1, 2].Value = "تعداد";
            workSheet.Cells[1, 3].Value = "تاریخ شروع";
            workSheet.Cells[1, 4].Value = "تاریخ پایان";
            workSheet.Cells[1, 5].Value = "قیمت پایانی";




            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=DebtBonds" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }







        [Authorize]
        public void ExportSymbolAssets()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var FundId = Request.QueryString.GetValues("FundId").FirstOrDefault();
            //List<GetInputOutputFlows_Result> data = new List<GetInputOutputFlows_Result>();
            var Symbol = Request.QueryString.GetValues("Symbol").FirstOrDefault();

            var lq = new LinqHelper();

            var result = lq.GetFundPortfolioSymbolAssets(startDate.ToValidMsgDate()
                                                                  , endDate.ToValidMsgDate()
                                                                  , FundId.ToValidMsgInt()
                                                                  , Symbol).Select(item => new
                                                                  {
                                                                      PDate = item.PDate,
                                                                      Instrument = item.Instrument,
                                                                      Count = item.Count,
                                                                      SymbolNAdjPrice = item.SymbolNAdjPrice,
                                                                      Value = item.Value,

                                                                      //State = item.State,
                                                                  }).ToList();



            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.View.RightToLeft = true;

            workSheet.Cells[1, 1].LoadFromCollection(result, true);

            workSheet.Cells[1, 1].Value = "تاریخ";
            workSheet.Cells[1, 2].Value = "نماد";
            workSheet.Cells[1, 3].Value = "تعداد";
            workSheet.Cells[1, 4].Value = "قیمت";
            workSheet.Cells[1, 5].Value = "ارزش";

            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=SymbolAssets" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }




        [Authorize]
        public void ExportFundTradesBuy()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var FundId = Request.QueryString.GetValues("FundId").FirstOrDefault();
            //List<GetInputOutputFlows_Result> data = new List<GetInputOutputFlows_Result>();
            var lq = new LinqHelper();
            var data = lq.GetSumFundTradesBuy(FundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate()).Select(item => new
            {
                Instrument = item.Instrument,
                ChangesCount = item.ChangesCount,
                SumPrice = item.SumPrice,
                Average = item.Average,
                //simpleAverage = item.simpleAverage,

                //State = item.State,
                _PDate = item.PDate,
            }).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.View.RightToLeft = true;

            workSheet.Cells[1, 1].LoadFromCollection(data, true);

            workSheet.Cells[1, 1].Value = "نماد";
            workSheet.Cells[1, 2].Value = "تعداد";
            workSheet.Cells[1, 3].Value = "ارزش";
            workSheet.Cells[1, 4].Value = "قیمت";
            //workSheet.Cells[1, 5].Value = "میانگین ساده 	";
            workSheet.Cells[1, 5].Value = "تاریخ	";


            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=FundTradesBuy" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }




        [Authorize]
        public void ExportFundTradesDetail()
        {

            var FundId = Request.QueryString.GetValues("FundId").FirstOrDefault();
            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var chType = Request.QueryString.GetValues("chType").FirstOrDefault();
            var group = Request.QueryString.GetValues("group").FirstOrDefault();

            var lq = new LinqHelper();
            var data = lq.GetSumFundTrades(FundId.ToValidMsgId(),
                                                   startDate.ToValidMsgDate(),
                                                   endDate.ToValidMsgDate()
                                                   , group.ToValidMsgInt(), chType.ToValidMsgInt()).Select(item => new
                                                   {
                                                       Instrument = item.Instrument,
                                                       ChangesCount = item.ChangesCount,
                                                       SumPrice = item.SumPrice,
                                                       Average = item.Average,
                                                       State = item.State,
                                                       PDate = item._PDate,
                                                       SumTax = item.SumTax,
                                                       SumTotalFee = item.SumTotalFee,
                                                       SumBrokerFee = item.SumBrokerFee,
                                                       BrokerName = item.BrokerName
                                                   }).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.View.RightToLeft = true;

            workSheet.Cells[1, 1].LoadFromCollection(data, true);

            workSheet.Cells[1, 1].Value = "نماد";
            workSheet.Cells[1, 2].Value = "تعداد";
            workSheet.Cells[1, 3].Value = "ارزش";
            workSheet.Cells[1, 4].Value = "قیمت میانگین";
            workSheet.Cells[1, 5].Value = "وضعیت";
            workSheet.Cells[1, 6].Value = "تاریخ";
            workSheet.Cells[1, 7].Value = "مالیات";
            workSheet.Cells[1, 8].Value = "کارمزد کل ";
            workSheet.Cells[1, 9].Value = "کارمزد کارگزاری";
            workSheet.Cells[1, 10].Value = "کارگزاری";


            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                 Response.AddHeader("content-disposition", "attachment;  filename=معاملات   "+ getFundName(FundId) + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");




                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }



        private string getFundName(string FundId)
        {


            var FundName = "";
            switch (FundId)
            {
                case "1":
                    FundName = "صندوق سرمايه گذاري لوتوس پارسيان";
                    break;
                case "2":
                    FundName = "صندوق سرمايه گذاري با درآمد ثابت و با پيش بيني سود پيروزان";
                    break;
                case "3":
                    FundName = "صندوق سرمايه گذاري نيکوکاري لوتوس رويان";
                    break;
                case "4":
                    FundName = "صندوق سرمايه گذاري زرين پارسيان";
                    break;
                case "5":
                    FundName = "صندوق سرمايه گذاري نيکوکاري دانشگاه الزهرا";
                    break;
                case "6":
                    FundName = "صندوق سرمایه گذاری پشتوانه طلای لوتوس";
                    break;
                case "7":
                    FundName = "صندوق سرمايه گذاري قابل معامله اعتمادآفرين پارسيان";
                    break;
                case "8":
                    FundName = "صندوق سرمايه گذاري قابل معامله ثروت آفرين پارسيان";
                    break;
                case "9":
                    FundName = "صندوق سرمايه گذاري اختصاصی بازارگردانی اميد لوتوس پارسيان";
                    break;
                default:
                    break;
            }

            return FundName;

        }






        [Authorize]
        public void ExportRiskPortfolio()
        {

            var fundId = Request.QueryString.GetValues("fundId").FirstOrDefault();
            var Date = Request.QueryString.GetValues("Date").FirstOrDefault();
          

            var lq = new LinqHelper();
            var res = lq.GetLastFundPortfoliosByDate(fundId.TryParseInt32(), Date.ToValidMsgDate()).ToList();

            foreach (var Item in res)
            {
                if (Item.IsRight == true)
                    Item.Instrument = Item.Instrument + " (تقدم)";

            }








            var data= res.Select(item => new
                                                   {
                                                       Instrument = item.Instrument,
                Date = item.PDate,
                Count = item.Count,
                Price = item.Price,
                MarketValue = item.MarketValue,
                Weight = item.Weight,
                Ownership = item.Ownership/100
            }).ToList();



          


            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.View.RightToLeft = true;

            workSheet.Cells[1, 1].LoadFromCollection(data, true);

            workSheet.Cells[1, 1].Value = "نماد";
            workSheet.Cells[1, 2].Value = "تاریخ";
            workSheet.Cells[1, 3].Value = "تعداد";
            workSheet.Cells[1, 4].Value = "قیمت";
            workSheet.Cells[1, 5].Value = "ارزش";
            workSheet.Cells[1, 6].Value = "وزن";
            workSheet.Cells[1, 7].Value = "مالکیت";


 

            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=پرتفوی " + getFundName(fundId) + Assistant.TodayDateInt() + "(" + Date +  ").xlsx");




                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }



















        [Authorize]
        public void ExportFundTradesSell()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var FundId = Request.QueryString.GetValues("FundId").FirstOrDefault();
            //List<GetInputOutputFlows_Result> data = new List<GetInputOutputFlows_Result>();
            var lq = new LinqHelper();
            var data = lq.GetSumFundTradesSell(FundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate()).Select(item => new
            {
                Instrument = item.Instrument,
                ChangesCount = item.ChangesCount,
                SumPrice = item.SumPrice,
                Average = item.Average,
                //simpleAverage = item.simpleAverage,
                //State = item.State,
                _PDate = item.PDate,
            }).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.View.RightToLeft = true;

            workSheet.Cells[1, 1].LoadFromCollection(data, true);

            workSheet.Cells[1, 1].Value = "نماد";
            workSheet.Cells[1, 2].Value = "تعداد";
            workSheet.Cells[1, 3].Value = "ارزش";
            workSheet.Cells[1, 4].Value = "قیمت";
            //workSheet.Cells[1, 5].Value = "میانگین ساده 	";
            workSheet.Cells[1, 5].Value = "تاریخ	";


            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=FundTradesSell" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }







        [Authorize]
        public void FundProfits()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var FundId = Request.QueryString.GetValues("FundId").FirstOrDefault();
            //List<GetInputOutputFlows_Result> data = new List<GetInputOutputFlows_Result>();
            var lq = new LinqHelper();
            var data = lq.GetFundProfits(FundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate()).Select(item => new
            {
                PDate = item.PDate,
                PROFIT_ID = item.PROFIT_ID,
                SHARE_PROFIT = item.SHARE_PROFIT,
                SHARE_COUNT = item.SHARE_COUNT,
                RECEIPT_DATE = item.RECEIPT_DATE,
                COMMENTS = item.COMMENTS

                //State = item.State,
            }).ToList();

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.View.RightToLeft = true;

            workSheet.Cells[1, 1].LoadFromCollection(data, true);
            workSheet.Cells[1, 1].Value = "تاریخ";
            workSheet.Cells[1, 2].Value = "شماره سود";
            workSheet.Cells[1, 3].Value = "میزان سود  ";
            workSheet.Cells[1, 4].Value = "تعداد";
            workSheet.Cells[1, 5].Value = "تاریخ وصول 	";
            workSheet.Cells[1, 6].Value = "توضیح	";
            workSheet.Cells[1, 7].Value = "تاریخ سند	";




            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=FundProfits" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }

















        [Authorize]
        public void ExportFundIOFlows()
        {

            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            //List<GetInputOutputFlows_Result> data = new List<GetInputOutputFlows_Result>();
            var lq = new LinqHelper();
            var data = lq.GetFundsInputOutputFlows(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)FlowTypes.All, 1).Select(item => new FundInputOutputFlows
            {
                AffectDate = item.AffectDate,
                InCashInput = item.InCashInput,
                InReInvestmentProfit = item.InReInvestmentProfit,
                InReInvestmentBondsProfit = item.InReInvestmentBondsProfit,
                InBondsProfit = item.InBondsProfit,
                InStocksProfit = item.InStocksProfit,
                InBondsSell = item.InBondsSell,
                InBondsMaturity = item.InBondsMaturity,
                InStocksSell = item.InStocksSell,
                InClosingDepositSpecificFlows = item.InClosingDepositSpecificFlows,
                InIssuingFee = item.InIssuingFee,
                InRevocationFee = item.InRevocationFee,
                InCashFlowIssuance = item.InCashFlowIssuance,
                OutStocksBuy = item.OutStocksBuy,
                OutReInvestmentBondsBuy = item.OutReInvestmentBondsBuy,
                OutBondsBut = item.OutBondsBut,
                OutCreatingDepositSpecificFlows = item.OutCreatingDepositSpecificFlows,
                OutProfitPay = item.OutProfitPay,
                OutPillarsFee = item.OutPillarsFee,
                OutAuditorCost = item.OutAuditorCost,
                OutSoftwareCost = item.OutSoftwareCost,
                OutCommunityCost = item.OutCommunityCost,
                OutRevocationFundUnit = item.OutRevocationFundUnit,
                TotalInput = item.TotalInput,
                TotalOutput = item.TotalOutput,
                NetInputOutput = item.NetInputOutput,
                NetAcc = item.NetAcc,



            }).ToList();
            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.Cells[1, 1].LoadFromCollection(data, true);

            workSheet.Cells[1, 1].Value = "تاریخ";
            workSheet.Cells[1, 2].Value = "سود سپرده";
            workSheet.Cells[1, 3].Value = "سود سرمایه گذاری مجدد";
            workSheet.Cells[1, 4].Value = "سود اوراق سرمایه گذاری مجدد";
            workSheet.Cells[1, 5].Value = "سود اوراق";
            workSheet.Cells[1, 6].Value = "سود سهام";
            workSheet.Cells[1, 7].Value = "فروش اوراق";
            workSheet.Cells[1, 8].Value = "سررسید اوراق";
            workSheet.Cells[1, 9].Value = "فروش سهام";
            workSheet.Cells[1, 10].Value = "بستن سپرده ناشی از جریانات خاص";
            workSheet.Cells[1, 11].Value = "کارمزد صدور";
            workSheet.Cells[1, 12].Value = "کارمزد ابطال";
            workSheet.Cells[1, 13].Value = "وجه نقد ورودی ناشی از صدور واحد	";


            workSheet.Cells[1, 14].Value = "خرید سهام";
            workSheet.Cells[1, 15].Value = "خرید اوراق سرمایه گذاری مجدد";
            workSheet.Cells[1, 16].Value = "خرید اوراق";
            workSheet.Cells[1, 17].Value = "ایجاد سپرده ناشی از جریانات خاص";
            workSheet.Cells[1, 18].Value = "پرداخت سود";
            workSheet.Cells[1, 19].Value = "کارمزد ارکان";
            workSheet.Cells[1, 20].Value = "حق الزحمه حسابرس";
            workSheet.Cells[1, 21].Value = "هزینه نرم افزار";
            workSheet.Cells[1, 22].Value = "هزینه مجامع";
            workSheet.Cells[1, 23].Value = "ابطال واحد صندوق";
            workSheet.Cells[1, 24].Value = "جمع ورودی	";
            workSheet.Cells[1, 25].Value = "جمع خروجی 	";
            workSheet.Cells[1, 26].Value = "خالص وجه نقد	";
            workSheet.Cells[1, 27].Value = "وجه نقد فعلی";


            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=FundIOFlows" + Assistant.TodayDateInt() + "(" + startDate + "-" + endDate + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }
        }








        [Authorize]
        public void ExportDailyInterestsFile(string symbol)
        {
            List<GetSymbolDailyInterestBySymbol_Result> data = new List<GetSymbolDailyInterestBySymbol_Result>();
            var lq = new LinqHelper();
            data = lq.GetSymbolDailyInterest(symbol, 0);

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].LoadFromCollection(data, true);

            //workSheet.Cells[1, 1].Value = "رديف";
            //workSheet.Cells[1, 2].Value = "تارخ ميلادي";
            //workSheet.Cells[1, 3].Value = "تاريخ شمسي";
            //workSheet.Cells[1, 4].Value = "مقدار";

            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=SymbolDailyInterest-" + symbol + "-" + Assistant.TodayDateInt() + ".xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }

        }


        [Authorize]
        public void ExportCouponssFile(string symbol)
        {
            List<GetSymbolCouponBySymbolName_Result> data = new List<GetSymbolCouponBySymbolName_Result>();
            var lq = new LinqHelper();
            data = lq.GetSymbolCoupons(symbol, 0);

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].LoadFromCollection(data, true);

            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=SymbolCoupons-" + symbol + "-" + Assistant.TodayDateInt() + ".xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }

        }



        [Authorize]
        public void ExportChashFlowFile(string Isin, string symbol)
        {
            List<GetSymbolCashFlow_Result> data = new List<GetSymbolCashFlow_Result>();
            var lq = new LinqHelper();
            var Pdate = Assistant.TodayDateInt();
            data = lq.GetChashFlow(Isin, Pdate);

            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
            workSheet.View.RightToLeft = true;
            workSheet.Cells[1, 1].LoadFromCollection(data, true);

            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=SymbolChashFlow-" + symbol + "-" + Assistant.TodayDateInt() + ".xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }

        }

        [Authorize]
        public void ExportPortfolioFile()
        {
            int pid = -1;

            var sql = new LinqHelper();
            var objPortfolio = sql.GetPortfolio(Assistant.CurrentUser()).ToList();


            if (objPortfolio.Count > 0)
                pid = objPortfolio.FirstOrDefault().Id;


            var dataPortfolio = objPortfolio.Select(item => new
            {
                Title = item.Title,
                StartDate = item._StartDate,
                EndDate = item._EndDate,
                ManagerFee = item.ManagerFee,
                ReinvestmentRate = item.ReinvestmentRate,
                BankFeeFee = item.BankFee
            }).ToList();

            var dataPortfolioBonds = sql.GetPortfolioBonds(pid).Select(item => new
            {
                InsCode = item.InsCode,
                Symbol = item.Symbol,
                SymbolNumber = item._SymbolNumber,
                TotalAmount = item._TotalAmount,
                RateStart = item._RateStart,
                PeriodProfitStart = item._PeriodProfitStart,
                TotalPriceStart = item._TotalPriceStart,
                RateEnd = item._RateEnd,
                PeriodProfitEnd = item._PeriodProfitEnd,
                TotalPriceEnd = item._TotalPriceEnd,
                PeriodProfit = item._PeriodProfit,
                WeightBonds = item._WeightBonds,
                EfficiencyWeighing = item._EfficiencyWeighing
            }).ToList();

            var dataPortfolioDeposits = sql.GetPortfolioDeposits(pid).Select(item => new
            {
                InsCode = item.Title,
                Symbol = item._ProfitRate,
                SymbolNumber = item._Amount,
                TotalAmount = item._DepositWeight,
                RateStart = item._EfficiencyWeighing
            }).ToList();
            //-------------------------------------------------------
            ExcelPackage excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add("سبد");
            workSheet.Cells[1, 1].LoadFromCollection(dataPortfolio, true);

            workSheet.Cells[1, 1].Value = "عنوان سبد";
            workSheet.Cells[1, 2].Value = "تاریخ شروع دوره";
            workSheet.Cells[1, 3].Value = "پایان دوره";
            workSheet.Cells[1, 4].Value = " کارمزد مدیر";
            workSheet.Cells[1, 5].Value = "نرخ سرمایه گذاری	";
            workSheet.Cells[1, 6].Value = "کارمزد ضمانت بانک	";
            //-------------------------------------------------------
            var workSheet1 = excel.Workbook.Worksheets.Add("اوراق بدهی");
            workSheet1.Cells[1, 1].LoadFromCollection(dataPortfolioBonds, true);

            workSheet1.Cells[1, 1].Value = "ISIN";
            workSheet1.Cells[1, 2].Value = "نماد";
            workSheet1.Cells[1, 3].Value = "تعداد";
            workSheet1.Cells[1, 4].Value = "مبلغ کل";
            workSheet1.Cells[1, 5].Value = "نرخ ابتدا";
            workSheet1.Cells[1, 6].Value = " سود دوره ";
            workSheet1.Cells[1, 7].Value = "بهای کل ابتدا	";
            workSheet1.Cells[1, 8].Value = "نرخ انتها	";
            workSheet1.Cells[1, 9].Value = "سود دوره	";
            workSheet1.Cells[1, 10].Value = "بهای انتها	";
            workSheet1.Cells[1, 11].Value = "سود دوره کل	";
            workSheet1.Cells[1, 12].Value = "وزن اوراق	";
            workSheet1.Cells[1, 13].Value = "بازدهی وزنی	";

            //------------------------------------------------------
            var workSheet2 = excel.Workbook.Worksheets.Add("سپرده های بانکی");
            workSheet2.Cells[1, 1].LoadFromCollection(dataPortfolioDeposits, true);

            workSheet2.Cells[1, 1].Value = "عنوان";
            workSheet2.Cells[1, 2].Value = "نرخ سود";
            workSheet2.Cells[1, 3].Value = "مبلغ";
            workSheet2.Cells[1, 4].Value = "وزن سپرده";
            workSheet2.Cells[1, 5].Value = "بازدهی وزنی";


            //------------------------------------------------------

            using (var memoryStream = new MemoryStream())
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //here i have set filname as Students.xlsx
                Response.AddHeader("content-disposition", "attachment;  filename=portfolio - " + Assistant.TodayDateInt() + ").xlsx");
                excel.SaveAs(memoryStream);

                memoryStream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
                Response.Clear();
            }

        }

    }
}