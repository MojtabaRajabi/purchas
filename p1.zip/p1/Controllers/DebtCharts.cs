﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Web.Security;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dic;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Models;
using Sanay.Library.Utility;
using System.IO;
using System.Data;
using ExcelDataReader;


namespace Sanay.Lotus.Erm.Controllers
{
    public class DebtChartsController : Controller
    {

       
        // GET: AccountingCode
        [Authorize]

        public ActionResult Index( )
        {
            ViewBag.startDate = Assistant.Last3Months();
            ViewBag.endDate = Assistant.TodayDateBySlash();

            return View();
        }

       

        [HttpPost]
        public JsonResult LoadAvgMarket()
        {
            try
            {
                using (var sql = new LinqHelper())
                {

                   var result =
                   sql.GetAvgMarket(Assistant.TodayDateInt());
                   
                    return Json(result, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }
         

        [HttpPost]
        public JsonResult LoadAvgMarketLatest()
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result =
                    sql.GetSymbolHistoricYtmAvg( );
                    return Json(result, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult LoadNomAvgMarketLatest()
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result =
                    sql.GetSymbolHistoricNYtmAvg();
                    return Json(result, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        public JsonResult LoadWeekTradesChart( )
        {
            try
            {
                using (var sql = new LinqHelper())
                {

                    var result =
                    sql.GetWeekTrades(Assistant.ShamsiToMiladi(Assistant.Last3Months()),
                                      Assistant.ShamsiToMiladi(Assistant.TodayDateInt())).OrderBy(c => c.StartWeek);
                    var list = result.ToList()
                        .Select(x => new
                        {
                            YTM = x.SumYtmEfficiencyRhythmic,
                            NYTM = x.SumEfficiencyRhythmic,
                            weekDate = Assistant.MiladiToShamsiWithSlash((int)x.StartWeek)
                        }).ToList();
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }






    }
}