﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Mvc.Jsonp;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.Models;
using Sanay.Lotus.Erm.Lib.Enum;


namespace Sanay.Lotus.Erm.Controllers
{
    public class BuySellController : Controller
    {
        // GET: Positions
   
        [Authorize]
        public ActionResult Index(string Symbol, string Account,string StartDate,string EndDate)
        {
            if (Symbol==null) { ViewBag.Symbol = "همه"; } else {ViewBag.Symbol = Symbol;}
            if (Account == null) { ViewBag.Account = "همه";} else {ViewBag.Account = Account; }
            if (StartDate == null) { ViewBag.StartDate = Assistant.DateToDisplayMode(Assistant.YesterdayDateInt()); } else { ViewBag.StartDate = StartDate; };
            if (EndDate == null) { ViewBag.EndDate = Assistant.DateToDisplayMode(Assistant.YesterdayDateInt()); } else { ViewBag.EndDate = EndDate; }

            //ViewBag.pDate = Assistant.MiladiToShamsiWithSlash(Assistant.TodayDateIntMiladi());

            return View();
        }

        //---------------------------------------------------------------------



        [Authorize]
        public ActionResult InsertBuySell()
        {
            //if (Symbol == null) { ViewBag.Symbol = "همه"; } else { ViewBag.Symbol = Symbol; }
            //if (Account == null) { ViewBag.Account = "همه"; } else { ViewBag.Account = Account; }
            //if (StartDate == null) { ViewBag.StartDate = Assistant.DateToDisplayMode(Assistant.YesterdayDateInt()); } else { ViewBag.StartDate = StartDate; };
            //if (EndDate == null) { ViewBag.EndDate = Assistant.DateToDisplayMode(Assistant.YesterdayDateInt()); } else { ViewBag.EndDate = EndDate; }

            return View();
        }

    


        [Authorize]
        public ActionResult LoadData()
        {
            try
            { 

                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var symbol = Request.Form.GetValues("symbol").FirstOrDefault();
                var portType = Request.Form.GetValues("portType").FirstOrDefault();
                //var account = Request.Form.GetValues("account").FirstOrDefault();
                var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault();

                if (symbol == "همه") symbol = "%%";
               // if (account == "همه") account = "%%";


                using (var sql = new LinqHelper())
                {

                    var result = sql.GetBuySells(start.ToValidMsgInt(), length.ToValidMsgInt(), searchValue, (int)TradeType.All, symbol.ToValidMsgString(), "%%", startDate.ToValidMsgDate(), endDate.ToValidMsgDate());

                    int recordsTotal = 0;
                    if (result.Count > 0)
                        recordsTotal = result.FirstOrDefault().TotalRow ?? 0;

                    var recordsFiltered = recordsTotal;

                    //Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = result
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }





        [HttpGet]
        public JsonResult GetSymbols(string term)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    //var list = sql.GetBuySellsSymbol()
                    var list = sql.GetInstruments()
                        .Select(x => new
                        {
                            Id = x.InsCode,
                            Text = x.LVal18AFC
                        }).ToList();

                    //list.Add(new {Id = -1, Text = "همه"});
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }



        [HttpGet]
        public JsonResult GetAccounts(string term)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetBuySellsAccount()
                        .Select(x => new
                        {
                            Id = x.Id,
                            Text = x.Account
                        }).ToList();
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult GetBrokers(string term)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetBrokers()
                        .Select(x => new
                        {
                            Id = x.Id,
                            Text = x.BrokerCode
                        }).ToList();
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        public ActionResult RegisterBuySell(string OrderType,string Symbol, string Account,string BrokerCode,string Shares,string Price,string TradeDate,string Intrest,string SumAllFee,string BrokerFee)
        {
            using (var sql = new LinqHelper())
            {
                //obj.BuyTotal = obj.BuyTotal.Replace(",", "");
                //obj.BuyFee = obj.BuyFee.Replace(",", "");
                //obj.BuyInterest = obj.BuyInterest.Replace(",", "");
                //obj.BuyTotalAndFee = obj.BuyTotalAndFee.Replace(",", "");
                //obj.SellTotal = obj.SellTotal.Replace(",", "");
                //obj.SellFee = obj.SellFee.Replace(",", "");
                //obj.SellInterest = obj.SellInterest.Replace(",", "");
                //obj.SellTotalAndFee = obj.SellTotalAndFee.Replace(",", "");

                //sql.InsertBuySell(Symbol, Account, TradeDate.TryParseInt32(), Shares.ToValidMsgdecimal(), Price.ToValidMsgdecimal(), Intrest.ToValidMsgdecimal(), SumAllFee.ToValidMsgdecimal()
                //                                 , BrokerFee.ToValidMsgdecimal(), BrokerCode, OrderType.TryParseInt32());


                if (OrderType.TryParseInt32() == 1)
                {
                    sql.InsertOrderBuy(Symbol, Account, TradeDate.TryParseInt32(), Shares.ToValidMsgdecimal(), Price.ToValidMsgdecimal(), Intrest.ToValidMsgdecimal(), SumAllFee.ToValidMsgdecimal()
                        , BrokerFee.ToValidMsgdecimal(), BrokerCode
                        ,Assistant.TodayDateInt(), Assistant.TimeNowInt(), Assistant.CurrentUser()
                        );
                }

                if (OrderType.TryParseInt32() == -1)
                {
                    sql.InsertOrderSell(Symbol, Account, TradeDate.TryParseInt32(), Shares.ToValidMsgdecimal(), Price.ToValidMsgdecimal(), Intrest.ToValidMsgdecimal(), SumAllFee.ToValidMsgdecimal()
                        , BrokerFee.ToValidMsgdecimal(), BrokerCode
                         ,Assistant.TodayDateInt(), Assistant.TimeNowInt(), Assistant.CurrentUser()
                        );
                }



                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "AccountingCode" }, JsonRequestBehavior.AllowGet);
            }
        }




    }
}