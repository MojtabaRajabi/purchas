﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.DataAccess;

namespace Sanay.Lotus.Erm.Controllers
{
    [Authorize]
    public class DebtGroupSpreadController : Controller
    {
        // GET: DebtGroupSpread
        public ActionResult Index()
        {

            using (var sql = new LinqHelper())
            {
                var groupsName = sql.GetSymbolGroupsName().ToList();
                ViewBag.groupsName = groupsName;

                var symbolName = sql.GetNamesSymbols().ToList();
                ViewBag.symbolName = symbolName;
            }
            return View();
        }

        public ActionResult GetGroupSpreadData()
        {
            var date = Request.Form.GetValues("date").FirstOrDefault();
            using (var sql = new LinqHelper())
            {
                try
                {

                    var result = sql.GetSymbolGroupYtm(date.Replace(".", "").ToValidMsgDate()).ToList();
                    return Json(new { data = result }, behavior: JsonRequestBehavior.AllowGet);
                }
                catch (Exception ex)
                {
                    return Json(new { data = "" }, JsonRequestBehavior.AllowGet);
                }
            }

        }

        public ActionResult GetGroupSpreadDataChart(int groupId1, int groupId2)
        {

            using (var sql = new LinqHelper())
            {
                try
                {

                    var result = sql.GetSymbolGroupYtmHistorical(groupId1, groupId2).ToList().OrderByDescending(c => c.Pdate);
                    return Json(result, JsonRequestBehavior.AllowGet);

                }
                catch (Exception ex)
                {
                    return Json("", JsonRequestBehavior.AllowGet);
                }
            }

        }

        public ActionResult GetGroupSpreadSymbolDataChart(string isin1, string isin2)
        {

            using (var sql = new LinqHelper())
            {
                try
                {

                    var result = sql.GetSymbolYtmSpreadHistorical(isin1, isin2).ToList().OrderByDescending(c => c.Pdate);
                    return Json(result, JsonRequestBehavior.AllowGet);
                }
                catch (Exception ex)
                {
                    return Json("", JsonRequestBehavior.AllowGet);
                }
            }

        }

        [HttpPost]
        public ActionResult GetYtmTableSpreadWithItems(List<GetSymbolGroupYtm_Result> items)
        {
            string myString = "";
            try
            {
                if (items.Count > 0)
                {

                    myString+="<thead><th>ردیف</th>";

                    foreach (var item in items)
                    {
                        myString+=("<th  style='background-color: #08733b;color:#fdfdfd;'>" + item.Name + "</th>");
                    }

                    myString += "</thead> <tbody>";

                    foreach (var item in items)
                    {
                        myString += "<tr><td style='background-color: #08733b;color:#fdfdfd;'>" + item.Name + "</td>";
                        for (var i = 0; i < items.Count; i++)
                        {
                            var styletd = "";
                            var x = item.AvgYtm - items[i].AvgYtm;
                            styletd = items[i].Name == item.Name ? "background-color: beige;" : "";
                            myString+="<td style='" + styletd + " ;    direction: ltr;'>" + String.Format("{0:0.00}", x) + "</td>";
                        }
                        myString+="</tr>";
                    }
                    myString+="</tbody>";
                }

                return Json(myString.ToString() ,JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public ActionResult GetNomTableSpreadWithItems(List<GetSymbolGroupYtm_Result> items)
        {
            string myString = "";
            try
            {
                if (items.Count > 0)
                {

                    myString += "<thead><th>ردیف</th>";

                    foreach (var item in items)
                    {
                        myString += ("<th style='background-color: #08733b;color:#fdfdfd;'>" + item.Name + "</th>");
                    }

                    myString += "</thead> <tbody>";

                    foreach (var item in items)
                    {
                        myString += "<tr><td style='background-color: #08733b;color:#fdfdfd;'>" + item.Name + "</td>";
                        for (var i = 0; i < items.Count; i++)
                        {
                            var styletd = "";
                            var x = item.AvgNomYtm - items[i].AvgNomYtm;
                            styletd = items[i].Name == item.Name ? "background-color: beige;" : "";
                            myString += "<td style='" + styletd + " ;    direction: ltr;'>" + String.Format("{0:0.00}", x) + "</td>";
                        }
                        myString += "</tr>";
                    }
                    myString += "</tbody>";
                }

                return Json(myString.ToString(), JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }



    }
}