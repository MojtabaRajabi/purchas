﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using Sanay.Library.Utility;
using System.IO;
using System.Web.Mvc;
using System.Web.Services;
using Microsoft.Ajax.Utilities;
using Sanay.Library.DataAccess;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.Lib.Enum;
using Sanay.Lotus.Erm.Lib.Dto;
using OfficeOpenXml;

namespace Sanay.Lotus.Erm.Controllers
{
    [Authorize]
    public class DebtBoardController : Controller
    {
        // GET: DebtBoard

        public ActionResult Index()
        {
            using (var sql = new LinqHelper())
            {
                var result = sql.GetSymbolMarketMaker();
                ViewBag.MarketMaker = result;
            }

            return View();
        }

        public ActionResult Details()
        {
            ViewBag.startDate = Assistant.TodayDateBySlash();
            ViewBag.endDate = Assistant.Next2years();


            return View();
        }
        public ActionResult Details1()
        {
            ViewBag.startDate = Assistant.TodayDateBySlash();
            ViewBag.endDate = Assistant.Next2years();


            return View();
        }

        [HttpPost]
        public JsonResult GetSymbolByFilter()
        {
            //var draw = Request.Form.GetValues("draw").FirstOrDefault();
            //var start = Request.Form.GetValues("start").FirstOrDefault();
            //var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            //var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData-------------------------------------------

            var symbol = Request.Form.GetValues("symbol").FirstOrDefault();
            var name = Request.Form.GetValues("name").FirstOrDefault();
            var marketMaker = Request.Form.GetValues("marketMaker").FirstOrDefault();
            var promisor = Request.Form.GetValues("promisor").FirstOrDefault();
            var sponsor = Request.Form.GetValues("sponsor").FirstOrDefault();
            var publishDate = Request.Form.GetValues("publishDate").FirstOrDefault();
            var maturityDate = Request.Form.GetValues("maturityDate").FirstOrDefault();
            var rate = Request.Form.GetValues("rate").FirstOrDefault();
            var isin = Request.Form.GetValues("isin").FirstOrDefault();
            var chm1 = Request.Form.GetValues("chm1").FirstOrDefault();
            var chm2 = Request.Form.GetValues("chm2").FirstOrDefault();
            var chm3 = Request.Form.GetValues("chm3").FirstOrDefault();
            var chm4 = Request.Form.GetValues("chm4").FirstOrDefault();
            var chm5 = Request.Form.GetValues("chm5").FirstOrDefault();
            var chg1 = Request.Form.GetValues("chg1").FirstOrDefault();
            var chg2 = Request.Form.GetValues("chg2").FirstOrDefault();
            var chg3 = Request.Form.GetValues("chg3").FirstOrDefault();
            var chg4 = Request.Form.GetValues("chg4").FirstOrDefault();
            var chg5 = Request.Form.GetValues("chg5").FirstOrDefault();
            var chg6 = Request.Form.GetValues("chg6").FirstOrDefault();
            var chg7 = Request.Form.GetValues("chg7").FirstOrDefault();
            var chM1 = Request.Form.GetValues("chMaturity1").FirstOrDefault();
            var chM2 = Request.Form.GetValues("chMaturity2").FirstOrDefault();
            var chS1 = Request.Form.GetValues("chS1").FirstOrDefault();
            var chSetting1 = Request.Form.GetValues("chSetting1").FirstOrDefault();
            var chSetting2 = Request.Form.GetValues("chSetting2").FirstOrDefault();
            var rdo1 = Request.Form.GetValues("rdo1").FirstOrDefault();

            //---------------------------------getData-------------------------------------------

            using (var sql = new LinqHelper())
            {

                try
                {
                    //---------------------------------initialize-------------------------------------------

                    List<byte> categoryMarkets = new List<byte>();
                    categoryMarkets.Add(chm1.TryParseByte());
                    categoryMarkets.Add(chm2.TryParseByte());
                    categoryMarkets.Add(chm3.TryParseByte());
                    categoryMarkets.Add(chm4.TryParseByte());
                    categoryMarkets.Add(chm5.TryParseByte());
                    categoryMarkets = categoryMarkets.Where(c => c > 0).ToList();
                    if (chm1 == "-1") categoryMarkets.Add(0);



                    List<byte> categoryGroups = new List<byte>();
                    categoryGroups.Add(chg1.TryParseByte());
                    categoryGroups.Add(chg2.TryParseByte());
                    categoryGroups.Add(chg3.TryParseByte());
                    categoryGroups.Add(chg4.TryParseByte());
                    categoryGroups.Add(chg5.TryParseByte());
                    categoryGroups.Add(chg6.TryParseByte());
                    categoryGroups.Add(chg7.TryParseByte());
                    categoryGroups = categoryGroups.Where(c => c > 0).ToList();
                    if (chm1 == "-1") categoryGroups.Add(0);


                    List<byte> categorySymbolType = new List<byte>();

                    categorySymbolType.Add(chS1.TryParseByte());

                    if (chS1 == "0")
                    {
                        categorySymbolType.Add(1);
                        categorySymbolType.Add(2);
                    }

                    if (chm1 == "-1") categorySymbolType.Add(0);

                    if (chg7 == "-1") categoryGroups.Add(18);


                    name.ToValidMsgString();

                    //---------------------------------Duration-------------------------------------------

                    var Duration = sql.GetDuration();

                    //---------------------------------getInfo-------------------------------------------
                    int count;
                    var result = sql.GetSymbolByFilter(symbol.ToLikeMsgString(), name.ToLikeMsgString(),
                        "%%", promisor.ToLikeMsgString()
                        , sponsor.ToLikeMsgString(), 0, 0, publishDate.ToValidMsgInt(), maturityDate.ToValidMsgInt(),
                        rate, isin, Assistant.TodayDateInt(), rdo1.ToValidMsgByte()
                        , chSetting2,
                        0, int.MaxValue, sortColumn, sortColumnDir, out count)
                                                        .Where(c => categoryMarkets.Contains((byte)c.MarketId))
                                                        .Where(c => categoryGroups.Contains((byte)c.GroupNameId))
                                                        .Where(c => categorySymbolType.Contains((byte)c.SymbolType))
                                                        .ToList();
                    //---------------------------------getInfo-------------------------------------------
                    foreach (var Item in result)
                    {
                        var dItem = Duration.Where(a => a.Isin == Item.Isin).FirstOrDefault();
                        if (dItem != null)
                        {
                            Item.duration = dItem.Duration;

                        }

                        //result[Item.Id].duration = Duration.Where(c => c.Isin == Item.Isin).Select(c => c.Duration).FirstOrDefault();
                    }



                    //---------------------------------initialize-------------------------------------------
                    if (marketMaker != "0")
                    {
                        result = result.Where(c => c.MarketMaker == marketMaker).ToList();
                    }

                    if (chM1 != "1")
                    {
                        result = result.Where(c => c.MaturityDays > 0).ToList();
                    }
                    if (chM2 != "1")
                    {
                        result = result.Where(c => c.MaturityDays < 1).ToList();
                    }
                    if (chSetting1 == "1")
                    {
                        result = result.Where(c => c.dayLastDate.ToValidMsgDate() == Assistant.TodayDateInt()).ToList();
                    }

                    //---------------------------------initialize-------------------------------------------



                    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;

                    // Getting all Customer data  
                    var customerData = result;

                    //total number of rows count   
                    recordsTotal = customerData.Count();
                    //Paging   
                    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    ////Returning Json Data  
                    //return Json(new
                    //{
                    //    draw = draw,
                    //    recordsFiltered = recordsTotal,
                    //    recordsTotal = recordsTotal,
                    //    data = data
                    //});

                    var data = customerData.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });


                }
                catch (Exception ex)
                {
                    return null;
                }



            }
        }
        [HttpPost]
        public ActionResult SaveSettings(UserDebtBoardConfig obj)
        {
            using (var sql = new LinqHelper())
            {

                obj.UserName = Assistant.CurrentUser();
                obj.RegDate = Assistant.TodayDateInt();
                obj.RegTime = Assistant.TimeNowInt();
                obj.IsObsolete = false;
                var result = sql.AddUserDebtBoardConfig(obj);
                return Json("", JsonRequestBehavior.AllowGet);

            }
        }


        [HttpPost]
        public ActionResult getSymbolsTimeline(string startDate, string endDate)
        {
            using (var sql = new LinqHelper())
            {

                var result = sql.GetSymbolMaturity(startDate.ToValidMsgDate(), endDate.ToValidMsgDate()).ToList();

                return Json(result, JsonRequestBehavior.AllowGet);

            }
        }










        [HttpPost]
        public JsonResult GetTradeListDetails(string Isin)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetSymbolBestLimits(Isin);

                    return Json(result, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }



        [HttpGet]
        public JsonResult LoadConfigs()
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var user = Assistant.CurrentUser();
                    var obj = sql.GetUserDebtBoardConfigs(user);
                    if (obj != null)
                    {
                        return Json(obj, JsonRequestBehavior.AllowGet);
                    }
                    return Json("", JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }


        [HttpGet]
        public JsonResult GetSymbols(string term)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetSymbols()
                        .Select(x => new
                        {
                            Id = x.Isin,
                            Text = x.Symbol
                        }).ToList();

                    //list.Add(new {Id = -1, Text = "همه"});
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }


        [HttpGet]
        public JsonResult GetCalcSymbols(string term)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetSymbols()
                        .Select(x => new
                        {
                            Id = x.Isin,
                            Text = x.Symbol
                        }).ToList();

                    //list.Add(new {Id = -1, Text = "همه"});
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }








        [HttpPost]
        public JsonResult LoadSymbolDetailByIsin(string Isin)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    Isin.ToValidMsgInt();
                    int count;
                    var result = sql.GetSymbolDetailByIsin(Isin).Take(1);

                    return Json(result, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }


        [Authorize]
        public ActionResult LoadShareHoldersByIsin()
        {
            try
            {
                var isin = Request.Form.GetValues("Isin").FirstOrDefault();
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetMajorShareHolderByIsin(isin);
                    if (result == null)
                    {
                        return Json(new
                        {
                            recordsFiltered = 0,
                            recordsTotal = 0,
                            data = ""
                        });
                    }
                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    var data = result.ToList();
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }




        [HttpPost]
        public JsonResult CalculationByNominalRate(string Isin, string BuyDate, string SellDate, string BuyPrice, string SellPrice)
        {
            try
            {

                using (var sql = new LinqHelper())
                {


                    int count;
                    var result = sql.GetSpYtmByRate(Isin, BuyDate.ToValidMsgDate(), BuyPrice.ToValidMsgInt(), SellDate.ToValidMsgDate(), SellPrice.ToValidMsgInt());

                    return Json(result, JsonRequestBehavior.AllowGet);

                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        public JsonResult CalculationByBuyPrice(string Isin, string BuyDate, string SellDate, string SellPrice, string NominalRate)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    int count;
                    var result = sql.GetSpYtmByBuyPrice(Isin, BuyDate.ToValidMsgDate(), SellDate.ToValidMsgDate(), SellPrice.ToValidMsgInt(), NominalRate.TryParseDecimal());
                    return Json(result, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult CalculationBySellPrice(string Isin, string BuyDate, string BuyPrice, string SellDate, string NominalRate)
        {
            try
            {

                using (var sql = new LinqHelper())
                {
                    int count;
                    var result = sql.GetSpYtmBySellPrice(Isin, BuyDate.ToValidMsgDate(), BuyPrice.ToValidMsgInt(), SellDate.ToValidMsgDate(), NominalRate.TryParseDecimal());
                    return Json(result, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        public JsonResult LoadSymbolYtmHistorical(string Isin)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    Isin.ToValidMsgInt();
                    int count;
                    var result = sql.GetSymbolYtmHistorical(Isin);

                    return Json(result, JsonRequestBehavior.AllowGet); ;
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }


        //<s--------------- صفحه دارندگان اوراق ----------->



    }
}