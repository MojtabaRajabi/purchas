﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dto;
using ExcelDataReader;
using System.IO;
using System.Data;
using Microsoft.Ajax.Utilities;
using Sanay.Lotus.Erm.Lib.Enum;

namespace Sanay.Lotus.Erm.Controllers
{
    public class MarketRiskController : Controller
    {
        // GET: MarketRisk




        public ActionResult Index()
        {
            using (var sql = new LinqHelper())
            {
                List<GetCompanies_Result> list = sql.GetMainCoSymbols().OrderBy(c => c.CoName).ToList();
                List<Company> groupsList = sql.GetCoSymbolsGroups().OrderBy(c => c.GroupName).ToList();
                List<Company> industryList = sql.GetCoSymbolsIndustry().OrderBy(c => c.IndustryName).ToList();
                List<Company> MarketList = sql.GetCoMarket().OrderBy(c => c.IndustryName).ToList();

                ViewBag.list = list;
                ViewBag.groupsList = groupsList;
                ViewBag.industryList = industryList;
                ViewBag.MarketList = MarketList;

            }
            return View();
        }

        public ActionResult Add()
        {
            using (var sql = new LinqHelper())
            {
                List<GetCompanies_Result> list = sql.GetMainCoSymbols().OrderBy(c => c.CoName).ToList();
                List<Company> groupsList = sql.GetCoSymbolsGroups().OrderBy(c => c.GroupName).ToList();
                List<Company> industryList = sql.GetCoSymbolsIndustry().OrderBy(c => c.IndustryName).ToList();

                ViewBag.list = list;
                ViewBag.groupsList = groupsList;
                ViewBag.industryList = industryList;

            }

            return View();
        }


        public ActionResult AddSymbolToPortfolio()
        {
            using (var sql = new LinqHelper())
            {
                List<string> list = sql.GetMainCoSymbols().Where(x=>x.CoID< 1000001).OrderBy(c => c.CoTSESymbol).Select(c => c.CoTSESymbol).ToList();

                ViewBag.list = list;
            }
            return View();
        }

         

        public ActionResult AddHolderGroups(string GroupName)
        {
            ViewBag.GroupName = GroupName;
            return View();
        }
        public ActionResult ImportPortfolio(string GroupName)
        {
            ViewBag.GroupName = GroupName;
            return View();
        }


        public ActionResult AddDebtHolderGroups(string GroupName)
        {
            ViewBag.GroupName = GroupName;
            return View();
        }
        public ActionResult PortfolioDataStatistics()
        {
             return View();
        }


        public ActionResult StockMoneyInputs(string Symbol)
        {

            using (var sql = new LinqHelper())
            {
                var Group = sql.MoneyInputSymbols();
                ViewBag.List = Group.Select(c => c.Symbol);
            }

            ViewBag.startDate = Assistant.Last1Months();
            ViewBag.endDate = Assistant.TodayDateBySlash();

            ViewBag.Symbol = Symbol;
            return View();
        }




        public ActionResult HolderGroups()
        {
            using (var sql = new LinqHelper())
            {
                var Group = sql.ShareHolderGroupNames();
                ViewBag.groupsList = Group.Select(c => c.GroupName);
            }
            return View();
        }


        public ActionResult DebtHolderGroups()
        {
            using (var sql = new LinqHelper())
            {
                var Group = sql.ShareDebtHolderGroupNames();
                ViewBag.groupsList = Group.Select(c => new DebtHolderGroupName
                {
                    GroupName = c.GroupName
                                                 ,
                    Id = c.Id
                }).ToList();
            }
            return View();
        }

        public ActionResult HolderToGroups(string GroupName)
        {
            using (var sql = new LinqHelper())
            {

                var res = sql.GetRiskSymbolsShareHolders("", "", "", "", 0, int.MaxValue);
                var Group = sql.ShareHolderGroupNames();


                var SymbolList = sql.GetRiskShareHolders().Select(c => c.Shareholder);
                ViewBag.listGroup = Group;
                ViewBag.listHolder = SymbolList.Distinct();
                ViewBag.GroupName = GroupName;
            }
            return View();
        }


        public ActionResult DebtHolderToGroups(string GroupId, string GroupName)
        {
            using (var sql = new LinqHelper())
            {
                //var res = sql.GetRiskSymbolsShareHolders("", "", "", "", 0, int.MaxValue);
                //List<string> res = sql.GetLastMajorShareHolders().ToList();
                //var Group = sql.ShareHolderGroupNames();
                var SymbolList = sql.GetLastMajorShareHoldersDebt();
                // ViewBag.listGroup = Group;
                ViewBag.listHolder = SymbolList.Distinct();
                ViewBag.GroupId = GroupId;
                ViewBag.GroupName = GroupName;
            }
            return View();
        }

        public ActionResult DebtHolders()
        {
            ViewBag.startDate = Assistant.TodayDateBySlash();
            ViewBag.endDate = Assistant.Next2years();

            using (var sql = new LinqHelper())
            {
                List<string> list = sql.GetLastMajorShareHolders().ToList();
                var DebtList = sql.GetSymbolsShareHolders().Select(s => s.Symbol).ToList();
                ViewBag.list = list;
                ViewBag.DebtList = DebtList.Distinct();
            }
            return View();
        }


        public ActionResult StockHolders()
        {
            ViewBag.startDate = Assistant.TodayDateBySlash();
            ViewBag.endDate = Assistant.Next2years();

            using (var sql = new LinqHelper())
            {

                var res = sql.GetRiskSymbolsShareHolders("", "", "", "", 0, int.MaxValue);
                var SymbolList = res.Select(s => s.CoTSESymbol).ToList();
                var GroupNamelist = res.Select(s => s.GroupName).ToList();
                var MarketNamelist = res.Select(s => s.MarketName).ToList();
                var ShareHolder = res.Select(s => s.Shareholder).ToList();

                ViewBag.list = ShareHolder.Distinct();
                ViewBag.SymbolList = SymbolList.Distinct();
                ViewBag.GroupName = GroupNamelist.Distinct();
                ViewBag.MarketName = MarketNamelist.Distinct();
            }


            return View();
        }



        [Authorize]

        public ActionResult ShareChart1()
        {
            ViewBag.startDate = Assistant.DateToDisplayMode(Assistant.Last3Months());
            ViewBag.endDate = Assistant.TodayDateBySlash();

            return View();
        }





        [Authorize]

        public ActionResult ShareChart()
        {
            ViewBag.startDate = Assistant.DateToDisplayMode(Assistant.Last3Months());
            ViewBag.endDate = Assistant.TodayDateBySlash();

            using (var sql = new LinqHelper())
            {

                var Holder = "all";
                //var res = sql.GetSymbolsShares(startDate.ToValidMsgDate(), endDate.ToValidMsgDate()).OrderBy(c => c.MaturityDate);

                var res = sql.GetSymbolsShareHoldersProperties().Where(c => (c.Shareholder == Holder || Holder == "all")).Select(c => c._Year).ToList();


                ViewBag.Year = res.Distinct();
            }

            return View();
        }



        [Authorize]

        public ActionResult Trades()
        {
            ViewBag.startDate = Assistant.DateToDisplayMode(Assistant.Last3Months());
            ViewBag.endDate = Assistant.TodayDateBySlash();

            return View();
        }


        public ActionResult CustomizeHistoricalSymbolPrice()
        {
            using (var sql = new LinqHelper())
            {
                List<GetCompanies_Result> list = sql.GetMainCoSymbols().OrderBy(c => c.CoName).ToList();

                ViewBag.list = list;

            }
            return View();
        }


        [Authorize]

        public ActionResult HolderMaturity(string Holder)
        {

            using (var sql = new LinqHelper())
            {
                List<string> list = sql.GetLastMajorShareHolders().ToList();
                ViewBag.list = list;
                ViewBag.Holder = Holder;
            }

            return View();
        }




        public ActionResult AddPrice()
        {
            using (var sql = new LinqHelper())
            {
                List<GetCompanies_Result> list = sql.GetMainCoSymbols().OrderBy(c => c.CoName).ToList();

                ViewBag.list = list;

            }

            return View();
        }

        public ActionResult SymbolPriceChart(string Url, int SymbolId)
        {
            ViewBag.Url = Url;
            ViewBag.startDate = Assistant.DateToDisplayMode(Assistant.Last3Months());
            ViewBag.endDate = Assistant.TodayDateBySlash();
            @ViewBag.SymbolId = SymbolId;

            return View();
        }

        public ActionResult StockHoldersOwnership(string Holder)
        {
            using (var sql = new LinqHelper())
            {
                List<string> list = sql.GetLastMajorShareHoldersRisk().ToList();

                ViewBag.startDate = Assistant.DateToDisplayMode(Assistant.Last3Months());
                ViewBag.endDate = Assistant.TodayDateBySlash();
                ViewBag.Holder = Holder;

                ViewBag.list = list;

            }
            return View();
        }



        public ActionResult MajorShareHolderSymbolHistorical(string Holder)
        {
            using (var sql = new LinqHelper())
            {
                List<string> list = sql.GetLastMajorShareHoldersRisk().ToList();

                ViewBag.startDate = Assistant.DateToDisplayMode(Assistant.Last3Months());
                ViewBag.endDate = Assistant.TodayDateBySlash();
                ViewBag.Holder = Holder;

                ViewBag.list = list;

            }
            return View();
        }



        public ActionResult SymbolCountChart(int FundId, string Symbol)
        {
            ViewBag.startDate = Assistant.DateToDisplayMode(Assistant.Last3Months());
            ViewBag.endDate = Assistant.TodayDateBySlash();
            @ViewBag.Symbol = Symbol;
            @ViewBag.FundId = FundId;

            return View();
        }

        public ActionResult SymbolOwnership(int FundId, string Symbol)
        {
            ViewBag.startDate = Assistant.DateToDisplayMode(Assistant.Last3Months());
            ViewBag.endDate = Assistant.TodayDateBySlash();
            @ViewBag.Symbol = Symbol;
            @ViewBag.FundId = FundId;

            return View();
        }



        public ActionResult SymbolOwnershipCountChart(int FundId, string Symbol)
        {
            ViewBag.startDate = Assistant.DateToDisplayMode(Assistant.Last3Months());
            ViewBag.endDate = Assistant.TodayDateBySlash();
            @ViewBag.Symbol = Symbol;
            @ViewBag.FundId = FundId;


            using (var sql = new LinqHelper())
            {

                ViewBag.Symbol = Symbol;
                ViewBag.SymbolList = sql.GetRiskSymbolsShareHolders("", "", "", "", 0, int.MaxValue)
                    .DistinctBy(p => new { p.CoTSESymbol })
                    //.GroupBy(item => item.CoTSESymbol)
                    .Select(c => c.CoTSESymbol)
                    .ToList();
            }
            return View();
        }


        public ActionResult DaysRequiredSale(int FundId, string Symbol)
        {
            using (var sql = new LinqHelper())
            {
                ViewBag.startDate = Assistant.DateToDisplayMode(Assistant.Last3Months());
                ViewBag.endDate = Assistant.TodayDateBySlash();
                @ViewBag.Symbol = Symbol;
                @ViewBag.FundId = FundId;

                var LotusFundList = sql.GetLotusFundList();
                ViewBag.LotusFundList = LotusFundList;

                List<GetCompanies_Result> list = sql.GetMainCoSymbols().OrderBy(c => c.CoName).ToList();
                ViewBag.list = list;
                var l = list.Where(s => s.CoTSESymbol == Symbol).FirstOrDefault();
                ViewBag.Symbol = l.CoTSESymbol;

                ViewBag.Id = FundId;

                return View();
            }
        }



        [HttpPost]
        public JsonResult LoadSymbolPriceChart(string startDate, string endDate, string SymbolId)
        {
            try
            {
                using (var sql = new LinqHelper())
                {

                    var result =
                    sql.GetSymbolPriceGapCalculations(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), SymbolId.ToValidMsgInt()).OrderBy(c => c.DatePrice);
                    var list = result.ToList()
                        .Select(x => new
                        {
                            symbolPrice = x.SymbolPrice,
                            indexPrice = x.Indicator,
                            weekDate = x._DatePrice,
                            isGap = x.BackDateFlag
                        }).ToList();
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult LoadSymbolCountChart(string startDate, string endDate, string FundId, string Symbol)
        {
            try
            {
                using (var sql = new LinqHelper())
                {

                    var result =
                    sql.GetFundPortfolioSymbolCount(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), FundId.ToValidMsgInt(), Symbol);
                    var list = result.ToList()
                        .Select(x => new
                        {
                            Count = x.Count,
                            Instrument = x.Instrument,
                            PDate = x._PDate
                        }).ToList();
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        public JsonResult LoadSymbolOwnershipChart(string startDate, string endDate, string FundId, string Symbol)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result =
                    sql.GetSymbolOwnershippercentage(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), FundId.ToValidMsgInt(), Symbol);
                    var list = result.ToList()
                        .Select(x => new
                        {
                            percentage = x.percentage,
                            CoTSESymbol = x.CoTSESymbol,
                            DatePrice = x._DatePrice
                        }).ToList();
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }




        [HttpPost]
        public JsonResult LoadSymbolOwnershipCountChart(string startDate, string endDate, string FundId, string Symbol)
        {
            try
            {
                using (var sql = new LinqHelper())
                {

                    var resultSymbolOwnershippercentage = sql.GetSymbolOwnershippercentage(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), FundId.ToValidMsgInt(), Symbol);
                    var listSymbolOwnershippercentage = resultSymbolOwnershippercentage.ToList()
                        .Select(x => new
                        {
                            percentage = x.percentage,
                            CoTSESymbol = x.CoTSESymbol,
                            DatePrice = x._DatePrice
                        }).ToList();


                    var resultFundPortfolioSymbolCount = sql.GetFundPortfolioSymbolCount(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), FundId.ToValidMsgInt(), Symbol);
                    var listFundPortfolioSymbolCount = resultFundPortfolioSymbolCount.ToList()
                        .Select(x => new
                        {
                            Count = x.Count,
                            Instrument = x.Instrument,
                            PDate = x._PDate
                        }).ToList();

                    return Json(new
                    {
                        resultSymbolOwnershippercentage = listSymbolOwnershippercentage,
                        resultFundPortfolioSymbolCount = listFundPortfolioSymbolCount
                    });
                    //return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }







        public ActionResult Groups()
        {
            using (var sql = new LinqHelper())
            {
                //List<Company> list = sql.GetCoSymbols().OrderBy(c => c.CoName).ToList();

                //ViewBag.list = list;
            }

            return View();
        }


        public ActionResult SymbolPriceGaps(string Url, int Id)
        {
            ViewBag.startDate = Assistant.DateToDisplayMode(Assistant.Last3Months());
            ViewBag.endDate = Assistant.TodayDateBySlash();

            ViewBag.Url = Url;

            using (var sql = new LinqHelper())
            {
                List<GetCompanies_Result> list = sql.GetMainCoSymbols().OrderBy(c => c.CoName).ToList();
                ViewBag.list = list;
                var l = list.Where(s => s.Id == Id).FirstOrDefault();
                ViewBag.Symbol = l.CoTSESymbol;


            }



            ViewBag.Id = Id;
            return View();
        }

        public ActionResult SymbolPriceGapsDetailes(string Url, string Symbol)
        {

            ViewBag.Url = Url;

            using (var sql = new LinqHelper())
            {
                List<GetCompanies_Result> list = sql.GetMainCoSymbols().OrderBy(c => c.CoName).ToList();
                ViewBag.list = list;
                var l = list.Where(s => s.CoTSESymbol == Symbol).FirstOrDefault();
                ViewBag.Symbol = l.CoTSESymbol;
            }
            ViewBag.Id = Symbol;
            return View();
        }

        public ActionResult HistoricalSamePrices()
        {
            return View();
        }

        public ActionResult HistoricalSymbolPrice(int? FundId)
        {
            using (var sql = new LinqHelper())
            {
                var list = sql.GetlastFundPortfolio();
                List<GetCompanies_Result> list2 = sql.GetMainCoSymbols().OrderBy(c => c.CoName).ToList();
                ViewBag.list = list2;
                ViewBag.Date = Assistant.DateToDisplayMode(list.PDate);
                ViewBag.startDate = Assistant.DateToDisplayMode(Assistant.Last3Months());
                ViewBag.endDate = Assistant.DateToDisplayMode(Assistant.LastWeek());
                var LotusFundList = sql.GetLotusFundList();
                ViewBag.LotusFundList = LotusFundList;

                ViewBag.endDate = Assistant.DateToDisplayMode(Assistant.LastWeek());


            }
            if (FundId != null)
            {
                ViewBag.FundId = FundId;
            }
            else
            {
                ViewBag.FundId = 0;

            }
            return View();
        }


        public ActionResult FundTradeDetails(int? FundId)
        {
            using (var sql = new LinqHelper())
            {
                var list = sql.GetlastFundPortfolio();
                List<GetCompanies_Result> list2 = sql.GetMainCoSymbols().OrderBy(c => c.CoName).ToList();
                ViewBag.list = list2;
                ViewBag.Date = Assistant.DateToDisplayMode(list.PDate);
                ViewBag.LastWeek = Assistant.LastWeek();
                var LotusFundList = sql.GetLotusFundList();
                var isOmid = false;
                foreach (var Item in LotusFundList)
                {
                    if (Item.FundId == 9)
                        isOmid = true;
                }
                if (isOmid == false)
                    LotusFundList.Add(new GetLotusFundList_Result { FundId=9, FullName= "صندوق سرمايه گذاري اختصاصی بازارگردانی اميد لوتوس پارسيان" });

                ViewBag.LotusFundList = LotusFundList;
            }
            if (FundId != null)
            {
                ViewBag.FundId = FundId;
            }
            else
            {
                ViewBag.FundId = 0;

            }




            return View();
        }

        public ActionResult FundProfits(int? FundId)
        {
            using (var sql = new LinqHelper())
            {
                var list = sql.GetlastFundPortfolio();
                List<GetCompanies_Result> list2 = sql.GetMainCoSymbols().OrderBy(c => c.CoName).ToList();
                ViewBag.list = list2;
                ViewBag.Date = Assistant.DateToDisplayMode(list.PDate);
                ViewBag.Last3Months = Assistant.Last3Months();
            }
            if (FundId != null)
            {
                ViewBag.FundId = FundId;
            }
            else
            {
                ViewBag.FundId = 0;
            }
            return View();
        }

        public ActionResult HistoricalSymbolPriceDetails(string Url, string Symbol)
        {
            ViewBag.Symb = Symbol;
            ViewBag.Url = Url;

            return View();
        }
        public ActionResult ImportPrice()
        {
            using (var sql = new LinqHelper())
            {

                List<GetCompanies_Result> list = sql.GetMainCoSymbols().OrderBy(c => c.CoName).ToList();
                List<Company> groupsList = sql.GetCoSymbolsGroups().OrderBy(c => c.GroupName).ToList();
                List<Company> industryList = sql.GetCoSymbolsIndustry().OrderBy(c => c.IndustryName).ToList();
                ViewBag.groupsList = groupsList;
                ViewBag.industryList = industryList;
                ViewBag.list = list;
            }

            return View();
        }




        [Authorize]
        public ActionResult LoadDataGroups()
        {
            try
            {

                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                //var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var groupName = Request.Form.GetValues("groupName").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetGroups(groupName);

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {
                        case "GroupName":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.GroupName).ToList();
                            else
                                result = result.OrderByDescending(p => p.GroupName).ToList();
                            break;
                        case "IndustryName":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.IndustryName).ToList();
                            else
                                result = result.OrderByDescending(p => p.IndustryName).ToList();
                            break;
                        case "RegDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.RegDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.RegDate).ToList();
                            break;
                        case "RegTime":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.RegTime).ToList();
                            else
                                result = result.OrderByDescending(p => p.RegTime).ToList();
                            break;
                    }

                    //Paging Size
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();

                    ////Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }










        public ActionResult Industry()
        {
            using (var sql = new LinqHelper())
            {
                //List<Company> list = sql.GetCoSymbols().OrderBy(c => c.CoName).ToList();

                //ViewBag.list = list;
            }

            return View();
        }

        [Authorize]
        public ActionResult LoadDataIndustry()
        {
            try
            {

                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                //var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var industryName = Request.Form.GetValues("industryName").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetIndustries(industryName);

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {

                        case "IndustryName":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.IndustryName).ToList();
                            else
                                result = result.OrderByDescending(p => p.IndustryName).ToList();
                            break;
                        case "RegDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.RegDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.RegDate).ToList();
                            break;
                        case "RegTime":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.RegTime).ToList();
                            else
                                result = result.OrderByDescending(p => p.RegTime).ToList();
                            break;
                    }

                    //Paging Size
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();

                    ////Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        [Authorize]
        public ActionResult LoadHistoricalPrice()
        {
            try
            {

                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                //var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var Symbol = Request.Form.GetValues("Symbol").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.PreviewAutomaticHistoricalSymbolPrice(Symbol);

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {

                        case "JDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.JDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.JDate).ToList();
                            break;
                        case "ClosingPrice":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.ClosingPrice).ToList();
                            else
                                result = result.OrderByDescending(p => p.ClosingPrice).ToList();
                            break;
                        case "IndexClose":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.IndexClose).ToList();
                            else
                                result = result.OrderByDescending(p => p.IndexClose).ToList();
                            break;
                        case "Symbol":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Symbol).ToList();
                            else
                                result = result.OrderByDescending(p => p.Symbol).ToList();
                            break;
                    }

                    //Paging Size
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();

                    ////Returning Json Data  
                    return Json(new
                    {
                        //draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }





        [Authorize]
        public ActionResult LoadHolderGroups(string GroupName)
        {
            try
            {
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                //var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                //var Symbol = Request.Form.GetValues("Symbol").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetHolderGroupNames().Where(c => c.GroupName == GroupName || GroupName == "-1");

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();

                    //Paging Size

                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    var data = result;

                    ////Returning Json Data  
                    return Json(new
                    {
                        //draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }





        [Authorize]
        public ActionResult LoadDebtHolderGroups(string GroupName)
        {
            try
            {
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                //var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                //var Symbol = Request.Form.GetValues("Symbol").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetDebtHolderGroupNames().Where(c => c.GroupName == GroupName || GroupName == "-1");

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();

                    //Paging Size

                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    var data = result;

                    ////Returning Json Data  
                    return Json(new
                    {
                        //draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        [Authorize]
        public ActionResult LoadHolderAndGroups()
        {
            try
            {
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                //var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var GroupName = Request.Form.GetValues("GroupName").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetHolderToGroups().Where(c => c.GroupName == GroupName).ToList();

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();

                    //Paging Size

                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = 10;
                    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    var data = result;

                    ////Returning Json Data  
                    return Json(new
                    {
                        //draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }



        [Authorize]
        public ActionResult LoadDebtHolderAndGroups()
        {
            try
            {
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                //var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var GroupName = Request.Form.GetValues("GroupName").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetDebtHolderToGroups().Where(c => c.GroupName == GroupName).ToList();
                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    //Paging Size

                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = 10;
                    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    var data = result;

                    ////Returning Json Data  
                    return Json(new
                    {
                        //draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }







        [HttpPost]
        [Authorize]
        public ActionResult RegisterSymbolSimilar(string SymbolInscode, string SymbolSimilarInscode)
        {
            using (var sql = new LinqHelper())
            {
                var list = sql.GetSymbolSimilar();

                var obj = new SymbolSimilar()
                {
                    InsCodeSymbol = SymbolInscode.TryParseInt64(),
                    InsCodeSymbolSimilar = SymbolSimilarInscode.TryParseInt64(),
                    RegUser = Assistant.CurrentUser(),
                    RegDate = Assistant.TodayDateInt(),
                    RegTime = Assistant.TimeNowInt()
                };

                var result = sql.InsertSymbolSimilar(obj);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);

            }
        }


        [HttpPost]
        [Authorize]
        public ActionResult RegisterHolderGroup(string GroupName)
        {
            using (var sql = new LinqHelper())
            {

                var obj = new HolderGroupName()
                {
                    GroupName = GroupName,
                    RegUser = Assistant.CurrentUser(),
                    RegDate = Assistant.TodayDateInt(),
                    RegTime = Assistant.TimeNowInt()
                };

                var result = sql.InsertHolderGroupName(obj);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);

            }
        }




        [HttpPost]
        [Authorize]
        public ActionResult RegisterDebtHolderGroup(string GroupName)
        {
            using (var sql = new LinqHelper())
            {

                var obj = new DebtHolderGroupName()
                {
                    GroupName = GroupName,
                    RegUser = Assistant.CurrentUser(),
                    RegDate = Assistant.TodayDateInt(),
                    RegTime = Assistant.TimeNowInt()
                };

                var result = sql.InsertDebtHolderGroupName(obj);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);

            }
        }

        [HttpPost]
        [Authorize]
        public ActionResult RegisterHolderToGroup(string Holder, string Group)
        {
            using (var sql = new LinqHelper())
            {
                var GroupId = sql.ShareHolderGroupNames().Where(c => c.GroupName == Group).Select(x => x.Id).FirstOrDefault();
                var obj = new HolderGroup()
                {
                    GroupId = GroupId,
                    HolderName = Holder
                };

                var result = sql.InsertHolderToGroup(obj);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        [Authorize]
        public ActionResult RegisterHolderToDebtGroup(string Shareholder, string GroupName, string GroupId)
        {
            using (var sql = new LinqHelper())
            {
                var obj = new DebtHolderGroup()
                {
                    GroupId = GroupId.TryParseInt32(),
                    Shareholder = Shareholder
                };
                var result = sql.InsertHolderToDebtGroup(obj);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        [Authorize]
        public ActionResult RegisterPrice(string Symbol, string Weight)
        {
            using (var sql = new LinqHelper())
            {

                var result = sql.InsertHistoricalSymbolPrice(Symbol, Weight.ToValidMsgdouble());
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);

            }
        }



        [HttpPost]
        [Authorize]
        public JsonResult DeleteSymbolSimilars(int Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteSymbolSimilars(Id);
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        [Authorize]
        public JsonResult DeleteHolderGroup(int Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteHolderGroup(Id);
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        [Authorize]
        public JsonResult DeleteDebtHolderGroup(int Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteDebtHolderGroup(Id);
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        [Authorize]
        public JsonResult DeleteHolderToGroups(int Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteHolderToGroups(Id);
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        [Authorize]
        public JsonResult DeleteDebtHolderToGroups(int Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteDebtHolderToGroups(Id);
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }





        [HttpPost]
        [Authorize]
        public JsonResult DeleteSymbolPrices(string SymbolId)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteHistoricalSymbolPrices(SymbolId.ToValidMsgInt());
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        [Authorize]
        public ActionResult LoadFundTradeDetails()
        {
            try
            {
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                //var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var FundId = Request.Form.GetValues("FundId").FirstOrDefault();
                var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
                var chType = Request.Form.GetValues("chType").FirstOrDefault();
                var group = Request.Form.GetValues("group").FirstOrDefault();


                using (var sql = new LinqHelper())
                {
                    var result = sql.GetSumFundTrades(FundId.ToValidMsgId(),
                                                    startDate.ToValidMsgDate(),
                                                    endDate.ToValidMsgDate()
                                                    , group.ToValidMsgInt(), chType.ToValidMsgInt()).ToList();


                    //if (chType == "1")
                    //{
                    //    result = result.Where(c => c.SumPrice > 0).ToList();

                    //}

                    //if (chType == "-1")
                    //{
                    //    result = result.Where(c => c.SumPrice < 0).ToList();

                    //}

                    double Sum = 0;

                    foreach (var Item in result)
                    {
                        Sum = Sum + (double)Item.SumPrice;
                    }

                    foreach (var Item in result)
                    {
                        Item.Total = Sum;
                    }


                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {
                        case "Instrument":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Instrument).ToList();
                            else
                                result = result.OrderByDescending(p => p.Instrument).ToList();
                            break;
                        case "ChangesCount":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.ChangesCount).ToList();
                            else
                                result = result.OrderByDescending(p => p.ChangesCount).ToList();
                            break;
                        case "_Price":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Average).ToList();
                            else
                                result = result.OrderByDescending(p => p.Average).ToList();
                            break;
                        case "_Value":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.SumPrice).ToList();
                            else
                                result = result.OrderByDescending(p => p.SumPrice).ToList();
                            break;
                        case "State":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.State).ToList();
                            else
                                result = result.OrderByDescending(p => p.State).ToList();
                            break;
                        case "SumBrokerFee":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.SumBrokerFee).ToList();
                            else
                                result = result.OrderByDescending(p => p.SumBrokerFee).ToList();
                            break;
                        case "SumTax":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.SumTax).ToList();
                            else
                                result = result.OrderByDescending(p => p.SumTax).ToList();
                            break;
                        case "SumTotalFee":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.SumTotalFee).ToList();
                            else
                                result = result.OrderByDescending(p => p.SumTotalFee).ToList();
                            break;
                        case "BrokerName":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.BrokerName).ToList();
                            else
                                result = result.OrderByDescending(p => p.BrokerName).ToList();
                            break;
                        case "PDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.PDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.PDate).ToList();
                            break;
                        case "FullName":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.FullName).ToList();
                            else
                                result = result.OrderByDescending(p => p.FullName).ToList();
                            break;

                    }


                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;

                    // Getting all Customer data  
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    //Paging   
                    var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }




        [Authorize]
        public ActionResult LoadFundProfits()
        {
            try
            {
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                //var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                //var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                //var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var FundId = Request.Form.GetValues("FundId").FirstOrDefault();
                var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetFundProfits(FundId.ToValidMsgId(),
                                                    startDate.ToValidMsgDate(),
                                                    endDate.ToValidMsgDate()).ToList();

                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;

                    // Getting all Customer data  
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    //Paging   
                    var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }









        [HttpPost]
        [Authorize]
        public ActionResult LoadSymbolSimilars(string InsCodeSymbol)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetSymbolSimilars(InsCodeSymbol.TryParseInt64());
                    if (result == null)
                    {
                        return Json(new
                        {
                            recordsFiltered = 0,
                            recordsTotal = 0,
                            data = ""
                        });
                    }
                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    var data = result.ToList();
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        [HttpPost]
        public JsonResult GetGroupsAndIndustry(string SymbolCoId)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetGroupAndIndustryBySymbol(SymbolCoId.ToValidMsgInt()).Select(x => new
                    {
                        CoGroup = x.GroupName,
                        CoIndustry = x.IndustryName,

                    }).ToList();

                    //list.Add(new { Name = "همه", Id = -1 });
                    return Json(list, JsonRequestBehavior.AllowGet);
                    //return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        public JsonResult GetSimilarSymbols(string SymbolGroup, string SymbolIndustry)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetSimilarSymbols(SymbolGroup.ToValidMsgInt(), SymbolIndustry.ToValidMsgInt())
                        .Select(x => new
                        {
                            Name = x.CoTSESymbol,
                            CoId = x.CoID,

                        }).ToList();

                    //list.Add(new { Name = "همه", Id = -1 });
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }


        [Authorize]
        public ActionResult LoadSymbolPriceGaps()
        {
            try
            {
                // SqlHelper sql = new SqlHelper();
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form
                    .GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]")
                    .FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var SymbolId = Request.Form.GetValues("SymbolId").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetSymbolPriceGap(SymbolId.ToValidMsgInt());

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {
                        case "Symbol":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Symbol).ToList();
                            else
                                result = result.OrderByDescending(p => p.Symbol).ToList();
                            break;
                        case "DatePrice":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.DatePrice).ToList();
                            else
                                result = result.OrderByDescending(p => p.DatePrice).ToList();
                            break;
                        case "Indicator":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Indicator).ToList();
                            else
                                result = result.OrderByDescending(p => p.Indicator).ToList();
                            break;

                    }

                    //Paging Size (10,20,50,100)  
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;

                    // Getting all Customer data  
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    //Paging   
                    var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        [Authorize]
        public ActionResult LoadSymbolPriceGapsDetailes()
        {
            try
            {
                // SqlHelper sql = new SqlHelper();
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form
                    .GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]")
                    .FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var Symbol = Request.Form.GetValues("Symbol").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetSymbolPriceGapDetails(Symbol);

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();


                    //Paging Size (10,20,50,100)  
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;

                    // Getting all Customer data  
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    //Paging   
                    var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }





        [Authorize]
        public ActionResult LoadCompaniesData()
        {
            try
            {
                // SqlHelper sql = new SqlHelper();
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form
                    .GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]")
                    .FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var Symbol = Request.Form.GetValues("Symbol").FirstOrDefault();
                var TseSymbol = Request.Form.GetValues("TseSymbol").FirstOrDefault();
                var SymbolGroup = Request.Form.GetValues("SymbolGroup").FirstOrDefault();
                var SymbolIndustry = Request.Form.GetValues("SymbolIndustry").FirstOrDefault();
                var Market = Request.Form.GetValues("Market").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetCompanies(Symbol.ToValidMsgInt(), SymbolGroup.ToValidMsgInt(), SymbolIndustry.ToValidMsgInt(), Market.ToValidMsgInt(), TseSymbol);

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {
                        case "CoName":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.CoName).ToList();
                            else
                                result = result.OrderByDescending(p => p.CoName).ToList();
                            break;
                        case "CoTSESymbol":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.CoTSESymbol).ToList();
                            else
                                result = result.OrderByDescending(p => p.CoTSESymbol).ToList();
                            break;
                        case "GroupName":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.GroupName).ToList();
                            else
                                result = result.OrderByDescending(p => p.GroupName).ToList();
                            break;
                        case "IndustryName":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.IndustryName).ToList();
                            else
                                result = result.OrderByDescending(p => p.IndustryName).ToList();
                            break;
                        case "MarketName":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.MarketName).ToList();
                            else
                                result = result.OrderByDescending(p => p.MarketName).ToList();
                            break;
                        case "RegDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.RegDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.RegDate).ToList();
                            break;
                    }

                    //Paging Size (10,20,50,100)  
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;

                    // Getting all Customer data  
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    //Paging   
                    var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        [HttpGet]
        public JsonResult GetInstrumentSymbols(string term)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetInstrumentSymbols()
                        .Select(x => new
                        {
                            Text = x.LVal18AFC
                            //Id=x.InsCode

                        }).ToList();

                    //list.Add(new {Id = -1, Text = "همه"});
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }


        [HttpGet]
        public JsonResult GetdistinctInstrumentSymbols(string term)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetInstrumentSymbolsDistinct()
                        .Select(x => new
                        {
                            Text = x.Symbol
                            //Id=x.InsCode

                        }).ToList();

                    //list.Add(new {Id = -1, Text = "همه"});
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }
        [HttpPost]
        [Authorize]
        public ActionResult GetIndustryChart(string FundId, string Date)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetIndustryChart(FundId.ToValidMsgInt(), Date.ToValidMsgDate())
                        .Select(x => new
                        {
                            IndustryName = x.IndustryName,
                            IndCount = x.IndCount

                        }).ToList();

                    //list.Add(new {Id = -1, Text = "همه"});
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        [Authorize]
        public ActionResult LoadHistoricalHolderSymbols(string startDate, string endDate, string Holder)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetRiskShareHolderHistoricalOwnership(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), Holder).ToList();

                    //list.Add(new {Id = -1, Text = "همه"});
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        [Authorize]
        public ActionResult LoadHistoricalHolderSymbolsAllDate(string startDate, string endDate, string Holder, string Symbol)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    //var list = sql.GetRiskShareHolderHistoricalOwnership(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), Holder).ToList();
                    var list = sql.GetMajorShareHolderSymbolHistoricalAllDate(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), Holder, Symbol).ToList();

                    //list.Add(new {Id = -1, Text = "همه"});
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }








        [HttpPost]
        [Authorize]
        public ActionResult AddFundSymbolsToPortfolio(string FundId, string RemoveSymbol)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.InsertFundSymbolsToPortfolio(FundId.ToValidMsgInt(), RemoveSymbol.ToValidMsgInt());

                    //list.Add(new {Id = -1, Text = "همه"});
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }


        [Authorize]
        public FileResult DownloadHistoricalSymbols()
        {
            string path = Server.MapPath("~/App_Data/Files");
            string fileName = Path.GetFileName("SampleCalculations.xlsx");
            string fullPath = Path.Combine(path, fileName);
            return File(fullPath, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "SampleCalculations.xlsx");
        }







        [Authorize]
        public ActionResult LoadHistoricalSymbols(string Symbol, string chSymbol, string fields)
        {
            try
            {


                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form
                    .GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]")
                    .FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();




                using (var sql = new LinqHelper())
                {
                    var result = sql.GetSymbolHistoricalPrice(Symbol, chSymbol.ToValidMsgInt(), fields);
                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();

                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {
                        case "Symbol":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Symbol).ToList();
                            else
                                result = result.OrderByDescending(p => p.Symbol).ToList();
                            break;
                        case "Share":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Share).ToList();
                            else
                                result = result.OrderByDescending(p => p.Share).ToList();
                            break;
                    }





                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = result
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }










        [Authorize]
        public ActionResult LoadHistoricalFundPortfolios(string Date, string fundId)
        {
            try
            {


                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form
                    .GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]")
                    .FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();




                using (var sql = new LinqHelper())
                {
                    var result = sql.GetLastFundPortfoliosByDate(fundId.TryParseInt32(), Date.ToValidMsgDate());
                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();

                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {
                        case "Instrument":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Instrument).ToList();
                            else
                                result = result.OrderByDescending(p => p.Instrument).ToList();
                            break;
                        case "Count":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Count).ToList();
                            else
                                result = result.OrderByDescending(p => p.Count).ToList();
                            break;
                        case "Price":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Price).ToList();
                            else
                                result = result.OrderByDescending(p => p.Price).ToList();
                            break;
                        case "MarketValue":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.MarketValue).ToList();
                            else
                                result = result.OrderByDescending(p => p.MarketValue).ToList();
                            break;
                        case "MarketName":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.MarketName).ToList();
                            else
                                result = result.OrderByDescending(p => p.MarketName).ToList();
                            break;
                        case "Weight":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Weight).ToList();
                            else
                                result = result.OrderByDescending(p => p.Weight).ToList();
                            break;
                        case "Ownership":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Ownership).ToList();
                            else
                                result = result.OrderByDescending(p => p.Ownership).ToList();
                            break;
                        case "Date":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.PDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.PDate).ToList();
                            break;

                    }





                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = result
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }




        [Authorize]
        public ActionResult LoadHistoricalSymbolAssets()
        {
            try
            {
                // SqlHelper sql = new SqlHelper();
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form
                    .GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]")
                    .FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
                var FundId = Request.Form.GetValues("FundId").FirstOrDefault();
                var Symbol = Request.Form.GetValues("Symbol").FirstOrDefault();


                using (var sql = new LinqHelper())
                {
                    var result = sql.GetFundPortfolioSymbolAssets(startDate.ToValidMsgDate()
                                                                   , endDate.ToValidMsgDate()
                                                                   , FundId.ToValidMsgInt()
                                                                   , Symbol);

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();


                    //Paging Size (10,20,50,100)  
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;

                    // Getting all Customer data  
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    //Paging   
                    var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }





        [Authorize]
        public ActionResult LoadHistoricalSymbolMoneyInputs()
        {
            try
            {
                // SqlHelper sql = new SqlHelper();
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                //var sortColumn = Request.Form
                //    .GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]")
                //    .FirstOrDefault();
                //var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
                var Symbol = Request.Form.GetValues("Symbol").FirstOrDefault();


                using (var sql = new LinqHelper())
                {
                    var result = sql.GetHistoricalMoneyInputs(startDate.ToValidMsgDate()
                                                                   , endDate.ToValidMsgDate()
                                                                   , Symbol
                                                                   , start.ToValidMsgInt()
                                                                   , length.ToValidMsgInt()
                                                                   );

                    //sorting Data
                    //sortColumnDir = sortColumnDir.ToUpper();


                    //Paging Size (10,20,50,100)  
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;

                    // Getting all Customer data  
                    var customerData = result;
                    recordsTotal = customerData[0].Total.Value;
                    //Paging   
                    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = result
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }










        //[Authorize]
        //public ActionResult LoadHistoricalSamePrices(string pDate)
        //{
        //    try
        //    {
        //        using (var sql = new LinqHelper())
        //        {


        //            var result = sql.GetHistoricalSamePrices(pDate.ToValidMsgDate());

        //            int recordsTotal = 0;
        //            recordsTotal = result.Count();
        //            //Paging   
        //            // var data = result.Skip(skip).Take(pageSize).ToList();
        //            var data = result.ToList();
        //            //Returning Json Data  
        //            return Json(new
        //            {
        //                recordsFiltered = recordsTotal,
        //                recordsTotal = recordsTotal,
        //                data = data
        //            });
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw;
        //    }

        //}




        [Authorize]
        public ActionResult LoadHistoricalSymbolDetails(string Symbol)
        {
            try
            {
                using (var sql = new LinqHelper())
                {


                    var result = sql.GetSymbolHistoricalPriceBySymbol(Symbol);

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult HistoricalSymbolPrice(HttpPostedFileBase upload, string drpSymbol)
        {
            // اعتبار سنجی فایل آپلود شده
            if (upload != null && upload.ContentLength > 0 && (upload.FileName.EndsWith(".xls") || upload.FileName.EndsWith(".xlsx")))
            {
                Stream stream = upload.InputStream;

                using (MemoryStream ms = new MemoryStream())
                {
                    stream.CopyTo(ms);
                    var data = ms.ToArray();

                    IExcelDataReader reader = ExcelReaderFactory.CreateReader(stream);
                    DataSet result = reader.AsDataSet(new ExcelDataSetConfiguration()
                    {
                        ConfigureDataTable = (tableReader) => new ExcelDataTableConfiguration()
                        {
                            UseHeaderRow = false
                        }
                    });
                    var datatable = result.Tables[0];
                    var colHeader1 = datatable.Rows[0][0].ToString();
                    var colHeader2 = datatable.Rows[0][1].ToString();

                    //if (reader.FieldCount == 2 && colHeader1 == "زمان" && colHeader2 == "مبلغ سود هر ورقه")
                    if (true)
                    {
                        DataAccess.File fileObj = new DataAccess.File();
                        using (var sql = new LinqHelper())
                        {

                            fileObj.Name = Path.GetFileNameWithoutExtension(upload.FileName);
                            fileObj.Extension = Path.GetExtension(upload.FileName);
                            fileObj.Size = data.Length;
                            fileObj.Sender = Assistant.CurrentUser();
                            fileObj.StatusId = 1;
                            fileObj.RegDate = Convert.ToInt32(Assistant.MiladiToShamsi(Assistant.TodayDateIntMiladi()));
                            fileObj.RegTime = Assistant.TimeNowInt();
                            fileObj.Binary = data;
                            fileObj.FileTypeId = Convert.ToInt32(101);
                            var res = sql.InsertPosition(fileObj);

                            List<Lib.Dto.HistoricalSymbolPrice> list = datatable.AsEnumerable().Skip(1)
                                .Select(row => new Lib.Dto.HistoricalSymbolPrice
                                {
                                    Symbol = drpSymbol,
                                    DatePrice = (string)(row.Field<Object>(0) ?? "").ToString(),
                                    Indicator = (string)(row.Field<Object>(1) ?? "").ToString(),
                                    SymbolPrice = (string)(row.Field<Object>(2) ?? "").ToString(),
                                })
                                .ToList();

                            sql.DeleteHistoricalSymbolPrice(drpSymbol);

                            foreach (var item in list)
                            {
                                sql.InsertHistoricalSymbolPrice(item);
                            }
                        }
                        reader.Close();

                        ViewBag.Symbol = drpSymbol;
                        return View(datatable);
                    }
                }
            }

            ModelState.AddModelError("File", "خطایی رخ داده! فایل مورد نظر با فایل استاندارد همخوانی ندارد ...! ");
            return View();
        }


        public ActionResult AdjustedTradesAllDays()
        {
            using (var sql = new LinqHelper())
            {
                List<Company> Colist = sql.GetCoSymbols().OrderBy(c => c.CoName).ToList();

                ViewBag.Colist = Colist;
            }
            return View();
        }

        public ActionResult LoadDataAdjustedTradesAllDays()
        {
            try
            {
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                //var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var company = Request.Form.GetValues("Company").FirstOrDefault();
                var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetAdjustedTradesAllDays(
                        company.ToValidMsgInt(),
                        startDate.ToValidMsgInt(),
                        endDate.ToValidMsgInt(),
                        sortColumn,
                        sortColumnDir.ToUpper(),
                        start.ToValidMsgInt(),
                        length.ToValidMsgInt()
                        ).ToList();

                    int recordsTotal = 0;
                    if (result.Count > 0)
                        recordsTotal = result.FirstOrDefault().TotalRow ?? 0;

                    var recordsFiltered = recordsTotal;

                    ////Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = result
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public ActionResult LoadTrades()
        {
            try
            {
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                //var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var State = Request.Form.GetValues("State").FirstOrDefault();
                var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetTrades(State.TryParseBoolean()
                                                , startDate.ToValidMsgInt()
                                                , endDate.ToValidMsgInt()).ToList();

                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;

                    // Getting all Customer data  
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    //Paging   
                    var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }




        //<s--------------ضرایب تعدیل تاریخی---------------->

        public ActionResult AdjustmentRatios()
        {
            using (var sql = new LinqHelper())
            {
                List<Company> Colist = sql.GetCoSymbols().OrderBy(c => c.CoName).ToList();

                ViewBag.Colist = Colist;
            }
            return View();
        }

        [Authorize]
        public ActionResult LoadDataAdjustmentRatios()
        {
            try
            {
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                //var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                //var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                //var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var CompanyId = Request.Form.GetValues("Company").FirstOrDefault();
                var ajustTypeId = Request.Form.GetValues("ajustTypeId").FirstOrDefault();
                var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetAdjustmentRatiosByFilter(CompanyId.ToValidMsgId(),
                        ajustTypeId.ToValidMsgId(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(),
                        start.ToValidMsgId(), length.ToValidMsgId()).ToList();

                    int recordsTotal = 0;
                    if (result.Count > 0)
                        recordsTotal = (int)result.FirstOrDefault().TotalRow;

                    ////Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = result
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        //<e--------------ضرایب تعدیل تاریخی---------------->



        [HttpPost]
        public JsonResult LoadDataDebtHolders()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var StartDate = Request.Form.GetValues("StartDate").FirstOrDefault();
            var EndDate = Request.Form.GetValues("EndDate").FirstOrDefault();
            var Holder = Request.Form.GetValues("Holder").FirstOrDefault();
            var Symbol = Request.Form.GetValues("Symbol").FirstOrDefault();
            var sortColDir = Request.Form.GetValues("sortColDir").FirstOrDefault();

            using (var sql = new LinqHelper())
            {

                try
                {

                    var result = sql.GetSymbolsShareHolders()
                        .Where(c => (c.Symbol == Symbol || Symbol == "all")
                                                                     && (c.Shareholder == Holder || c.GroupShareholder == Holder || Holder == "all")
                                                                     && c.MaturityDate >= StartDate.ToValidMsgDate()
                                                                     && c.MaturityDate <= EndDate.ToValidMsgDate())
                        ;

                    if (sortColDir == "1")
                    {
                        result = result.OrderBy(x => x.MaturityDate).ToList();
                    }
                    else
                    {
                        result = result.OrderByDescending(x => x.MaturityDate).ToList();
                    }
                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = result.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }
        //<e--------------- صفحه دارندگان اوراق ----------->



        [HttpPost]
        public JsonResult LoadDataStockHolders()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            //var StartDate = Request.Form.GetValues("StartDate").FirstOrDefault();
            //var EndDate = Request.Form.GetValues("EndDate").FirstOrDefault();
            var Holder = Request.Form.GetValues("Holder").FirstOrDefault();
            var Symbol = Request.Form.GetValues("Symbol").FirstOrDefault();
            var MarketName = Request.Form.GetValues("MarketName").FirstOrDefault();
            var GroupName = Request.Form.GetValues("GroupName").FirstOrDefault();
            var sortColDir = Request.Form.GetValues("sortColDir").FirstOrDefault();

            using (var sql = new LinqHelper())
            {
                try
                {
                    var result = sql.GetRiskSymbolsShareHolders(Symbol
                                                                , Holder
                                                                , MarketName
                                                                , GroupName
                                                                , start.ToValidMsgInt()
                                                                , length.ToValidMsgInt());


                    if (sortColDir == "1")
                    {
                        result = result.OrderBy(x => x.CoTSESymbol).ToList();
                    }
                    else
                    {
                        result = result.OrderByDescending(x => x.CoTSESymbol).ToList();
                    }
                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    if (result.Count() != 0)
                        recordsTotal = (int)result.Max(t => t.Total);
                    else recordsTotal = 0;
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }
        //<e--------------- صفحه دارندگان سهام ----------->









        [HttpPost]
        public JsonResult LoadSharesChart(string startDate, string endDate, string TypeState, string CouponState)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result =
                    sql.GetAllSymbolsShares(startDate.ToValidMsgDate()
                                            , endDate.ToValidMsgDate()
                                            , TypeState.ToValidMsgInt()
                                            , CouponState.ToValidMsgInt()
                                            ).OrderBy(c => c.MaturityDate
                                            );
                    var list = result.ToList()
                        .Select(x => new
                        {
                            share = x.Share,
                            _share2 = x._Share2,
                            NominalPrice = x.NominalPrice,
                            _NominalPrice = x._NominalPrice,
                            Price = x.Price,

                            MaturityDate = Assistant.DateToDisplayMode((int)x.MaturityDate),
                            symbol = x.Symbol
                        }).ToList();
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }





        //[HttpPost]
        //public JsonResult LoadHolderSharesChart(string Holder)
        //{
        //    try
        //    {
        //        using (var sql = new LinqHelper())
        //        {

        //            var result =
        //            sql.GetHolderShares(Holder).OrderBy(c => c.MaturityDate);
        //            var list = result.ToList()
        //                .Select(x => new
        //                {
        //                    share = x.Share,
        //                     MaturityDate = Assistant.DateToDisplayMode((int)x.MaturityDate)
        //                }).ToList();
        //            return Json(list, JsonRequestBehavior.AllowGet);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return Json("", JsonRequestBehavior.AllowGet);
        //    }
        //}


        [HttpPost]
        public JsonResult LoadHolderSharesNameChart(string Holder)
        {
            try
            {
                using (var sql = new LinqHelper())
                {

                    var result =
                    sql.GetHolderSharesName(Holder).OrderBy(c => c.MaturityDate);
                    var list = result.ToList()
                        .Select(x => new
                        {
                            share = x.Share,
                            MaturityDate = Assistant.DateToDisplayMode((int)x.MaturityDate),
                            Symbols = x.Symbol
                        }).ToList();
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }







        [HttpPost]
        public JsonResult LoadShares()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            using (var sql = new LinqHelper())
            {

                try
                {

                    var result = sql.GetSymbolsShares(startDate.ToValidMsgDate(), endDate.ToValidMsgDate()).OrderBy(c => c.MaturityDate);

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = result.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }



        [HttpPost]
        public JsonResult LoadTopShares()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var TypeState = Request.Form.GetValues("TypeState").FirstOrDefault();
            var CouponState = Request.Form.GetValues("CouponState").FirstOrDefault();




            using (var sql = new LinqHelper())
            {

                try
                {
                    var Holder = "all";
                    //var res = sql.GetSymbolsShares(startDate.ToValidMsgDate(), endDate.ToValidMsgDate()).OrderBy(c => c.MaturityDate);

                    var res = sql.GetSymbolsShareHoldersProperties().Where(c => (c.Shareholder == Holder || Holder == "all")
                                                                   && c.MaturityDate >= startDate.ToValidMsgDate()
                                                                   && c.MaturityDate <= endDate.ToValidMsgDate());

                    //if (TypeState == "0")
                    //{
                    //    res = res.Where(c => c.SymbolGroup >= 8 && c.SymbolGroup <= 9).ToList();
                    //}
                    //else
                    //{
                    //    res = res.Where(c => c.SymbolGroup < 8 || c.SymbolGroup > 9).ToList();
                    //}

                    //if (CouponState == "0")
                    //{
                    //    res = res.Where(c => c.SymbolGroup==9).ToList();

                    //}
                    //else
                    //{
                    //    res = res.Where(c => c.SymbolGroup != 9).ToList();

                    //}


                    res = res.Where(c => c.Percent >= 5).ToList();

                    var list = res.GroupBy(d => d.Isin)
                                                 .Select(
                                                     g => new GetSymbolsShareHoldersProperties_Result
                                                     {
                                                         Id = g.First().Id,
                                                         Isin = g.First().Isin,
                                                         Symbol = g.First().Symbol,
                                                         PublishDate = g.First().PublishDate,
                                                         MaturityDate = g.First().MaturityDate,
                                                         SymbolType = g.First().SymbolType,
                                                         SymbolTypeTitle = g.First().SymbolTypeTitle,
                                                         Name = g.First().Name,
                                                         Shareholder = string.Join(" <br />", g.Select(a => a.Shareholder)),
                                                         Percent = g.First().Percent,
                                                         Share = g.First().Share,
                                                         SymbolGroup = g.First().SymbolGroup,
                                                         Market = g.First().Market,
                                                     }).ToList();





                    var result = list.OrderByDescending(x => x.Share).Take(5);

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = result.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }





        [HttpPost]
        public JsonResult LoadNearShares()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var TypeState = Request.Form.GetValues("TypeState").FirstOrDefault();
            var CouponState = Request.Form.GetValues("CouponState").FirstOrDefault();




            using (var sql = new LinqHelper())
            {

                try
                {
                    var Holder = "all";
                    //var res = sql.GetSymbolsShares(startDate.ToValidMsgDate(), endDate.ToValidMsgDate()).OrderBy(c => c.MaturityDate);

                    var res = sql.GetSymbolsShareHoldersProperties().Where(c => (c.Shareholder == Holder || Holder == "all")
                                                                   && c.MaturityDate >= startDate.ToValidMsgDate()
                                                                   && c.MaturityDate <= endDate.ToValidMsgDate());

                    //if (TypeState == "0")
                    //{
                    //    res = res.Where(c => c.SymbolGroup >= 8 && c.SymbolGroup <= 9).ToList();
                    //}
                    //else
                    //{
                    //    res = res.Where(c => c.SymbolGroup < 8 || c.SymbolGroup > 9).ToList();
                    //}

                    //if (CouponState == "0")
                    //{
                    //    res = res.Where(c => c.SymbolGroup == 9).ToList();

                    //}
                    //else
                    //{
                    //    res = res.Where(c => c.SymbolGroup != 9).ToList();

                    //}


                    res = res.Where(c => c.Percent >= 5).ToList();

                    var list = res.GroupBy(d => d.Isin)
                                                 .Select(
                                                     g => new GetSymbolsShareHoldersProperties_Result
                                                     {
                                                         Id = g.First().Id,
                                                         Isin = g.First().Isin,
                                                         Symbol = g.First().Symbol,
                                                         PublishDate = g.First().PublishDate,
                                                         MaturityDate = g.First().MaturityDate,
                                                         SymbolType = g.First().SymbolType,
                                                         SymbolTypeTitle = g.First().SymbolTypeTitle,
                                                         Name = g.First().Name,
                                                         Shareholder = string.Join(" <br />", g.Select(a => a.Shareholder)),
                                                         Percent = g.First().Percent,
                                                         Share = g.First().Share,
                                                         SymbolGroup = g.First().SymbolGroup,
                                                         Market = g.First().Market,
                                                     }).ToList();

                    var result = list.OrderBy(x => x.MaturityDate).Take(5);

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = result.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }




        [HttpPost]
        public JsonResult LoadYearlyShares()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var TypeState = Request.Form.GetValues("TypeState").FirstOrDefault();
            var CouponState = Request.Form.GetValues("CouponState").FirstOrDefault();




            using (var sql = new LinqHelper())
            {

                try
                {
                    var Holder = "all";
                    //var res = sql.GetSymbolsShares(startDate.ToValidMsgDate(), endDate.ToValidMsgDate()).OrderBy(c => c.MaturityDate);

                    var res = sql.GetSymbolsShareHoldersProperties().Where(c => (c.Shareholder == Holder || Holder == "all")).ToList();

                    //if (TypeState == "0")
                    //{
                    //    res = res.Where(c => c.SymbolGroup >= 8 && c.SymbolGroup <= 9).ToList();
                    //}
                    //else
                    //{
                    //    res = res.Where(c => c.SymbolGroup < 8 || c.SymbolGroup > 9).ToList();
                    //}

                    //if (CouponState == "0")
                    //{
                    //    res = res.Where(c => c.SymbolGroup == 9).ToList();

                    //}
                    //else
                    //{
                    //    res = res.Where(c => c.SymbolGroup != 9).ToList();

                    //}

                    res.ForEach(z => z.MaturityDate = z.MaturityDate / 10000);


                    var list = res.GroupBy(d => d.MaturityDate)
                                                 .Select(
                                                     g => new GetSymbolsShareHoldersProperties_Result
                                                     {
                                                         MaturityDate = g.First().MaturityDate,
                                                         Share = g.Sum(s => s.Share),
                                                     }).ToList();

                    var result = list.OrderBy(x => x.MaturityDate);

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = result.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }






        [HttpPost]
        public JsonResult LoadMonthlySharesDate()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var Date = Request.Form.GetValues("Date").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var TypeState = Request.Form.GetValues("TypeState").FirstOrDefault();
            var CouponState = Request.Form.GetValues("CouponState").FirstOrDefault();




            using (var sql = new LinqHelper())
            {

                try
                {
                    var Holder = "all";
                    //var res = sql.GetSymbolsShares(startDate.ToValidMsgDate(), endDate.ToValidMsgDate()).OrderBy(c => c.MaturityDate);

                    var res = sql.GetSymbolsShareHoldersProperties().Where(c => (c.Shareholder == Holder || Holder == "all")).ToList();
                    //&& c.MaturityDate >= startDate.ToValidMsgDate()
                    //&& c.MaturityDate <= endDate.ToValidMsgDate()).ToList();

                    //if (TypeState == "0")
                    //{
                    //    res = res.Where(c => c.SymbolGroup >= 8 && c.SymbolGroup <= 9).ToList();
                    //}
                    //else
                    //{
                    //    res = res.Where(c => c.SymbolGroup < 8 || c.SymbolGroup > 9).ToList();
                    //}

                    //if (CouponState == "0")
                    //{
                    //    res = res.Where(c => c.SymbolGroup == 9).ToList();

                    //}
                    //else
                    //{
                    //    res = res.Where(c => c.SymbolGroup != 9).ToList();

                    //}

                    res = res.Where(c => c._Year == Date).ToList();


                    var list = res.GroupBy(d => d._Month)
                                                 .Select(
                                                     g => new GetSymbolsShareHoldersProperties_Result
                                                     {
                                                         MaturityDate = g.First().MaturityDate,
                                                         Year = g.First()._Year,
                                                         Share = g.Sum(s => s.Share),
                                                         Month = g.First()._Month
                                                     }).ToList();

                    var result = list.OrderBy(x => x.MaturityDate);

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = result.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }


        [HttpPost]
        [Authorize]
        public ActionResult SaveSymbolGaps(string ModalSymbolId)
        {
            using (var sql = new LinqHelper())
            {


                var data = sql.insertHistoricalSymbolAllPrice(0, int.MaxValue, ModalSymbolId.ToValidMsgInt());

                //list.Add(new {Id = -1, Text = "همه"});
                return Json(data, JsonRequestBehavior.AllowGet);

                //return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Authorize]
        public ActionResult LoadFundLastTradeDate()
        {
            using (var sql = new LinqHelper())
            {


                var data2 = sql.GetLoadFundLastTradeDate();
                var data = Assistant.DateToDisplayMode(data2);
                //list.Add(new {Id = -1, Text = "همه"});
                return Json(data, JsonRequestBehavior.AllowGet);

                //return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }







        //[HttpPost]
        //public JsonResult LoadBigSmallSharesOwners()
        //{
        //    var draw = Request.Form.GetValues("draw").FirstOrDefault();
        //    var start = Request.Form.GetValues("start").FirstOrDefault();
        //    var length = Request.Form.GetValues("length").FirstOrDefault();
        //    var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
        //    var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
        //    var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

        //    //---------------------------------getData------------------------------------------        
        //    var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
        //    var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
        //    var TypeState = Request.Form.GetValues("TypeState").FirstOrDefault();
        //    var CouponState = Request.Form.GetValues("CouponState").FirstOrDefault();




        //    using (var sql = new LinqHelper())
        //    {

        //        try
        //        {
        //            var Holder = "all";
        //            //var res = sql.GetSymbolsShares(startDate.ToValidMsgDate(), endDate.ToValidMsgDate()).OrderBy(c => c.MaturityDate);

        //            var res = sql.GetSymbolsShareHoldersProperties().Where(c => (c.Shareholder == Holder || Holder == "all")
        //                                                           && c.MaturityDate >= startDate.ToValidMsgDate()
        //                                                           && c.MaturityDate <= endDate.ToValidMsgDate()).ToList();

        //            if (TypeState == "0")
        //            {
        //                res = res.Where(c => c.SymbolGroup >= 8 && c.SymbolGroup <= 9).ToList();
        //            }
        //            else
        //            {
        //                res = res.Where(c => c.SymbolGroup < 8 || c.SymbolGroup > 9).ToList();
        //            }

        //            if (CouponState == "0")
        //            {
        //                res = res.Where(c => c.SymbolGroup == 9).ToList();

        //            }
        //            else
        //            {
        //                res = res.Where(c => c.SymbolGroup != 9).ToList();

        //            }


        //            var resSmall = res.Where(c => c.Percent <= 1).ToList();
        //            var resBig = res.Where(c => c.Percent > 1).ToList();





        //            var list1 = res.GroupBy(d => d._Month)
        //                                         .Select(
        //                                             g => new GetSymbolsShareHoldersProperties_Result
        //                                             {
        //                                                 MaturityDate = g.First().MaturityDate,
        //                                                 Year = g.First()._Year,
        //                                                 Share = g.Sum(s => s.Share),
        //                                                 Month = g.First()._Month
        //                                             }).ToList();

        //            var result = list.OrderBy(x => x.MaturityDate);

        //            //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
        //            //    // int skip = start != null ? Convert.ToInt32(start) : 0;
        //            int recordsTotal = 0;
        //            //    //total number of rows count   
        //            recordsTotal = result.Count();
        //            //    //Paging   
        //            //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
        //            //    ////Returning Json Data                  

        //            var data = result.ToList();
        //            //Returning Json Data  
        //            return Json(new
        //            {
        //                recordsFiltered = recordsTotal,
        //                recordsTotal = recordsTotal,
        //                data = data
        //            });
        //        }
        //        catch (Exception ex)
        //        {
        //            return null;
        //        }
        //    }
        //}



        [HttpPost]
        public JsonResult LoadBigOwners()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var HolderPrcnt = Request.Form.GetValues("HolderPrcnt").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var TypeState = Request.Form.GetValues("TypeState").FirstOrDefault();
            var CouponState = Request.Form.GetValues("CouponState").FirstOrDefault();


            using (var sql = new LinqHelper())
            {

                try
                {
                    var Holder = "all";
                    //var res = sql.GetSymbolsShares(startDate.ToValidMsgDate(), endDate.ToValidMsgDate()).OrderBy(c => c.MaturityDate);

                    var res = sql.GetSymbolsShareHoldersProperties().Where(c => (c.Shareholder == Holder || Holder == "all")).ToList();
                    //&& c.MaturityDate >= startDate.ToValidMsgDate()
                    //&& c.MaturityDate <= endDate.ToValidMsgDate()).ToList();

                    //if (TypeState == "0")
                    //{
                    //    res = res.Where(c => c.SymbolGroup >= 8 && c.SymbolGroup <= 9).ToList();
                    //}
                    //else
                    //{
                    //    res = res.Where(c => c.SymbolGroup < 8 || c.SymbolGroup > 9).ToList();
                    //}

                    //if (CouponState == "0")
                    //{
                    //    res = res.Where(c => c.SymbolGroup == 9).ToList();

                    //}
                    //else
                    //{
                    //    res = res.Where(c => c.SymbolGroup != 9).ToList();

                    //}






                    double total = (double)res.Sum(x => x.Share);



                    var list = res.GroupBy(d => d.Shareholder)
                                                 .Select(
                                                     g => new GetSymbolsShareHoldersProperties_Result
                                                     {
                                                         MaturityDate = g.First().MaturityDate,
                                                         Shareholder = g.First().Shareholder,
                                                         Share = g.Sum(s => s.Share),
                                                         Percent = g.Sum(s => s.Share) * 100 / total,

                                                     }).ToList();

                    var result = list.Where(c => c.Percent >= HolderPrcnt.ToValidMsgInt()).OrderByDescending(x => x.Percent);

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = result.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }



        [HttpPost]
        public JsonResult LoadBestHoldersSharesChart(string startDate, string endDate, string TypeState, string CouponState)
        {
            try
            {

                var Type = false;
                var Coupon = false;
                if (TypeState == "1") Type = true;
                if (CouponState == "1") Coupon = true;



                using (var sql = new LinqHelper())
                {

                    var Holder = "all";
                    //var res = sql.GetSymbolsShares(startDate.ToValidMsgDate(), endDate.ToValidMsgDate()).OrderBy(c => c.MaturityDate);

                    var res = sql.GetSymbolsShareHoldersProperties().Where(c => (c.Shareholder == Holder || Holder == "all")).ToList();
                    //&& c.MaturityDate >= startDate.ToValidMsgDate()
                    //&& c.MaturityDate <= endDate.ToValidMsgDate())

                    //if (TypeState == "0")
                    //{
                    //    res = res.Where(c => c.SymbolGroup >= 8 && c.SymbolGroup <= 9).ToList();
                    //}
                    //else
                    //{
                    //    res = res.Where(c => c.SymbolGroup < 8 || c.SymbolGroup > 9).ToList();
                    //}

                    //if (CouponState == "0")
                    //{
                    //    res = res.Where(c => c.SymbolGroup == 9).ToList();

                    //}
                    //else
                    //{
                    //    res = res.Where(c => c.SymbolGroup != 9).ToList();

                    //}


                    double total = (double)res.Sum(x => x.Share);



                    var list = res.GroupBy(d => d.Shareholder)
                                                 .Select(
                                                     g => new GetSymbolsShareHoldersProperties_Result
                                                     {
                                                         MaturityDate = g.First().MaturityDate,
                                                         Shareholder = g.First().Shareholder,
                                                         Share = g.Sum(s => s.Share),
                                                         Percent = g.Sum(s => s.Share) * 100 / total,

                                                     }).ToList();

                    var TopResult = list.Where(c => c.Shareholder != "مرکزمدیریت بدهی وزارت اقتصاد").OrderByDescending(x => x.Percent).Take(5);

                    var result = res.Where(c => c.Shareholder == TopResult.ElementAt(0).Shareholder
                                              || c.Shareholder == TopResult.ElementAt(1).Shareholder
                                              || c.Shareholder == TopResult.ElementAt(2).Shareholder
                                              || c.Shareholder == TopResult.ElementAt(3).Shareholder
                                              || c.Shareholder == TopResult.ElementAt(4).Shareholder).OrderBy(c => c.MaturityDate).ToList();

                    result.Where(c => c.Shareholder == TopResult.ElementAt(0).Shareholder).ToList().ForEach(z => z.Rate = 0);
                    result.Where(c => c.Shareholder == TopResult.ElementAt(1).Shareholder).ToList().ForEach(z => z.Rate = 1);
                    result.Where(c => c.Shareholder == TopResult.ElementAt(2).Shareholder).ToList().ForEach(z => z.Rate = 2);
                    result.Where(c => c.Shareholder == TopResult.ElementAt(3).Shareholder).ToList().ForEach(z => z.Rate = 3);
                    result.Where(c => c.Shareholder == TopResult.ElementAt(4).Shareholder).ToList().ForEach(z => z.Rate = 4);

                    return Json(result, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }





        [HttpPost]
        public JsonResult LoadBigHoldersStatistics()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var TypeState = Request.Form.GetValues("TypeState").FirstOrDefault();
            var CouponState = Request.Form.GetValues("CouponState").FirstOrDefault();


            using (var sql = new LinqHelper())
            {

                try
                {
                    var Holder = "all";
                    //var res = sql.GetSymbolsShares(startDate.ToValidMsgDate(), endDate.ToValidMsgDate()).OrderBy(c => c.MaturityDate);

                    var res = sql.GetSymbolsShareHoldersProperties().Where(c => (c.Shareholder == Holder || Holder == "all")).ToList();
                    //&& c.MaturityDate >= startDate.ToValidMsgDate()
                    //&& c.MaturityDate <= endDate.ToValidMsgDate()

                    //if (TypeState == "0")
                    //{
                    //    res = res.Where(c => c.SymbolGroup >= 8 && c.SymbolGroup <= 9).ToList();
                    //}
                    //else
                    //{
                    //    res = res.Where(c => c.SymbolGroup < 8 || c.SymbolGroup > 9).ToList();
                    //}

                    //if (CouponState == "0")
                    //{
                    //    res = res.Where(c => c.SymbolGroup == 9).ToList();

                    //}
                    //else
                    //{
                    //    res = res.Where(c => c.SymbolGroup != 9).ToList();

                    //}


                    double total = (double)res.Sum(x => x.Share);
                    res = res.OrderByDescending(c => c.Share).ToList();

                    //for (int i = 0; i < res.Count(); i++)
                    //{
                    //    res.ElementAt(i).DebtId = i + 1;
                    //}


                    var list = res.GroupBy(d => d.Shareholder)
                                                 .Select(
                                                     g => new GetSymbolsShareHoldersProperties_Result
                                                     {
                                                         DebtId = g.First().DebtId,
                                                         MaturityDate = g.First().MaturityDate,
                                                         Shareholder = g.First().Shareholder,
                                                         Share = g.Sum(s => s.Share),
                                                         Percent = g.Sum(s => s.Share) * 100 / total,
                                                         DebtCount = g.Count(),
                                                         ShareAve = (g.Sum(s => s.Share)) / g.Count(),
                                                         MarketRatio = ((g.Sum(s => s.Share)) / g.Count()) /*/ g.First().DebtId*/
                                                     }).ToList();

                    list = list.OrderByDescending(c => c.Share).ToList();

                    for (int i = 0; i < list.Count(); i++)
                    {
                        list.ElementAt(i).DebtId = i + 1;
                    }

                    for (int i = 0; i < list.Count(); i++)
                    {
                        list.ElementAt(i).MarketRatio = list.ElementAt(i).MarketRatio / list.ElementAt(i).DebtId;
                    }


                    var result = list.Where(c => c.Percent >= 1).OrderByDescending(x => x.MarketRatio);

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = result.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }







        [HttpPost]
        public JsonResult LoadBigDebtHolders()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var Value = Request.Form.GetValues("Value").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var TypeState = Request.Form.GetValues("TypeState").FirstOrDefault();
            var CouponState = Request.Form.GetValues("CouponState").FirstOrDefault();


            using (var sql = new LinqHelper())
            {

                try
                {
                    var Holder = "all";
                    //var res = sql.GetSymbolsShares(startDate.ToValidMsgDate(), endDate.ToValidMsgDate()).OrderBy(c => c.MaturityDate);

                    var res = sql.GetSymbolsShareHoldersPropertiesWithValue().Where(c => (c.Shareholder == Holder || Holder == "all")).ToList();
                    //&& c.MaturityDate >= startDate.ToValidMsgDate()
                    //&& c.MaturityDate <= endDate.ToValidMsgDate())

                    //if (TypeState == "0")
                    //{
                    //    res = res.Where(c => c.SymbolGroup >= 8 && c.SymbolGroup <= 9).ToList();
                    //}
                    //else
                    //{
                    //    res = res.Where(c => c.SymbolGroup < 8 || c.SymbolGroup > 9).ToList();
                    //}

                    //if (CouponState == "0")
                    //{
                    //    res = res.Where(c => c.SymbolGroup == 9).ToList();

                    //}
                    //else
                    //{
                    //    res = res.Where(c => c.SymbolGroup != 9).ToList();

                    //}


                    var result = res.Where(c => c.Value >= Value.ToValidMsglong()).OrderByDescending(x => x.Value).ToList();

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = result.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }






        [HttpPost]
        public JsonResult GetSymbolDaysRequiredSale(string FundId, string Symbol, string Period, string PercentageParticipation)
        {
            try
            {
                using (var sql = new LinqHelper())
                {


                    var endDate = Assistant.TodayDateInt();
                    var startDate = 0;
                    if (Period == "1")
                        startDate = Assistant.LastWeekFromDate((Assistant.ShamsiToMiladyDate(endDate).TryParseDateTime()));
                    else if (Period == "2")
                        startDate = Assistant.LastMonthFromDate((Assistant.ShamsiToMiladyDate(endDate).TryParseDateTime()));
                    else if (Period == "3")
                        startDate = Assistant.Last2MonthFromDate((Assistant.ShamsiToMiladyDate(endDate).TryParseDateTime()));
                    else if (Period == "4")
                        startDate = Assistant.Last3MonthFromDate((Assistant.ShamsiToMiladyDate(endDate).TryParseDateTime()));
                    else if (Period == "5")
                        startDate = Assistant.Last6MonthFromDate((Assistant.ShamsiToMiladyDate(endDate).TryParseDateTime()));
                    else if (Period == "6")
                        startDate = Assistant.LastYearFromDate((Assistant.ShamsiToMiladyDate(endDate).TryParseDateTime()));




                    var result =
                        sql.GetSymbolDaysRequiredSale(FundId.ToValidMsgInt(), Symbol.ToValidString(),
                            Period.ToValidMsgInt(), PercentageParticipation.ToValidMsgdouble() / 100, startDate, endDate);
                    var list = result.ToList()
                        .Select(x => new
                        {
                            CalResult = x._CalResult,
                            ExistingStocks = x._ExistingStocks,
                            AverageStocksTraded = x._AverageStocksTraded,
                            StartDateInt = x._StartDateInt,
                            EndDateInt = x._EndDateInt
                        }).FirstOrDefault();
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }



        public ActionResult StockHoldersComboChart(string Symbol)
        {
            using (var sql = new LinqHelper())
            {

                ViewBag.Symbol = Symbol;
                ViewBag.SymbolList = sql.GetRiskSymbolsShareHolders("", "", "", "", 0, int.MaxValue)
                    .DistinctBy(p => new { p.CoTSESymbol })
                    //.GroupBy(item => item.CoTSESymbol)
                    .Select(c => c.CoTSESymbol)
                    .ToList();
            }
            return View();
        }


        [HttpPost]
        public JsonResult GetDataComboChart(string Symbol)
        {
            try
            {
                using (var sql = new LinqHelper())
                {

                    //var result = sql.GetRiskSymbolsShareHolders(Symbol, "", "", ""
                    //    , 0
                    //    , 100);

                    var result = sql.GetRiskSymbolsShareHolders2(Symbol, "", "", ""
                        , 0
                        , 100);

                    var list = result.ToList()
                        .Select(x => new
                        {
                            Percents = x.Percents,
                            Share = x.Share,
                            Shareholder = x.Shareholder,
                        }).ToList();
                    return Json(list.OrderByDescending(c => c.Percents), JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }




        [HttpPost]
        public JsonResult LoadPreviewDataGridValueAtRisk()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();
            var InterVal = Request.Form.GetValues("InterVal").FirstOrDefault();

            using (var lq = new LinqHelper())
            {

                try
                {
                    var Value = lq.GetFundLastValue(fundId.ToValidMsgInt());

                    if (InterVal == "-1")
                    {

                        var result = lq.CalculatePortfolioYieldVAR(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt(), 1);
                        var result2 = lq.CalculatePortfolioYieldVAR(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt(), 5);
                        var result3 = lq.CalculatePortfolioYieldVAR(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt(), 21);
                        var result4 = lq.CalculatePortfolioYieldVAR(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt(), 63);
                        var result5 = lq.CalculatePortfolioYieldVAR(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt(), 126);

                        result.Add(new CalcPortfolioVarByYield_Result { _Title = "ارزش روزانه", VaR1 = result[0].VaR1 * Value, VaR2 = result[0].VaR2 * Value, VarMonteCarlo = result[0].VarMonteCarlo * Value });
                        result2.Add(new CalcPortfolioVarByYield_Result { _Title = "ارزش هفتگی", VaR1 = result2[0].VaR1 * Value, VaR2 = result2[0].VaR2 * Value, VarMonteCarlo = result2[0].VarMonteCarlo * Value });
                        result3.Add(new CalcPortfolioVarByYield_Result { _Title = "ارزش ماهانه", VaR1 = result3[0].VaR1 * Value, VaR2 = result3[0].VaR2 * Value, VarMonteCarlo = result3[0].VarMonteCarlo * Value });
                        result4.Add(new CalcPortfolioVarByYield_Result { _Title = "ارزش فصلی", VaR1 = result4[0].VaR1 * Value, VaR2 = result4[0].VaR2 * Value, VarMonteCarlo = result4[0].VarMonteCarlo * Value });
                        result5.Add(new CalcPortfolioVarByYield_Result { _Title = "ارزش شش ماهه", VaR1 = result5[0].VaR1 * Value, VaR2 = result5[0].VaR2 * Value, VarMonteCarlo = result5[0].VarMonteCarlo * Value });
                        result[0]._Title = "درصد روزانه ";
                        result2[0]._Title = "درصد هفتگی ";
                        result3[0]._Title = "درصد ماهانه ";
                        result4[0]._Title = "درصد فصلی ";
                        result5[0]._Title = "درصد شش ماهه";
                        result.Add(new CalcPortfolioVarByYield_Result { _Title = " ", VaR1 = null, VaR2 = null, VarMonteCarlo = null });

                        result.AddRange(result2);
                        result.Add(new CalcPortfolioVarByYield_Result { _Title = " ", VaR1 = null, VaR2 = null, VarMonteCarlo = null });

                        result.AddRange(result3);
                        result.Add(new CalcPortfolioVarByYield_Result { _Title = " ", VaR1 = null, VaR2 = null, VarMonteCarlo = null });

                        result.AddRange(result4);
                        result.Add(new CalcPortfolioVarByYield_Result { _Title = " ", VaR1 = null, VaR2 = null, VarMonteCarlo = null });

                        result.AddRange(result5);


                        //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                        //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                        int recordsTotal = 0;
                        //    //total number of rows count   
                        recordsTotal = result.Count();
                        //    //Paging   
                        //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                        //    ////Returning Json Data                  

                        var data = result.ToList();
                        //Returning Json Data  
                        return Json(new
                        {
                            recordsFiltered = recordsTotal,
                            recordsTotal = recordsTotal,
                            data = data
                        });

                    }
                    else
                    {
                        List<CalcPortfolioVarByYield_Result> result = new List<CalcPortfolioVarByYield_Result>();
                        if (InterVal.ToValidMsgInt() == (int)YieldCycle.Daily)
                        {
                            result = lq.CalculatePortfolioYieldVAR(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt(), (int)YieldCycle.Daily);
                            result.Add(new CalcPortfolioVarByYield_Result { _Title = "ارزش روزانه ", VaR1 = result[0].VaR1 * Value, VaR2 = result[0].VaR2 * Value, VarMonteCarlo = result[0].VarMonteCarlo * Value });
                            result[0]._Title = "درصد روزانه  ";
                        }
                        else if (InterVal.ToValidMsgInt() == (int)YieldCycle.Weekly)
                        {
                            result = lq.CalculatePortfolioYieldVAR(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt(), (int)YieldCycle.Weekly);
                            result.Add(new CalcPortfolioVarByYield_Result { _Title = "ارزش هفتگی ", VaR1 = result[0].VaR1 * Value, VaR2 = result[0].VaR2 * Value, VarMonteCarlo = result[0].VarMonteCarlo * Value });
                            result[0]._Title = "درصد هفتگی  ";
                        }
                        else if (InterVal.ToValidMsgInt() == (int)YieldCycle.Monthly)
                        {
                            result = lq.CalculatePortfolioYieldVAR(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt(), (int)YieldCycle.Monthly);
                            result.Add(new CalcPortfolioVarByYield_Result { _Title = "ارزش ماهانه ", VaR1 = result[0].VaR1 * Value, VaR2 = result[0].VaR2 * Value, VarMonteCarlo = result[0].VarMonteCarlo * Value });
                            result[0]._Title = "درصد ماهانه  ";
                        }
                        else if (InterVal.ToValidMsgInt() == (int)YieldCycle.Seasonal)
                        {
                            result = lq.CalculatePortfolioYieldVAR(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt(), (int)YieldCycle.Seasonal);
                            result.Add(new CalcPortfolioVarByYield_Result { _Title = "ارزش فصلی ", VaR1 = result[0].VaR1 * Value, VaR2 = result[0].VaR2 * Value, VarMonteCarlo = result[0].VarMonteCarlo * Value });
                            result[0]._Title = "درصد فصلی  ";
                        }
                        else if (InterVal.ToValidMsgInt() == (int)YieldCycle.Months6)
                        {
                            result = lq.CalculatePortfolioYieldVAR(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt(), (int)YieldCycle.Months6);
                            result.Add(new CalcPortfolioVarByYield_Result { _Title = "ارزش شش ماهه ", VaR1 = result[0].VaR1 * Value, VaR2 = result[0].VaR2 * Value, VarMonteCarlo = result[0].VarMonteCarlo * Value });
                            result[0]._Title = "درصد شش ماهه  ";
                        }



                        //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                        //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                        int recordsTotal = 0;
                        //    //total number of rows count   
                        recordsTotal = result.Count();
                        //    //Paging   
                        //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                        //    ////Returning Json Data                  

                        var data = result.ToList();
                        //Returning Json Data  
                        return Json(new
                        {
                            recordsFiltered = recordsTotal,
                            recordsTotal = recordsTotal,
                            data = data
                        });




                    }





                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }





        [HttpPost]
        public JsonResult LoadPreviewDataGridPortfolioVar()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();
            var InterVal = Request.Form.GetValues("InterVal").FirstOrDefault();

            using (var lq = new LinqHelper())
            {

                try
                {

                    if (InterVal == "-1")
                    {
                        var result = lq.CalculateSemiSTDV2(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Daily).ToList();
                        var result2 = lq.CalculateSemiSTDV2(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Weekly).ToList();
                        var result3 = lq.CalculateSemiSTDV2(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Monthly).ToList();
                        var result4 = lq.CalculateSemiSTDV2(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Seasonal).ToList();
                        var result5 = lq.CalculateSemiSTDV2(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Months6).ToList();
                        var result6 = lq.CalculateSemiSTDV2(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Yearly).ToList();

                        result[0]._Title = " روزانه ";
                        result2[0]._Title = " هفتگی ";
                        result3[0]._Title = " ماهانه ";
                        result4[0]._Title = " فصلی ";
                        result5[0]._Title = " شش ماهه";
                        result6[0]._Title = "سالانه";

                        result.AddRange(result2);
                        result.AddRange(result3);
                        result.AddRange(result4);
                        result.AddRange(result5);
                        result.AddRange(result6);


                        //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                        //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                        int recordsTotal = 0;
                        //    //total number of rows count   
                        recordsTotal = result.Count();
                        //    //Paging   
                        //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                        //    ////Returning Json Data                  

                        var data = result.ToList();
                        //Returning Json Data  
                        return Json(new
                        {
                            recordsFiltered = recordsTotal,
                            recordsTotal = recordsTotal,
                            data = data
                        });

                    }
                    else
                    {
                        List<CalculateSemiSTDV2_Result> result = new List<CalculateSemiSTDV2_Result>();
                        if (InterVal.ToValidMsgInt() == (int)YieldCycle.Daily)
                        {
                            result = lq.CalculateSemiSTDV2(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Daily).ToList();
                            result[0]._Title = "  روزانه  ";
                        }
                        else if (InterVal.ToValidMsgInt() == (int)YieldCycle.Weekly)
                        {
                            result = lq.CalculateSemiSTDV2(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Weekly).ToList();
                            result[0]._Title = "  هفتگی  ";
                        }
                        else if (InterVal.ToValidMsgInt() == (int)YieldCycle.Monthly)
                        {
                            result = lq.CalculateSemiSTDV2(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Monthly).ToList();
                            result[0]._Title = "  ماهانه  ";
                        }
                        else if (InterVal.ToValidMsgInt() == (int)YieldCycle.Seasonal)
                        {
                            result = lq.CalculateSemiSTDV2(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Seasonal).ToList();
                            result[0]._Title = " فصلی ";
                        }
                        else if (InterVal.ToValidMsgInt() == (int)YieldCycle.Months6)
                        {
                            result = lq.CalculateSemiSTDV2(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Months6).ToList();
                            result[0]._Title = "  شش ماهه  ";
                        }
                        else if (InterVal.ToValidMsgInt() == (int)YieldCycle.Yearly)
                        {
                            result = lq.CalculateSemiSTDV2(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Yearly).ToList();
                            result[0]._Title = "  شش ماهه  ";
                        }


                        //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                        //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                        int recordsTotal = 0;
                        //    //total number of rows count   
                        recordsTotal = result.Count();
                        //    //Paging   
                        //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                        //    ////Returning Json Data                  

                        var data = result.ToList();
                        //Returning Json Data  
                        return Json(new
                        {
                            recordsFiltered = recordsTotal,
                            recordsTotal = recordsTotal,
                            data = data
                        });




                    }





                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }


        [HttpPost]
        public JsonResult LoadPreviewDataGridBeta()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {

                try
                {


                    var result = lq.GetPortfolioBeta(fundId.ToValidMsgInt(), startDate.ToValidMsgInt(), endDate.ToValidMsgInt());


                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = result.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }



        [HttpPost]
        public JsonResult LoadPreviewDataGridSTDEV()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {

                try
                {
                    var res = lq.CalculatePortfolioTrackingError(fundId.ToValidMsgInt(), startDate.ToValidMsgInt(), endDate.ToValidMsgInt()).ToList();

                    List<double?> result = new List<double?>();
                    foreach (var item in res)
                    {
                        result.Add(Math.Round((double)item, 4));

                    }

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = result.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }

        //------------------------------------------------------------------------------------------


        [HttpPost]
        public JsonResult LoadPreviewDataGridPerformanceEvaluation()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();
            var Percent = Request.Form.GetValues("Percent").FirstOrDefault();

            using (var lq = new LinqHelper())
            {

                try
                {
                    var result = lq.CalculatePortfolioPerformanceEvaluation(fundId.ToValidMsgInt(), startDate.ToValidMsgInt(), endDate.ToValidMsgInt(), Percent.ToValidMsgdouble()).ToList();


                    var data1 = result.Select(s => new
                    {
                        Id = 1,
                        Title = "واریانس شاخص",
                        Value = (double?)Math.Round((double)s.IndexVAR, 4),

                    }).ToList();

                    data1.Add(new { Id = 2, Title = "واریانس پرتفوی", Value = (double?)Math.Round((double)result[0].PortVAR, 4) });
                    data1.Add(new { Id = 3, Title = "انحراف معیار شاخص", Value = (double?)Math.Round((double)result[0].IndexSTDEV, 4) });
                    data1.Add(new { Id = 4, Title = "انحراف معیار پرتفوی", Value = (double?)Math.Round((double)result[0].PortSTDEV, 4) });
                    data1.Add(new { Id = 5, Title = "نیم انحراف معیار پرتفوی", Value = (double?)Math.Round((double)result[0].PortHalfSTDEV, 4) });
                    data1.Add(new { Id = 6, Title = "کوواریانس ", Value = (double?)Math.Round((double)result[0].COV, 4) });
                    data1.Add(new { Id = 7, Title = "بتا", Value = (double?)Math.Round((double)result[0].Beta, 4) });
                    data1.Add(new { Id = 8, Title = "نرخ بدون ریسک برای دوره مورد نظر", Value = (double?)Math.Round((double)result[0].NoneRiskRate, 4) });
                    data1.Add(new { Id = 9, Title = "بازدهی کل دوره صندوق", Value = (double?)Math.Round((double)result[0].PortfolioTotalYield, 4) });
                    data1.Add(new { Id = 10, Title = "بازدهی کل دوره شاخص", Value = (double?)Math.Round((double)result[0].IndexTotalYield, 4) });
                    data1.Add(new { Id = 11, Title = "CAPM بازدهی با ", Value = (double?)Math.Round((double)result[0].CAPMYield, 4) });
                    data1.Add(new { Id = 12, Title = "نسبت ترینر ", Value = (double?)Math.Round((double)result[0].Trainer, 4) });
                    data1.Add(new { Id = 13, Title = "نسبت شارپ", Value = (double?)Math.Round((double)result[0].Sharp, 4) });
                    data1.Add(new { Id = 14, Title = "نسبت سورتینو", Value = (double?)Math.Round((double)result[0].Sortino, 4) });
                    data1.Add(new { Id = 15, Title = "معیار جنسن", Value = (double?)Math.Round((double)result[0].Jensen, 4) });


                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = result.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = data1.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }




        //------------------------------------------------------------------------------------------

        private static List<GetPortfolioVaRRanking_Result> DailyVarRanking = new List<GetPortfolioVaRRanking_Result>();
        private static List<GetPortfolioVaRRanking_Result> WeeklyVarRanking = new List<GetPortfolioVaRRanking_Result>();
        private static List<GetPortfolioVaRRanking_Result> MonthlyVarRanking = new List<GetPortfolioVaRRanking_Result>();
        private static List<GetPortfolioVaRRanking_Result> SeasonalyVarRanking = new List<GetPortfolioVaRRanking_Result>();
        private static List<GetPortfolioVaRRanking_Result> Month6VarRanking = new List<GetPortfolioVaRRanking_Result>();
        private static List<GetPortfolioVaRRanking_Result> YearlyVarRanking = new List<GetPortfolioVaRRanking_Result>();




        [HttpPost]
        public JsonResult LoadPreviewDataGridVaRRankingMain()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {

                try
                {
                    var result = lq.GetPortfolioVaRRanking(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate()).ToList();

                    DailyVarRanking = result.OrderBy(c => c.VaR1).Where(c => c.DateStr == "Daily").ToList();
                    WeeklyVarRanking = result.OrderBy(c => c.VaR1).Where(c => c.DateStr == "Weekly").ToList();
                    MonthlyVarRanking = result.OrderBy(c => c.VaR1).Where(c => c.DateStr == "Monthly").ToList();
                    SeasonalyVarRanking = result.OrderBy(c => c.VaR1).Where(c => c.DateStr == "Seasonaly").ToList();
                    Month6VarRanking = result.OrderBy(c => c.VaR1).Where(c => c.DateStr == "6Monthly").ToList();
                    YearlyVarRanking = result.OrderBy(c => c.VaR1).Where(c => c.DateStr == "Yearly").ToList();


                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = DailyVarRanking.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = DailyVarRanking.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }

        //------------------------------------------------------------

        [HttpPost]
        public JsonResult LoadPreviewDataGridVaRRankingWeekly()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        


            using (var lq = new LinqHelper())
            {

                try
                {

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = WeeklyVarRanking.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = WeeklyVarRanking.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }


        //------------------------------------------------------------
        [HttpPost]
        public JsonResult LoadPreviewDataGridVaRRankingMonthly()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        


            using (var lq = new LinqHelper())
            {

                try
                {

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = MonthlyVarRanking.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = MonthlyVarRanking.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }

        //------------------------------------------------------------
        [HttpPost]
        public JsonResult LoadPreviewDataGridVaRRankingSeasonaly()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        


            using (var lq = new LinqHelper())
            {

                try
                {

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = SeasonalyVarRanking.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = SeasonalyVarRanking.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }
        //------------------------------------------------------------
        [HttpPost]
        public JsonResult LoadPreviewDataGridVaRRankingMonth6()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        


            using (var lq = new LinqHelper())
            {

                try
                {

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = Month6VarRanking.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = Month6VarRanking.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }
        //------------------------------------------------------------
        [HttpPost]
        public JsonResult LoadPreviewDataGridVaRRankingYearly()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        


            using (var lq = new LinqHelper())
            {

                try
                {

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = YearlyVarRanking.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = YearlyVarRanking.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }
        //------------------------------------------------------------



        [HttpPost]
        public JsonResult LoadPreviewDataGridVarianceRankingMain()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {

                try
                {

                    var resultVarianceRanking = lq.GetPortfolioSemiSTDRanking(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt())
                                 .Select(s => new
                                 {
                                     Symbol = s.Symbol,
                                     STDEVH_1 = s._STDEVH_1,
                                     STDEVC_1 = s._STDEVC_1,
                                     STDEVH_5 = s._STDEVH_5,
                                     STDEVC_5 = s._STDEVC_5,
                                     STDEVH_21 = s._STDEVH_21,
                                     STDEVC_21 = s._STDEVC_21,
                                     STDEVH_63 = s._STDEVH_63,
                                     STDEVC_63 = s._STDEVC_63,
                                     STDEVH_126 = s._STDEVH_126,
                                     STDEVC_126 = s._STDEVC_126,
                                     STDEVH_252 = s._STDEVH_252,
                                     STDEVC_252 = s._STDEVC_252

                                 }).OrderBy(c => c.STDEVH_1).ToList();




                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = resultVarianceRanking.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = resultVarianceRanking.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }

        //------------------------------------------------------------

        [HttpPost]
        public JsonResult LoadPreviewDataGridVarianceRankingWeekly()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        


            using (var lq = new LinqHelper())
            {

                try
                {
                    var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                    var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
                    var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

                    var resultVarianceRanking = lq.GetPortfolioSemiSTDRanking(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt())
                               .Select(s => new
                               {
                                   Symbol = s.Symbol,
                                   STDEVH_1 = s._STDEVH_1,
                                   STDEVC_1 = s._STDEVC_1,
                                   STDEVH_5 = s._STDEVH_5,
                                   STDEVC_5 = s._STDEVC_5,
                                   STDEVH_21 = s._STDEVH_21,
                                   STDEVC_21 = s._STDEVC_21,
                                   STDEVH_63 = s._STDEVH_63,
                                   STDEVC_63 = s._STDEVC_63,
                                   STDEVH_126 = s._STDEVH_126,
                                   STDEVC_126 = s._STDEVC_126,
                                   STDEVH_252 = s._STDEVH_252,
                                   STDEVC_252 = s._STDEVC_252

                               }).OrderBy(c => c.STDEVH_5).ToList();


                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = resultVarianceRanking.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = resultVarianceRanking.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }


        //------------------------------------------------------------
        [HttpPost]
        public JsonResult LoadPreviewDataGridVarianceRankingMonthly()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        


            using (var lq = new LinqHelper())
            {

                try
                {
                    var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                    var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
                    var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

                    var resultVarianceRanking = lq.GetPortfolioSemiSTDRanking(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt())
                  .Select(s => new
                  {
                      Symbol = s.Symbol,
                      STDEVH_1 = s._STDEVH_1,
                      STDEVC_1 = s._STDEVC_1,
                      STDEVH_5 = s._STDEVH_5,
                      STDEVC_5 = s._STDEVC_5,
                      STDEVH_21 = s._STDEVH_21,
                      STDEVC_21 = s._STDEVC_21,
                      STDEVH_63 = s._STDEVH_63,
                      STDEVC_63 = s._STDEVC_63,
                      STDEVH_126 = s._STDEVH_126,
                      STDEVC_126 = s._STDEVC_126,
                      STDEVH_252 = s._STDEVH_252,
                      STDEVC_252 = s._STDEVC_252

                  }).OrderBy(c => c.STDEVH_21).ToList();

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = resultVarianceRanking.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = resultVarianceRanking.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }

        //------------------------------------------------------------
        [HttpPost]
        public JsonResult LoadPreviewDataGridVarianceRankingSeasonaly()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        


            using (var lq = new LinqHelper())
            {

                try
                {
                    var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                    var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
                    var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

                    var resultVarianceRanking = lq.GetPortfolioSemiSTDRanking(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt())
                  .Select(s => new
                  {
                      Symbol = s.Symbol,
                      STDEVH_1 = s._STDEVH_1,
                      STDEVC_1 = s._STDEVC_1,
                      STDEVH_5 = s._STDEVH_5,
                      STDEVC_5 = s._STDEVC_5,
                      STDEVH_21 = s._STDEVH_21,
                      STDEVC_21 = s._STDEVC_21,
                      STDEVH_63 = s._STDEVH_63,
                      STDEVC_63 = s._STDEVC_63,
                      STDEVH_126 = s._STDEVH_126,
                      STDEVC_126 = s._STDEVC_126,
                      STDEVH_252 = s._STDEVH_252,
                      STDEVC_252 = s._STDEVC_252

                  }).OrderBy(c => c.STDEVH_63).ToList();

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = resultVarianceRanking.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = resultVarianceRanking.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }
        //------------------------------------------------------------
        [HttpPost]
        public JsonResult LoadPreviewDataGridVarianceRankingMonth6()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        


            using (var lq = new LinqHelper())
            {

                try
                {
                    var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                    var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
                    var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

                    var resultVarianceRanking = lq.GetPortfolioSemiSTDRanking(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt())
                  .Select(s => new
                  {
                      Symbol = s.Symbol,
                      STDEVH_1 = s._STDEVH_1,
                      STDEVC_1 = s._STDEVC_1,
                      STDEVH_5 = s._STDEVH_5,
                      STDEVC_5 = s._STDEVC_5,
                      STDEVH_21 = s._STDEVH_21,
                      STDEVC_21 = s._STDEVC_21,
                      STDEVH_63 = s._STDEVH_63,
                      STDEVC_63 = s._STDEVC_63,
                      STDEVH_126 = s._STDEVH_126,
                      STDEVC_126 = s._STDEVC_126,
                      STDEVH_252 = s._STDEVH_252,
                      STDEVC_252 = s._STDEVC_252

                  }).OrderBy(c => c.STDEVH_126).ToList();

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = resultVarianceRanking.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = resultVarianceRanking.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }
        //------------------------------------------------------------
        [HttpPost]
        public JsonResult LoadPreviewDataGridVarianceRankingYearly()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        


            using (var lq = new LinqHelper())
            {

                try
                {
                    var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                    var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
                    var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

                    var resultVarianceRanking = lq.GetPortfolioSemiSTDRanking(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt())
                      .Select(s => new
                      {
                          Symbol = s.Symbol,
                          STDEVH_1 = s._STDEVH_1,
                          STDEVC_1 = s._STDEVC_1,
                          STDEVH_5 = s._STDEVH_5,
                          STDEVC_5 = s._STDEVC_5,
                          STDEVH_21 = s._STDEVH_21,
                          STDEVC_21 = s._STDEVC_21,
                          STDEVH_63 = s._STDEVH_63,
                          STDEVC_63 = s._STDEVC_63,
                          STDEVH_126 = s._STDEVH_126,
                          STDEVC_126 = s._STDEVC_126,
                          STDEVH_252 = s._STDEVH_252,
                          STDEVC_252 = s._STDEVC_252

                      }).OrderBy(c => c.STDEVH_252).ToList();

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = resultVarianceRanking.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = resultVarianceRanking.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }
        //------------------------------------------------------------









        [HttpPost]
        public JsonResult LoadPreviewDataGridStdevRanking()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        


            using (var lq = new LinqHelper())
            {

                try
                {
                    var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                    var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
                    var fundId = Request.Form.GetValues("fundId").FirstOrDefault();
                    var result = lq.GetPortfolioTrackingErrorRanking(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt())
                                  .Select(s => new
                                  {
                                      Symbol = s.Symbol
                                                      ,
                                      TrackingError = s._TrackingError
                                  }).ToList();



                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = result.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }
        //------------------------------------------------------------




        [HttpPost]
        public JsonResult LoadPreviewDataGridBetaRanking()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        


            using (var lq = new LinqHelper())
            {

                try
                {
                    var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                    var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
                    var fundId = Request.Form.GetValues("fundId").FirstOrDefault();
                    var result = lq.GetPortfolioBetaRanking(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), fundId.ToValidMsgInt()).Select(s => new { Symbol = s.Symbol, Beta = s._Beta, }).ToList();




                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = result.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }
        //------------------------------------------------------------


        [HttpPost]
        public JsonResult LoadPreviewDataGridYieldRankingDaily()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {

                try
                {

                    var result = lq.GetPortfolioYieldRanking(startDate.ToValidMsgDate(), fundId.ToValidMsgInt()).ToList();


                    var data_Daily = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Daily").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, _Symbolret = s._Symbolret, }).ToList();
                    //var data_Weekly = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Weekly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    //var data_Monthly = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Monthly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    //var data_Seasonal = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Seasonaly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    //var data_Months6 = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "6Monthly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    //var data_Yearly = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "6Monthly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();





                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = data_Daily.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = data_Daily.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }


        [HttpPost]
        public JsonResult LoadPreviewDataGridYieldRankingWeekly()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {

                try
                {

                    var result = lq.GetPortfolioYieldRanking(startDate.ToValidMsgDate(), fundId.ToValidMsgInt()).ToList();


                    //var data_Daily = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Daily").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    var data_Weekly = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Weekly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, _Symbolret = s._Symbolret, }).ToList();
                    //var data_Monthly = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Monthly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    //var data_Seasonal = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Seasonaly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    //var data_Months6 = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "6Monthly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    //var data_Yearly = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "6Monthly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();





                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = data_Weekly.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = data_Weekly.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }



        [HttpPost]
        public JsonResult LoadPreviewDataGridYieldRankingMonthly()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {

                try
                {

                    var result = lq.GetPortfolioYieldRanking(startDate.ToValidMsgDate(), fundId.ToValidMsgInt()).ToList();


                    //var data_Daily = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Daily").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    //var data_Weekly = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Weekly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    var data_Monthly = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Monthly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, _Symbolret = s._Symbolret, }).ToList();
                    //var data_Seasonal = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Seasonaly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    //var data_Months6 = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "6Monthly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    //var data_Yearly = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "6Monthly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();





                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = data_Monthly.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = data_Monthly.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }


        [HttpPost]
        public JsonResult LoadPreviewDataGridYieldRankingSeasonaly()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {

                try
                {

                    var result = lq.GetPortfolioYieldRanking(startDate.ToValidMsgDate(), fundId.ToValidMsgInt()).ToList();


                    //var data_Daily = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Daily").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    //var data_Weekly = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Weekly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    //var data_Monthly = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Monthly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    var data_Seasonal = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Seasonaly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, _Symbolret = s._Symbolret, }).ToList();
                    //var data_Months6 = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "6Monthly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    //var data_Yearly = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "6Monthly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();





                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = data_Seasonal.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = data_Seasonal.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }


        [HttpPost]
        public JsonResult LoadPreviewDataGridYieldRankingMonth6()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {

                try
                {

                    var result = lq.GetPortfolioYieldRanking(startDate.ToValidMsgDate(), fundId.ToValidMsgInt()).ToList();


                    //var data_Daily = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Daily").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    //var data_Weekly = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Weekly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    //var data_Monthly = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Monthly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    //var data_Seasonal = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Seasonaly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    var data_Months6 = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "6Monthly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, _Symbolret = s._Symbolret, }).ToList();
                    //var data_Yearly = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "6Monthly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();





                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = data_Months6.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = data_Months6.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }

        [HttpPost]
        public JsonResult LoadPreviewDataGridYieldRankingYearly()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {

                try
                {
                    var result = lq.GetPortfolioYieldRanking(startDate.ToValidMsgDate(), fundId.ToValidMsgInt()).ToList();

                    //var data_Daily = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Daily").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    //var data_Weekly = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Weekly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    //var data_Monthly = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Monthly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    //var data_Seasonal = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Seasonaly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    //var data_Months6 = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "6Monthly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, Symbolret = s.Symbolret, }).ToList();
                    var data_Yearly = result.OrderBy(c => c.Symbolret).Where(c => c.DateStr == "Yearly").Select(s => new { Symbol = s.Symbol, DatePrice = s.DatePrice, _Symbolret = s._Symbolret, }).ToList();


                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = data_Yearly.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = data_Yearly.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }




        [HttpPost]
        public JsonResult LoadPreviewDataGridYieldDaily()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {

                try
                {

                    var data_Daily = lq.GetPortfolioYield(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Daily).ToList();
                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = data_Daily.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = data_Daily.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }




        [HttpPost]
        public JsonResult LoadPreviewDataGridYieldWeekly()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {

                try
                {

                    var data_Weekly = lq.GetPortfolioYield(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Weekly).ToList();
                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = data_Weekly.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = data_Weekly.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }




        [HttpPost]
        public JsonResult LoadPreviewDataGridYieldMonthly()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {

                try
                {

                    var data_Monthly = lq.GetPortfolioYield(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Monthly).ToList();
                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = data_Monthly.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = data_Monthly.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }



        [HttpPost]
        public JsonResult LoadPreviewDataGridYieldSeasonaly()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {

                try
                {

                    var data_Seasonal = lq.GetPortfolioYield(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Seasonal).ToList();
                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = data_Seasonal.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = data_Seasonal.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }



        [HttpPost]
        public JsonResult LoadPreviewDataGridYieldMonth6()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {
                try
                {
                    var data_Months6 = lq.GetPortfolioYield(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Months6).ToList();
                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = data_Months6.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = data_Months6.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }




        [HttpPost]
        public JsonResult LoadPreviewDataGridYieldYearly()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {
                try
                {
                    var data_Yearly = lq.GetPortfolioYield(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Yearly).ToList();
                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = data_Yearly.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = data_Yearly.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }


        //-----------------------------------------------------------------------------------

        [HttpPost]
        public JsonResult LoadPreviewDataGridYieldAdjPriceDaily()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {
                try
                {
                    var data_Daily = lq.CalculateFundYieldSimplePrice(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Daily).ToList();

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;

                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = data_Daily.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = data_Daily.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }


        [HttpPost]
        public JsonResult LoadPreviewDataGridYieldAdjPriceWeekly()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {
                try
                {
                    var data_Weekly = lq.CalculateFundYieldSimplePrice(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Weekly).ToList();

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;

                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = data_Weekly.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = data_Weekly.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }



        [HttpPost]
        public JsonResult LoadPreviewDataGridYieldAdjPriceMonthly()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {
                try
                {
                    var data_Monthly = lq.CalculateFundYieldSimplePrice(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Monthly).ToList();

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;

                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = data_Monthly.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = data_Monthly.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }


        [HttpPost]
        public JsonResult LoadPreviewDataGridYieldAdjPriceSeasonaly()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {
                try
                {
                    var data_Monthly = lq.CalculateFundYieldSimplePrice(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Seasonal).ToList();

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;

                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = data_Monthly.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = data_Monthly.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }


        [HttpPost]
        public JsonResult LoadPreviewDataGridYieldAdjPriceMonth6()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {
                try
                {
                    var data_Months6 = lq.CalculateFundYieldSimplePrice(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Months6).ToList();

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;

                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = data_Months6.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = data_Months6.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }




        [HttpPost]
        public JsonResult LoadPreviewDataGridYieldAdjPriceYearly()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {
                try
                {
                    var data_Yearly = lq.CalculateFundYieldSimplePrice(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), (int)YieldCycle.Yearly).ToList();

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;

                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = data_Yearly.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = data_Yearly.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }



        [HttpPost]
        public JsonResult LoadPreviewDaysRequiredForSale()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var Percent = Request.Form.GetValues("Percent").FirstOrDefault();
            var Period = Request.Form.GetValues("Period").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();
            var PDate = Request.Form.GetValues("PDate").FirstOrDefault();

            using (var lq = new LinqHelper())
            {
                try
                {
                    var endDate = PDate.ToValidMsgDate();
                    var startDate = 0;
                    if (Period == "1")
                        startDate = Assistant.LastWeekFromDate((Assistant.ShamsiToMiladyDate(PDate.ToValidMsgDate()).TryParseDateTime()));
                    else if (Period == "2")
                        startDate = Assistant.LastMonthFromDate((Assistant.ShamsiToMiladyDate(PDate.ToValidMsgDate()).TryParseDateTime()));
                    else if (Period == "3")
                        startDate = Assistant.Last2MonthFromDate((Assistant.ShamsiToMiladyDate(PDate.ToValidMsgDate()).TryParseDateTime()));
                    else if (Period == "4")
                        startDate = Assistant.Last3MonthFromDate((Assistant.ShamsiToMiladyDate(PDate.ToValidMsgDate()).TryParseDateTime()));
                    else if (Period == "5")
                        startDate = Assistant.Last6MonthFromDate((Assistant.ShamsiToMiladyDate(PDate.ToValidMsgDate()).TryParseDateTime()));
                    else if (Period == "6")
                        startDate = Assistant.LastYearFromDate((Assistant.ShamsiToMiladyDate(PDate.ToValidMsgDate()).TryParseDateTime()));


                    List<GetSymbolDaysRequiredSale_Result> list = new List<GetSymbolDaysRequiredSale_Result>();

                    var listSymbols = lq.GetLastFundPortfoliosByDate(fundId.TryParseInt32(), PDate.ToValidMsgDate());


                    var res = listSymbols.GroupBy(d => d.Instrument)
                                                 .Select(
                                                     g => new GetLastFundPortfoliosByDate_Result
                                                     {
                                                         Instrument = g.First().Instrument

                                                     }).ToList();

                    foreach (var item in res)
                    {
                        var result = lq.GetSymbolDaysRequiredSale(fundId.ToValidMsgInt(), item.Instrument,
                        Period.ToValidMsgInt(), Percent.ToValidMsgdouble() / 100, startDate, endDate).FirstOrDefault();
                        result.Symbol = item.Instrument;
                        list.Add(result);


                    }


                    var finalResult = list
                            .Select(x => new
                            {
                                Symbol = x.Symbol,
                                CalResult = x._CalResult,
                                ExistingStocks = x._ExistingStocks,
                                AverageStocksTraded = x._AverageStocksTraded,
                                StartDateInt = x._StartDateInt,
                                EndDateInt = x._EndDateInt
                            }).ToList();


                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {

                        case "Symbol":
                            if (sortColumnDir == "ASC")
                                finalResult = finalResult.OrderBy(p => p.Symbol).ToList();
                            else
                                finalResult = finalResult.OrderByDescending(p => p.Symbol).ToList();
                            break;
                        case "StartDateInt":
                            if (sortColumnDir == "ASC")
                                finalResult = finalResult.OrderBy(p => p.StartDateInt).ToList();
                            else
                                finalResult = finalResult.OrderByDescending(p => p.StartDateInt).ToList();
                            break;
                        case "EndDateInt":
                            if (sortColumnDir == "ASC")
                                finalResult = finalResult.OrderBy(p => p.EndDateInt).ToList();
                            else
                                finalResult = finalResult.OrderByDescending(p => p.EndDateInt).ToList();
                            break;
                        case "ExistingStocks":
                            if (sortColumnDir == "ASC")
                                finalResult = finalResult.OrderBy(p => p.ExistingStocks).ToList();
                            else
                                finalResult = finalResult.OrderByDescending(p => p.ExistingStocks).ToList();
                            break;
                        case "AverageStocksTraded":
                            if (sortColumnDir == "ASC")
                                finalResult = finalResult.OrderBy(p => p.AverageStocksTraded).ToList();
                            else
                                finalResult = finalResult.OrderByDescending(p => p.AverageStocksTraded).ToList();
                            break;
                        case "CalResult":
                            if (sortColumnDir == "ASC")
                                finalResult = finalResult.OrderBy(p => p.CalResult).ToList();
                            else
                                finalResult = finalResult.OrderByDescending(p => p.CalResult).ToList();
                            break;
                    }


                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;

                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   
                    recordsTotal = finalResult.Count();
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = finalResult.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }



        [HttpPost]
        [Authorize]
        public ActionResult GetDataSymbolTradeDetail(string FundId, string startDate, string endDate, string chType, string group)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetSumFundTradesDetailes(FundId.ToValidMsgId(),
                                                             startDate.ToValidMsgDate(),
                                                             endDate.ToValidMsgDate()
                                                             , group.ToValidMsgInt(), chType.ToValidMsgInt()).ToList();

                    //list.Add(new {Id = -1, Text = "همه"});
                    return Json(result, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ImportPortfolio(HttpPostedFileBase upload, string drpPortfolio)
        {

            try
            {
                // اعتبار سنجی فایل آپلود شده
                if (upload != null && upload.ContentLength > 0 && (upload.FileName.EndsWith(".xls") || upload.FileName.EndsWith(".xlsx")))
                {
                    Stream stream = upload.InputStream;

                    using (MemoryStream ms = new MemoryStream())
                    {
                        stream.CopyTo(ms);
                        var data = ms.ToArray();

                        IExcelDataReader reader = ExcelReaderFactory.CreateReader(stream);
                        DataSet result = reader.AsDataSet(new ExcelDataSetConfiguration()
                        {
                            ConfigureDataTable = (tableReader) => new ExcelDataTableConfiguration()
                            {
                                UseHeaderRow = false
                            }
                        });
                        var datatable = result.Tables[0];
                        var colHeader1 = datatable.Rows[0][0].ToString();
                        var colHeader2 = datatable.Rows[0][1].ToString();

                        //if (reader.FieldCount == 2 && colHeader1 == "زمان" && colHeader2 == "مبلغ سود هر ورقه")
                        if (true)
                        {
                            DataAccess.File fileObj = new DataAccess.File();
                            using (var sql = new LinqHelper())
                            {

                                fileObj.Name = Path.GetFileNameWithoutExtension(upload.FileName);
                                fileObj.Extension = Path.GetExtension(upload.FileName);
                                fileObj.Size = data.Length;
                                fileObj.Sender = Assistant.CurrentUser();
                                fileObj.StatusId = 1;
                                fileObj.RegDate = Convert.ToInt32(Assistant.MiladiToShamsi(Assistant.TodayDateIntMiladi()));
                                fileObj.RegTime = Assistant.TimeNowInt();
                                fileObj.Binary = data;
                                fileObj.FileTypeId = Convert.ToInt32(201);
                                var res = sql.InsertPosition(fileObj);

                                List<FundPortfolio> list = datatable.AsEnumerable().Skip(1)
                                    .Select(row => new FundPortfolio
                                    {
                                        FundId = drpPortfolio.ToValidMsgInt(),
                                        PDate = ((string)(row.Field<string>(0)).ToString()).ToValidMsgDate(),
                                        Count = ((string)(row.Field<Object>(1)).ToString()).ToValidMsglong(),
                                        Instrument = (string)(row.Field<string>(2)).ToString(),
                                        IsRight = Convert.ToBoolean(((string)(row.Field<Object>(3)).ToString()).ToValidMsgInt())
                                    })
                                    .ToList();


                                 

                                foreach (var item in list)
                                {
                                    item.RegDate = Assistant.TodayDateInt();
                                    item.RegTime = Assistant.TimeNowInt();


                                    sql.InsertPortfolioSymbol(item);
                                }
                            }
                            reader.Close();


                            ViewBag.Symbol = drpPortfolio;
                            return View(datatable);
                        }
                    }
                }

                ModelState.AddModelError("File", "خطایی رخ داده! فایل مورد نظر با فایل استاندارد همخوانی ندارد ...! ");
                return View();
            }

            catch (Exception ex)
            {
                ModelState.AddModelError("File", "خطایی رخ داده! فایل مورد نظر با فایل استاندارد همخوانی ندارد ...! ");
                return View();
            }
        }



        [Authorize]
        public FileResult DownloadPortfolio()
        {
            string path = Server.MapPath("~/App_Data/Files");
            string fileName = Path.GetFileName("PortfolioSample.xlsx");
            string fullPath = Path.Combine(path, fileName);
            return File(fullPath, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "PortfolioSample.xlsx");
        }





        [HttpPost]
        public JsonResult LoadDataPortfolioDataStatistics()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {
                try
                {
                    var res = lq.GetFundPortfolioUpdateStatus(fundId.ToValidMsgInt(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate(),start.ToValidMsgInt(), length.ToValidMsgInt()).ToList();



                    var max = 0;
                    foreach(var item in res)
                    {
                        if (item.LastRegDate > max)
                        {
                            max =(int) item.LastRegDate;
                        }

                    }

                    res=res.Select(row => new GetFundPortfolioUpdateStatus_Result
                    {
                        RecordNum =  row.RecordNum,
                        LastRegDate = row.LastRegDate,
                        PDate = row.PDate,
                        FundId = row.FundId,
                        FullName = row.FullName,
                        Total = row.Total,
                        RowNumber = row.RowNumber,
                       MaxDate= max
                    }).ToList();

 


        //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;

        //    // int skip = start != null ? Convert.ToInt32(start) : 0;
        int recordsTotal = 0;
                    //    //total number of rows count   

                    if (res.Count != 0)
                        recordsTotal = (int)res[0].Total;
                    else recordsTotal = 0;
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = res.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }


        [HttpPost]
        [Authorize]
        public JsonResult DeletePortfolioData(string PDate, string FundId)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteFundPortfolioByDate(FundId.ToValidMsgInt(), PDate.ToValidMsgInt());
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = PDate.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }





        [HttpPost]
        [Authorize]
        public ActionResult RegisterPortfolioSymbol(FundPortfolio obj)
        {
            using (var sql = new LinqHelper())
            {
                var list = sql.GetSymbolSimilar();


                obj.RegDate = Assistant.TodayDateInt();
                obj.RegTime = Assistant.TimeNowInt();
         

                var result = sql.InsertPortfolioSymbol(obj);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);

            }
        }




        [HttpPost]
        public JsonResult LoadPortfolioSymbols()
        {
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            //---------------------------------getData------------------------------------------        
            var PDate = Request.Form.GetValues("PDate").FirstOrDefault();
            var FundId = Request.Form.GetValues("FundId").FirstOrDefault();

            using (var lq = new LinqHelper())
            {
                try
                {
                    var res = lq.GetPortfolioSymbolsByDate(FundId.ToValidMsgInt(), PDate.ToValidMsgDate()).ToList();

                    //    // int pageSize = length != null ? Convert.ToInt32(length) : 0;

                    //    // int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    //    //total number of rows count   

                    if (res != null)
                        recordsTotal = 0;
                    else recordsTotal = 0;
                    //    //Paging   
                    //    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //    ////Returning Json Data                  

                    var data = res.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });

                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }

















    }
}