﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Library.Utility;

namespace Sanay.Lotus.Erm.Controllers
{
    [Authorize]
    public class LogInfoController : Controller
    {
        // GET: LogInfo
        public ActionResult Index()
        {
            return RedirectToAction("Events");
            //return View();
        }

        public ActionResult Events(string Username)
        {
            using (var sql = new LinqHelper())
            {
                //var Users = sql.GetUserAcc().ToList();
                //ViewBag.users = Users;
                if (Username == null) { ViewBag.Username = "همه"; } else { ViewBag.Username = Username; }


            }

            return View();
        }

        public ActionResult LoadData()
        {
            try
            {

                var userName = Request.Form.GetValues("userName").FirstOrDefault().ToValidMsgString();

                var startDate = Request.Form.GetValues("startDate").FirstOrDefault().ToValidMsgDate();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault().ToValidMsgDate();
                var startTime = Request.Form.GetValues("startTime").FirstOrDefault().Replace(":", "").ToValidMsgInt();
                var endTime = Request.Form.GetValues("endTime").FirstOrDefault().Replace(":", "").ToValidMsgInt();

                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault().ToValidMsgInt();
                var length = Request.Form.GetValues("length").FirstOrDefault().ToValidMsgInt(); ;

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetEventsByFilter(userName, "%%", "%%", startDate, endDate, startTime, endTime, start, length).ToList();
                    int recordsTotal = 0;
                    if (result.Count > 0)
                        recordsTotal = result.FirstOrDefault().TotalRow ?? 0; var recordsFiltered = recordsTotal;
                    var customerData = result;

                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsFiltered,
                        recordsTotal = recordsTotal,
                        data = result
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }



    






        [HttpGet]
        public JsonResult GetUsers()
        {

            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetUserAcc()
                        .Select(x => new
                        {
                            Id = x.UserName,
                            Text = x.FullName
                        }).ToList();

                    //list.Add(new {Id = -1, Text = "همه"});
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }


    }
}