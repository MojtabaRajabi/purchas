﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Lib.Enum;

namespace Sanay.Lotus.Erm.Controllers
{
    [Authorize]
    public class FundDepositsController : Controller
    {
        // GET: FundDeposits
        public ActionResult Index()
        {
            return View();
        }

        
        public ActionResult AddDeposit()
        {
            
            return View();
        }

        [HttpPost]
        public ActionResult RegisterDeposit(FundDeposit obj)
        {
            using (var sql = new LinqHelper())
            {
                obj.RegUser = Assistant.CurrentUser();
                obj.RegDate = Assistant.TodayDateInt();
                obj.RegTime = Assistant.TimeNowInt();
               
                var result = sql.InsertFundDeposits(obj);
                sql.AutomaticDepositsFundIOFlowCycle(result,(int) obj.FundId);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        [Authorize]
        public ActionResult EditDeposit(Guid Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetFundDepositsById(Id);
                    return View(result);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        public ActionResult UpdateDeposit(FundDeposit obj)
        {
            using (var sql = new LinqHelper())
            {
                obj.RegUser = Assistant.CurrentUser();
                obj.RegDate = Assistant.TodayDateInt();
                obj.RegTime = Assistant.TimeNowInt();

                var item = sql.GetFundDepositsById(obj.Id);
                if (item != null)
                {
                    sql.DeleteFundDeposits(obj.Id,(int) obj.FundId);
                    var result = sql.InsertFundDeposits(obj);
                    sql.AutomaticDepositsFundIOFlowCycle(result, (int)obj.FundId);
                }
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "AccountingCode" }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult DeleteDeposits(Guid Id, int fundId)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteFundDeposits(Id, fundId);
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }



        public ActionResult LoadData()
        {
            //return null;
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            //var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            var startDate = Request.Form.GetValues("startDate").FirstOrDefault().ToValidMsgDate();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault().ToValidMsgDate();
            var fundId = Request.Form.GetValues("fundId").FirstOrDefault().ToValidMsgInt();

            if (endDate == 0) endDate = int.MaxValue;
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetFundDepositsByFundId(fundId).Where(c => c.StartDate >= startDate && c.StartDate <= endDate).OrderBy(c => c.Id).ToList();

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {
                        case "AccountNumber":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.AccountNumber).ToList();
                            else
                                result = result.OrderByDescending(p => p.AccountNumber).ToList();
                            break;
                        case "Bank":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Bank).ToList();
                            else
                                result = result.OrderByDescending(p => p.Bank).ToList();
                            break;
                        case "Rate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Rate).ToList();
                            else
                                result = result.OrderByDescending(p => p.Rate).ToList();
                            break;
                        case "PayDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.PayDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.PayDate).ToList();
                            break;
                        case "Deposit":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Deposit).ToList();
                            else
                                result = result.OrderByDescending(p => p.Deposit).ToList();
                            break;
                        case "Blocked":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Blocked).ToList();
                            else
                                result = result.OrderByDescending(p => p.Blocked).ToList();
                            break;
                        case "StartDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.StartDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.StartDate).ToList();
                            break;
                        case "MaturityDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.MaturityDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.MaturityDate).ToList();
                            break;
                    }

                    //paging Data
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();

                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        [HttpPost]
        public ActionResult PreviewIOFlow(string Rate, string Deposit, string Blocked, string PayDate, string StartDate, string MaturityDate)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.PreviewAutomaticFundDepositsInputOutputFlowCycle(Rate.ToValidMsgdouble(), Deposit.ToValidMsgdouble(), Blocked.ToValidMsgdouble(), PayDate.ToValidMsgInt(), StartDate.ToValidMsgDate(), MaturityDate.ToValidMsgDate());
                    return Json(new
                    {
                        data = result
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}