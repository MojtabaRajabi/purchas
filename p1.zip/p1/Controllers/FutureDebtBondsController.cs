﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Web.Security;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dic;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Models;
using Sanay.Library.Utility;
using Stimulsoft.Report.Components;

namespace Sanay.Lotus.Erm.Controllers
{
    public class FutureDebtBondsController : Controller
    {
        // GET: AccountingCode
        [Authorize]

        public ActionResult Index()
        {
            return View();
        }



        [Authorize]
        public ActionResult AddFutureDebtBonds()
        {
            return View();
        }



        [HttpGet]
        [Authorize]
        public ActionResult EditFutureDebtBonds(string Id)
        {
            try
            {
                using (var sql2 = new LinqHelper())
                {

                    LinqHelper sql = new LinqHelper();
                    var result = sql.GetFutureDebtBond(Guid.Parse(Id));
                    List<Role> objs = new List<Role>();
                    objs.Add(new Role() { Id = 1, Title = " 1 ماهه" });
                    objs.Add(new Role() { Id = 2, Title = " 2 ماهه" });
                    objs.Add(new Role() { Id = 3, Title = " 3 ماهه" });
                    objs.Add(new Role() { Id = 4, Title = " 4 ماهه" });
                    objs.Add(new Role() { Id = 5, Title = " 5 ماهه" });
                    objs.Add(new Role() { Id = 6, Title = " 6 ماهه" });
                    objs.Add(new Role() { Id = 7, Title = " 7 ماهه" });
                    objs.Add(new Role() { Id = 8, Title = " 8 ماهه" });
                    objs.Add(new Role() { Id = 9, Title = " 9 ماهه" });
                    objs.Add(new Role() { Id = 10, Title = " 10 ماهه" });
                    objs.Add(new Role() { Id = 11, Title = " 11 ماهه" });
                    objs.Add(new Role() { Id = 12, Title = " 12 ماهه" });


                    ViewBag.CouponPeriod = new SelectList(objs, "Id", "Title", result.CouponPeriod);



                    return View(result);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        [Authorize]
        public JsonResult DeleteFutureDebtBonds(string Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    sql.DeleteFutureDebtBonds(Guid.Parse(Id));
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }

        [Authorize]
        public ActionResult LoadData()
        {
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            var startDate = Request.Form.GetValues("startDate").FirstOrDefault().ToValidMsgDate();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault().ToValidMsgDate();

            if (endDate == 0) endDate = int.MaxValue;
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetFutureDebtBond().Where(c => c.PublishDate >= startDate && c.PublishDate <= endDate).OrderBy(c => c.Id).ToList();


                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {
                        case "PublishDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.PublishDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.PublishDate).ToList();
                            break;
                        case "Company":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Company).ToList();
                            else
                                result = result.OrderByDescending(p => p.Company).ToList();
                            break;
                        case "ServiceType":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.ServiceType).ToList();
                            else
                                result = result.OrderByDescending(p => p.ServiceType).ToList();
                            break;
                        case "Value":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Value).ToList();
                            else
                                result = result.OrderByDescending(p => p.Value).ToList();
                            break;
                        case "BondRate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.BondRate).ToList();
                            else
                                result = result.OrderByDescending(p => p.BondRate).ToList();
                            break;
                        case "IpoFee":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.IpoFee).ToList();
                            else
                                result = result.OrderByDescending(p => p.IpoFee).ToList();
                            break;
                        case "MarketMakingFee":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.MarketMakingFee).ToList();
                            else
                                result = result.OrderByDescending(p => p.MarketMakingFee).ToList();
                            break;
                        case "InitialCapital":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.InitialCapital).ToList();
                            else
                                result = result.OrderByDescending(p => p.InitialCapital).ToList();
                            break;
                        case "CouponPeriod":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.CouponPeriod).ToList();
                            else
                                result = result.OrderByDescending(p => p.CouponPeriod).ToList();
                            break;
                        case "RedeemDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.RedeemDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.RedeemDate).ToList();
                            break;
                    }

                    //paging Data
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();

                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [HttpPost]
        [Authorize]
        public ActionResult RegisterFutureDebtBond(FutureDebtBond obj)
        {
            using (var sql = new LinqHelper())
            {
                obj.RegUser = Assistant.CurrentUser();
                obj.RegDate = Assistant.TodayDateInt();
                obj.RegTime = Assistant.TimeNowInt();
                var result = sql.InsertFutureDebtBond(obj);
                sql.AutomaticFutureDebtBondsInputOutputFlow(result);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        [Authorize]
        public ActionResult PreviewIOFlow(string PublishDate, string Value, string BondRate
            , string IpoFee, string MarketMakingFee, string InitialCapital, string CouponPeriod, string RedeemDate)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.PreviewAutomaticFutureDebtBondsInputOutputFlow(PublishDate.ToValidMsgDate(), RedeemDate.ToValidMsgDate(), CouponPeriod.ToValidMsgInt()
                                     , Value.ToValidMsgdouble(), InitialCapital.ToValidMsgdouble(), IpoFee.ToValidMsgdouble(), MarketMakingFee.ToValidMsgdouble());
                    return Json(new
                    {
                        data = result
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        [HttpPost]
        public ActionResult UpdateFutureDebtBonds(FutureDebtBond obj)
        {
            using (var sql = new LinqHelper())
            {

                obj.RegUser = Assistant.CurrentUser();
                obj.RegDate = Assistant.TodayDateInt();
                obj.RegTime = Assistant.TimeNowInt();

                var item = sql.GetFutureDebtBond(obj.Id);
                if (item != null)
                {
                    sql.DeleteFutureDebtBonds(obj.Id);
                    var result = sql.InsertFutureDebtBond(obj);
                    sql.AutomaticFutureDebtBondsInputOutputFlow(result);
                    //var result = sql.UpdateFutureDebtBond(obj);
                }
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "AccountingCode" }, JsonRequestBehavior.AllowGet);


            }
        }


    }
}