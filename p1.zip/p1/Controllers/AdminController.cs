﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Sanay.Lotus.Erm.Lib.Enum;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Models;

namespace Sanay.Lotus.Erm.Controllers
{
    public class AdminController : Controller
    {
        [Authorize]
        public ActionResult Index()
        {
            // CheckAccount();
            return View();
        }
        [Authorize]
        public ActionResult Index2()
        {
            return View();
        }
        private void CheckAccount()
        {
            HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            if (authCookie == null) Redirect("/Accounts/login");
            FormsAuthenticationTicket ticket2 = FormsAuthentication.Decrypt(authCookie.Value);
            if (string.IsNullOrEmpty(ticket2.Name) || ticket2.UserData != ((int)UserRole.Admin).ToString()) Redirect("/Accounts/login");
        }

        [Authorize]
        public ActionResult ChangePassword()
        {
            return View();
        }

        [HttpPost]
        [Authorize]
        public ActionResult UpdatePassword(UserAccount userInfo)
        {
            var userName = HttpContext.User.Identity.Name;
            userInfo.UserName = userName;

            using (var sql = new LinqHelper())
            {
                //checked password
                var resultCheckPass = sql.CheckLogin(userInfo);
                if (resultCheckPass != null)
                {
                    //Update password
                    var result = sql.UpdatePassword(userInfo);
                    return Json(new MessageResponse { Success = true, Message = result.ToString(), ReturnUrl = "" },
                        JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new MessageResponse { Success = false, Message = "", ReturnUrl = "" },
                        JsonRequestBehavior.AllowGet);
                }
            }
        }


    }
}