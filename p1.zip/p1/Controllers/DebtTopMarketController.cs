﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Library.Utility;

namespace Sanay.Lotus.Erm.Controllers
{
    [Authorize]
    public class DebtTopMarketController : Controller
    {
        // GET: DebtTopMarket
        public ActionResult Index()
        {
            return View();
        }


        [HttpPost]
        public JsonResult GetTableTotalLimitsBuy()
     
        {
            using (var sql = new LinqHelper())
            {
                try
                {

                    var categoryMarkets = new List<int>();
                    for (int i = 1; i <= 7; i++)
                        categoryMarkets.Add(Request.Form.GetValues("ch" + i).FirstOrDefault().TryParseInt32());
                    categoryMarkets = categoryMarkets.Where(c => c > 0).ToList();
                    var ch7 = Request.Form.GetValues("ch7").FirstOrDefault();
                    if (ch7 == "-1") categoryMarkets.Add(0);

                    var chMd0 = Request.Form.GetValues("chMd0").FirstOrDefault();
                    var chMd1 = Request.Form.GetValues("chMd1").FirstOrDefault();
                    var chMd2 = Request.Form.GetValues("chMd2").FirstOrDefault();
                    var chMd3 = Request.Form.GetValues("chMd3").FirstOrDefault();
                    var chMd4 = Request.Form.GetValues("chMd4").FirstOrDefault();
                    var chMd5 = Request.Form.GetValues("chMd5").FirstOrDefault();


                    var result = sql.GetTotalLimitsBuy().ToList();

                    result = result.Where(c => categoryMarkets.Contains(c.GroupId)).ToList();

                    var obj1 = chMd1.TryParseInt32() > 0 ? result.Where(c => c.MaturityDays >= 0 && c.MaturityDays < 90).ToList() : null;
                    var obj2 = chMd2.TryParseInt32() > 0 ? result.Where(c => c.MaturityDays >= 90 && c.MaturityDays < 180).ToList() : null;
                    var obj3 = chMd3.TryParseInt32() > 0 ? result.Where(c => c.MaturityDays >= 180 && c.MaturityDays < 360).ToList() : null;
                    var obj4 = chMd4.TryParseInt32() > 0 ? result.Where(c => c.MaturityDays >= 360 && c.MaturityDays < 720).ToList() : null;
                    var obj5 = chMd5.TryParseInt32() > 0 ? result.Where(c => c.MaturityDays >= 720).ToList() : null;

                    var allList = new List<GetTotalLimitsBuy_Result>();
                    if (chMd0 != "-1")
                    {
                        if (obj1 != null) allList.AddRange(obj1);
                        if (obj2 != null) allList.AddRange(obj2);
                        if (obj3 != null) allList.AddRange(obj3);
                        if (obj4 != null) allList.AddRange(obj4);
                        if (obj5 != null) allList.AddRange(obj5);
                    }
                    else
                    {
                        allList.AddRange(result);
                    }

                    return Json(new
                    {
                        data = allList
                    });
                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }

        [HttpPost]
        public JsonResult GetTableTotalLimitsSell()
       
        {
            using (var sql = new LinqHelper())
            {
                try
                {
                    var categoryMarkets = new List<int>();
                    for (int i = 1; i <= 7; i++)
                        categoryMarkets.Add(Request.Form.GetValues("ch" + i).FirstOrDefault().TryParseInt32());
                    categoryMarkets = categoryMarkets.Where(c => c > 0).ToList();
                    var ch7 = Request.Form.GetValues("ch7").FirstOrDefault();
                    if (ch7 == "-1") categoryMarkets.Add(0);

                    var chMd0 = Request.Form.GetValues("chMd0").FirstOrDefault();
                    var chMd1 = Request.Form.GetValues("chMd1").FirstOrDefault();
                    var chMd2 = Request.Form.GetValues("chMd2").FirstOrDefault();
                    var chMd3 = Request.Form.GetValues("chMd3").FirstOrDefault();
                    var chMd4 = Request.Form.GetValues("chMd4").FirstOrDefault();
                    var chMd5 = Request.Form.GetValues("chMd5").FirstOrDefault();


                    var result = sql.GetTotalLimitsSell().ToList();

                    result = result.Where(c => categoryMarkets.Contains(c.GroupId)).ToList();

                    var obj1 = chMd1.TryParseInt32() > 0 ? result.Where(c => c.MaturityDays >= 0 && c.MaturityDays < 90).ToList() : null;
                    var obj2 = chMd2.TryParseInt32() > 0 ? result.Where(c => c.MaturityDays >= 90 && c.MaturityDays < 180).ToList() : null;
                    var obj3 = chMd3.TryParseInt32() > 0 ? result.Where(c => c.MaturityDays >= 180 && c.MaturityDays < 360).ToList() : null;
                    var obj4 = chMd4.TryParseInt32() > 0 ? result.Where(c => c.MaturityDays >= 360 && c.MaturityDays < 720).ToList() : null;
                    var obj5 = chMd5.TryParseInt32() > 0 ? result.Where(c => c.MaturityDays >= 720).ToList() : null;

                    var allList = new List<GetTotalLimitsSell_Result>();
                    if (chMd0 != "-1")
                    {
                        if (obj1 != null) allList.AddRange(obj1);
                        if (obj2 != null) allList.AddRange(obj2);
                        if (obj3 != null) allList.AddRange(obj3);
                        if (obj4 != null) allList.AddRange(obj4);
                        if (obj5 != null) allList.AddRange(obj5);
                    }
                    else
                    {
                        allList.AddRange(result);
                    }


                    return Json(new
                    {
                        data = allList
                    });
                }
                catch (Exception ex)
                {
                    return null;
                }
            }

        }

    }
}