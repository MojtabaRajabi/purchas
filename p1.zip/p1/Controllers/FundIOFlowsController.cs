﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.DataAccess.Helper;
using System.Data;
using Sanay.Lotus.Erm.DataAccess;
using System.IO;
using ExcelDataReader;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Lib.Enum;

namespace Sanay.Lotus.Erm.Controllers
{
    public class FundIoFlowsController : Controller
    {

        // GET: IOFlows
        [Authorize]
        public ActionResult Index()
        {
            ViewBag.EndDate = Assistant.MiladiToShamsiWithSlash(Convert.ToInt32(DateTime.Now.ToString("yyyyMMdd")));
            ViewBag.StartDate = Assistant.GetYear(Assistant.MiladiToShamsi(Convert.ToInt32(DateTime.Now.ToString("yyyyMMdd")))).ToString();
            ViewBag.StartDate = ViewBag.StartDate + "/01/01";
            ViewBag.FundId = (int) FundNames.charity;
            return View();
        }

        [Authorize]
        public FileResult Download()
        {
            string path = Server.MapPath("~/App_Data/Files");
            string fileName = Path.GetFileName("sample.xlsx");
            string fullPath = Path.Combine(path, fileName);
            return File(fullPath, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "IOFlowsSample.xlsx");
        }
        [Authorize]
        public ActionResult Import()
        {
            return View();
        }

        [Authorize]
        public ActionResult Generates()
        {
            return View();
        }

        [Authorize]
        public ActionResult TestPage()
        {
            return View();
        }
        [Authorize]
        public ActionResult IOFlowDetails(string Tag, string returnLink, string fundId)
        {
            ViewBag.Tag = Tag;
            ViewBag.fundId = fundId;
            if (returnLink == null) ViewBag.returnLink = "1"; else ViewBag.returnLink = returnLink;

            return View();
        }

        [HttpPost]
        [Authorize]
        public ActionResult RegisterGenerateInfo(string IOFlowCycles, string StartDate, string EndDate, string Value)
        {
            using (var sql = new LinqHelper())
            {

                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Import(HttpPostedFileBase upload, string IO)
        {
            // اعتبار سنجی فایل آپلود شده
            if (upload != null && upload.ContentLength > 0 && (upload.FileName.EndsWith(".xls") || upload.FileName.EndsWith(".xlsx")))
            {
                Stream stream = upload.InputStream;

                using (MemoryStream ms = new MemoryStream())
                {
                    stream.CopyTo(ms);
                    var data = ms.ToArray();

                    IExcelDataReader reader = ExcelReaderFactory.CreateReader(stream);
                    DataSet result = reader.AsDataSet(new ExcelDataSetConfiguration()
                    {
                        ConfigureDataTable = (tableReader) => new ExcelDataTableConfiguration()
                        {
                            UseHeaderRow = false
                        }
                    });
                    var datatable = result.Tables[0];
                    var colHeader1 = datatable.Rows[0][0].ToString();
                    var colHeader2 = datatable.Rows[0][1].ToString();

                    if (reader.FieldCount == 2 && colHeader1 == "تاریخ" && colHeader2 == "مبلغ")
                    {
                        DataAccess.File fileObj = new DataAccess.File();
                        using (var sql = new LinqHelper())
                        {

                            fileObj.Name = Path.GetFileNameWithoutExtension(upload.FileName);
                            fileObj.Extension = Path.GetExtension(upload.FileName);
                            fileObj.Size = data.Length;
                            fileObj.Sender = Assistant.CurrentUser();
                            fileObj.StatusId = 1;
                            fileObj.RegDate = Convert.ToInt32(Assistant.MiladiToShamsi(Assistant.TodayDateIntMiladi()));
                            fileObj.RegTime = Assistant.TimeNowInt();
                            fileObj.Binary = data;
                            fileObj.FileTypeId = Convert.ToInt32(IO);
                            var res = sql.InsertPosition(fileObj);

                            List<DataAccess.InputOutputFlow> list = datatable.AsEnumerable().Skip(1)
                                .Select(row => new DataAccess.InputOutputFlow
                                {
                                    AffectDate = (row.Field<string>(0)).TryParseInt32(),
                                    Val = (double?)(row.Field<Object>(1)).ToString().TryParseDouble(),//todo:

                                    InputOutputFlowType = IO.TryParseInt32(),
                                    IsFuture = true,
                                    TagSource = (int)IOFlowSources.FileUploud

                                })
                                .ToList();

                            foreach (var item in list)
                            {
                                sql.InsertInputOutputFlow(item);
                            }
                        }
                        reader.Close();
                        return View(datatable);
                    }
                }
            }

            ModelState.AddModelError("File", "خطایی رخ داده! فایل مورد نظر با فایل استاندارد همخوانی ندارد ...! ");
            return View();
        }


        public List<GetFundInputOutputFlows_Result> result = new List<GetFundInputOutputFlows_Result>();



        [Authorize]
        public ActionResult LoadData()
        {
            try
            {

                var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
                var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    result = sql.GetFundsInputOutputFlows(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(),-1, fundId.ToValidMsgInt());

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    var data = result.ToList();
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        [Authorize]
        public ActionResult loadIOFlowSourceNavs()
        {
            try
            {
                var pdate = Request.Form.GetValues("pdate").FirstOrDefault();
                //var IOFlowType = Request.Form.GetValues("type").FirstOrDefault();
                var fundId = Request.Form.GetValues("fundId").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var Result = sql.GetNavsByDateId(fundId.ToValidMsgInt(), pdate.ToValidMsgDate()).ToList();
               
                    int recordsTotal = 0;
                    recordsTotal = Result.Count();
                    var data = Result.ToList();
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        [Authorize]
       

        [Authorize]
        public ActionResult loadInIOFlow()
        {
            try
            {
                var pdate = Request.Form.GetValues("pdate").FirstOrDefault();
                var type = Request.Form.GetValues("type").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var VoucherResult = sql.GetInputOutputFlowByDateType(type.ToValidMsgInt(), pdate.ToValidMsgDate());

                    int recordsTotal = 0;
                    recordsTotal = VoucherResult.Count();
                    var data = VoucherResult.ToList();
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }



        [Authorize]
        public ActionResult Generated()
        {
            return View();
        }




        [Authorize]
        public ActionResult LoadDataGenerated()
        {
            try
            {

                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetInputOutputFlowGenerates(start.ToValidMsgInt(), length.ToValidMsgInt(), searchValue, 0, 0);

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    var data = result.ToList();
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }




        [Authorize]
        public ActionResult RemoveFlow()
        {
            return View();
        }


        [HttpPost]
        [Authorize]
        public ActionResult RemoveFlowData(string startDate, string endDate, string IOFlow)
        {
            using (var sql = new LinqHelper())
            {
                sql.DeleteIOFlow(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), IOFlow.ToValidMsgInt());
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Authorize]
        public ActionResult RemoveFlowDataById(string Id)
        {
            using (var sql = new LinqHelper())
            {
                sql.RemoveInputOutputFlowById(Id.ToValidMsgInt());
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }

        [Authorize]
        public ActionResult PreviewRemoveFlowData()
        {
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            var startDate = Request.Form.GetValues("startDate").FirstOrDefault().ToValidMsgDate();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault().ToValidMsgDate();
            var IOFlow = Request.Form.GetValues("IOFlow").FirstOrDefault().ToValidMsgInt();

            if (endDate == 0) endDate = int.MaxValue;
            using (var sql = new LinqHelper())
            {
                var result = sql.GetIOFlowDetails(startDate, endDate, IOFlow,-1, "", (int)FlowTypes.Forecast, -1, -1, 0, int.MaxValue);

                //sorting Data
                sortColumnDir = sortColumnDir.ToUpper();
                switch (sortColumn)
                {
                    case "InputOutputFlowTitle":
                        if (sortColumnDir == "ASC")
                            result = result.OrderBy(p => p.InputOutputFlowTitle).ToList();
                        else
                            result = result.OrderByDescending(p => p.InputOutputFlowTitle).ToList();
                        break;
                    case "Val":
                        if (sortColumnDir == "ASC")
                            result = result.OrderBy(p => p.Val).ToList();
                        else
                            result = result.OrderByDescending(p => p.Val).ToList();
                        break;
                    case "AffectDate":
                        if (sortColumnDir == "ASC")
                            result = result.OrderBy(p => p.AffectDate).ToList();
                        else
                            result = result.OrderByDescending(p => p.AffectDate).ToList();
                        break;
                    case "IsFuture":
                        if (sortColumnDir == "ASC")
                            result = result.OrderBy(p => p.IsFuture).ToList();
                        else
                            result = result.OrderByDescending(p => p.IsFuture).ToList();
                        break;

                }

                //paging Data
                int pageSize = length != null ? Convert.ToInt32(length) : 0;
                int skip = start != null ? Convert.ToInt32(start) : 0;
                int recordsTotal = 0;
                var customerData = result;
                recordsTotal = customerData.Count();
                var data = customerData.Skip(skip).Take(pageSize).ToList();

                //Returning Json Data  
                return Json(new
                {
                    recordsFiltered = recordsTotal,
                    recordsTotal = recordsTotal,
                    data = data
                });
            }
        }

        [Authorize]
        public ActionResult LoadIOFlowDetails()
        {
            try
            {
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                //var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                //var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                //var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var fundId =  Request.Form.GetValues("fund").FirstOrDefault();
                var isFuture = -1;
                var flow = Request.Form.GetValues("flow").FirstOrDefault();
                var startDate = Request.Form.GetValues("startDate").FirstOrDefault().Trim();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault().Trim();
                var tag = Request.Form.GetValues("Tag").FirstOrDefault();

                var startValue = Request.Form.GetValues("startValue").FirstOrDefault();
                var endValue = Request.Form.GetValues("endValue").FirstOrDefault();

                startValue = startValue.Trim() == "" ? "-1" : startValue;
                endValue = endValue.Trim() == "" ? "-1" : endValue;

                using (var sql = new LinqHelper())
                {

                    var result =  sql.GetFundIOFlowDetails(startDate.ToValidMsgDate(), endDate.Replace(".", "").ToValidMsgDate(), flow.ToValidMsgInt(), tag.ToUpper(), isFuture,fundId.ToValidMsgInt(), startValue.ToValidMsgInt(), endValue.ToValidMsgInt(), 0, int.MaxValue);
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }





        [Authorize]
        public ActionResult LoadDataDeposits()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();


            try
            {
                using (var sql = new LinqHelper())
                {
                    var listTag = sql.GetFundInputOutputFlowsByDateFlow(flowDate, iOFlowType).Select(c => Guid.Parse(c.Tag)).ToList();
                    var result = sql.GetFundDeposits().Where(a => listTag.Contains(a.Id)).OrderBy(c => c.Id);

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [Authorize]
        public ActionResult LoadDataDebtBonds()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetFundInputOutputFlowsByDateFlow(flowDate, iOFlowType).Select(c => Guid.Parse(c.Tag)).ToList();
                    var result = sql.GetFundDebtBonds().Where(a => listTag.Contains(a.Id)).OrderBy(c => c.Id);

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }



        [Authorize]
        public ActionResult LoadDataIOFlowFund()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Select(c => Guid.Parse(c.Tag)).ToList();
                    var result = sql.GetIOFlowFund().Where(a => listTag.Contains(a.Id)).OrderBy(c => c.Id);

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        [Authorize]
        public ActionResult LoadDataAdditionalContractFees()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Select(c => Guid.Parse(c.Tag)).ToList();
                    listTag.AddRange(sql.GetInputOutputFlowsByDateFlow(flowDate, 15).Select(c => Guid.Parse(c.Tag)).ToList());
                    var result = sql.GetAdditionalContractFee().Where(a => listTag.Contains(a.Id)).OrderBy(c => c.Id);

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }



        [Authorize]
        public ActionResult LoadDataCapitalBonds()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Select(c => Guid.Parse(c.Tag)).ToList();
                    listTag.AddRange(sql.GetInputOutputFlowsByDateFlow(flowDate, 15).Select(c => Guid.Parse(c.Tag)).ToList());
                    var result = sql.GetCapitalBonds().Where(a => listTag.Contains(a.Id)).OrderBy(c => c.Id);

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }




        [Authorize]
        public ActionResult LoadDataManualFlows()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Select(c => Guid.Parse(c.Tag)).ToList();
                    var result = sql.GetCapitalIncreases().Where(a => listTag.Contains(a.Id)).OrderBy(c => c.Id);//todo:

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [Authorize]
        public ActionResult LoadDataManualFlowsOutputCosts()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Select(c => Guid.Parse(c.Tag)).ToList();
                    var result = sql.GetOutputCosts().Where(a => listTag.Contains(a.Id)).OrderBy(c => c.Id);//todo:

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [Authorize]
        public ActionResult LoadDataCurrentTaxAndCosts()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Select(c => Guid.Parse(c.Tag)).ToList();
                    var result = sql.GetCurrentTaxAndCost().Where(a => listTag.Contains(a.Id)).OrderBy(c => c.Id);//todo:

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        [Authorize]
        public ActionResult LoadDataFutureDebtBonds()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Select(c => Guid.Parse(c.Tag)).ToList();
                    var result = sql.GetFutureDebtBond().Where(a => listTag.Contains(a.Id)).OrderBy(c => c.Id);//todo:

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [Authorize]
        public ActionResult LoadDataBondIssuances()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Select(c => Guid.Parse(c.Tag)).ToList();
                    var result = sql.GetBondIssuances().Where(a => listTag.Contains(a.Id)).OrderBy(c => c.Id);//todo:

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        [Authorize]
        public ActionResult LoadDataFundSell()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Select(c => Guid.Parse(c.Tag)).ToList();
                    var result = sql.GetFundSell().Where(a => listTag.Contains(a.Id)).OrderBy(c => c.Id);//todo:

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

    }
}