﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dto;
using ExcelDataReader;
using Sanay.Library.Utility;
using System.IO;
using System.Data;


namespace Sanay.Lotus.Erm.Controllers
{
    public class FundsController : Controller
    {
        // GET: TalaFund
        [Authorize]
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Add(int? Id)
        {

            ViewBag.Id = Id;
            return View();
        }

        public ActionResult ContractDetailDebtTrading(int? Id)
        {

            ViewBag.Id = Id;
            return View();
        }


        public ActionResult ContractDetailDebtReception(int? Id)
        {

            ViewBag.Id = Id;
            return View();
        }


        public ActionResult ContractDetailReception(int? Id)
        {

            ViewBag.Id = Id;
            return View();
        }

        public ActionResult ContractDetailAdvice(int? Id)
        {

            ViewBag.Id = Id;
            return View();
        }

        public ActionResult ContractDetailAdviceFinancialServices(int? Id)
        {

            ViewBag.Id = Id;
            return View();
        }

        public ActionResult ContractDetailDebtBuySell(int? Id)
        {

            ViewBag.Id = Id;
            return View();
        }
        public ActionResult ContractDetailPurchaseOfServices(int? Id)
        {

            ViewBag.Id = Id;
            return View();
        }



        public ActionResult ContractDetailCapitalIncreaseSupplyAdvice(int? Id)
        {

            ViewBag.Id = Id;
            return View();
        }

        public ActionResult FundNAVs(string FundName)
        {

            ViewBag.Name = FundName;
            ViewBag.StartDate = Assistant.LastYear();
            ViewBag.EndDate = Assistant.TodayDateBySlash();
            return View();
        }
        public ActionResult ContractDetailValuations(int? Id)
        {

            ViewBag.Id = Id;
            return View();
        }
        public ActionResult FundInvestorOrders(int? Id)
        {
            using (var sql = new LinqHelper())
            {
                List<Fund> List1 = sql.GetFundInvestorOrdersFunds().OrderBy(c => c.Id).ToList();
                List<FundInvestorOrder> List2 = sql.GetFundInvestorOrdersType().OrderBy(c => c.FundId).ToList();

                ViewBag.FundInvestorOrdersFunds = List1;
                ViewBag.FundInvestorOrdersType = List2;
            }

            ViewBag.Id = Id;
            return View();
        }

        public ActionResult CapitalTurnover()
        {
            //using (var sql = new LinqHelper())
            //{
            //    List<Fund> list = sql.getFundlist().OrderBy(c => c.Id).ToList();
            //    ViewBag.Funds = list;

            //}
            using (var sql = new LinqHelper())
            {
                var funds = sql.GetFunds().OrderBy(c => c.Name)
                    .ToList();
                ViewBag.funds = funds;

                var fundsType = funds.Select(c => c.FundType).Distinct().ToList();
                ViewBag.fundsType = fundsType;
            }





            ViewBag.startDate = Assistant.DateToDisplayMode(Assistant.Last3Months());
            ViewBag.endDate = Assistant.TodayDateBySlash();

            return View();
        }




        [HttpPost]
        public JsonResult LoadFundsCapitalTurnoverChart(string startDate, string endDate, string manager)
        {
            try
            {
                using (var sql = new LinqHelper())
                {

                    var result =
                    sql.GetFundsCapitalTurnoverByManager(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), manager);
                    var list = result.ToList()
                        .Select(x => new
                        {
                            PurchaseNAVPerShare = x.PurchaseNAVPerShare,
                            SellNAVPerShare = x.SellNAVPerShare,
                            _JalaliDate = x._JalaliDate,
                            JalaliDate = x.JalaliDate,
                            FundType = x.FundType,
                            Description = x.Description
                        }).ToList();
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        public JsonResult LoadFundsCapitalTurnoverDetailesByManager(string startDate, string endDate, string manager)
        {
            try
            {
                using (var sql = new LinqHelper())
                {

                    var result =
                    sql.GetFundsCapitalTurnoverDetailesByManager(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), manager);
                    var list = result.ToList()
                        .Select(x => new
                        {
                            //PurchaseNAVPerShare = x.PurchaseNAVPerShare,
                            Gap = x.Gap,
                            _JalaliDate = x._JalaliDate,
                            JalaliDate = x.JalaliDate,
                            Name = x.Name,
                            Description = x.Description
                            //,RowNumber = x.RowNumber
                        }).ToList();


                    //list=list.OrderBy(c => c.Name).ThenBy(c=>c.JalaliDate).ToList();




                    return Json(list, JsonRequestBehavior.AllowGet);
                    // return Json(new object { jsonSeries, "بدليل تکراري بودن قابل ثبت نيست", ReturnUrl = "" });

                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        public JsonResult InsertChartDesc(string Desc, string chartDate, string chartName)
        {
            try
            {
                using (var sql = new LinqHelper())
                {



                    var obj = new FundTypeDescription();
                    obj.FundTypeName = chartName;
                    obj.PDate = chartDate.ToValidMsgDate();
                    obj.Description = Desc;


                    sql.InsertChartDescription(obj);

                    //list=list.OrderBy(c => c.Name).ThenBy(c=>c.JalaliDate).ToList();
                    return Json("ok", JsonRequestBehavior.AllowGet);
                    // return Json(new object { jsonSeries, "بدليل تکراري بودن قابل ثبت نيست", ReturnUrl = "" });

                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }









        [Authorize]
        public ActionResult LoadBestFundManagerData()
        {
            try
            {
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form
                    .GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]")
                    .FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
                var FundType = Request.Form.GetValues("FundType").FirstOrDefault();


                using (var sql = new LinqHelper())
                {
                    var result = sql.GetFundsMarketCapitalTurnover(
                                                    startDate.ToValidMsgDate(),
                                                    endDate.ToValidMsgDate(),
                                                    FundType
                                                     ).ToList();
                    var list = result.GroupBy(d => d.FundType)
                                        .Select(
                                            g => new GetFundsMarketCapitalTurnover_Result
                                            {
                                                FundType = g.First().FundType + "     ",
                                                Manager = "جمع کل ",
                                                RowNumber = g.First().RowNumber,

                                                Gap = g.Sum(s => s.Gap),
                                                PurchaseNAVPerShare = g.Sum(s => s.PurchaseNAVPerShare),
                                                SellNAVPerShare = g.Sum(s => s.SellNAVPerShare),
                                            }).ToList();



                    result.AddRange(list);


                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {
                        case "PurchaseNAVPerShare":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.PurchaseNAVPerShare).ToList();
                            else
                                result = result.OrderByDescending(p => p.PurchaseNAVPerShare).ToList();
                            break;
                        case "SellNAVPerShare":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.SellNAVPerShare).ToList();
                            else
                                result = result.OrderByDescending(p => p.SellNAVPerShare).ToList();
                            break;
                        case "Gap":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Gap).ToList();
                            else
                                result = result.OrderByDescending(p => p.Gap).ToList();
                            break;
                        case "Manager":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Manager).ToList();
                            else
                                result = result.OrderByDescending(p => p.Manager).ToList();
                            break;
                    }

                    result = result.OrderBy(c => c.FundType).ToList();




                    //Paging Size (10,20,50,100)  
                    //int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;

                    // Getting all Customer data  
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    //Paging   
                    // var data = customerData.Skip(skip).Take(pageSize).ToList();
                    var data = customerData.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        //  draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [Authorize]
        public ActionResult LoadFundsManagerCapitalTurnover()
        {
            try
            {
                // SqlHelper sql = new SqlHelper();
                //var draw = Request.Form.GetValues("draw").FirstOrDefault();
                //var start = Request.Form.GetValues("start").FirstOrDefault();
                //var length = Request.Form.GetValues("length").FirstOrDefault();
                //var sortColumn = Request.Form
                //    .GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]")
                //    .FirstOrDefault();
                //var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                //var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
                var manager = Request.Form.GetValues("manager").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetFundsManagerCapitalTurnover(
                                                    startDate.ToValidMsgDate(),
                                                    endDate.ToValidMsgDate(),
                                                    manager
                                                     );


                    //sortColumnDir = sortColumnDir.ToUpper();
                    //switch (sortColumn)
                    //{
                    //    case "PurchaseNAVPerShare":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.PurchaseNAVPerShare).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.PurchaseNAVPerShare).ToList();
                    //        break;
                    //    case "SellNAVPerShare":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.SellNAVPerShare).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.SellNAVPerShare).ToList();
                    //        break;
                    //    case "Gap":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.Gap).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.Gap).ToList();
                    //        break;
                    //    case "Manager":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.Manager).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.Manager).ToList();
                    //        break;
                    //}


                    result = result.OrderBy(c => c.Manager).ToList();


                    result = result.OrderByDescending(c => c.RowNumber).ToList();

                    //if (result.Count == 1)
                    //{
                    //    result = null;
                    //}

                    //Paging Size (10,20,50,100)  
                    //int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;

                    // Getting all Customer data  
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    //Paging   
                    // var data = customerData.Skip(skip).Take(pageSize).ToList();
                    var data = customerData.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        // draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }



        [Authorize]
        public ActionResult LoadCapitalTurnoverManagerDetailes()
        {
            try
            {
                // SqlHelper sql = new SqlHelper();
                //var draw = Request.Form.GetValues("draw").FirstOrDefault();
                //var start = Request.Form.GetValues("start").FirstOrDefault();
                //var length = Request.Form.GetValues("length").FirstOrDefault();
                //var sortColumn = Request.Form
                //    .GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]")
                //    .FirstOrDefault();
                //var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                //var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
                var manager = Request.Form.GetValues("manager").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetFundsCapitalTurnoverFundDetailes(
                                                    startDate.ToValidMsgDate(),
                                                    endDate.ToValidMsgDate(),
                                                    manager
                                                     );


                    //sortColumnDir = sortColumnDir.ToUpper();
                    //switch (sortColumn)
                    //{
                    //    case "PurchaseNAVPerShare":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.PurchaseNAVPerShare).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.PurchaseNAVPerShare).ToList();
                    //        break;
                    //    case "SellNAVPerShare":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.SellNAVPerShare).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.SellNAVPerShare).ToList();
                    //        break;
                    //    case "Gap":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.Gap).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.Gap).ToList();
                    //        break;
                    //    case "Name":
                    //        if (sortColumnDir == "ASC")
                    //            result = result.OrderBy(p => p.Name).ToList();
                    //        else
                    //            result = result.OrderByDescending(p => p.Name).ToList();
                    //        break;
                    //}

                    result = result.OrderByDescending(c => c.RowNumber).ToList();

                    //if (result.Count == 1)
                    //{
                    //    result = null;
                    //}

                    //Paging Size (10,20,50,100)  
                    //int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    //int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;

                    // Getting all Customer data  
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    //Paging   
                    //var data = customerData.Skip(skip).Take(pageSize).ToList();
                    var data = customerData.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        //draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }























        public ActionResult FundDetails(string Id)
        {
            if (Id == null) { ViewBag.Id = "0"; } else { ViewBag.Id = Id; }
            //if (Account == null) { ViewBag.Account = "همه"; } else { ViewBag.Account = Account; }
            //if (StartDate == null) { ViewBag.StartDate = Assistant.MiladiToShamsiWithSlash(Assistant.TodayDateIntMiladi()); } else { ViewBag.StartDate = StartDate; }
            //if (EndDate == null) { ViewBag.EndDate = Assistant.MiladiToShamsiWithSlash(Assistant.TodayDateIntMiladi()); } else { ViewBag.EndDate = EndDate; }

            //ViewBag.pDate = Assistant.MiladiToShamsiWithSlash(Assistant.TodayDateIntMiladi());

            return View();
        }


        public ActionResult FundContracts()
        {

            using (var sql = new LinqHelper())
            {
                List<FundContract> List1 = sql.GetFundCategory().OrderBy(c => c.CategoryName).ToList();
                List<FundContract> List2 = sql.GetFundContractType().OrderBy(c => c.ContractType).ToList();
                List<FundContract> List3 = sql.GetFundContractState().OrderBy(c => c.ContractState).ToList();
                List<FundContract> List4 = sql.GetFundContractSector().OrderBy(c => c.ContractSector).ToList();

                ViewBag.FundCategory = List1;
                ViewBag.FundContractType = List2;
                ViewBag.FundContractState = List3;
                ViewBag.FundContractSector = List4;

            }
            return View();
        }







        [HttpGet]
        public JsonResult GetFunds(string term)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetFunds()
                        .Select(x => new
                        {
                            Name = x.Name,
                            Manager = x.Manager,
                            Guaranteer = x.Guaranteer,
                            Owner = x.Owner,
                            FundType = x.FundType
                        }).ToList();

                    //list.Add(new {Id = -1, Text = "همه"});
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }





        [Authorize]
        public ActionResult LoadData()
        {
            try
            {
                // SqlHelper sql = new SqlHelper();
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form
                    .GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]")
                    .FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var Name = Request.Form.GetValues("Name").FirstOrDefault();
                var Manager = Request.Form.GetValues("Manager").FirstOrDefault();
                var Guaranteer = Request.Form.GetValues("Guaranteer").FirstOrDefault();
                var Owner = Request.Form.GetValues("Owner").FirstOrDefault();
                var FundType = Request.Form.GetValues("FundType").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetFunds(
                                                    Name,
                                                    Manager,
                                                    Guaranteer,
                                                    Owner,
                                                    FundType, sortColumn, sortColumnDir);


                    //Paging Size (10,20,50,100)  
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;

                    // Getting all Customer data  
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    //Paging   
                    var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        [Authorize]
        public ActionResult LoadFundNavData()
        {
            try
            {
                // SqlHelper sql = new SqlHelper();
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form
                    .GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]")
                    .FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var Name = Request.Form.GetValues("Name").FirstOrDefault();
                var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault();

                using (var sql = new LinqHelper())
                {

                    var fundId = sql.GetFundIdByFundName(Name).Id;
                    var result = sql.GetFundNAVs(
                                                    fundId,
                                                    startDate.ToValidMsgDate(),
                                                    endDate.ToValidMsgDate()
                                                   );

                    //Paging Size (10,20,50,100)  
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;

                    // Getting all Customer data  
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    //Paging   
                    var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }











        [HttpPost]
        [Authorize]
        public JsonResult LoadContractDetailDebtTrading(string Id)
        {
            using (var sql = new LinqHelper())
            {

                var result = sql.LoadContractDetailDebtTrading(Id.TryParseInt32());

                return Json(result, JsonRequestBehavior.AllowGet);


            }
        }



        [HttpPost]
        [Authorize]
        public JsonResult LoadContractDetailDebtReception(string Id)
        {
            using (var sql = new LinqHelper())
            {
                var result = sql.LoadContractDetailDebtReception(Id.TryParseInt32());
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Authorize]
        public JsonResult LoadContractDetailReception(string Id)
        {
            using (var sql = new LinqHelper())
            {

                var result = sql.LoadContractDetailReception(Id.TryParseInt32());

                return Json(result, JsonRequestBehavior.AllowGet);


            }
        }

        [HttpPost]
        [Authorize]
        public JsonResult LoadContractDetailValuations(string Id)
        {
            using (var sql = new LinqHelper())
            {

                var result = sql.LoadContractDetailValuations(Id.TryParseInt32());

                return Json(result, JsonRequestBehavior.AllowGet);


            }
        }
        [HttpPost]
        [Authorize]
        public JsonResult LoadContractDetailPurchaseOfServices(string Id)
        {
            using (var sql = new LinqHelper())
            {
                var result = sql.LoadContractDetailPurchaseOfServices(Id.TryParseInt32());
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }





        [HttpPost]
        [Authorize]
        public JsonResult LoadContractDetailCapitalIncreaseSupplyAdvice(string Id)
        {
            using (var sql = new LinqHelper())
            {
                var result = sql.GetContractDetailCapitalIncreaseSupplyAdvice(Id.TryParseInt32());
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }




        [HttpPost]
        [Authorize]
        public JsonResult LoadContractDetailDebtBuySell(string Id)
        {
            using (var sql = new LinqHelper())
            {

                var result = sql.LoadContractDetailDebtBuySell(Id.TryParseInt32());

                return Json(result, JsonRequestBehavior.AllowGet);


            }
        }
        [HttpPost]
        [Authorize]
        public JsonResult LoadContractDetailAdvice(string Id)
        {
            using (var sql = new LinqHelper())
            {

                var result = sql.LoadContractDetailAdvice(Id.TryParseInt32());

                return Json(result, JsonRequestBehavior.AllowGet);


            }
        }


        [HttpPost]
        [Authorize]
        public JsonResult ContractDetailAdviceFinancialServices(string Id)
        {
            using (var sql = new LinqHelper())
            {
                var result = sql.ContractDetailAdviceFinancialServices(Id.TryParseInt32());
                return Json(result, JsonRequestBehavior.AllowGet);

            }
        }



        [Authorize]
        public ActionResult LoadFundContracts()
        {
            try
            {
                // SqlHelper sql = new SqlHelper();
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();

                var CategoryId = Request.Form.GetValues("CategoryId").FirstOrDefault();
                var ContractType = Request.Form.GetValues("ContractType").FirstOrDefault();
                var ContractState = Request.Form.GetValues("ContractState").FirstOrDefault();
                var ContractSector = Request.Form.GetValues("ContractSector").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetFundContracts(
                                                    CategoryId.ToValidMsgInt(),
                                                    ContractType.ToValidMsgStringWithPresentage(),
                                                    ContractState.ToValidMsgStringWithPresentage(),
                                                    ContractSector.ToValidMsgStringWithPresentage()
                                                    );


                    //Paging Size (10,20,50,100)  
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;

                    // Getting all Customer data  
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    //Paging   
                    var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        [Authorize]
        public ActionResult LoadFundPayments()
        {
            try
            {
                // SqlHelper sql = new SqlHelper();
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();

                var Id = Request.Form.GetValues("Id").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetFundPayments(Id.ToValidMsgInt());


                    //Paging Size (10,20,50,100)  
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;

                    // Getting all Customer data  
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    //Paging   
                    var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [Authorize]
        public ActionResult LoadFundCorrectiveComments()
        {
            try
            {
                // SqlHelper sql = new SqlHelper();
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();

                var Id = Request.Form.GetValues("Id").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetFundCorrectiveComments(Id.ToValidMsgInt());


                    //Paging Size (10,20,50,100)  
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;

                    // Getting all Customer data  
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    //Paging   
                    var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [Authorize]
        public ActionResult LoadFundInvestorOrders()
        {
            try
            {
                // SqlHelper sql = new SqlHelper();
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();



                var Fund = Request.Form.GetValues("Fund").FirstOrDefault();
                var FundType = Request.Form.GetValues("FundType").FirstOrDefault();
                var StartDate = Request.Form.GetValues("StartDate").FirstOrDefault();
                var EndDate = Request.Form.GetValues("EndDate").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetFundInvestorOrdersById(
                                                    Fund.ToValidMsgInt()
                                                   , FundType.ToValidMsgInt()
                                                   , StartDate.ToValidMsgDate()
                                                   , EndDate.ToValidMsgDate());


                    //Paging Size (10,20,50,100)  
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;

                    // Getting all Customer data  
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    //Paging   
                    var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }





        [HttpPost]
        [Authorize]
        public JsonResult LoadIndustriesData(string Id)
        {
            using (var sql = new LinqHelper())
            {
                var result = sql.GetFundIndustriesByFundId(Id.TryParseInt32());
                return Json(result, JsonRequestBehavior.AllowGet);


            }
        }

        [HttpPost]
        [Authorize]
        public JsonResult LoadMixAssetsData(string Id)
        {
            using (var sql = new LinqHelper())
            {

                var result = sql.GetFundMixAssetsByFundId(Id.TryParseInt32());

                return Json(result, JsonRequestBehavior.AllowGet);


            }
        }


        [HttpPost]
        [Authorize]
        public JsonResult LoadFundData(string Id)
        {
            using (var sql = new LinqHelper())
            {

                var result = sql.GetFundDataByFundId(Id.TryParseInt32());

                return Json(result, JsonRequestBehavior.AllowGet);


            }
        }

        [HttpPost]
        [Authorize]
        public JsonResult LoadFundProperties(string Id)
        {
            using (var sql = new LinqHelper())
            {

                var result = sql.GetFundPropertiesByFundId(Id.TryParseInt32());

                return Json(result, JsonRequestBehavior.AllowGet);


            }
        }


        [HttpGet]
        public JsonResult GetDebtTitle()
        {

            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetLastMajorShareHolders()
                        .Select(x => new
                        {

                            Text = x
                        }).ToList();

                    //list.Add(new {Id = -1, Text = "همه"});
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }






        [HttpPost]
        [Authorize]
        public ActionResult RegisterFundBondAssets(DataAccess.FundBondAsset obj)
        {
            using (var sql = new LinqHelper())
            {
                obj.RegUser = Assistant.CurrentUser();
                obj.RegDate = Assistant.TodayDateInt();
                obj.RegTime = Assistant.TimeNowInt();

                int FundId = obj.FundId.GetValueOrDefault();
                if (sql.GetFundBondAsset(FundId).Where(p => p.ShareHolders.Contains(obj.ShareHolders)).Count() == 0)
                {
                    var result = sql.InsertFundBondAssets(obj);
                    return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);

                }
                else
                    return Json(new MessageResponse { Success = false, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);

            }
        }


        [HttpPost]
        [Authorize]
        public ActionResult LoadFundDebtData()
        {

            try
            {
                var FundId = Request.Form.GetValues("Id").FirstOrDefault();
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetFundBondAsset(FundId.ToValidMsgInt());
                    if (result == null)
                    {
                        return Json(new
                        {
                            recordsFiltered = 0,
                            recordsTotal = 0,
                            data = ""
                        });
                    }
                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    var data = result.ToList();
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [HttpPost]
        [Authorize]
        public ActionResult LoadFundBondAssets(string Id)
        {
            using (var sql = new LinqHelper())
            {

                var result = sql.GetFundBondAsset(Id.ToValidMsgInt());

                return Json(result, JsonRequestBehavior.AllowGet);


            }

        }


        [HttpPost]
        [Authorize]
        public JsonResult DeleteFundDebt(int Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteFundDebt(Id);
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }

        [HttpPost]
        [Authorize]
        public JsonResult AddContractFlow(int ContractId)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.AddContractFlow(ContractId);
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = ContractId.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }


        [HttpPost]
        [Authorize]
        public JsonResult UpdateContracts()
        {
            try
            {
                using (var sql = new LinqHelper())
                {

                    Service obj = new Service();
                    obj.Id = 8;
                    obj.Title = "MFR";
                    obj.HasUpdate = false;


                    //sql.DeleteFundContracts();

                    var result = sql.UpdateContracts(obj);
                    return Json(data: "Success", behavior: JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = "Error", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }


        [HttpPost]
        [Authorize]
        public JsonResult DeleteContractFlowByTag(int contractId)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteContractFlowByTag(contractId);
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = contractId.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }





        [HttpPost]
        [Authorize]
        public JsonResult LoadFundSymbols(string Id, string sortId, string direction)
        {
            using (var sql = new LinqHelper())
            {

                var result = sql.GetFundSymbolsByFundId(Id.TryParseInt32(), Assistant.TodayDateInt());

                if (direction == "asc")
                {
                    switch (sortId)
                    {
                        case "عنوان":
                            result = result.OrderBy(p => p.Shareholder).ToList();
                            break;
                        case "نماد":
                            result = result.OrderBy(p => p.Symbol).ToList();
                            break;

                        case "تعداد":
                            result = result.OrderBy(p => p.Share).ToList();
                            break;
                        case "درصد":
                            result = result.OrderBy(p => p.Percent).ToList();
                            break;
                        case "تاریخ سررسید	":
                            result = result.OrderBy(p => p.MaturityDate).ToList();
                            break;
                        default:
                            result = result.OrderBy(p => p.MaturityDays).ToList();
                            break;
                    }

                }
                else
                {
                    switch (sortId)
                    {
                        case "عنوان":
                            result = result.OrderByDescending(p => p.Shareholder).ToList();
                            break;
                        case "نماد":
                            result = result.OrderByDescending(p => p.Symbol).ToList();
                            break;

                        case "تعداد":
                            result = result.OrderByDescending(p => p.Share).ToList();
                            break;
                        case "درصد":
                            result = result.OrderByDescending(p => p.Percent).ToList();
                            break;
                        case "تاریخ سررسید	":
                            result = result.OrderByDescending(p => p.MaturityDate).ToList();
                            break;
                        default:
                            result = result.OrderByDescending(p => p.MaturityDays).ToList();
                            break;
                    }


                }



                return Json(result, JsonRequestBehavior.AllowGet);


            }
        }


        [Authorize]
        public ActionResult LoadFundReturnData()
        {
            try
            {

                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();


                var startDate = Request.Form.GetValues("startDate").FirstOrDefault().Trim();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault().Trim();

                var Fundid = Request.Form.GetValues("Id").FirstOrDefault().ToValidMsgInt();

                var _startDate = startDate.ToValidMsgDate();
                var _endDate = endDate.ToValidMsgDate();

                using (var sql = new LinqHelper())
                {

                    var result = sql.GetFundYtms(_startDate, _endDate, Fundid).ToList();

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {
                        case "JalaliDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.JalaliDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.JalaliDate).ToList();
                            break;
                        case "Ytm":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Ytm).ToList();
                            else
                                result = result.OrderByDescending(p => p.Ytm).ToList();
                            break;
                        case "YtmYear":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.YtmYear).ToList();
                            else
                                result = result.OrderByDescending(p => p.YtmYear).ToList();
                            break;
                    }

                    //paging Data
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();

                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }



        [HttpPost]
        [Authorize]
        public ActionResult PreviewIOFlow(string ContractId)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.PreviewMFRInputOutputFlowCycle(ContractId.ToValidMsgInt());
                    return Json(new
                    {
                        data = result
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }








    }
}