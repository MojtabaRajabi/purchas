﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Services;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.Lib.Enum;


namespace Sanay.Lotus.Erm.Controllers
{
    public class FundLiquidityGapsController : Controller
    {
        // GET: LiquidityGaps
        [Authorize]
        public ActionResult Index()
        {

            ViewBag.EndDate = Assistant.MiladiToShamsiWithSlash(Convert.ToInt32(DateTime.Now.ToString("yyyyMMdd")));
            ViewBag.StartDate = Assistant.GetYear(Assistant.MiladiToShamsi(Convert.ToInt32(DateTime.Now.ToString("yyyyMMdd")))).ToString();
            ViewBag.StartDate = ViewBag.StartDate + "/01/01";

            return View();
        }

        [HttpPost]
        [Authorize]
        public JsonResult LoadCalculateCapitalSufficiencies(string startdate ,string enddate)
        {
            using (var sql = new LinqHelper())
            {
                var result = sql.GetCalculateCapitalSufficiencies(startdate.ToValidMsgDate(), enddate.ToValidMsgDate());
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }


        [Authorize]
        public ActionResult Dashboard()
        {

            ViewBag.EndDate = Assistant.MiladiToShamsiWithSlash(Convert.ToInt32(DateTime.Now.ToString("yyyyMMdd")));
            ViewBag.StartDate = Assistant.GetYear(Assistant.MiladiToShamsi(Convert.ToInt32(DateTime.Now.ToString("yyyyMMdd")))).ToString();
            ViewBag.StartDate = ViewBag.StartDate + "/01/01";

            return View();
        }

        [Authorize]
        public ActionResult LoadData()
        {
            try
            {
                var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
                var strData = Request.Form.GetValues("csvData").FirstOrDefault();
                var LiquidityGapsState = Request.Form.GetValues("LiquidityGapsState").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    strData = strData.Replace("%", "");
                    var result = sql.GetFundLiquidityGapWithNums(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), strData, LiquidityGapsState.TryParseInt32());
                    if (result == null)
                    {
                        return Json(new
                        {
                            recordsFiltered = 0,
                            recordsTotal = 0,
                            data = ""
                        });
                    }
                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    var data = result.ToList();
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        [HttpPost]
        public ActionResult SaveSettings(UserFundInputOutputFlowsConfig obj)
        {
            using (var sql = new LinqHelper())
            {
                obj.UserName=Assistant.CurrentUser();
                obj.RegDate=Assistant.TodayDateInt();
                obj.RegTime=Assistant.TimeNowInt();
                obj.IsObsolete = false;
                var result = sql.AddUserFundInputOutputFlowsConfig(obj);
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }






        [HttpGet]
        public JsonResult ChartLiquidityGap(string startDate,string endDate,string csvData)
        {
            try
            {
               

                using (var sql = new LinqHelper())
                {
                    var list = sql.GetFundLiquidityGapWithNums(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), csvData,(int)FlowTypes.All)
                        .Select(x => new
                        {
                            name = x.MonthGap+ x.YearGap,
                            value = x.NetInputOutput
                        }).ToList();
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }


        [HttpGet]
        public JsonResult GetConfigs()
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var user = Assistant.CurrentUser();
                    var obj = sql.GetUserFundInputOutputFlowsConfigs(user).FirstOrDefault();
                    return Json(obj, JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }



    }
}