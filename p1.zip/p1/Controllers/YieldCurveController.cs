﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Web.Security;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dic;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Models;
using Sanay.Library.Utility;
using System.IO;
using System.Data;
using ExcelDataReader;


namespace Sanay.Lotus.Erm.Controllers
{
    public class YieldCurveController : Controller
    {
 

        // GET: AccountingCode
        [Authorize]

        public ActionResult Index()
        {


            var d = DateTime.Today.AddDays(-7);
            var dint = Assistant.DateToInt(d);
            var dslash = Assistant.DateToDisplayMode(dint);
            ViewBag.startDate = dslash;

            ViewBag.endDate = Assistant.TodayDateBySlash();

            return View();
        }


        [HttpPost]
        public JsonResult LoadYieldCurveChart(string startDate, string endDate,
                                              string chg1, string chg2, string chg3, string chg4, string chg5, string chg6, string chg7,
                                              string MinVolume, string MaturityDate, string YTMorNYTM, string StartDiff, string EndDiff, string OF1)


        {
            try
            {

                List<byte> categoryGroups = new List<byte>();
                categoryGroups.Add(chg1.TryParseByte());
                categoryGroups.Add(chg2.TryParseByte());
                categoryGroups.Add(chg3.TryParseByte());
                categoryGroups.Add(chg4.TryParseByte());
                categoryGroups.Add(chg5.TryParseByte());
                categoryGroups.Add(chg6.TryParseByte());
                categoryGroups.Add(chg7.TryParseByte());
                categoryGroups = categoryGroups.Where(c => c > 0).ToList();
                if (chg7 == "-1") categoryGroups.Add(18);

                string User = Assistant.CurrentUser();
                string cDate = DateTime.Now.ToShortDateString();
                string cTime = Assistant.TimeNow();

                List<GetSymbolValues_Result> objSymbol = new List<GetSymbolValues_Result>();
                List<GetSymbolValues_Result> Obj = new List<GetSymbolValues_Result>();
                List<GetSymbolValuesCompare_Result> objSymbol2 = new List<GetSymbolValuesCompare_Result>();
                List<GetSymbolValuesCompare_Result> Obj2 = new List<GetSymbolValuesCompare_Result>();

                using (var sql = new LinqHelper())
                {

                    if (OF1 == "")
                    {

                        foreach (var Item in categoryGroups)
                        {
                            objSymbol = sql.GetSymbolValues(startDate.ToValidMsgDate(),
                               endDate.ToValidMsgDate(),
                                Convert.ToInt32(Item),
                                MinVolume.ToValidMsgInt(),
                                YTMorNYTM.ToValidMsgInt(),
                                MaturityDate.ToValidMsgDate()
                            );
                            Obj.AddRange(objSymbol);

                        }
                        var FinalObj = Obj.OrderBy(x => x.MaturityDate).ToList();

                        return Json(FinalObj, JsonRequestBehavior.AllowGet);


                    }
                    else
                    {
 
                        foreach (var Item in categoryGroups)
                        {
                            objSymbol2 = sql.GetSymbolValuescompare(
                               startDate.ToValidMsgDate(),
                                endDate.ToValidMsgDate(),
                                Convert.ToInt32(Item),
                                MinVolume.ToValidMsgInt(),
                                YTMorNYTM.ToValidMsgInt(),
                                StartDiff.ToValidMsgDate(),
                                EndDiff.ToValidMsgDate(),
                                MaturityDate.ToValidMsgDate()

                            );
                            Obj2.AddRange(objSymbol2);

                        }
                        var FinalObj2 = Obj2.OrderBy(x => x.MaturityDate).ToList();


                        return Json(FinalObj2, JsonRequestBehavior.AllowGet);


                    }


                    return null;

                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }









    }
}