﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Library.Utility;


namespace Sanay.Lotus.Erm.Controllers
{
    [Authorize]
    public class FundsDataController : Controller
    {
        // GET: FundsData
        public ActionResult Index()
        {
            return RedirectToAction("LoadDataOrderStatistics");
            //return View();
        }

        public ActionResult OrderStatistics()
        {
            return View();
        }

        public ActionResult LoadDataOrderStatistics()
        {
            try
            {
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                //var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var fundId = Request.Form.GetValues("fund").FirstOrDefault();
                var startDate = Request.Form.GetValues("startDate").FirstOrDefault().Trim().ToValidMsgInt();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault().Trim().ToValidMsgInt();

                using (var sql = new LinqHelper())
                {
                    endDate = endDate == 0 ? int.MaxValue : endDate;
                    var result = sql.GetOrderStatisticsById(fundId.ToValidMsgInt()).Where(c => c.RegDate >= startDate && c.RegDate <= endDate).ToList();

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {
                        case "IssueCount":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.IssueCount).ToList();
                            else
                                result = result.OrderByDescending(p => p.IssueCount).ToList();
                            break;
                        case "RevokeCount":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.RevokeCount).ToList();
                            else
                                result = result.OrderByDescending(p => p.RevokeCount).ToList();
                            break;
                        case "RegDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.RegDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.RegDate).ToList();
                            break;
                        case "RegTime":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.RegTime).ToList();
                            else
                                result = result.OrderByDescending(p => p.RegTime).ToList();
                            break;

                    }
                 
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public ActionResult LotusFundPortfolios()
        {
            using (var sql = new LinqHelper())
            {
                //ViewBag.InstrumentType = sql.GetFundPortfoliosInstrumentType().ToList();
                ViewBag.Symbols = sql.GetFundPortfoliosSymbols().ToList();
            }
            
            return View();
        }


        public ActionResult ServateLotusFundPortfolios()
        {
            using (var sql = new LinqHelper())
            {
                //ViewBag.InstrumentType = sql.GetFundPortfoliosInstrumentType().ToList();
                ViewBag.Symbols = sql.GetFundPortfoliosSymbols().ToList();
            }

            return View();
        }

        public ActionResult PirouzanLotusFundPortfolios()
        {
            using (var sql = new LinqHelper())
            {
                //ViewBag.InstrumentType = sql.GetFundPortfoliosInstrumentType().ToList();
                ViewBag.Symbols = sql.GetFundPortfoliosSymbols().ToList();
            }

            return View();
        }

        public ActionResult ParsianZarinLotusFundPortfolios()
        {
            using (var sql = new LinqHelper())
            {
                //ViewBag.InstrumentType = sql.GetFundPortfoliosInstrumentType().ToList();
                ViewBag.Symbols = sql.GetFundPortfoliosSymbols().ToList();
            }

            return View();
        }

        public ActionResult OmidLotusFundPortfolios()
        {
            using (var sql = new LinqHelper())
            {
                //ViewBag.InstrumentType = sql.GetFundPortfoliosInstrumentType().ToList();
                ViewBag.Symbols = sql.GetFundPortfoliosSymbols().ToList();
            }

            return View();
        }

        public ActionResult NikokariLotusFundPortfolios()
        {
            using (var sql = new LinqHelper())
            {
                //ViewBag.InstrumentType = sql.GetFundPortfoliosInstrumentType().ToList();
                ViewBag.Symbols = sql.GetFundPortfoliosSymbols().ToList();
            }

            return View();
        }

        public ActionResult GoldLotusFundPortfolios()
        {
            using (var sql = new LinqHelper())
            {
                //ViewBag.InstrumentType = sql.GetFundPortfoliosInstrumentType().ToList();
                ViewBag.Symbols = sql.GetFundPortfoliosSymbols().ToList();
            }

            return View();
        }

        public ActionResult EtemadLotusFundPortfolios()
        {
            using (var sql = new LinqHelper())
            {
                //ViewBag.InstrumentType = sql.GetFundPortfoliosInstrumentType().ToList();
                ViewBag.Symbols = sql.GetFundPortfoliosSymbols().ToList();
            }

            return View();
        }

        public ActionResult AlzahraFundPortfolios()
        {
            using (var sql = new LinqHelper())
            {
                //ViewBag.InstrumentType = sql.GetFundPortfoliosInstrumentType().ToList();
                ViewBag.Symbols = sql.GetFundPortfoliosSymbols().ToList();
            }

            return View();
        }
         

        public ActionResult LoadDataFundPortfolios()
        {
            try
            {
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                //var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                 var fundId = Request.Form.GetValues("fund").FirstOrDefault();
                 var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                 var Symbol = Request.Form.GetValues("Symbol").FirstOrDefault();
                 

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetFundPortfoliosByDate(fundId.ToValidMsgInt(), startDate.ToValidMsgDate());
                         

                    //if(InstrumentType != "-1")
                    //    result = result.Where(c=>c.InstrumentTypeTitle == InstrumentType).ToList();
                    if (Symbol != "-1")
                        result = result.Where(c => c.Instrument == Symbol).ToList();

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                  
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public ActionResult LoadDataLastFundPortfolios(string fundId)
        {
            try
            {            
                //var fundId = Request.Form.GetValues("fund").FirstOrDefault();
               
                using (var sql = new LinqHelper())
                {               
                    var result = sql.GetLastFundPortfolios(fundId.ToValidMsgInt()).OrderByDescending(c=>c.Count).ToList();                                                    
                    return Json(result);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public ActionResult Navs()
        {
            return View();
        }

        public ActionResult LoadDataNavs()
        {
            try
            {
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                //var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var fundId = Request.Form.GetValues("fund").FirstOrDefault().ToValidMsgInt();
                var startDate = Request.Form.GetValues("startDate").FirstOrDefault().Trim().ToValidMsgInt();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault().Trim().ToValidMsgInt();

                using (var sql = new LinqHelper())
                {
                    endDate = endDate == 0 ? int.MaxValue : endDate;
                    var result = sql.GetNavsById(fundId).Where(c => c.Date >= startDate && c.Date <= endDate).ToList();

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {
                        case "PurchaseValue":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.PurchaseValue).ToList();
                            else
                                result = result.OrderByDescending(p => p.PurchaseValue).ToList();
                            break;
                        case "SaleValue":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.SaleValue).ToList();
                            else
                                result = result.OrderByDescending(p => p.SaleValue).ToList();
                            break;
                        case "MarketValue":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.MarketValue).ToList();
                            else
                                result = result.OrderByDescending(p => p.MarketValue).ToList();
                            break;
                        case "IssuedUnitCount":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.IssuedUnitCount).ToList();
                            else
                                result = result.OrderByDescending(p => p.IssuedUnitCount).ToList();
                            break;
                        case "RevokedUnitCount":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.RevokedUnitCount).ToList();
                            else
                                result = result.OrderByDescending(p => p.RevokedUnitCount).ToList();
                            break;
                        case "ShareholdersCount":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.ShareholdersCount).ToList();
                            else
                                result = result.OrderByDescending(p => p.ShareholdersCount).ToList();
                            break;
                        case "IntrinsicValue":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.IntrinsicValue).ToList();
                            else
                                result = result.OrderByDescending(p => p.IntrinsicValue).ToList();
                            break;
                        case "StatisticValue":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.StatisticValue).ToList();
                            else
                                result = result.OrderByDescending(p => p.StatisticValue).ToList();
                            break;
                        case "Date":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Date).ToList();
                            else
                                result = result.OrderByDescending(p => p.Date).ToList();
                            break;
                        case "RegDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.RegDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.RegDate).ToList();
                            break;
                        case "RegTime":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.RegTime).ToList();
                            else
                                result = result.OrderByDescending(p => p.RegTime).ToList();
                            break;

                    }

                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        
    }
}