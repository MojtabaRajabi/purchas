﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Sanay.Lotus.Erm.Controllers
{
    public class UnitChangeController : Controller
    {
        // GET: UnitChange
        [Authorize]
        public ActionResult Index()
        {
            return View();
        }
    }
}