﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Lib.Enum;

namespace Sanay.Lotus.Erm.Controllers
{
    public class FundSellController : Controller
    {
        // GET: TaxAndInsurance
        [Authorize]
        public ActionResult Index()
        {
            return View();
        }


        [Authorize]
        public ActionResult Add()
        {
            return View();
        }

        [HttpGet]
        [Authorize]
        public ActionResult Edit(string Id)
        {
            try
            {
                using (var sql2 = new LinqHelper())
                {
                    LinqHelper sql = new LinqHelper();
                    var result = sql.GetCurrentFundSell(Guid.Parse(Id));
                    return View(result);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        [Authorize]
        public ActionResult LoadData()
        {
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            var startDate = Request.Form.GetValues("startDate").FirstOrDefault().ToValidMsgDate();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault().ToValidMsgDate();

            if (endDate == 0) endDate = int.MaxValue;

            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetFundSell().Where(c => c.StartDate >= startDate && c.StartDate <= endDate).OrderBy(c => c.Id).ToList();

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {
                        case "Num":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Num).ToList();
                            else
                                result = result.OrderByDescending(p => p.Num).ToList();
                            break;
                        case "Interest":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Interest).ToList();
                            else
                                result = result.OrderByDescending(p => p.Interest).ToList();
                            break;
                        case "StartDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.StartDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.StartDate).ToList();
                            break;
                        case "EndDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.EndDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.EndDate).ToList();
                            break;
                    }

                    //paging Data
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();

                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }



        [HttpPost]
        [Authorize]
        public ActionResult Register(string num, string interest, string startDate, string endDate)
        {
            using (var sql = new LinqHelper())
            {
                var objFundSell = new FundSell()
                {
                    Num = (int?)num.ToValidMsgdouble(),
                    Interest = interest.ToValidMsgdouble(),
                    StartDate = startDate.ToValidMsgDate(),
                    EndDate = endDate.ToValidMsgDate(),
                    RegUser = Assistant.CurrentUser(),
                    RegDate = Assistant.TodayDateInt(),
                    RegTime = Assistant.TimeNowInt()
                };
                var result = sql.InsertFundSell(objFundSell);
                sql.AutomaticFundSellInputOutputFlow(result);
                return Json(new MessageResponse { Success = true, Message = result.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        [Authorize]
        public ActionResult PreviewIOFlow(string Num, string Interest, string StartDate, string EndDate)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.PreviewAutomaticFundSellInputOutputFlow(Num.ToValidMsgdouble(), Interest.ToValidMsgdouble(), StartDate.ToValidMsgDate(), EndDate.ToValidMsgDate() );
                    return Json(new
                    {
                        data = result
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }



        [HttpPost]
        public ActionResult Update(string id, string num, string interest, string startDate, string endDate)
        {
  
            using (var sql = new LinqHelper())
            {
                var objFundSell = new FundSell()
                {
                    Num =(int?) num.ToValidMsgdouble(),
                    Interest = interest.ToValidMsgdouble(),
                    StartDate = startDate.ToValidMsgDate(),
                    EndDate = endDate.ToValidMsgDate(),
                    RegUser = Assistant.CurrentUser(),
                    RegDate = Assistant.TodayDateInt(),
                    RegTime = Assistant.TimeNowInt()
                };
                string message = "";
                 var item = sql.GetFundSellById(Guid.Parse(id));
                if (item != null)
                {
                    sql.DeleteFundSell(Guid.Parse(id));
                    var result = sql.InsertFundSell(objFundSell);
                    sql.AutomaticFundSellInputOutputFlow(result);

                    message = result.ToString();
                }
                return Json(new MessageResponse { Success = true, Message = message, ReturnUrl = "AccountingCode" }, JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        public JsonResult LastValueTaxAndInsurance(string sdate)
        {
            try
            {
                using (var db = new LinqHelper())
                {
                    if (string.IsNullOrEmpty(sdate)) return Json("", JsonRequestBehavior.AllowGet);
                    var obj = db.GetLastValueTaxAndInsurance(sdate.ToValidMsgDate());
                    return Json(obj, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        [Authorize]
        public JsonResult Delete(string Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteFundSell(Guid.Parse(Id));
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }


    }
}