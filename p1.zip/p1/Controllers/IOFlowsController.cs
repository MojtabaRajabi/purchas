﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.DataAccess.Helper;
using System.Data;
using Sanay.Lotus.Erm.DataAccess;
using System.IO;
using ExcelDataReader;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Lib.Enum;

namespace Sanay.Lotus.Erm.Controllers
{
    public class IOFlowsController : Controller
    {

        // GET: IOFlows
        [Authorize]
        public ActionResult Index()
        {
            ViewBag.EndDate = Assistant.MiladiToShamsiWithSlash(Convert.ToInt32(DateTime.Now.ToString("yyyyMMdd")));
            ViewBag.StartDate = Assistant.GetYear(Assistant.MiladiToShamsi(Convert.ToInt32(DateTime.Now.ToString("yyyyMMdd")))).ToString();
            ViewBag.StartDate = ViewBag.StartDate + "/01/01";

            return View();
        }

        [Authorize]
        public FileResult Download()
        {
            string path = Server.MapPath("~/App_Data/Files");
            string fileName = Path.GetFileName("sample.xlsx");
            string fullPath = Path.Combine(path, fileName);
            return File(fullPath, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "IOFlowsSample.xlsx");
        }
        [Authorize]
        public ActionResult Import()
        {
            return View();
        }

        [Authorize]
        public ActionResult Generates()
        {
            return View();
        }

        [Authorize]
        public ActionResult TestPage()
        {
            return View();
        }
        [Authorize]
        public ActionResult IOFlowDetails(string Tag, string returnLink)
        {
            ViewBag.Tag = Tag;

            if (returnLink == null) ViewBag.returnLink = "1"; else ViewBag.returnLink = returnLink;

            using (var sql = new LinqHelper())
            {
                List<InputOutputFlowsSource> TagList = sql.GetTagSources().ToList();
                ViewBag.TagList = TagList;
 
            }
            return View();
        }



        [HttpPost]
        [Authorize]
        public ActionResult RegisterGenerateInfo(string IOFlowCycles, string StartDate, string EndDate, string Value)
        {
            using (var sql = new LinqHelper())
            {

                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Import(HttpPostedFileBase upload, string IO)
        {
            // اعتبار سنجی فایل آپلود شده
            if (upload != null && upload.ContentLength > 0 && (upload.FileName.EndsWith(".xls") || upload.FileName.EndsWith(".xlsx")))
            {
                Stream stream = upload.InputStream;

                using (MemoryStream ms = new MemoryStream())
                {
                    stream.CopyTo(ms);
                    var data = ms.ToArray();

                    IExcelDataReader reader = ExcelReaderFactory.CreateReader(stream);
                    DataSet result = reader.AsDataSet(new ExcelDataSetConfiguration()
                    {
                        ConfigureDataTable = (tableReader) => new ExcelDataTableConfiguration()
                        {
                            UseHeaderRow = false
                        }
                    });
                    var datatable = result.Tables[0];
                    var colHeader1 = datatable.Rows[0][0].ToString();
                    var colHeader2 = datatable.Rows[0][1].ToString();

                    if (reader.FieldCount == 2 && colHeader1 == "تاریخ" && colHeader2 == "مبلغ")
                    {
                        DataAccess.File fileObj = new DataAccess.File();
                        using (var sql = new LinqHelper())
                        {

                            fileObj.Name = Path.GetFileNameWithoutExtension(upload.FileName);
                            fileObj.Extension = Path.GetExtension(upload.FileName);
                            fileObj.Size = data.Length;
                            fileObj.Sender = Assistant.CurrentUser();
                            fileObj.StatusId = 1;
                            fileObj.RegDate = Convert.ToInt32(Assistant.MiladiToShamsi(Assistant.TodayDateIntMiladi()));
                            fileObj.RegTime = Assistant.TimeNowInt();
                            fileObj.Binary = data;
                            fileObj.FileTypeId = Convert.ToInt32(IO);
                            var res = sql.InsertPosition(fileObj);

                            List<DataAccess.InputOutputFlow> list = datatable.AsEnumerable().Skip(1)
                                .Select(row => new DataAccess.InputOutputFlow
                                {
                                    AffectDate = (row.Field<string>(0)).TryParseInt32(),
                                    Val = (double?)(row.Field<Object>(1)).ToString().TryParseDouble(),//todo:

                                    InputOutputFlowType = IO.TryParseInt32(),
                                    IsFuture = true,
                                    TagSource = (int)IOFlowSources.FileUploud

                                })
                                .ToList();

                            foreach (var item in list)
                            {
                                sql.InsertInputOutputFlow(item);
                            }
                        }
                        reader.Close();
                        return View(datatable);
                    }
                }
            }

            ModelState.AddModelError("File", "خطایی رخ داده! فایل مورد نظر با فایل استاندارد همخوانی ندارد ...! ");
            return View();
        }


        public List<GetInputOutputFlows_Result> result = new List<GetInputOutputFlows_Result>();



        [Authorize]
        public ActionResult LoadData()
        {
            try
            {

                var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault();
                var IOFlowState = Request.Form.GetValues("IOFlowState").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    result = sql.GetInputOutputFlows(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), IOFlowState.TryParseInt32());

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    var data = result.ToList();
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }




        [Authorize]
        public ActionResult loadInVoucher()
        {
            try
            {
                var pdate = Request.Form.GetValues("pdate").FirstOrDefault();
                var VoucherDetailState = Request.Form.GetValues("type").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var VoucherResult = sql.GetVoucherByDateType(pdate.ToValidMsgDate(), VoucherDetailState.ToValidMsgInt());

                    int recordsTotal = 0;
                    recordsTotal = VoucherResult.Count();
                    var data = VoucherResult.ToList();
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }



        [Authorize]
        public ActionResult loadInIOFlow()
        {
            try
            {
                var pdate = Request.Form.GetValues("pdate").FirstOrDefault();
                var type = Request.Form.GetValues("type").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var VoucherResult = sql.GetInputOutputFlowByDateType(type.ToValidMsgInt(), pdate.ToValidMsgDate());

                    int recordsTotal = 0;
                    recordsTotal = VoucherResult.Count();
                    var data = VoucherResult.ToList();
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }



        [Authorize]
        public ActionResult Generated()
        {
            return View();
        }




        [Authorize]
        public ActionResult LoadDataGenerated()
        {
            try
            {

                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetInputOutputFlowGenerates(start.ToValidMsgInt(), length.ToValidMsgInt(), searchValue, 0, 0);

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    var data = result.ToList();
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }




        [Authorize]
        public ActionResult RemoveFlow()
        {
            return View();
        }


        [HttpPost]
        [Authorize]
        public ActionResult RemoveFlowData(string startDate, string endDate, string IOFlow)
        {
            using (var sql = new LinqHelper())
            {
                sql.DeleteIOFlow(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), IOFlow.ToValidMsgInt());
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Authorize]
        public ActionResult RemoveFlowDataById(string Id)
        {
            using (var sql = new LinqHelper())
            {
                sql.RemoveInputOutputFlowById(Id.ToValidMsgInt());
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }

        [Authorize]
        public ActionResult PreviewRemoveFlowData()
        {
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            var startDate = Request.Form.GetValues("startDate").FirstOrDefault().ToValidMsgDate();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault().ToValidMsgDate();
            var IOFlow = Request.Form.GetValues("IOFlow").FirstOrDefault().ToValidMsgInt();

            if (endDate == 0) endDate = int.MaxValue;
            using (var sql = new LinqHelper())
            {
                var result = sql.GetIOFlowDetails(startDate, endDate, IOFlow,-1, "", (int)FlowTypes.Forecast, -1, -1, 0, int.MaxValue);

                //sorting Data
                sortColumnDir = sortColumnDir.ToUpper();
                switch (sortColumn)
                {
                    case "InputOutputFlowTitle":
                        if (sortColumnDir == "ASC")
                            result = result.OrderBy(p => p.InputOutputFlowTitle).ToList();
                        else
                            result = result.OrderByDescending(p => p.InputOutputFlowTitle).ToList();
                        break;
                    case "Val":
                        if (sortColumnDir == "ASC")
                            result = result.OrderBy(p => p.Val).ToList();
                        else
                            result = result.OrderByDescending(p => p.Val).ToList();
                        break;
                    case "AffectDate":
                        if (sortColumnDir == "ASC")
                            result = result.OrderBy(p => p.AffectDate).ToList();
                        else
                            result = result.OrderByDescending(p => p.AffectDate).ToList();
                        break;
                    case "IsFuture":
                        if (sortColumnDir == "ASC")
                            result = result.OrderBy(p => p.IsFuture).ToList();
                        else
                            result = result.OrderByDescending(p => p.IsFuture).ToList();
                        break;

                }

                //paging Data
                int pageSize = length != null ? Convert.ToInt32(length) : 0;
                int skip = start != null ? Convert.ToInt32(start) : 0;
                int recordsTotal = 0;
                var customerData = result;
                recordsTotal = customerData.Count();
                var data = customerData.Skip(skip).Take(pageSize).ToList();

                //Returning Json Data  
                return Json(new
                {
                    recordsFiltered = recordsTotal,
                    recordsTotal = recordsTotal,
                    data = data
                });
            }
        }

        [Authorize]
        public ActionResult LoadIOFlowDetails()
        {
            try
            {

                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var type = Request.Form.GetValues("type").FirstOrDefault();
                var flow = Request.Form.GetValues("flow").FirstOrDefault();
                var TagSource = Request.Form.GetValues("TagSource").FirstOrDefault();
                var startDate = Request.Form.GetValues("startDate").FirstOrDefault().Trim();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault().Trim();
                var tag = Request.Form.GetValues("Tag").FirstOrDefault();

                var startValue = Request.Form.GetValues("startValue").FirstOrDefault();
                var endValue = Request.Form.GetValues("endValue").FirstOrDefault();

                startValue = startValue.Trim() == "" ? "-1" : startValue;
                endValue = endValue.Trim() == "" ? "-1" : endValue;

                using (var sql = new LinqHelper())
                {

                    var result = sql.GetIOFlowDetails(startDate.ToValidMsgDate(), endDate.Replace(".", "").ToValidMsgDate(), flow.ToValidMsgInt(), TagSource.ToValidMsgInt(), tag.ToUpper(), type.ToValidMsgInt(), startValue.ToValidMsgInt(), endValue.ToValidMsgInt(), 0, int.MaxValue);
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }





        [Authorize]
        public ActionResult LoadDataDeposits()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();


            try
            {
                using (var sql = new LinqHelper())
                {
                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Where(c => c.TagSource != 15).Select(c => c.Tag.ToLower()).ToList();
                    listTag.AddRange(sql.GetInputOutputFlowsByDateFlow(flowDate, 15).Select(c => c.Tag).ToList());
                    var result = sql.GetDeposits().Where(a => listTag.Contains(a.Id.ToString())).OrderBy(c => c.Id);


                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [Authorize]
        public ActionResult LoadDataDebtBonds()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Where(c => c.TagSource != 15).Select(c => c.Tag.ToLower()).ToList();
                    listTag.AddRange(sql.GetInputOutputFlowsByDateFlow(flowDate, 15).Select(c => c.Tag).ToList());
                    var result = sql.GetDebtBonds().Where(a => listTag.Contains(a.Id.ToString())).OrderBy(c => c.Id);


                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }



        [Authorize]
        public ActionResult LoadDataIOFlowFund()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Where(c => c.TagSource != 15).Select(c => c.Tag.ToLower()).ToList();
                    listTag.AddRange(sql.GetInputOutputFlowsByDateFlow(flowDate, 15).Select(c => c.Tag).ToList());
                    var result = sql.GetIOFlowFund().Where(a => listTag.Contains(a.Id.ToString())).OrderBy(c => c.Id);


                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        [Authorize]
        public ActionResult LoadDataAdditionalContractFees()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Where(c => c.TagSource != 15).Select(c => c.Tag.ToLower()).ToList();
                    listTag.AddRange(sql.GetInputOutputFlowsByDateFlow(flowDate, 15).Select(c => c.Tag).ToList());
                    var result = sql.GetAdditionalContractFee().Where(a => listTag.Contains(a.Id.ToString())).OrderBy(c => c.Id);

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }







        [Authorize]
        public ActionResult LoadDataMFR_DebtBuySell()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Where(c => c.TagSource == 15).Select(c => c.Tag.ToLower()).ToList();
                    listTag.AddRange(sql.GetInputOutputFlowsByDateFlow(flowDate, 15).Select(c => c.Tag).ToList());
                    //var result = sql.GetAdditionalContractFee().Where(a => listTag.Contains(a.Id.ToString())).OrderBy(c => c.Id);
                    var result = sql.GetContractDetailDebtBuySells().Where(a => listTag.Contains(a.ContractId.ToString())).OrderBy(c => c.Id);

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        [Authorize]
        public ActionResult LoadDataMFR_Reception()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Where(c => c.TagSource == 15).Select(c => c.Tag.ToLower()).ToList();
                    listTag.AddRange(sql.GetInputOutputFlowsByDateFlow(flowDate, 15).Select(c => c.Tag).ToList());
                    //var result = sql.GetAdditionalContractFee().Where(a => listTag.Contains(a.Id.ToString())).OrderBy(c => c.Id);
                    var result = sql.GetContractDetailReception().Where(a => listTag.Contains(a.ContractId.ToString())).OrderBy(c => c.Id);

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        [Authorize]
        public ActionResult LoadDataMFR_DebtReception()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Where(c => c.TagSource == 15).Select(c => c.Tag.ToLower()).ToList();
                    listTag.AddRange(sql.GetInputOutputFlowsByDateFlow(flowDate, 15).Select(c => c.Tag).ToList());
                    //var result = sql.GetAdditionalContractFee().Where(a => listTag.Contains(a.Id.ToString())).OrderBy(c => c.Id);
                    var result = sql.GetContractDetailDebtReception().Where(a => listTag.Contains(a.ContractId.ToString())).OrderBy(c => c.Id);

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }



        [Authorize]
        public ActionResult LoadDataMFR_CapitalIncreaseSupplyAdvice()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Where(c => c.TagSource == 15).Select(c => c.Tag.ToLower()).ToList();
                    listTag.AddRange(sql.GetInputOutputFlowsByDateFlow(flowDate, 15).Select(c => c.Tag).ToList());
                    //var result = sql.GetAdditionalContractFee().Where(a => listTag.Contains(a.Id.ToString())).OrderBy(c => c.Id);
                    var result = sql.GetContractDetailCapitalIncreaseSupplyAdvices().Where(a => listTag.Contains(a.ContractId.ToString())).OrderBy(c => c.Id);

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }




        [Authorize]
        public ActionResult LoadDataMFR_DebtTrading()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Where(c => c.TagSource == 15).Select(c => c.Tag.ToLower()).ToList();
                    listTag.AddRange(sql.GetInputOutputFlowsByDateFlow(flowDate, 15).Select(c => c.Tag).ToList());
                    //var result = sql.GetAdditionalContractFee().Where(a => listTag.Contains(a.Id.ToString())).OrderBy(c => c.Id);
                    var result = sql.GetContractDetailDebtTrading().Where(a => listTag.Contains(a.ContractId.ToString())).OrderBy(c => c.Id);

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        [Authorize]
        public ActionResult LoadDataMFR_DebtSupplyAdvice()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Where(c => c.TagSource == 15).Select(c => c.Tag.ToLower()).ToList();
                    listTag.AddRange(sql.GetInputOutputFlowsByDateFlow(flowDate, 15).Select(c => c.Tag).ToList());
                    //var result = sql.GetAdditionalContractFee().Where(a => listTag.Contains(a.Id.ToString())).OrderBy(c => c.Id);
                    var result = sql.GetContractDetailAdvices().Where(a => listTag.Contains(a.ContractId.ToString())).OrderBy(c => c.Id);

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        [Authorize]
        public ActionResult LoadDataMFR_PurchaseOfService()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Where(c => c.TagSource == 15).Select(c => c.Tag.ToLower()).ToList();
                    listTag.AddRange(sql.GetInputOutputFlowsByDateFlow(flowDate, 15).Select(c => c.Tag).ToList());
                    //var result = sql.GetAdditionalContractFee().Where(a => listTag.Contains(a.Id.ToString())).OrderBy(c => c.Id);
                    var result = sql.GetContractDetailPurchaseOfService().Where(a => listTag.Contains(a.ContractId.ToString())).OrderBy(c => c.Id);

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }



        [Authorize]
        public ActionResult LoadDataMFR_Valuation()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Where(c => c.TagSource == 15).Select(c => c.Tag.ToLower()).ToList();
                    listTag.AddRange(sql.GetInputOutputFlowsByDateFlow(flowDate, 15).Select(c => c.Tag).ToList());
                    //var result = sql.GetAdditionalContractFee().Where(a => listTag.Contains(a.Id.ToString())).OrderBy(c => c.Id);
                    var result = sql.GetContractDetailValuations().Where(a => listTag.Contains(a.ContractId.ToString())).OrderBy(c => c.Id);

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        [Authorize]
        public ActionResult LoadDataMFR_AdviceFinancialService()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Where(c => c.TagSource == 15).Select(c => c.Tag.ToLower()).ToList();
                    listTag.AddRange(sql.GetInputOutputFlowsByDateFlow(flowDate, 15).Select(c => c.Tag).ToList());
                    //var result = sql.GetAdditionalContractFee().Where(a => listTag.Contains(a.Id.ToString())).OrderBy(c => c.Id);
                    var result = sql.GetContractDetailAdviceFinancialServices().Where(a => listTag.Contains(a.ContractId.ToString())).OrderBy(c => c.Id);

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }







        [Authorize]
        public ActionResult LoadDataCapitalBonds()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {
                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Where(c=>c.TagSource!=15).Select(c => (c.Tag).ToString()).ToList();
                    listTag.AddRange(sql.GetInputOutputFlowsByDateFlow(flowDate, 15).Select(c => (c.Tag).ToString()).ToList());
                    var result = sql.GetCapitalBonds().Where(a => listTag.Contains(a.Id.ToString())).OrderBy(c => c.Id);

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }




        [Authorize]
        public ActionResult LoadDataManualFlows()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Where(c => c.TagSource != 15).Select(c => c.Tag.ToLower()).ToList();
                    listTag.AddRange(sql.GetInputOutputFlowsByDateFlow(flowDate, 15).Select(c => c.Tag).ToList());
                    var result = sql.GetCapitalIncreases().Where(a => listTag.Contains(a.Id.ToString())).OrderBy(c => c.Id);

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [Authorize]
        public ActionResult LoadDataManualFlowsOutputCosts()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {


                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Where(c => c.TagSource != 15).Select(c => c.Tag.ToLower()).ToList();
                    listTag.AddRange(sql.GetInputOutputFlowsByDateFlow(flowDate, 15).Select(c => c.Tag).ToList());
                    var result = sql.GetOutputCosts().Where(a => listTag.Contains(a.Id.ToString())).OrderBy(c => c.Id);



                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [Authorize]
        public ActionResult LoadDataCurrentTaxAndCosts()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Where(c => c.TagSource != 15).Select(c => c.Tag.ToLower()).ToList();
                    listTag.AddRange(sql.GetInputOutputFlowsByDateFlow(flowDate, 15).Select(c => c.Tag).ToList());
                    var result = sql.GetCurrentTaxAndCost().Where(a => listTag.Contains(a.Id.ToString())).OrderBy(c => c.Id);


                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        [Authorize]
        public ActionResult LoadDataFutureDebtBonds()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {
                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Where(c => c.TagSource != 15).Select(c => c.Tag.ToLower()).ToList();
                    listTag.AddRange(sql.GetInputOutputFlowsByDateFlow(flowDate, 15).Select(c => c.Tag).ToList());
                    var result = sql.GetFutureDebtBond().Where(a => listTag.Contains(a.Id.ToString())).OrderBy(c => c.Id);

                   

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [Authorize]
        public ActionResult LoadDataBondIssuances()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Where(c => c.TagSource != 15).Select(c => c.Tag.ToLower()).ToList();
                    listTag.AddRange(sql.GetInputOutputFlowsByDateFlow(flowDate, 15).Select(c => c.Tag).ToList());
                    var result = sql.GetBondIssuances().Where(a => listTag.Contains(a.Id.ToString())).OrderBy(c => c.Id);

                    



                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        [Authorize]
        public ActionResult LoadDataFundSell()
        {
            var flowDate = Request.Form.GetValues("FlowDate").FirstOrDefault().ToValidMsgDate();
            var iOFlowType = Request.Form.GetValues("IOFlowType").FirstOrDefault().ToValidMsgDate();
            try
            {
                using (var sql = new LinqHelper())
                {

                    var listTag = sql.GetInputOutputFlowsByDateFlow(flowDate, iOFlowType).Where(c => c.TagSource != 15).Select(c => c.Tag.ToLower()).ToList();
                    listTag.AddRange(sql.GetInputOutputFlowsByDateFlow(flowDate, 15).Select(c => c.Tag).ToList());
                    var result = sql.GetFundSell().Where(a => listTag.Contains(a.Id.ToString())).OrderBy(c => c.Id);


                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

    }
}