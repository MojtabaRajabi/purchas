﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.DataAccess;

namespace Sanay.Lotus.Erm.Controllers
{
    [Authorize]
    public class DebtMarketValueController : Controller
    {
        // GET: DebtMarketValue
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult GetMarketDetail(string StartDate, string EndDate)

        {
            try
            {
                var today =  Assistant.TodayDateInt();

 

                using (var db = new LinqHelper())
                {


                    var Marketavg = db.GetMarketValueInRange(today);
                    if (Marketavg.Count > 0)
                    {
                        //int i = 0;
                   

                        var Tot = Marketavg.Sum(c => c.Total);
                        var Val = Marketavg.Sum(c => c.MarketValue);
                        var Nval = Marketavg.Sum(c => c.NominalValue);

                        var total = new GetMarketValues_Result()
                        {
                            Total = Tot,
                            MarketValue = Val,
                            NominalValue = Nval,
                            GroupName = "مجموع",
                        };

                        Marketavg.Add(total);

                        return Json(data: Marketavg, behavior: JsonRequestBehavior.AllowGet);
                    }
                    else
                        return Json(data: "", behavior: JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception e)
            {
                return Json(data: "", behavior: JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public ActionResult MarketTotalDetails(string StartDate, string EndDate)

        {
            try
            {
                var today = Assistant.DateToDisplayMode(Assistant.TodayDateInt());


                StartDate = today.Replace("/", "");
                EndDate = today.Replace("/", "");

                using (var db = new LinqHelper())
                {

                    var data1 = db.GetMarketTotalValueInRange(StartDate, EndDate);

                    return Json(data: data1, behavior: JsonRequestBehavior.AllowGet);

                }
            }
            catch (Exception e)
            {
                return Json(data: "", behavior: JsonRequestBehavior.AllowGet);
            }
        }

    }
}