﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Web.Security;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dic;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Models;
using Sanay.Library.Utility;
using System.IO;
using System.Data;

using ExcelDataReader;
using Sanay.Lotus.Erm.Lib.Dto;

namespace Sanay.Lotus.Erm.Controllers
{
    public class DebtBondsController : Controller
    {
        // GET: AccountingCode
        [Authorize]

        public ActionResult Index()
        {
            return View();
        }


        [Authorize]
        public ActionResult DebtBonds()
        {
            return View();
        }

        [Authorize]
        public ActionResult ImportCoupons(string Symbol)
        {
            ViewBag.Symbol = Symbol;
            return View();
        }
        [Authorize]
        public ActionResult ImportSymbolDailyInterest(string Symbol)
        {
            ViewBag.Symbol = Symbol;
            return View();
        }

        [Authorize]

        public ActionResult SymbolDailyInterest(string Symbol)
        {
            ViewBag.Symbol = Symbol;

            return View();
        }

        [Authorize]

        public ActionResult SymbolCoupons(string Symbol)
        {
            ViewBag.Symbol = Symbol;
            return View();
        }



        [Authorize]
        public ActionResult Add()
        {
            return View();
        }

        [Authorize]
        public ActionResult RegisterBond()
        {
            return View();
        }



        [HttpGet]
        [Authorize]
        public ActionResult Edit(string Id)
        {
            try
            {
                using (var sql2 = new LinqHelper())
                {

                    LinqHelper sql = new LinqHelper();
                    var result = sql.GetDebtBondsById(Guid.Parse(Id));
                    return View(result);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }


        [HttpGet]
        [Authorize]
        public ActionResult EditSymbol(string Id)
        {
            try
            {
                using (var sql2 = new LinqHelper())
                {

                    LinqHelper sql = new LinqHelper();
                    var result = sql.GetDebtSymbolById(Id.ToValidMsgInt());
                    var objSymGroup = sql.GetSymbolGroupsByIsin(result.Isin);


                    List<Role> objs = new List<Role>();
                    objs.Add(new Role() { Id = 1, Title = " بورس انرژی" });
                    objs.Add(new Role() { Id = 2, Title = "فرابورس" });
                    objs.Add(new Role() { Id = 3, Title = "بورس تهران" });
                    objs.Add(new Role() { Id = 4, Title = "بورس کالا" });
                    ViewBag.MarketId = new SelectList(objs, "Id", "Title", result.MarketId);

                    List<Role> objs2 = new List<Role>();
                    objs2.Add(new Role() { Id = 8, Title = "شهرداری" });
                    objs2.Add(new Role() { Id = 9, Title = "اسناد خزانه" });
                    objs2.Add(new Role() { Id = 10, Title = " مشارکت دولتی " });
                    objs2.Add(new Role() { Id = 11, Title = " مشارکت خصوصی " });
                    objs2.Add(new Role() { Id = 12, Title = " گواهي سپرده " });
                    objs2.Add(new Role() { Id = 18, Title = "سایر اوراق " });
                    objs2.Add(new Role() { Id = 19, Title = "سلف " });
                    ViewBag.SymbolType = new SelectList(objs2, "Id", "Title", objSymGroup.GroupsNameId);


                    List<Role> objs3 = new List<Role>();
                    objs3.Add(new Role() { Id = 8, Title = "سایر" });
                    objs3.Add(new Role() { Id = 9, Title = "تأميـن سرمايه كاردان  " });
                    objs3.Add(new Role() { Id = 10, Title = " تأميـن سرمايه امين " });
                    objs3.Add(new Role() { Id = 11, Title = " تأميـن سرمايه آرمان " });
                    objs3.Add(new Role() { Id = 12, Title = " تأميـن سرمايه نوين " });
                    objs3.Add(new Role() { Id = 18, Title = "كارگزاري بانك سپه " });
                    objs3.Add(new Role() { Id = 19, Title = "تأميـن سرمايه لوتوس پارسيان " });
                    objs3.Add(new Role() { Id = 19, Title = "تأميـن سرمايه اميد " });
                    objs3.Add(new Role() { Id = 19, Title = "سرمايه گذاري پارس آريان " });
                    objs3.Add(new Role() { Id = 19, Title = "تأميـن سرمايه بانك ملت " });
                    ViewBag.MarketMakerId = new SelectList(objs3, "Id", "Title", result.MarketMakerId);






                    ViewBag.symbolId = result.Id;


                    return View(result);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpGet]
        [Authorize]
        public ActionResult UpdateDebtSymbol(string Id)
        {
            try
            {
                using (var sql2 = new LinqHelper())
                {

                    LinqHelper sql = new LinqHelper();
                    var result = sql.GetDebtSymbolById(Id.ToValidMsgInt());
                    return View(result);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }







        [HttpPost]
        [Authorize]
        public JsonResult DeleteDebtSymbol(string Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteDebtSymbol(Id.ToValidMsgInt());
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }

        [HttpPost]
        [Authorize]
        public JsonResult DeleteDebtBondSymbol(string Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteDebtBondSymbol(Guid.Parse(Id));
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }




        [Authorize]
        public ActionResult LoadData()
        {
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            var startDate = Request.Form.GetValues("startDate").FirstOrDefault().ToValidMsgDate();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault().ToValidMsgDate();

            try
            {
                using (var sql = new LinqHelper())
                {


                    var result = sql.GetDebtBondswithClosing().Where(c => c.StartDate >= startDate && c.StartDate <= endDate)
                        .OrderBy(c => c.Id).ToList();

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {
                        case "Symbol":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Symbol).ToList();
                            else
                                result = result.OrderByDescending(p => p.Symbol).ToList();
                            break;
                        case "Num":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Num).ToList();
                            else
                                result = result.OrderByDescending(p => p.Num).ToList();
                            break;
                        case "StartDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.StartDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.StartDate).ToList();
                            break;
                        case "EndDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.EndDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.EndDate).ToList();
                            break;

                        case "ClosingPrice":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.ClosingPrice).ToList();
                            else
                                result = result.OrderByDescending(p => p.ClosingPrice).ToList();
                            break;

                    }

                    //paging Data
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();

                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        [Authorize]
        public ActionResult LoadSymbolDailyInterest(string Symbol, string Date)
        {
            try
            {
                using (var sql = new LinqHelper())
                {


                    var result = sql.GetSymbolDailyInterest(Symbol, Date.ToValidMsgInt());

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }




        [Authorize]
        public ActionResult LoadSymbolCoupons(string Symbol, string Date)
        {
            try
            {
                using (var sql = new LinqHelper())
                {


                    var result = sql.GetSymbolCoupons(Symbol, Date.ToValidMsgInt());

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }





        [Authorize]
        public ActionResult LoadSymbolLatest()
        {
            try
            {
                var Symbol = Request.Form.GetValues("Symbol").FirstOrDefault();



                using (var sql = new LinqHelper())
                {
                    var result = sql.GetDebtSymbolLatest(Symbol.ToValidMsgString());
                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [HttpPost]
        [Authorize]
        public ActionResult Register(DebtBond obj)
        {
            using (var sql = new LinqHelper())
            {
                obj.RegUser = Assistant.CurrentUser();
                obj.RegDate = Assistant.TodayDateInt();
                obj.RegTime = Assistant.TimeNowInt();

                var result = sql.InsertDebtBonds(obj);
                sql.AutoGenerateDebtBonds(result);


                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Authorize]
        public ActionResult RegisterAllDebtBonds(string StartDate,string EndDate)
        {
            using (var sql = new LinqHelper())
            {
                    sql.AutoGeneratePositionDebtBonds(StartDate.ToValidMsgDate(),EndDate.ToValidMsgDate());
                    return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Authorize]
        public ActionResult PreviewIOFlow(string Symbol, string Num, string StartDate, string EndDate)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.PreviewAutomaticDebtBondsInputOutputFlowCycle(Symbol, StartDate.ToValidMsgDate(), EndDate.ToValidMsgDate(), Num.ToValidMsgdouble());
                    return Json(new
                    {
                        data = result
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }



        [HttpPost]
        [Authorize]
        public ActionResult InsertBond(
              string SymbolName
            , string Name
            , string InsCode
            , string PublishDate
            , string MaturityDate
            , string NominalPrice
            , string Rate
            , string TotalAccepted
            , string Total
            , string TotalBond
            , string TotalAcceptedNumber
            , string Publisher
            , string Promisor
            , string MarketMaker
            , string BuyPriceGuarantee
            , string MaxDailyGuarantee
            , string SellAgent
            , string Accounter
            , string SecondaryDate
            , string MarketType
            , string SymbolGroup

            , string MinYieldRate
            , string MaxYieldRate
            , string BuyGuaranteeRate
            , string InitialPrice
            , string BaseAsset
            , string MarketMakerId
            , string MarketDes
            , string Sponsor
            , string Founder
            , string ProfitPaymentOperat
            )
        {

            using (var sql = new LinqHelper())
            {

                //بررسی تکراری نبود نام نماد و کدنماد
                // if (sql.GetSymbolByName(SymbolName) != null) return Json(new MessageResponse { Success = false, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet); 
                var obj = sql.GetInstrumentsBySymbol(SymbolName);
                if (obj == null) return Json(new MessageResponse { Success = false, Message = "نماد نامعتبر می باشد", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
                if (obj.InsCode.ToString() != InsCode) return Json(new MessageResponse { Success = false, Message = "نام نماد با کد مطابقت ندارد", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
                if (sql.GetSymbolByIsin(InsCode) != null) return Json(new MessageResponse { Success = false, Message = "نماد تکراری می باشد", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
                //if (txtMaturityDate.Text.TryParseInt32() != 0 &&
                //    txtPublisher.Text.TryParseInt32() == txtMaturityDate.Text.TryParseInt32()) return;
                //if (sql.GetNamesSymbols().Where(c => c.Name == SymbolName) != null) return Json(new MessageResponse { Success = false, Message = "نماد تکراری می باشد", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);


                var objSymbol = new Sanay.Lotus.Erm.DataAccess.Symbol
                {
                    Symbol1 = SymbolName
                    ,
                    Name = Name
                    ,
                    Isin = InsCode
                    ,
                    PublishDate = PublishDate.ToValidMsgDate()
                    ,
                    MaturityDate = MaturityDate.ToValidMsgDate()
                    ,
                    NominalPrice = NominalPrice.ToValidMsgdecimal()
                    ,
                    Rate = Rate
                    ,
                    TotalAccepted = TotalAccepted.ToValidMsgInt()
                    ,
                    Publisher = Publisher
                    ,
                    Promisor = Promisor
                    ,
                    MarketMaker = MarketMaker
                    ,
                    BuyPriceGuarantee = BuyPriceGuarantee.ToValidMsgdecimal()
                    ,
                    MaxDailyGuarantee = MaxDailyGuarantee.ToValidMsgdecimal()
                    ,
                    SellAgent = SellAgent
                    ,
                    Accounter = Accounter
                    ,
                    SecondaryDate = SecondaryDate.ToValidMsgDate()
                    ,
                    MarketId = MarketType.ToValidMsgByte()
                    ,
                    SymbolType = 1
                    ,
                    MinYieldRate = MinYieldRate.ToValidMsgdouble()
                    ,
                    MaxYieldRate = MaxYieldRate.ToValidMsgdouble()
                    ,
                    BuyGuaranteeRate = BuyGuaranteeRate.ToValidMsgdouble()
                    ,
                    InitialPrice = InitialPrice.ToValidMsgdecimal()
                    ,
                    BaseAsset = BaseAsset.ToValidMsgInt()
                    ,
                    MarketMakerId = MarketMakerId.ToValidMsgInt()
                    ,
                    MarketDesc = MarketDes

                    ,
                    Total = Total.ToValidMsgInt()
                    ,
                    Sponsor = Sponsor
                    ,
                    Founder = Founder
                    ,
                    ProfitPaymentOperat = ProfitPaymentOperat
                    ,
                    StatusId = 1
                    ,
                    TotalAcceptedNumber = TotalAcceptedNumber.ToValidMsgInt()
                };
                var result = sql.InsertSymbol(objSymbol);

                var objSymGroup = new SymbolGroup
                {
                    SymbolIsin = objSymbol.Isin,
                    GroupsNameId = SymbolGroup.ToValidMsgInt(),
                    RegDate = Assistant.TodayDateInt(),
                    StatusId = 1,
                };



                sql.InsertSymbolGroups(objSymGroup);
                sql.InsertSymbolBlockByIsin(objSymGroup);





                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        [Authorize]
        public ActionResult UpdateSymbol(
            string Id
           , string SymbolName
         , string Name
         , string InsCode
         , string PublishDate
         , string MaturityDate
         , string NominalPrice
         , string Rate
         , string TotalAccepted
         , string Total
         , string TotalBond
         , string TotalAcceptedNumber
         , string Publisher
         , string Promisor
         , string MarketMaker
         , string BuyPriceGuarantee
         , string MaxDailyGuarantee
         , string SellAgent
         , string Accounter
         , string SecondaryDate
         , string MarketId
         , string SymbolType

         , string MarketMakerId
         , string MarketDes
         , string Sponsor
         , string Founder
         , string ProfitPaymentOperat
            )
        {

            using (var sql = new LinqHelper())
            {

                //بررسی تکراری نبود نام نماد و کدنماد
                // if (sql.GetSymbolByName(SymbolName) != null) return Json(new MessageResponse { Success = false, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet); 
                //if (sql.GetSymbolByIsin(InsCode) != null) return Json(new MessageResponse { Success = false, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
                //if (txtMaturityDate.Text.TryParseInt32() != 0 &&
                //    txtPublisher.Text.TryParseInt32() == txtMaturityDate.Text.TryParseInt32()) return;

                var objSymbol = new Sanay.Lotus.Erm.DataAccess.Symbol
                {
                    Id = Id.ToValidMsgInt(),
                    Symbol1 = SymbolName
                    ,
                    Name = Name
                    ,
                    Isin = InsCode
                    ,
                    PublishDate = PublishDate.ToValidMsgDate()
                    ,
                    MaturityDate = MaturityDate.ToValidMsgDate()
                    ,
                    NominalPrice = NominalPrice.ToValidMsgdecimal()
                    ,
                    Rate = Rate
                    ,
                    TotalAccepted = TotalAccepted.ToValidMsgInt()
                    ,
                    Publisher = Publisher
                    ,
                    Promisor = Promisor
                    ,
                    MarketMaker = MarketMaker
                    ,
                    BuyPriceGuarantee = BuyPriceGuarantee.ToValidMsgdecimal()
                    ,
                    MaxDailyGuarantee = MaxDailyGuarantee.ToValidMsgdecimal()
                    ,
                    SellAgent = SellAgent
                    ,
                    Accounter = Accounter
                    ,
                    SecondaryDate = SecondaryDate.ToValidMsgDate()
                    ,
                    MarketId = MarketId.ToValidMsgByte()
                    ,
                    SymbolType = 1
                    ,
                    MinYieldRate = 0
                    ,
                    MaxYieldRate = 0
                    ,
                    BuyGuaranteeRate = 0
                    ,
                    InitialPrice = 0
                    ,
                    BaseAsset = 0
                    ,
                    MarketMakerId = MarketMakerId.ToValidMsgInt()
                    ,
                    MarketDesc = MarketDes
                    ,
                    Total = Total.ToValidMsgInt()
                    ,
                    Sponsor = Sponsor
                    ,
                    Founder = Founder
                    ,
                    ProfitPaymentOperat = ProfitPaymentOperat
                    ,
                    StatusId = 1
                    ,
                    TotalAcceptedNumber = TotalAcceptedNumber.ToValidMsgInt()
                };
                var result = sql.UpdateDebtSymbol(objSymbol);

                var objSymGroup = sql.GetSymbolGroupsByIsin(InsCode);
                if (objSymGroup != null)
                {
                    var objSymbolGroup = new SymbolGroup()
                    {
                        Id = objSymGroup.Id,
                        GroupsNameId = SymbolType.ToValidMsgInt(),
                        RegDate = Assistant.TodayDateInt()
                    };
                    sql.UpdateSymbolGroups(objSymbolGroup.Id, (int)objSymbolGroup.GroupsNameId, (int)objSymbolGroup.RegDate, InsCode);
                }

                var res = sql.UpdateSymbolBlock(objSymbol);





                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }







        [HttpPost]
        public ActionResult Update(DebtBond obj)
        {
            using (var sql = new LinqHelper())
            {
                obj.RegUser = Assistant.CurrentUser();
                obj.RegDate = Assistant.TodayDateInt();
                obj.RegTime = Assistant.TimeNowInt();

                var item = sql.GetDebtBondsById(obj.Id);
                if (item != null)
                {
                    sql.DeleteDebtBondSymbol(obj.Id);
                    var result = sql.InsertDebtBonds(obj);
                    sql.AutoGenerateDebtBonds(result);
                }
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "AccountingCode" }, JsonRequestBehavior.AllowGet);


            }
        }

        [HttpGet]
        public JsonResult GetSymbols(string term)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetSymbols()
                        .Select(x => new
                        {
                            Text = x.Symbol
                        }).ToList();

                    //list.Add(new {Id = -1, Text = "همه"});
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }


        [HttpGet]
        public JsonResult GetDebtBondSymbols(string term)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetDebtBondSymbols()
                        .Select(x => new
                        {
                            Text = x.Symbol
                        }).ToList();

                    //list.Add(new {Id = -1, Text = "همه"});
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }









        [HttpPost]
        public ActionResult GetDebtNum(string Symbol)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetDebtBondNum(Symbol);

                    //list.Add(new {Id = -1, Text = "همه"});
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }

         

        [HttpPost]
        public JsonResult CheckInstrumentsSymbol(string symbolName)
        {

            try
            {
                using (var db = new LinqHelper())
                {

                    // symbolName = Assistant.ReplacePersianToArabicStrings(symbolName);
                    if (string.IsNullOrEmpty(symbolName)) return Json("", JsonRequestBehavior.AllowGet);

                    var obj = db.GetInstrumentsBySymbol(symbolName);
                    if (obj != null)
                    {
                        var res = !string.IsNullOrEmpty(obj.LVal18AFC) ? obj.InsCode.ToString() : "";
                        return Json(res, JsonRequestBehavior.AllowGet);
                    }

                    var obj1 = db.GetInstrumentsBySymbol(symbolName.Substring(0, symbolName.Length - 1));
                    if (obj1 != null)
                    {
                        var res = !string.IsNullOrEmpty(obj1.LVal18AFC) ? obj1.InsCode.ToString() : "";
                        return Json(res, JsonRequestBehavior.AllowGet);
                    }

                    return Json("", JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }


        [Authorize]
        public ActionResult LoadCoupons()
        {
            try
            {
                var Symbol = Request.Form.GetValues("Symbol").FirstOrDefault();
                //var Num = Request.Form.GetValues("Num").FirstOrDefault();
                var StartDate = Request.Form.GetValues("StartDate").FirstOrDefault();
                var EndDate = Request.Form.GetValues("EndDate").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetSymbolCouponsByFilter(Symbol, StartDate.TryParseInt32(), EndDate.TryParseInt32());
                    if (result == null)
                    {
                        return Json(new
                        {
                            recordsFiltered = 0,
                            recordsTotal = 0,
                            data = ""
                        });
                    }
                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    var data = result.ToList();
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ImportCoupons(HttpPostedFileBase upload, string Symbol)
        {
            // اعتبار سنجی فایل آپلود شده
            if (upload != null && upload.ContentLength > 0 && (upload.FileName.EndsWith(".xls") || upload.FileName.EndsWith(".xlsx")))
            {
                Stream stream = upload.InputStream;

                using (MemoryStream ms = new MemoryStream())
                {
                    stream.CopyTo(ms);
                    var data = ms.ToArray();

                    IExcelDataReader reader = ExcelReaderFactory.CreateReader(stream);
                    DataSet result = reader.AsDataSet(new ExcelDataSetConfiguration()
                    {
                        ConfigureDataTable = (tableReader) => new ExcelDataTableConfiguration()
                        {
                            UseHeaderRow = false
                        }
                    });
                    var datatable = result.Tables[0];
                    var colHeader1 = datatable.Rows[0][0].ToString();
                    var colHeader2 = datatable.Rows[0][1].ToString();

                    //if (reader.FieldCount == 2 && colHeader1 == "زمان" && colHeader2 == "مبلغ سود هر ورقه")
                    if (true)
                    {
                        DataAccess.File fileObj = new DataAccess.File();
                        using (var sql = new LinqHelper())
                        {

                            fileObj.Name = Path.GetFileNameWithoutExtension(upload.FileName);
                            fileObj.Extension = Path.GetExtension(upload.FileName);
                            fileObj.Size = data.Length;
                            fileObj.Sender = Assistant.CurrentUser();
                            fileObj.StatusId = 1;
                            fileObj.RegDate = Convert.ToInt32(Assistant.MiladiToShamsi(Assistant.TodayDateIntMiladi()));
                            fileObj.RegTime = Assistant.TimeNowInt();
                            fileObj.Binary = data;
                            fileObj.FileTypeId = Convert.ToInt32(101);
                            var res = sql.InsertPosition(fileObj);

                            List<Lib.Dto.SymbolCoupons> list = datatable.AsEnumerable().Skip(1)
                                .Select(row => new Lib.Dto.SymbolCoupons
                                {
                                    Symbol = Symbol,
                                    Pdate = (string)(row.Field<string>(0)).ToString(),
                                    Interest = (string)(row.Field<Object>(1)).ToString(),
                                })
                                .ToList();

                            sql.DeleteSymbolCoupons(Symbol);

                            foreach (var item in list)
                            {

                                sql.InsertSymbolCoupons(item);
                            }

                            sql.InsertSymbolCouponsBlock(Symbol);

                        }
                        reader.Close();




                        ViewBag.Symbol = Symbol;
                        return View(datatable);
                    }
                }
            }

            ModelState.AddModelError("File", "خطایی رخ داده! فایل مورد نظر با فایل استاندارد همخوانی ندارد ...! ");
            return View();
        }


        [Authorize]
        public FileResult DownloadCoupons()
        {
            string path = Server.MapPath("~/App_Data/Files");
            string fileName = Path.GetFileName("SampleCoupon.xlsx");
            string fullPath = Path.Combine(path, fileName);
            return File(fullPath, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "SymbolCouponsSample.xlsx");
        }


        [Authorize]
        public FileResult DownloadDailyInterest()
        {
            string path = Server.MapPath("~/App_Data/Files");
            string fileName = Path.GetFileName("SampleSymbolDailyInterest.xlsx");
            string fullPath = Path.Combine(path, fileName);
            return File(fullPath, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "SymbolDailyInterestsSample.xlsx");
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ImportSymbolDailyInterest(HttpPostedFileBase upload, string Symbol)
        {
            // اعتبار سنجی فایل آپلود شده
            if (upload != null && upload.ContentLength > 0 && (upload.FileName.EndsWith(".xls") || upload.FileName.EndsWith(".xlsx")))
            {
                Stream stream = upload.InputStream;

                using (MemoryStream ms = new MemoryStream())
                {
                    stream.CopyTo(ms);
                    var data = ms.ToArray();

                    IExcelDataReader reader = ExcelReaderFactory.CreateReader(stream);
                    DataSet result = reader.AsDataSet(new ExcelDataSetConfiguration()
                    {
                        ConfigureDataTable = (tableReader) => new ExcelDataTableConfiguration()
                        {
                            UseHeaderRow = false
                        }
                    });
                    var datatable = result.Tables[0];
                    var colHeader1 = datatable.Rows[0][0].ToString();
                    var colHeader2 = datatable.Rows[0][1].ToString();

                    //if (reader.FieldCount == 2 && colHeader1 == "زمان" && colHeader2 == "سودهای روزشمار")
                    if (true)
                    {
                        DataAccess.File fileObj = new DataAccess.File();
                        using (var sql = new LinqHelper())
                        {

                            fileObj.Name = Path.GetFileNameWithoutExtension(upload.FileName);
                            fileObj.Extension = Path.GetExtension(upload.FileName);
                            fileObj.Size = data.Length;
                            fileObj.Sender = Assistant.CurrentUser();
                            fileObj.StatusId = 1;
                            fileObj.RegDate = Convert.ToInt32(Assistant.MiladiToShamsi(Assistant.TodayDateIntMiladi()));
                            fileObj.RegTime = Assistant.TimeNowInt();
                            fileObj.Binary = data;
                            fileObj.FileTypeId = Convert.ToInt32(102);
                            var res = sql.InsertPosition(fileObj);

                            List<Lib.Dto.SymbolCoupons> list = datatable.AsEnumerable().Skip(1)
                                .Select(row => new Lib.Dto.SymbolCoupons
                                {
                                    Symbol = Symbol,
                                    Pdate = (string)(row.Field<string>(0)).ToString(),
                                    Interest = (string)(row.Field<Object>(1)).ToString(),
                                })
                                .ToList();

                            sql.DeleteSymbolDailyInterest(Symbol);

                            foreach (var item in list)
                            {

                                sql.InsertSymbolDailyInterest(item);
                            }

                            sql.InsertSymbolDailyInterestsBlock(Symbol);



                        }
                        reader.Close();
                        ViewBag.Symbol = Symbol;

                        return View(datatable);
                    }
                }
            }

            ModelState.AddModelError("File", "خطایی رخ داده! فایل مورد نظر با فایل استاندارد همخوانی ندارد ...! ");
            return View();
        }








    }
}