﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.DataAccess;

namespace Sanay.Lotus.Erm.Controllers
{
    [Authorize]
    public class TopFundsController : Controller
    {
        // GET: TopFunds
        public ActionResult Index()
        {

            ViewBag.TodayDate = Assistant.TodayDateBySlash();


            return View();
        }



        //[HttpPost]
        //[Authorize]
        //public JsonResult LoadSumNAVData()
        //{
        //    using (var sql = new LinqHelper())
        //    {

        //        List<GetLatestFunds_Result> a1 = new List<GetLatestFunds_Result>();
        //        var result = sql.GetLatestFunds(0, int.MaxValue).OrderByDescending(c => c.NAV).ToList();

        //        result = result.GroupBy(d => d.FundType)
        //                                       .Select(
        //                                           g => new GetLatestFunds_Result
        //                                           {
        //                                               Id = g.First().Id,
        //                                               FundType = g.First().FundType,
        //                                               NAV = g.Sum(s => s.NAV)
        //                                           }).ToList();  

        //        //var result = sql.LoadDataAnalysis(MiladiDate);
        //        return Json(result, JsonRequestBehavior.AllowGet);
        //    }
        //}


        public ActionResult LoadSumNAVData()
        {
            try
            {

                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var Date = Request.Form.GetValues("Date").FirstOrDefault();

                //var cht1 = Request.Form.GetValues("cht1").FirstOrDefault();
                //var cht2 = Request.Form.GetValues("cht2").FirstOrDefault();
                //var cht3 = Request.Form.GetValues("cht3").FirstOrDefault();

                //List<string> fundsType = new List<string>();
                //fundsType.Add(cht1);
                //fundsType.Add(cht2);
                //fundsType.Add(cht3);

                //var cht0 = 0;
                //if (cht1 == "" && cht2 == "" && cht3 == "")
                //    cht0 = -1;

                using (var sql = new LinqHelper())
                {
                    List<GetLatestFunds_Result> a1 = new List<GetLatestFunds_Result>();
                    var result = sql.GetLatestFunds(0, int.MaxValue, Date.ToValidMsgDate()).OrderByDescending(c => c.NAV).ToList();

                    result = result.GroupBy(d => d.FundType)
                                                   .Select(
                                                       g => new GetLatestFunds_Result
                                                       {
                                                           Id = g.First().Id,
                                                           FundType = g.First().FundType,
                                                           NAV = g.Sum(s => s.NAV)
                                                       }).ToList();

                   var  resultTotal = result.GroupBy(d => d.JalaliDate)
                                                  .Select(
                                                      g => new GetLatestFunds_Result
                                                      {
                                                          Id = g.First().Id,
                                                          FundType = "همه",
                                                          NAV = g.Sum(s => s.NAV)
                                                      }).ToList();

                    result.AddRange(resultTotal);



                    var i = 1;
                    foreach (var f in result)
                        f.RowNum = i++;

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                   

                    //paging Data
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();

                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }








        public ActionResult LoadNAVData()
        {
            try
            {

                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var cht1 = Request.Form.GetValues("cht1").FirstOrDefault();
                var cht2 = Request.Form.GetValues("cht2").FirstOrDefault();
                var cht3 = Request.Form.GetValues("cht3").FirstOrDefault();
                var cht4 = Request.Form.GetValues("cht4").FirstOrDefault();
                var cht5 = Request.Form.GetValues("cht5").FirstOrDefault();
                var cht6 = Request.Form.GetValues("cht6").FirstOrDefault();

                var Date = Request.Form.GetValues("Date").FirstOrDefault();


                List<string> fundsType = new List<string>();
                fundsType.Add(cht1);
                fundsType.Add(cht2);
                fundsType.Add(cht3);
                fundsType.Add(cht4);
                fundsType.Add(cht5);
                fundsType.Add(cht6);

                var cht0 = 0;
                if (cht1 == "" && cht2 == "" && cht3 == "" && cht4 == "" && cht5 == "" && cht6 == "")
                    cht0 = -1;

                using (var sql = new LinqHelper())
                {

                    var result = sql.GetLatestFunds(0, int.MaxValue, Date.ToValidMsgDate())
                        .OrderByDescending(c => c.NAV)
                        .Where(c => cht0 == -1 || fundsType.Contains(c.FundType)).ToList();

                    var i = 1;
                    foreach (var f in result)
                        f.RowNum = i++;

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {
                        case "JalaliDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.JalaliDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.JalaliDate).ToList();
                            break;
                        case "NAV":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.NAV).ToList();
                            else
                                result = result.OrderByDescending(p => p.NAV).ToList();
                            break;
                        case "Name":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Name).ToList();
                            else
                                result = result.OrderByDescending(p => p.Name).ToList();
                            break;
                        case "FundType":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.FundType).ToList();
                            else
                                result = result.OrderByDescending(p => p.FundType).ToList();
                            break;
                        case "RowNum":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.RowNum).ToList();
                            else
                                result = result.OrderByDescending(p => p.RowNum).ToList();
                            break;

                    }


                    //paging Data
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();

                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

    }
}