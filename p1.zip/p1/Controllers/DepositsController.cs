﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Globalization;
using System.Web.Security;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dic;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Models;
using Sanay.Library.Utility;

namespace Sanay.Lotus.Erm.Controllers
{
    public class DepositsController : Controller
    {
        // GET: AccountingCode
        [Authorize]

        public ActionResult Index()
        {
            return View();
        }
        [Authorize]
        public ActionResult AddDeposit()
        {
            return View();
        }

    

        [HttpGet]
        [Authorize]
        public ActionResult EditDeposit(Guid Id)
        {
            try
            {
                using (var sql2 = new LinqHelper())
                {

                    LinqHelper sql = new LinqHelper();
                    var result = sql.GetDepositById(Id);
                    return View(result);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        [Authorize]
        public JsonResult DeleteDeposits(Guid Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteDeposit(Id);
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }
        
        [Authorize]
        public ActionResult LoadData()
        {
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            var startDate = Request.Form.GetValues("startDate").FirstOrDefault().ToValidMsgDate();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault().ToValidMsgDate();

            if (endDate == 0) endDate = int.MaxValue;
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetDeposits().Where(c=>c.StartDate>= startDate && c.StartDate<= endDate).OrderBy(c=>c.Id).ToList();

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn) {
                        case "AccountNumber":
                            if(sortColumnDir=="ASC")
                                result = result.OrderBy(p => p.AccountNumber).ToList();
                            else
                                result = result.OrderByDescending(p => p.AccountNumber).ToList();
                            break;
                        case "Bank":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Bank).ToList();
                            else
                                result = result.OrderByDescending(p => p.Bank).ToList();
                            break;
                        case "Rate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Rate).ToList();
                            else
                                result = result.OrderByDescending(p => p.Rate).ToList();
                            break;
                        case "PayDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.PayDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.PayDate).ToList();
                            break;
                        case "Deposit1":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Deposit1).ToList();
                            else
                                result = result.OrderByDescending(p => p.Deposit1).ToList();
                            break;
                        case "Blocked":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Blocked).ToList();
                            else
                                result = result.OrderByDescending(p => p.Blocked).ToList();
                            break;
                        case "StartDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.StartDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.StartDate).ToList();
                            break;
                        case "MaturityDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.MaturityDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.MaturityDate).ToList();
                            break;
                    }

                    //paging Data
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();

                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [HttpPost]
        [Authorize]
        public ActionResult RegisterDeposit(Deposit obj)
        {
            using (var sql = new LinqHelper())
            {
                obj.RegUser = Assistant.CurrentUser();
                obj.RegDate = Assistant.TodayDateInt();
                obj.RegTime = Assistant.TimeNowInt();

                var result = sql.InsertDeposit(obj);
                sql.AutoGenerateDeposit(result);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }




        [HttpPost]
        [Authorize]
        public ActionResult PreviewIOFlow(string Rate,string Deposit1,string Blocked, string PayDate, string StartDate, string MaturityDate)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.PreviewAutomaticDepositsInputOutputFlowCycle(Rate.ToValidMsgdouble(), Deposit1.ToValidMsgdouble(),  Blocked.ToValidMsgdouble(), PayDate.ToValidMsgInt(),StartDate.ToValidMsgDate(),MaturityDate.ToValidMsgDate());
                    return Json(new
                    {
                        data =result
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        [HttpPost]
        public ActionResult UpdateDeposit(Deposit obj)
        {
            using (var sql = new LinqHelper())
            {
                obj.RegUser = Assistant.CurrentUser();
                obj.RegDate = Assistant.TodayDateInt();
                obj.RegTime = Assistant.TimeNowInt();

                var item =sql.GetDepositById(obj.Id);
                if (item != null)
                {
                    sql.DeleteDeposit(obj.Id);
                    var result = sql.InsertDeposit(obj);
                    sql.AutoGenerateDeposit(result);
                }
                //var result = sql.UpdateDeposit(obj);
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "AccountingCode" }, JsonRequestBehavior.AllowGet);
            }
        }


    }
} 