﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Mvc.Jsonp;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.App_Start;
using Sanay.Lotus.Erm.Models;
using Sanay.Lotus.Erm.Lib.Enum;
 using Sanay.Lotus.Erm.DataAccess.HelperUser;

namespace Sanay.Lotus.Erm.Controllers
{
    public class PositionsController : Controller
    {
        // GET: Positions
        [Authorize]
        public ActionResult Index()
        {
            return View();
        }

        [Authorize]
        public ActionResult PositionOperation()
        {
            return View();
        }


        [Authorize]
        public ActionResult LoadDataPositionOperation()
        {
            try
            {
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var symbol = Request.Form.GetValues("symbol").FirstOrDefault();
                //var account = Request.Form.GetValues("account").FirstOrDefault();
                var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault();

                if (symbol == "همه") symbol = "%%";
                // if (account == "همه") account = "%%";


                using (var sql = new LinqHelper())
                {
                    var result = sql.GetPositionOperation(start.ToValidMsgInt(), length.ToValidMsgInt(), symbol.ToValidMsgString(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate());
                    int recordsTotal = 0;
                    if (result.Count > 0)
                        recordsTotal = result.FirstOrDefault().TotalRow ?? 0;

                    var recordsFiltered = recordsTotal;

                    //Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = result
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }




        [Authorize]
        public ActionResult AddPosition()
        {
            return View();
        }



        [Authorize]
        public ActionResult PositionPoints()
        {

            ViewBag.Position = 0;
            return View();
        }

        [HttpGet]
        [Authorize]
        public ActionResult EditPosition(string Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                   var result = sql.GetPositionsById(Id.TryParseInt32()).FirstOrDefault();
                    return View(result);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id, ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        [Authorize]
        public ActionResult PositionCouponsDetail(string Symbol, string Account)
        {
            if (Symbol == null) { ViewBag.Symbol = "همه"; } else { ViewBag.Symbol = Symbol; }
            if (Account == null) { ViewBag.Account = "همه"; } else { ViewBag.Account = Account; }
            return View();
        }


        [Authorize]
        public ActionResult PositionDetails()
        {

             ViewBag.Position = 0;

            return View();
        }

        public ActionResult AddPositionCoupons(string Symbol, string Account)
        {
            if (Symbol == null) { ViewBag.Symbol = "همه"; } else { ViewBag.Symbol = Symbol; }
            if (Account == null) { ViewBag.Account = "همه"; } else { ViewBag.Account = Account; }
            return View();
        }



        [Authorize]
        public ActionResult LoadCoupons()
        {
            try
            {
                var Symbol = Request.Form.GetValues("Symbol").FirstOrDefault();
               // var Account = Request.Form.GetValues("Account").FirstOrDefault();
                var SymbolDebt = Request.Form.GetValues("SymbolDebt").FirstOrDefault();

                //var Num = Request.Form.GetValues("Num").FirstOrDefault();
                //var StartDate = Request.Form.GetValues("StartDate").FirstOrDefault();
                //var EndDate = Request.Form.GetValues("EndDate").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetSymbolCoupons(Symbol, SymbolDebt);
                    if (result == null)
                    {
                        return Json(new
                        {
                            recordsFiltered = 0,
                            recordsTotal = 0,
                            data = ""
                        });
                    }
                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    var data = result.ToList();
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        [Authorize]
        public ActionResult LoadPositionCoupons()
        {
            try
            {
                var Symbol = Request.Form.GetValues("Symbol").FirstOrDefault();
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetPositionCoupons(Symbol);
                    if (result == null)
                    {
                        return Json(new
                        {
                            recordsFiltered = 0,
                            recordsTotal = 0,
                            data = ""
                        });
                    }
                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    var data = result.ToList();
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }


     


        [HttpPost]
        [Authorize]
        public JsonResult DeletePositionPoint(int Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeletePositionPoint(Id);
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }



        [HttpGet]
        public JsonResult GetSymbolsDebt(string term)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetSymbols()
                        .Select(x => new
                        {
                            Id = x.Id,
                            Text = x.Symbol
                        }).ToList();

                    //list.Add(new {Id = -1, Text = "همه"});
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }



        //---------------------------------------------------------------------
        [Authorize]
        public ActionResult LoadDataPositions()
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetPosition();

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        [Authorize]
        public ActionResult LoadPositionPoints()
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetPositionPoints();

                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }



        [HttpPost]
        [Authorize]
        public ActionResult RegisterPosition(Position obj)
        {
            if (obj.Date < Assistant.TodayDateInt())
                return Json(new MessageResponse { Success = false, Message = "تاریخ ثبت موقعیت دارایی نمی تواند قبل از روز جاری باشد.", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);

            using (var sql = new LinqHelper())
            {

                var check= sql.GetCheckPositions(obj.Symbol,obj.Account,(int)obj.Date).ToList();
                if(check.Count>0)
                    return Json(new MessageResponse { Success = false, Message = "برای این تاریخ، نماد و کد سهامداری قبلا موقعیت ثبت شده است.", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);

                obj.Symbol = obj.Symbol.Replace(",", "");
                obj.Account = obj.Account.Replace(",", "");
                // return Json(login.RegisterUser(register), JsonRequestBehavior.AllowGet);
                obj.ActionId = -1;
                var result = sql.InsertPosition(obj);            

                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        [Authorize]
        public ActionResult UpdatePosition(Position obj)
        {
            //if (obj.Date < Assistant.TodayDateInt())
            //    return Json(new MessageResponse { Success = false, Message = "تاریخ ثبت موقعیت دارایی نمی تواند قبل از روز جاری باشد.", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);

            using (var sql = new LinqHelper())
            {
                //var check= sql.GetCheckPositions(obj.Symbol,obj.Account,(int)obj.Date).ToList();
                //if(check.Count>0)
                //    return Json(new MessageResponse { Success = false, Message = "برای این تاریخ، نماد و کد سهامداری قبلا موقعیت ثبت شده است.", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);

                //obj.Symbol = obj.Symbol.Replace(",", "");
                //obj.Account = obj.Account.Replace(",", "");
                //// return Json(login.RegisterUser(register), JsonRequestBehavior.AllowGet);
                //obj.ActionId = -1;
                ////var result = sql.InsertPosition(obj);

                obj.IsPoint = true;
                obj.IsUpdate = true;
                obj.TradeType = -2;

                var result = sql.UpdatePosition(obj);            

                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        [Authorize]
        public ActionResult RegisterPositionCoupons(string Symbol, string Account, string SymbolDebt)
        {
            //if (obj.Date < Assistant.TodayDateInt())
            //    return Json(new MessageResponse { Success = false, Message = "تاریخ ثبت موقعیت دارایی نمی تواند قبل از روز جاری باشد.", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);

            using (var sql = new LinqHelper())
            {

                //var check = sql.GetCheckPositions(obj.Symbol, obj.Account, (int)obj.Date).ToList();
                //if (check.Count > 0)
                //    return Json(new MessageResponse { Success = false, Message = "برای این تاریخ، نماد و کد سهامداری قبلا موقعیت ثبت شده است.", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
                 sql.InsertSymbolCouponsInPosition(Symbol, Account, SymbolDebt,Assistant.TodayDateInt() ,Assistant.TimeNowInt() , Assistant.CurrentUser());
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        public JsonResult GetTimeline(string StartDate, string EndDate,string CycleState,string Position)
        {
            using (var sql = new LinqHelper())
            {

                var data = sql.GetSymbolTimeline(StartDate.ToValidMsgInt(), EndDate.ToValidMsgInt(), CycleState.ToValidMsgInt(), Position.ToValidMsgInt());
                data = data.OrderByDescending(c => c.Date).ToList();

                return Json(data, JsonRequestBehavior.AllowGet);
                //return Json(new MessageResponse { Success = true, Message = data.id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }

         
        [Authorize]
        public ActionResult LoadDataPositionDetails()
        {
            try
            {

                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                var symbol = Request.Form.GetValues("symbol").FirstOrDefault();
                var account = Request.Form.GetValues("account").FirstOrDefault();
                var startDate = Request.Form.GetValues("startDate").FirstOrDefault();
                var endDate = Request.Form.GetValues("endDate").FirstOrDefault();



                using (var sql = new LinqHelper())
                {

                    var result = sql.GetBuySells(start.ToValidMsgInt(), length.ToValidMsgInt(), searchValue, (int)TradeType.All, symbol.ToValidMsgString(), account.ToValidString(), startDate.ToValidMsgDate(), endDate.ToValidMsgDate());
                    //Paging Size (10,20,50,100)  
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;

                    // Getting all Customer data  
                    var customerData = result;

                    //total number of rows count   
                    recordsTotal = customerData.Count();
                    //Paging   
                    var data = customerData.Skip(skip).Take(pageSize).ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        draw = draw,
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }





        [HttpGet]
        public JsonResult GetSymbols(string term)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetBuySellsSymbol()
                        .Select(x => new
                        {
                            Id = x.Id,
                            Text = x.Symbol
                        }).ToList();

                    //list.Add(new {Id = -1, Text = "همه"});
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }



        [HttpGet]
        public JsonResult GetAccounts(string term)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetBuySellsAccount()
                        .Select(x => new
                        {
                            Id = x.Id,
                            Text = x.Account
                        }).ToList();
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult GetBrokers(string term)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetBrokers()
                        .Select(x => new
                        {
                            Id = x.Id,
                            Text = x.BrokerCode
                        }).ToList();
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }


        [Authorize]
        public ActionResult Rollback()
        {
            return View();
        }

        [Authorize]
        public ActionResult RollbackToDate(string date)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    for (int i = 0; i < 1000000000; i++)
                    {
                        
                    }
                    //var list = sql.();
                    return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

                return Json(new MessageResponse { Success = false, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);

            }
        }
    }
}