﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Web.Security;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dic;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Models;
using Sanay.Library.Utility;
using System.IO;
using System.Data;

using ExcelDataReader;
using Sanay.Lotus.Erm.Lib.Dto;

namespace Sanay.Lotus.Erm.Controllers
{
    public class FundDebtBondsController : Controller
    {
        // GET: AccountingCode
        [Authorize]

        public ActionResult Index()
        {
            return View();
        }


        [Authorize]
        public ActionResult DebtBonds()
        {
            return View();
        }

        [Authorize]
    

     



        [Authorize]
        public ActionResult Add()
        {
            return View();
        }

     


        [HttpGet]
        [Authorize]
        public ActionResult Edit(string Id)
        {
            try
            {
                using (var sql2 = new LinqHelper())
                {

                    LinqHelper sql = new LinqHelper();
                    var result = sql.GetFundDebtBondsById(Guid.Parse(Id),1);
                    return View(result);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }

        }


        [HttpPost]
        [Authorize]
        public JsonResult DeleteFundDebtBond(string Id)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.DeleteFundDebtBondSymbol(Guid.Parse(Id),1);
                    return Json(data: "Deleted", behavior: JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(new MessageResponse { Success = true, Message = Id.ToString(), ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }




        [Authorize]
        public ActionResult LoadData()
        {
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
            var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

            var startDate = Request.Form.GetValues("startDate").FirstOrDefault().ToValidMsgDate();
            var endDate = Request.Form.GetValues("endDate").FirstOrDefault().ToValidMsgDate();

            try
            {
                using (var sql = new LinqHelper())
                {


                    var result = sql.GetFundDebtBonds().Where(c => ((c.StartDate >= startDate  && c.StartDate <= endDate) || startDate == 0) && c.FundId==1)
                        .OrderBy(c => c.Id).ToList();

                    //sorting Data
                    sortColumnDir = sortColumnDir.ToUpper();
                    switch (sortColumn)
                    {
                        case "Symbol":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Symbol).ToList();
                            else
                                result = result.OrderByDescending(p => p.Symbol).ToList();
                            break;
                        case "Num":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.Num).ToList();
                            else
                                result = result.OrderByDescending(p => p.Num).ToList();
                            break;
                        case "StartDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.StartDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.StartDate).ToList();
                            break;
                        case "EndDate":
                            if (sortColumnDir == "ASC")
                                result = result.OrderBy(p => p.EndDate).ToList();
                            else
                                result = result.OrderByDescending(p => p.EndDate).ToList();
                            break;

                    }

                    //paging Data
                    int pageSize = length != null ? Convert.ToInt32(length) : 0;
                    int skip = start != null ? Convert.ToInt32(start) : 0;
                    int recordsTotal = 0;
                    var customerData = result;
                    recordsTotal = customerData.Count();
                    var data = customerData.Skip(skip).Take(pageSize).ToList();

                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

         

        [Authorize]
        public ActionResult LoadSymbolLatest()
        {
            try
            {
                var Symbol = Request.Form.GetValues("Symbol").FirstOrDefault();



                using (var sql = new LinqHelper())
                {
                    var result = sql.GetDebtSymbolLatest(Symbol.ToValidMsgString());
                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    //Paging   
                    // var data = result.Skip(skip).Take(pageSize).ToList();
                    var data = result.ToList();
                    //Returning Json Data  
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [HttpPost]
        [Authorize]
        public ActionResult Register(FundDebtBond obj)
        {
            using (var sql = new LinqHelper())
            {
                obj.RegUser = Assistant.CurrentUser();
                obj.RegDate = Assistant.TodayDateInt();
                obj.RegTime = Assistant.TimeNowInt();
                obj.FundId = 1;
                var result = sql.InserFundtDebtBonds(obj);
                sql.AutoGenerateFundDebtBonds(result,1);


                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "" }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        [Authorize]
        public ActionResult PreviewFundIOFlow(string Symbol, string Num, string StartDate, string EndDate)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.PreviewAutomaticFundDebtBondsInputOutputFlowCycle(Symbol, StartDate.ToValidMsgDate(), EndDate.ToValidMsgDate(), Num.ToValidMsgdouble(),1);
                    return Json(new
                    {
                        data = result
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }



     





        [HttpPost]
        public ActionResult Update(FundDebtBond obj)
        {
            using (var sql = new LinqHelper())
            {
                obj.RegUser = Assistant.CurrentUser();
                obj.RegDate = Assistant.TodayDateInt();
                obj.RegTime = Assistant.TimeNowInt();
                obj.FundId = 1;

                var item = sql.GetFundDebtBondsById(obj.Id,1);
                if (item != null)
                {
                     
                    sql.DeleteFundDebtBondSymbol(obj.Id,1);
                    var result = sql.InserFundtDebtBonds(obj);
                    sql.AutoGenerateFundDebtBonds(result, 1);
                }
                return Json(new MessageResponse { Success = true, Message = "", ReturnUrl = "AccountingCode" }, JsonRequestBehavior.AllowGet);


            }
        }

        [HttpGet]
        public JsonResult GetSymbols(string term)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var list = sql.GetSymbols()
                        .Select(x => new
                        {
                            Text = x.Symbol
                        }).ToList();

                    //list.Add(new {Id = -1, Text = "همه"});
                    return Json(list, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }




        [HttpPost]
        public JsonResult CheckInstrumentsSymbol(string symbolName)
        {

            try
            {
                using (var db = new LinqHelper())
                {

                    // symbolName = Assistant.ReplacePersianToArabicStrings(symbolName);
                    if (string.IsNullOrEmpty(symbolName)) return Json("", JsonRequestBehavior.AllowGet);

                    var obj = db.GetInstrumentsBySymbol(symbolName);
                    if (obj != null)
                    {
                        var res = !string.IsNullOrEmpty(obj.LVal18AFC) ? obj.InsCode.ToString() : "";
                        return Json(res, JsonRequestBehavior.AllowGet);
                    }

                    var obj1 = db.GetInstrumentsBySymbol(symbolName.Substring(0, symbolName.Length - 1));
                    if (obj1 != null)
                    {
                        var res = !string.IsNullOrEmpty(obj1.LVal18AFC) ? obj1.InsCode.ToString() : "";
                        return Json(res, JsonRequestBehavior.AllowGet);
                    }

                    return Json("", JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
        }


        [Authorize]
        public ActionResult LoadCoupons()
        {
            try
            {
                var Symbol = Request.Form.GetValues("Symbol").FirstOrDefault();
                //var Num = Request.Form.GetValues("Num").FirstOrDefault();
                var StartDate = Request.Form.GetValues("StartDate").FirstOrDefault();
                var EndDate = Request.Form.GetValues("EndDate").FirstOrDefault();

                using (var sql = new LinqHelper())
                {
                    var result = sql.GetSymbolCouponsByFilter(Symbol, StartDate.TryParseInt32(), EndDate.TryParseInt32());
                    if (result == null)
                    {
                        return Json(new
                        {
                            recordsFiltered = 0,
                            recordsTotal = 0,
                            data = ""
                        });
                    }
                    int recordsTotal = 0;
                    recordsTotal = result.Count();
                    var data = result.ToList();
                    return Json(new
                    {
                        recordsFiltered = recordsTotal,
                        recordsTotal = recordsTotal,
                        data = data
                    });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }


      




    }
}