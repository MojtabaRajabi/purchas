﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Stimulsoft.Report;

using Stimulsoft.Report.Web;
using Stimulsoft.Report.Mvc;
using Sanay.Lotus.Erm.DataAccess;

namespace Sanay.Lotus.Erm.Controllers
{
    public class ViewerController : Controller
    {

        static ViewerController()
        {
            // How to Activate
            //Stimulsoft.Base.StiLicense.Key = "6vJhGtLLLz2GNviWmUTrhSqnO...";
            //Stimulsoft.Base.StiLicense.LoadFromFile("license.key");
            //Stimulsoft.Base.StiLicense.LoadFromStream(stream);
        }

        public ActionResult Index()
        {
            return View();
        }
        private void CheckReference(StiReport report)
        {
            string assemblyName = Assembly.GetExecutingAssembly().ManifestModule.Name;
            List<string> refs = new List<string>(report.ReferencedAssemblies);
            if (!refs.Contains(assemblyName))
            {
                refs.Add(assemblyName);
                report.ReferencedAssemblies = refs.ToArray();
            }
        }





        public ActionResult ReportIssuanceBuys(string symbol, string account, string startDate, string endDate)
        {
            return View("ViewReportIssuanceBuys");
        }

        public ActionResult ViewerEventIssuanceBuys()
        {
            return StiMvcViewer.ViewerEventResult();
        }
        public ActionResult GetReportIssuanceBuys()
        {
            var symbol = Request.QueryString.GetValues("symbol").FirstOrDefault();
            var account = Request.QueryString.GetValues("account").FirstOrDefault();
            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();

            var sql = new LinqHelper();
            var result = sql.GetIssuanceBuys(symbol, account, startDate.ToValidMsgDate(), endDate.ToValidMsgDate());
            StiReport report = new StiReport();
            report.Load(Server.MapPath("~/Content/Reports/IssuanceBuys.mrt"));
            report.RegBusinessObject("Info", new { symbol = symbol, account = account, _StartDate = startDate, _EndDate = endDate });
            report.RegBusinessObject("Objects", result);
            CheckReference(report);
            return StiMvcViewer.GetReportResult(report);
        }






        public ActionResult ReportIssuanceSells(string symbol, string account, string startDate, string endDate)
        {
            return View("ViewReportIssuanceSells");
        }

        public ActionResult ReportCalculateCapitalSufficiencies(string startDate, string endDate)
        {
            return View("ViewReportCalculateCapitalSufficiencies");
        }

        public ActionResult ViewerEventIssuanceSells()
        {
            return StiMvcViewer.ViewerEventResult();
        }
        public ActionResult GetReportIssuanceSells()
        {
            var symbol = Request.QueryString.GetValues("symbol").FirstOrDefault();
            var account = Request.QueryString.GetValues("account").FirstOrDefault();
            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();

            var sql = new LinqHelper();
            var result = sql.GetIssuanceSells(symbol, account, startDate.ToValidMsgDate(), endDate.ToValidMsgDate());
            StiReport report = new StiReport();
            report.Load(Server.MapPath("~/Content/Reports/IssuanceSells.mrt"));
            report.RegBusinessObject("Info", new { symbol = symbol, account = account, _StartDate = startDate, _EndDate = endDate });
            report.RegBusinessObject("Objects", result);
            CheckReference(report);
            return StiMvcViewer.GetReportResult(report);
        }


        public ActionResult GetReportCalculateCapitalSufficiencies()
        {
            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();

            var sql = new LinqHelper();
            var result = sql.GetCalculateCapitalSufficiencies(startDate.ToValidMsgDate(), endDate.ToValidMsgDate());
            StiReport report = new StiReport();
            report.Load(Server.MapPath("~/Content/Reports/CalcuteCapitalSufficiencies.mrt"));
            report.RegBusinessObject("Info", new { _StartDate = startDate, _EndDate = endDate });
            report.RegBusinessObject("Objects", result);
            CheckReference(report);
            return StiMvcViewer.GetReportResult(report);
        }
        public ActionResult ViewerEventCapitalSufficiencies()
        {
            return StiMvcViewer.ViewerEventResult();
        }











        public ActionResult ReportCapitalSufficiencies()
        {
            return View("ViewCapitalSufficiencies");
        }

        public ActionResult GetReportCapitalSufficiencies()
        {


            var Id = Request.QueryString.GetValues("Id").FirstOrDefault();
            var DF1 = "200";
            var DF2 = "30";
            var DF3 = "200";


            var sql = new LinqHelper();
            var result = sql.GetResultCapitalSufficienciesById(Id.TryParseInt32());
            StiReport report = new StiReport();
            report.Load(Server.MapPath("~/Content/Reports/CapitalSufficiencies.mrt"));
            report.RegBusinessObject("Info", new { DF1 = DF1.TryParseDouble(), DF2 = DF2.TryParseDouble(), DF3 = DF3.TryParseDouble() });
            report.RegBusinessObject("Objects", result);
            CheckReference(report);
            return StiMvcViewer.GetReportResult(report);
        }




        public ActionResult ReportFund()
        {
            return View("ViewReportFund");
        }
        public ActionResult GetReportFund()
        {

            var Id = Request.QueryString.GetValues("Id").FirstOrDefault();
            var sql = new LinqHelper();

            var FundData = sql.GetFundDataByFundId(Id.TryParseInt32());

            var FundProperties = sql.GetFundPropertiesByFundId(Id.TryParseInt32());

            var FundBondAsset = sql.GetFundBondAsset(Id.ToValidMsgInt());

            var FundSymbols = sql.GetFundSymbolsByFundId(Id.TryParseInt32(), Assistant.TodayDateInt());

            var FundIndustries = sql.GetFundIndustriesByFundId(Id.TryParseInt32());
            foreach (var f in FundIndustries)
                f.Value = Math.Round((double)f.Value, 2);
            var FundMixAssets = sql.GetFundMixAssetsByFundId(Id.TryParseInt32()).FirstOrDefault();


            StiReport report = new StiReport();
            report.Load(Server.MapPath("~/Content/Reports/Fund.mrt"));
            report.RegBusinessObject("FundData", FundData);
            report.RegBusinessObject("FundProperties", FundProperties);
            report.RegBusinessObject("FundBondAsset", FundBondAsset);
            report.RegBusinessObject("FundSymbols", FundSymbols);
            report.RegBusinessObject("FundIndustries", FundIndustries);
            report.RegBusinessObject("FundMixAssets", FundMixAssets);



            report.RegBusinessObject("FundMixAssetsChart", new object[] { new{ data = Math.Round((double)FundMixAssets.DepositTodayPercent,2), lable = "سپرده بانکی" }
                                                                        , new { data = Math.Round((double)FundMixAssets.TopFiveStockTodayPercent,2), lable = "پنج سهم با بیشترین وزن" }
                                                                        , new { data = Math.Round((double)FundMixAssets.CashTodayPercent,2), lable = "وجه نقد" }
                                                                        , new { data = Math.Round((double)FundMixAssets.OtherAssetTodayPercent,2), lable = "سایر دارایی ها" }
                                                                        , new { data = Math.Round((double)FundMixAssets.BondTodayPercent,2), lable = "اوراق مشارکت" }
                                                                        , new { data =Math.Round((double)(100 - FundMixAssets.BondTodayPercent-FundMixAssets.DepositTodayPercent
                                                                        -FundMixAssets.TopFiveStockTodayPercent-FundMixAssets.CashTodayPercent-FundMixAssets.OtherAssetTodayPercent),2), lable = "سایر سهام" }
                                                                        });



            CheckReference(report);
            return StiMvcViewer.GetReportResult(report);
        }
        public ActionResult ViewerEventReportFund()
        {
            return StiMvcViewer.ViewerEventResult();
        }


        public ActionResult ReportPortfolio()
        {
            return View("ViewReportPortfolio");
        }
        public ActionResult GetReportPortfolio()
        {
            int pid = -1;

            var sql = new LinqHelper();
            var objPortfolio = sql.GetPortfolio(Assistant.CurrentUser()).ToList();

            if (objPortfolio.Count > 0)
                pid = objPortfolio.FirstOrDefault().Id;

            var portfolioBonds = sql.GetPortfolioBonds(pid).ToList();
            var portfolioDeposits = sql.GetPortfolioDeposits(pid).ToList();

            StiReport report = new StiReport();
            report.Load(Server.MapPath("~/Content/Reports/Portfolio.mrt"));
            report.RegBusinessObject("PortfolioDetails", portfolioBonds);
            report.RegBusinessObject("Deposits", portfolioDeposits);
            report.RegBusinessObject("Portfolio", objPortfolio.FirstOrDefault());
            //report.RegBusinessObject("Objects", result);
            CheckReference(report);
            return StiMvcViewer.GetReportResult(report);
        }
        public ActionResult ViewerEventReportPortfolio()
        {
            return StiMvcViewer.ViewerEventResult();
        }


        public ActionResult ReportSymbolInfo()
        {
            return View("ViewReportSymbolInfo");
        }
        public ActionResult GetReportSymbolInfo()
        {
            var isin = Request.QueryString.GetValues("Isin").FirstOrDefault();

            var sql = new LinqHelper();
            var obj = sql.GetSymbolByIsin(isin);

            StiReport report = new StiReport();
            report.Load(Server.MapPath("~/Content/Reports/SymbolInfo.mrt"));
            report.RegBusinessObject("Info", obj.Symbol);
            report.RegBusinessObject("Objects", obj);
            CheckReference(report);
            return StiMvcViewer.GetReportResult(report);
        }
        public ActionResult ViewerEventReportSymbolInfo()
        {
            return StiMvcViewer.ViewerEventResult();
        }





        public ActionResult ReportPositions()
        {
            return View("ViewReportPositions");
        }

        public ActionResult GetReportPositions()
        {
            var sql = new LinqHelper();
            var result = sql.GetPosition();
            StiReport report = new StiReport();
            report.Load(Server.MapPath("~/Content/Reports/Positions.mrt"));
            report.RegBusinessObject("Info", new { });
            report.RegBusinessObject("Objects", result);
            CheckReference(report);
            return StiMvcViewer.GetReportResult(report);
        }
        public ActionResult ViewerEventReportPositions()
        {
            return StiMvcViewer.ViewerEventResult();
        }











        public ActionResult ReportHoldersTopShares()
        {
            return View("ViewReportHoldersTopShares");
        }
        public ActionResult GetReportHoldersTopShares()
        {
            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();

            var sql = new LinqHelper();

            var res = sql.GetSymbolsShareHoldersProperties().Where(c => c.MaturityDate >= startDate.ToValidMsgDate()
                                                                        && c.MaturityDate <= endDate.ToValidMsgDate());

            res = res.Where(c => c.Percent >= 5).ToList();

            var list = res.GroupBy(d => d.Isin)
                                         .Select(
                                             g => new GetSymbolsShareHoldersProperties_Result
                                             {
                                                 Id = g.First().Id,
                                                 Isin = g.First().Isin,
                                                 Symbol = g.First().Symbol,
                                                 PublishDate = g.First().PublishDate,
                                                 MaturityDate = g.First().MaturityDate,
                                                 SymbolType = g.First().SymbolType,
                                                 SymbolTypeTitle = g.First().SymbolTypeTitle,
                                                 Name = g.First().Name,
                                                 Shareholder = string.Join(" \n ", g.Select(a => a.Shareholder)),
                                                 Percent = g.First().Percent,
                                                 Share = g.First().Share,
                                                 SymbolGroup = g.First().SymbolGroup,
                                                 Market = g.First().Market,
                                             }).ToList();

            var obj = list.OrderByDescending(x => x.Share).Take(5);


            StiReport report = new StiReport();
            report.Load(Server.MapPath("~/Content/Reports/HoldersTopShares.mrt"));
            report.RegBusinessObject("Info", new { });
            report.RegBusinessObject("Objects", obj);
            CheckReference(report);
            return StiMvcViewer.GetReportResult(report);
        }
        public ActionResult ViewerEventReportHoldersTopShares()
        {
            return StiMvcViewer.ViewerEventResult();
        }



        public ActionResult ReportHoldersNearShares()
        {
            return View("ViewReportHoldersNearShares");
        }
        public ActionResult GetReportHoldersNearShares()
        {
            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();

            var sql = new LinqHelper();
            var res = sql.GetSymbolsShareHoldersProperties().Where(c => c.MaturityDate >= startDate.ToValidMsgDate()
                                                                     && c.MaturityDate <= endDate.ToValidMsgDate());

            res = res.Where(c => c.Percent >= 5).ToList();

            var list = res.GroupBy(d => d.Isin)
                                         .Select(
                                             g => new GetSymbolsShareHoldersProperties_Result
                                             {
                                                 Id = g.First().Id,
                                                 Isin = g.First().Isin,
                                                 Symbol = g.First().Symbol,
                                                 PublishDate = g.First().PublishDate,
                                                 MaturityDate = g.First().MaturityDate,
                                                 SymbolType = g.First().SymbolType,
                                                 SymbolTypeTitle = g.First().SymbolTypeTitle,
                                                 Name = g.First().Name,
                                                 Shareholder = string.Join(" \n ", g.Select(a => a.Shareholder)),
                                                 Percent = g.First().Percent,
                                                 Share = g.First().Share,
                                                 SymbolGroup = g.First().SymbolGroup,
                                                 Market = g.First().Market,
                                             }).ToList();

            var obj = list.OrderBy(x => x.MaturityDate).Take(5);

            StiReport report = new StiReport();
            report.Load(Server.MapPath("~/Content/Reports/HoldersNearShares.mrt"));
            report.RegBusinessObject("Info", new { });
            report.RegBusinessObject("Objects", obj);
            CheckReference(report);
            return StiMvcViewer.GetReportResult(report);
        }
        public ActionResult ViewerEventReportHoldersNearShares()
        {
            return StiMvcViewer.ViewerEventResult();
        }




        public ActionResult ReportYearlySharesDate()
        {
            return View("ViewReportYearlySharesDate");
        }
        public ActionResult GetReportYearlySharesDate()
        {
            //var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            //var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();

            var sql = new LinqHelper();

            var res = sql.GetSymbolsShareHoldersProperties().ToList();

            res.ForEach(z => z.MaturityDate = z.MaturityDate / 10000);

            var list = res.GroupBy(d => d.MaturityDate)
                                         .Select(
                                             g => new GetSymbolsShareHoldersProperties_Result
                                             {
                                                 MaturityDate = g.First().MaturityDate,
                                                 Share = g.Sum(s => s.Share),
                                             }).ToList();

            var obj = list.OrderBy(x => x.MaturityDate);


            StiReport report = new StiReport();
            report.Load(Server.MapPath("~/Content/Reports/YearlySharesDate.mrt"));
            report.RegBusinessObject("Info", new { });
            report.RegBusinessObject("Objects", obj);
            CheckReference(report);
            return StiMvcViewer.GetReportResult(report);
        }
        public ActionResult ViewerEventReportYearlySharesDate()
        {
            return StiMvcViewer.ViewerEventResult();
        }


        public ActionResult ReportMonthlySharesDate()
        {
            return View("ViewReportMonthlySharesDate");
        }
        public ActionResult GetReportMonthlySharesDate()
        {
            var Year = Request.QueryString.GetValues("Year").FirstOrDefault();
            //var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();

            var sql = new LinqHelper();

            var res = sql.GetSymbolsShareHoldersProperties().ToList();


            res = res.Where(c => c._Year == Year).ToList();


            var list = res.GroupBy(d => d._Month)
                                         .Select(
                                             g => new GetSymbolsShareHoldersProperties_Result
                                             {
                                                 MaturityDate = g.First().MaturityDate,
                                                 Year = g.First()._Year,
                                                 Share = g.Sum(s => s.Share),
                                                 Month = g.First()._Month
                                             }).ToList();

            var obj = list.OrderBy(x => x.MaturityDate);



            StiReport report = new StiReport();
            report.Load(Server.MapPath("~/Content/Reports/MonthlySharesDate.mrt"));
            report.RegBusinessObject("Info", new { });
            report.RegBusinessObject("Objects", obj);

            CheckReference(report);
            return StiMvcViewer.GetReportResult(report);
        }
        public ActionResult ViewerEventReportMonthlySharesDate()
        {
            return StiMvcViewer.ViewerEventResult();
        }




        public ActionResult ReportBigOwners()
        {
            return View("ViewReportBigOwners");
        }
        public ActionResult GetReportBigOwners()
        {
            var HolderPrcnt = Request.QueryString.GetValues("HolderPrcnt").FirstOrDefault();
            //var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();

            var sql = new LinqHelper();

            var res = sql.GetSymbolsShareHoldersProperties().ToList();
            double total = (double)res.Sum(x => x.Share);

            var list = res.GroupBy(d => d.Shareholder)
                                         .Select(
                                             g => new GetSymbolsShareHoldersProperties_Result
                                             {
                                                 MaturityDate = g.First().MaturityDate,
                                                 Shareholder = g.First().Shareholder,
                                                 Share = g.Sum(s => s.Share),
                                                 Percent = g.Sum(s => s.Share) * 100 / total,

                                             }).ToList();

            var obj = list.Where(c => c.Percent >= HolderPrcnt.ToValidMsgInt()).OrderByDescending(x => x.Percent);


            StiReport report = new StiReport();
            report.Load(Server.MapPath("~/Content/Reports/BigHolders.mrt"));
            report.RegBusinessObject("Info", new { });
            report.RegBusinessObject("Objects", obj);
            CheckReference(report);
            return StiMvcViewer.GetReportResult(report);
        }
        public ActionResult ViewerEventReportBigOwners()
        {
            return StiMvcViewer.ViewerEventResult();
        }



        public ActionResult ReportBigHoldersStatistics()
        {
            return View("ViewReportBigHoldersStatistics");
        }
        public ActionResult GetReportBigHoldersStatistics()
        {
            //var HolderPrcnt = Request.QueryString.GetValues("HolderPrcnt").FirstOrDefault();
            //var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();

            var sql = new LinqHelper();

            var res = sql.GetSymbolsShareHoldersProperties().ToList();

            double total = (double)res.Sum(x => x.Share);
            res = res.OrderByDescending(c => c.Share).ToList();

            for (int i = 0; i < res.Count(); i++)
            {
                res.ElementAt(i).DebtId = i + 1;
            }
            var list = res.GroupBy(d => d.Shareholder)
                                         .Select(
                                             g => new GetSymbolsShareHoldersProperties_Result
                                             {
                                                 DebtId = g.First().DebtId,
                                                 MaturityDate = g.First().MaturityDate,
                                                 Shareholder = g.First().Shareholder,
                                                 Share = g.Sum(s => s.Share),
                                                 Percent = g.Sum(s => s.Share) * 100 / total,
                                                 DebtCount = g.Count(),
                                                 ShareAve = (g.Sum(s => s.Share)) / g.Count(),
                                                 MarketRatio = ((g.Sum(s => s.Share)) / g.Count()) / g.First().DebtId
                                             }).ToList();

            var obj = list.Where(c => c.Percent >= 1).OrderByDescending(x => x.MarketRatio);

            StiReport report = new StiReport();
            report.Load(Server.MapPath("~/Content/Reports/BigHoldersStatistics.mrt"));
            report.RegBusinessObject("Info", new { });
            report.RegBusinessObject("Objects", obj);
            CheckReference(report);
            return StiMvcViewer.GetReportResult(report);
        }
        public ActionResult ViewerEventReportBigHoldersStatistics()
        {
            return StiMvcViewer.ViewerEventResult();
        }




        public ActionResult ReportBigDebtHolders()
        {
            return View("ViewReportBigDebtHolders");
        }
        public ActionResult GetReportBigDebtHolders()
        {
            var Value = Request.QueryString.GetValues("Value").FirstOrDefault();
            //var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();

            var sql = new LinqHelper();


            var res = sql.GetSymbolsShareHoldersPropertiesWithValue().ToList();

            var obj = res.Where(c => c.Value >= Value.ToValidMsglong()).OrderByDescending(x => x.Value).ToList();

            StiReport report = new StiReport();
            report.Load(Server.MapPath("~/Content/Reports/BigDebtHolders.mrt"));
            report.RegBusinessObject("Info", new { });
            report.RegBusinessObject("Objects", obj);
            CheckReference(report);
            return StiMvcViewer.GetReportResult(report);
        }
        public ActionResult ViewerEventReportBigDebtHolders()
        {
            return StiMvcViewer.ViewerEventResult();
        }







        public ActionResult ReportBestHoldersSharesChart()
        {
            return View("ViewReportBestHoldersSharesChart");
        }
        public ActionResult GetReportBestHoldersSharesChart()
        {
            var sql = new LinqHelper();

            var res = sql.GetSymbolsShareHoldersProperties().ToList();

            double total = (double)res.Sum(x => x.Share);

            var list = res.GroupBy(d => d.Shareholder)
                                         .Select(
                                             g => new GetSymbolsShareHoldersProperties_Result
                                             {
                                                 MaturityDate = g.First().MaturityDate,
                                                 Shareholder = g.First().Shareholder,
                                                 Share = g.Sum(s => s.Share),
                                                 Percent = g.Sum(s => s.Share) * 100 / total,

                                             }).ToList();

            var TopResult = list.Where(c => c.Shareholder != "مرکزمدیریت بدهی وزارت اقتصاد").OrderByDescending(x => x.Percent).Take(5);

            var result = res.Where(c => c.Shareholder == TopResult.ElementAt(0).Shareholder
                                      || c.Shareholder == TopResult.ElementAt(1).Shareholder
                                      || c.Shareholder == TopResult.ElementAt(2).Shareholder
                                      || c.Shareholder == TopResult.ElementAt(3).Shareholder
                                      || c.Shareholder == TopResult.ElementAt(4).Shareholder).OrderBy(c => c.MaturityDate).ToList();

            result.Where(c => c.Shareholder == TopResult.ElementAt(0).Shareholder).ToList().ForEach(z => z.Rate = 0);
            result.Where(c => c.Shareholder == TopResult.ElementAt(1).Shareholder).ToList().ForEach(z => z.Rate = 1);
            result.Where(c => c.Shareholder == TopResult.ElementAt(2).Shareholder).ToList().ForEach(z => z.Rate = 2);
            result.Where(c => c.Shareholder == TopResult.ElementAt(3).Shareholder).ToList().ForEach(z => z.Rate = 3);
            result.Where(c => c.Shareholder == TopResult.ElementAt(4).Shareholder).ToList().ForEach(z => z.Rate = 4);


            var Best1 = result.Where(s => s.Rate == 0);
            var Best2 = result.Where(s => s.Rate == 1);
            var Best3 = result.Where(s => s.Rate == 2);
            var Best4 = result.Where(s => s.Rate == 3);
            var Best5 = result.Where(s => s.Rate == 4);

            StiReport report = new StiReport();
            report.Load(Server.MapPath("~/Content/Reports/BestHoldersSharesChart.mrt"));
            report.RegBusinessObject("Best1", Best1);
            report.RegBusinessObject("Best2", Best2);
            report.RegBusinessObject("Best3", Best3);
            report.RegBusinessObject("Best4", Best4);
            report.RegBusinessObject("Best5", Best5);

            CheckReference(report);
            return StiMvcViewer.GetReportResult(report);
        }
        public ActionResult ViewerEventReportBestHoldersSharesChart()
        {
            return StiMvcViewer.ViewerEventResult();
        }






        public ActionResult ReportMaturityChart()
        {
            return View("ViewReportMaturityChart");
        }
        public ActionResult GetReportMaturityChart()
        {
             
            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var TypeState = Request.QueryString.GetValues("TypeState").FirstOrDefault();
            var CouponState = Request.QueryString.GetValues("CouponState").FirstOrDefault();
            var ValState = Request.QueryString.GetValues("ValState").FirstOrDefault();


            var sql = new LinqHelper();

            var Type = false;
            var Coupon = false;
            if (TypeState == "1") Type = true;
            if (CouponState == "1") Coupon = true;


            var result =
                     sql.GetAllSymbolsShares(startDate.ToValidMsgDate()
                                            , endDate.ToValidMsgDate()
                                            , TypeState.ToValidMsgInt()
                                            , CouponState.ToValidMsgInt()
                                            ).OrderBy(c => c.MaturityDate
                                               );



            List <GetSymbolsMaturitySharesSymbols_Result> list = new List<GetSymbolsMaturitySharesSymbols_Result>( );


            var res = result.GroupBy(d => d.MaturityDate)
                                                           .Select(
                                                               g => new GetSymbolsMaturitySharesSymbols_Result
                                                               {
                                                                   Share = g.First().Share,
                                                                   Symbol = g.First().Symbol,
                                                                   MaturityDate = g.First().MaturityDate,
                                                                   NominalPrice = g.First().NominalPrice,
                                                                   Price = g.First().Price,
                                                                  
                                                               }).ToList();

            if (ValState == "0")
            {
                list = res.ToList()
                          .Select(x => new GetSymbolsMaturitySharesSymbols_Result
                          {
                              _Share = x.Share,
                              Symbol = Assistant.DateToDisplayMode((int)x.MaturityDate),

                          }).ToList();

            }
            else if (ValState == "1")
            {
                list = res.ToList()
                       .Select(x => new GetSymbolsMaturitySharesSymbols_Result
                       {
                           _Share =  x.NominalPrice,
                           Symbol = Assistant.DateToDisplayMode((int)x.MaturityDate),

                       }).ToList();
            }
            else
            {
                list = res.ToList()
                       .Select(x => new GetSymbolsMaturitySharesSymbols_Result
                       {
                           _Share =    x.Price ,
                           Symbol = Assistant.DateToDisplayMode((int)x.MaturityDate),

                       }).ToList();
            }

             


            var obj = list;


            StiReport report = new StiReport();
            report.Load(Server.MapPath("~/Content/Reports/MaturityChart.mrt"));
            report.RegBusinessObject("Info", new { });
            report.RegBusinessObject("Objects", obj);
            CheckReference(report);
            return StiMvcViewer.GetReportResult(report);
        }
        public ActionResult ViewerEventReportMaturityChart()
        {
            return StiMvcViewer.ViewerEventResult();
        }

        //--------------------------------------------------------------------------------------------------------------
        //--------------------------------------------------------------------------------------------------------------
        //--------------------------------------------------------------------------------------------------------------
        //--------------------------------------------------------------------------------------------------------------
        //--------------------------------------------------------------------------------------------------------------
        //--------------------------------------------------------------------------------------------------------------

        public ActionResult ReportHoldersTotal()
        {
            return View("ViewReportHoldersTotal");
        }
        public ActionResult GetReportHoldersTotal()
        {
            var sql = new LinqHelper();
            //--------------------------------------------------------------------------------------------------------------
            var startDate = Request.QueryString.GetValues("startDate").FirstOrDefault();
            var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
            var TypeState = Request.QueryString.GetValues("TypeState").FirstOrDefault();
            var CouponState = Request.QueryString.GetValues("CouponState").FirstOrDefault();
            var ValState = Request.QueryString.GetValues("ValState").FirstOrDefault();

            var result =
                     sql.GetAllSymbolsShares(startDate.ToValidMsgDate()
                                            , endDate.ToValidMsgDate()
                                            , TypeState.ToValidMsgInt()
                                            , CouponState.ToValidMsgInt()
                                            ).OrderBy(c => c.MaturityDate
                                               );
            List<GetSymbolsMaturitySharesSymbols_Result> list = new List<GetSymbolsMaturitySharesSymbols_Result>();
            var res = result.GroupBy(d => d.MaturityDate)
                                                           .Select(
                                                               g => new GetSymbolsMaturitySharesSymbols_Result
                                                               {
                                                                   Share = g.First().Share,
                                                                   Symbol = g.First().Symbol,
                                                                   MaturityDate = g.First().MaturityDate,
                                                                   NominalPrice = g.First().NominalPrice,
                                                                   Price = g.First().Price,

                                                               }).ToList();

            if (ValState == "0")
            {
                list = res.ToList()
                          .Select(x => new GetSymbolsMaturitySharesSymbols_Result
                          {
                              _Share = x.Share,
                              Symbol = Assistant.DateToDisplayMode((int)x.MaturityDate),

                          }).ToList();

            }
            else if (ValState == "1")
            {
                list = res.ToList()
                       .Select(x => new GetSymbolsMaturitySharesSymbols_Result
                       {
                           _Share = x.NominalPrice,
                           Symbol = Assistant.DateToDisplayMode((int)x.MaturityDate),

                       }).ToList();
            }
            else
            {
                list = res.ToList()
                       .Select(x => new GetSymbolsMaturitySharesSymbols_Result
                       {
                           _Share = x.Price,
                           Symbol = Assistant.DateToDisplayMode((int)x.MaturityDate),

                       }).ToList();
            }

            var obj0 = list;

            //--------------------------------------------------------------------------------------------------------------

            var resTotal = sql.GetSymbolsShareHoldersProperties().ToList();
             
            //--------------------------------------------------------------------------------------------------------------

            var startDate1 = Request.QueryString.GetValues("startDate1").FirstOrDefault();
            var endDate1 = Request.QueryString.GetValues("endDate1").FirstOrDefault();

 
            var res1 = resTotal.Where(c => c.MaturityDate >= startDate1.ToValidMsgDate()
                                       && c.MaturityDate <= endDate1.ToValidMsgDate());
            res1 = res1.Where(c => c.Percent >= 5).ToList();

            var list1 = res1.GroupBy(d => d.Isin)
                                         .Select(
                                             g => new GetSymbolsShareHoldersProperties_Result
                                             {
                                                 Id = g.First().Id,
                                                 Isin = g.First().Isin,
                                                 Symbol = g.First().Symbol,
                                                 PublishDate = g.First().PublishDate,
                                                 MaturityDate = g.First().MaturityDate,
                                                 SymbolType = g.First().SymbolType,
                                                 SymbolTypeTitle = g.First().SymbolTypeTitle,
                                                 Name = g.First().Name,
                                                 Shareholder = string.Join(" \n ", g.Select(a => a.Shareholder)),
                                                 Percent = g.First().Percent,
                                                 Share = g.First().Share,
                                                 SymbolGroup = g.First().SymbolGroup,
                                                 Market = g.First().Market,
                                             }).ToList();

            var obj1 = list1.OrderByDescending(x => x.Share).Take(5);
 
            //--------------------------------------------------------------------------------------------------------------
            var startDate2 = Request.QueryString.GetValues("startDate2").FirstOrDefault();
            var endDate2 = Request.QueryString.GetValues("endDate2").FirstOrDefault();

             var res2 = resTotal.Where(c => c.MaturityDate >= startDate2.ToValidMsgDate()
                                         && c.MaturityDate <= endDate2.ToValidMsgDate());

            res2 = res2.Where(c => c.Percent >= 5).ToList();

            var list2 = res2.GroupBy(d => d.Isin)
                                         .Select(
                                             g => new GetSymbolsShareHoldersProperties_Result
                                             {
                                                 Id = g.First().Id,
                                                 Isin = g.First().Isin,
                                                 Symbol = g.First().Symbol,
                                                 PublishDate = g.First().PublishDate,
                                                 MaturityDate = g.First().MaturityDate,
                                                 SymbolType = g.First().SymbolType,
                                                 SymbolTypeTitle = g.First().SymbolTypeTitle,
                                                 Name = g.First().Name,
                                                 Shareholder = string.Join(" \n ", g.Select(a => a.Shareholder)),
                                                 Percent = g.First().Percent,
                                                 Share = g.First().Share,
                                                 SymbolGroup = g.First().SymbolGroup,
                                                 Market = g.First().Market,
                                             }).ToList();

            var obj2 = list2.OrderBy(x => x.MaturityDate).Take(5);
 
            //--------------------------------------------------------------------------------------------------------------
 
            var res3 = resTotal;

            res3.ForEach(z => z.MaturityDate = z.MaturityDate / 10000);

            var list3 = res3.GroupBy(d => d.MaturityDate)
                                         .Select(
                                             g => new GetSymbolsShareHoldersProperties_Result
                                             {
                                                 MaturityDate = g.First().MaturityDate,
                                                 Share = g.Sum(s => s.Share),
                                             }).ToList();

            var obj3 = list3.OrderBy(x => x.MaturityDate);
 
            //--------------------------------------------------------------------------------------------------------------
            var Year = Request.QueryString.GetValues("Year").FirstOrDefault();
            //var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();

            List<GetSymbolsShareHoldersProperties_Result> res4 = new List<GetSymbolsShareHoldersProperties_Result>();

            res4 = sql.GetSymbolsShareHoldersProperties().ToList();
            res4 = res4.Where(c => c._Year == Year).ToList();
            var list4 = res4.GroupBy(d => d._Month)
                                         .Select(
                                             g => new GetSymbolsShareHoldersProperties_Result
                                             {
                                                 MaturityDate = g.First().MaturityDate,
                                                 Year = g.First()._Year,
                                                 Share = g.Sum(s => s.Share),
                                                 Month = g.First()._Month
                                             }).ToList();

            var obj4 = list4.OrderBy(x => x.MaturityDate);
             
            //--------------------------------------------------------------------------------------------------------------
            var HolderPrcnt = Request.QueryString.GetValues("HolderPrcnt").FirstOrDefault();
            //var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
             var res5 = resTotal.ToList();
            double total = (double)res5.Sum(x => x.Share);

            var list5 = res5.GroupBy(d => d.Shareholder)
                                         .Select(
                                             g => new GetSymbolsShareHoldersProperties_Result
                                             {
                                                 MaturityDate = g.First().MaturityDate,
                                                 Shareholder = g.First().Shareholder,
                                                 Share = g.Sum(s => s.Share),
                                                 Percent = g.Sum(s => s.Share) * 100 / total,

                                             }).ToList();

            var obj5 = list5.Where(c => c.Percent >= HolderPrcnt.ToValidMsgInt()).OrderByDescending(x => x.Percent);
             
            //--------------------------------------------------------------------------------------------------------------
            var res6 = sql.GetSymbolsShareHoldersProperties().ToList(); 

            double total6 = (double)res.Sum(x => x.Share);

            var list6 = res6.GroupBy(d => d.Shareholder)
                                         .Select(
                                             g => new GetSymbolsShareHoldersProperties_Result
                                             {
                                                 MaturityDate = g.First().MaturityDate,
                                                 Shareholder = g.First().Shareholder,
                                                 Share = g.Sum(s => s.Share),
                                                 Percent = g.Sum(s => s.Share) * 100 / total6,

                                             }).ToList();

            var TopResult = list6.Where(c => c.Shareholder != "مرکزمدیریت بدهی وزارت اقتصاد").OrderByDescending(x => x.Percent).Take(5);

            var result6 = res6.Where(c => c.Shareholder == TopResult.ElementAt(0).Shareholder
                                      || c.Shareholder == TopResult.ElementAt(1).Shareholder
                                      || c.Shareholder == TopResult.ElementAt(2).Shareholder
                                      || c.Shareholder == TopResult.ElementAt(3).Shareholder
                                      || c.Shareholder == TopResult.ElementAt(4).Shareholder).OrderBy(c => c.MaturityDate).ToList();

            result6.Where(c => c.Shareholder == TopResult.ElementAt(0).Shareholder).ToList().ForEach(z => z.Rate = 0);
            result6.Where(c => c.Shareholder == TopResult.ElementAt(1).Shareholder).ToList().ForEach(z => z.Rate = 1);
            result6.Where(c => c.Shareholder == TopResult.ElementAt(2).Shareholder).ToList().ForEach(z => z.Rate = 2);
            result6.Where(c => c.Shareholder == TopResult.ElementAt(3).Shareholder).ToList().ForEach(z => z.Rate = 3);
            result6.Where(c => c.Shareholder == TopResult.ElementAt(4).Shareholder).ToList().ForEach(z => z.Rate = 4);


            var Best1 = result6.Where(s => s.Rate == 0);
            var Best2 = result6.Where(s => s.Rate == 1);
            var Best3 = result6.Where(s => s.Rate == 2);
            var Best4 = result6.Where(s => s.Rate == 3);
            var Best5 = result6.Where(s => s.Rate == 4);
            
            //--------------------------------------------------------------------------------------------------------------

            var res7 = resTotal;

            double total7 = (double)res7.Sum(x => x.Share);
            res7 = res7.OrderByDescending(c => c.Share).ToList();

            for (int i = 0; i < res7.Count(); i++)
            {
                res7.ElementAt(i).DebtId = i + 1;
            }
            var list7 = res7.GroupBy(d => d.Shareholder)
                                         .Select(
                                             g => new GetSymbolsShareHoldersProperties_Result
                                             {
                                                 DebtId = g.First().DebtId,
                                                 MaturityDate = g.First().MaturityDate,
                                                 Shareholder = g.First().Shareholder,
                                                 Share = g.Sum(s => s.Share),
                                                 Percent = g.Sum(s => s.Share) * 100 / total7,
                                                 DebtCount = g.Count(),
                                                 ShareAve = (g.Sum(s => s.Share)) / g.Count(),
                                                 MarketRatio = ((g.Sum(s => s.Share)) / g.Count()) / g.First().DebtId
                                             }).ToList();

            var obj7 = list7.Where(c => c.Percent >= 1).OrderByDescending(x => x.MarketRatio);

            //StiReport report = new StiReport();
            //report.Load(Server.MapPath("~/Content/Reports/BigHoldersStatistics.mrt"));
            //report.RegBusinessObject("Info", new { });
            //report.RegBusinessObject("Objects", obj);
            //CheckReference(report);
            //return StiMvcViewer.GetReportResult(report);
            //--------------------------------------------------------------------------------------------------------------
            var Value = Request.QueryString.GetValues("Value").FirstOrDefault();
            //var endDate = Request.QueryString.GetValues("endDate").FirstOrDefault();
             
            var res8 = sql.GetSymbolsShareHoldersPropertiesWithValue().ToList();

            var obj8 = res8.Where(c => c.Value >= Value.ToValidMsglong()).OrderByDescending(x => x.Value).ToList();

            //StiReport report = new StiReport();
            //report.Load(Server.MapPath("~/Content/Reports/BigDebtHolders.mrt"));
            //report.RegBusinessObject("Info", new { });
            //report.RegBusinessObject("Objects", obj);
            //CheckReference(report);
            //return StiMvcViewer.GetReportResult(report);
            //--------------------------------------------------------------------------------------------------------------

             

            StiReport report = new StiReport();
            report.Load(Server.MapPath("~/Content/Reports/HoldersTotalReport.mrt"));
            report.RegBusinessObject("Info", new { });
            report.RegBusinessObject("Objects", obj0);
            report.RegBusinessObject("PageA", obj1);
            report.RegBusinessObject("PageB", obj2);
            report.RegBusinessObject("PageC", obj3);
            report.RegBusinessObject("PageD", obj4);
            report.RegBusinessObject("PageE", obj5);
            report.RegBusinessObject("PageF", Best1);
            report.RegBusinessObject("PageG", Best2);
            report.RegBusinessObject("PageH", Best3);
            report.RegBusinessObject("PageI", Best4);
            report.RegBusinessObject("PageJ", Best5);
            report.RegBusinessObject("PageK", obj7);
            report.RegBusinessObject("PageL", obj8);

            CheckReference(report);
            return StiMvcViewer.GetReportResult(report);
        }
        public ActionResult ViewerEventReportHoldersTotal()
        {
            return StiMvcViewer.ViewerEventResult();
        }





































    }


}