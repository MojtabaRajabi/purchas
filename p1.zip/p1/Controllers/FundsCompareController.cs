﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using Sanay.Library.Utility;
using Sanay.Lotus.Erm.DataAccess;
using Sanay.Lotus.Erm.DataAccess.Helper;
using Sanay.Lotus.Erm.Lib.Dto;
using Sanay.Lotus.Erm.Lib.Enum;

namespace Sanay.Lotus.Erm.Controllers
{
    [Authorize]
    public class FundsCompareController : Controller
    {

        // GET: FundsCompare
        public ActionResult Index()
        {
            using (var sql = new LinqHelper())
            {
                var funds = sql.GetFunds().OrderBy(c => c.Name)
                    .ToList();
                ViewBag.funds = funds;

                var fundsType = funds.Select(c => c.FundType).Distinct().ToList();
                ViewBag.fundsType = fundsType;
            }

            ViewBag.startDate = Assistant.DateToDisplayMode(Assistant.Last3Months());
            ViewBag.endDate = Assistant.TodayDateBySlash();

            return View();
        }

        public ActionResult test()
        {
            return View();
        }

        [HttpPost]
        public JsonResult LoadFundsCompareChart(string startDate, string endDate, string fundId)
        {
            try
            {
                using (var sql = new LinqHelper())
                {

                    string s = fundId;

                    string[] values = s.Split(',');

                    values = values.Take(values.Count() - 1).ToArray();

                    var jsonObj = new StringBuilder();

                    jsonObj.Append("[");

                    string[] chartColors = { "#1274bb", "#f37c1e", "#09a64f", "#4b308f", "#e1058b", "#fad405", "#0ca9d2", "#eb1e25", "#a5cd38", "#76777b", "#f5abcc", "#044d80", "#e9eca5", "#aad6f1", "#b3dbc0", "#dcdddf", "#fef3d3", "#08733b", "#e9b81d", "#f9bda5" };

                    var colorCounter = 0;
                    foreach (string i in values)
                    {
                        var Result = sql.getFundsCompareChart(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), i.ToValidMsgInt());

                        if (Result.Count == 0)
                            continue;

                        var sb = new StringBuilder();
                        //foreach (var item in objectx)
                        //{
                        var name = Result[0].FundName;

                        sb.Append("{\"name\":");
                        sb.Append($"\"{name}\",");
                        sb.Append("\"color\":");
                        sb.Append($"\"{chartColors[colorCounter]}\",");

                        sb.Append("\"data\":[");
                        foreach (var x1 in Result
                            .Select(o => new { o._date, o.NAV })
                            .ToArray())
                        {
                            sb.Append("[" + x1._date + "," + x1.NAV + "],");
                        }
                        sb.Length--;
                        sb.Append("]},");
                        jsonObj.Append(sb);

                        colorCounter++;
                    }
                    if (jsonObj[jsonObj.Length - 1] == ',') jsonObj.Length--;
                    jsonObj.Append("]");

                    string Obj;
                    Obj = jsonObj.ToString();

                    return Json(Obj);

                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        [HttpPost]
        public JsonResult LoadFundsUnitsChart(string startDate, string endDate, string fundId)
        {
            try
            {
                using (var sql = new LinqHelper())
                {

                    string s = fundId;

                    string[] values = s.Split(',');

                    values = values.Take(values.Count() - 1).ToArray();

                    var jsonObj = new StringBuilder();

                    jsonObj.Append("[");

                    string[] chartColors = { "#1274bb", "#f37c1e", "#09a64f", "#4b308f", "#e1058b", "#fad405", "#0ca9d2", "#eb1e25", "#a5cd38", "#76777b", "#f5abcc", "#044d80", "#e9eca5", "#aad6f1", "#b3dbc0", "#dcdddf", "#fef3d3", "#08733b", "#e9b81d", "#f9bda5" };

                    var colorCounter = 0;
                    foreach (string i in values)
                    {
                        var Result = sql.getFundsCompareChart(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), i.ToValidMsgInt());

                        if (Result.Count == 0)
                            continue;

                        var sb = new StringBuilder();
                        //foreach (var item in objectx)
                        //{
                        var name = Result[0].FundName;

                        sb.Append("{\"name\":");
                        sb.Append($"\"{name}\",");
                        sb.Append("\"color\":");
                        sb.Append($"\"{chartColors[colorCounter]}\",");

                        sb.Append("\"data\":[");
                        foreach (var x1 in Result
                            .Select(o => new { o._date, o.Units })
                            .ToArray())
                        {
                            sb.Append($"[{x1._date},{x1.Units}],");
                        }
                        sb.Length--;
                        sb.Append("]},");
                        jsonObj.Append(sb);

                        colorCounter++;
                    }
                    if (jsonObj[jsonObj.Length - 1] == ',') jsonObj.Length--;
                    jsonObj.Append("]");

                    string Obj;
                    Obj = jsonObj.ToString();
                    return Json(Obj);
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpPost]
        public JsonResult LoadFundsYtmsChart(string startDate, string endDate, string fundId)
        {
            try
            {
                using (var sql = new LinqHelper())
                {

                    string s = fundId;

                    string[] values = s.Split(',');

                    values = values.Take(values.Count() - 1).ToArray();

                    var jsonObj = new StringBuilder();

                    jsonObj.Append("[");

                    string[] chartColors = { "#1274bb", "#f37c1e", "#09a64f", "#4b308f", "#e1058b", "#fad405", "#0ca9d2", "#eb1e25", "#a5cd38", "#76777b", "#f5abcc", "#044d80", "#e9eca5", "#aad6f1", "#b3dbc0", "#dcdddf", "#fef3d3", "#08733b", "#e9b81d", "#f9bda5" };

                    var colorCounter = 0;
                    foreach (string i in values)
                    {
                        var id = i.ToValidMsgInt();
                        var Result = sql.GetFundYtms(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), id)
                            .OrderBy(c => c.JalaliDate)
                            .ToList();

                        if (Result.Count == 0)
                            continue;

                        var fundName = sql.GetFundsName(id);
                        var name = fundName;

                        var sb = new StringBuilder();
                        sb.Append("{\"name\":");
                        sb.Append($"\"{name}\",");
                        sb.Append("\"color\":");
                        sb.Append($"\"{chartColors[colorCounter]}\",");

                        sb.Append("\"data\":[");
                        foreach (var x1 in Result
                            .Select(o => new { o._JalaliDateStamp, o.Ytm })
                            .ToArray())
                        {
                            sb.Append($"[{x1._JalaliDateStamp},{x1.Ytm}],");
                        }
                        sb.Length--;
                        sb.Append("]},");
                        jsonObj.Append(sb);

                        colorCounter++;
                    }
                    if (jsonObj[jsonObj.Length - 1] == ',') jsonObj.Length--;
                    jsonObj.Append("]");

                    string Obj;
                    Obj = jsonObj.ToString();

                    return Json(Obj);
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpPost]
        public JsonResult LoadFundsMixAssetsChart(string startDate, string endDate, string fundId, string mixAssetsType)
        {
            try
            {
                using (var sql = new LinqHelper())
                {

                    string s = fundId;

                    string[] values = s.Split(',');

                    values = values.Take(values.Count() - 1).ToArray();

                    var jsonObj = new StringBuilder();

                    jsonObj.Append("[");

                    string[] chartColors = { "#1274bb", "#f37c1e", "#09a64f", "#4b308f", "#e1058b", "#fad405", "#0ca9d2", "#eb1e25", "#a5cd38", "#76777b", "#f5abcc", "#044d80", "#e9eca5", "#aad6f1", "#b3dbc0", "#dcdddf", "#fef3d3", "#08733b", "#e9b81d", "#f9bda5" };

                    var colorCounter = 0;
                    foreach (string i in values)
                    {
                        var id = i.ToValidMsgInt();
                        var Result = sql.GetFundMixAsset(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), id)
                            .OrderBy(c => c.JalaliDate)
                            .ToList();

                        if (Result.Count == 0)
                            continue;

                        var fundName = sql.GetFundsName(id);
                        var name = fundName;

                        var sb = new StringBuilder();
                        sb.Append("{\"name\":");
                        sb.Append($"\"{name}\",");
                        sb.Append("\"color\":");
                        sb.Append($"\"{chartColors[colorCounter]}\",");

                        sb.Append("\"data\":[");
                        foreach (var x1 in Result)
                        {
                            switch (mixAssetsType.ToValidMsgInt())
                            {
                                case (int)MixAssetsType.BondTodayPercent:
                                    sb.Append($"[{x1._JalaliDateStamp},{x1.BondTodayPercent}],");
                                    break;
                                case (int)MixAssetsType.CashTodayPercent:
                                    sb.Append($"[{x1._JalaliDateStamp},{x1.CashTodayPercent}],");
                                    break;
                                case (int)MixAssetsType.DepositTodayPercent:
                                    sb.Append($"[{x1._JalaliDateStamp},{x1.DepositTodayPercent}],");
                                    break;
                                case (int)MixAssetsType.TopFiveStockTodayPercent:
                                    sb.Append($"[{x1._JalaliDateStamp},{x1.TopFiveStockTodayPercent}],");
                                    break;
                                case (int)MixAssetsType.OtherAssetTodayPercent:
                                    sb.Append($"[{x1._JalaliDateStamp},{x1.OtherAssetTodayPercent}],");
                                    break;
                            }
                        }
                        sb.Length--;
                        sb.Append("]},");
                        jsonObj.Append(sb);

                        colorCounter++;
                    }

                    if (jsonObj[jsonObj.Length - 1] == ',') jsonObj.Length--;
                    jsonObj.Append("]");

                    string Obj;
                    Obj = jsonObj.ToString();

                    return Json(Obj);

                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpPost]
        public JsonResult LoadFundsIssueRevocationChart(string startDate, string endDate, string fundId, string IssueRevocationType)
        {
            try
            {
                using (var sql = new LinqHelper())
                {

                    string s = fundId;

                    string[] values = s.Split(',');

                    values = values.Take(values.Count() - 1).ToArray();

                    var jsonObj = new StringBuilder();

                    jsonObj.Append("[");

                    string[] chartColors = { "#1274bb", "#f37c1e", "#09a64f", "#4b308f", "#e1058b", "#fad405", "#0ca9d2", "#eb1e25", "#a5cd38", "#76777b", "#f5abcc", "#044d80", "#e9eca5", "#aad6f1", "#b3dbc0", "#dcdddf", "#fef3d3", "#08733b", "#e9b81d", "#f9bda5" };

                    var colorCounter = 0;
                    foreach (string i in values)
                    {
                        var id = i.ToValidMsgInt();
                        var Result = sql.getFundsCompareChart(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), i.ToValidMsgInt())
                            .OrderBy(c => c.JalaliDate).ToList();

                        if (Result.Count == 0)
                            continue;

                        var name = Result[0].FundName;

                        var sb = new StringBuilder();
                        sb.Append("{\"name\":");
                        sb.Append($"\"{name}\",");
                        sb.Append("\"color\":");
                        sb.Append($"\"{chartColors[colorCounter]}\",");

                        sb.Append("\"data\":[");
                        foreach (var x1 in Result)
                        {
                            switch (IssueRevocationType)
                            {
                                case "0":
                                    sb.Append($"[{x1._date},{x1.AccumulativeIssuedUnits}],");
                                    break;
                                case "1":
                                    sb.Append($"[{x1._date},{x1.AccumulativeRevocedUnits}],");
                                    break;
                            }
                        }
                        sb.Length--;
                        sb.Append("]},");
                        jsonObj.Append(sb);

                        colorCounter++;
                    }

                    if (jsonObj[jsonObj.Length - 1] == ',') jsonObj.Length--;
                    jsonObj.Append("]");

                    string Obj;
                    Obj = jsonObj.ToString();

                    return Json(Obj);
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public JsonResult LoadFundsShareIndustries(string fundId)
        {
            try
            {
                using (var sql = new LinqHelper())
                {
                    var result = sql.GetFundIndustrieTypsFunds(fundId).ToList();
                    return Json(result, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpPost]
        public JsonResult LoadFundsShareIndustriesChart(string startDate, string endDate, string fundId, string ShareIndustriesType)
        {
            try
            {
                using (var sql = new LinqHelper())
                {

                    string s = fundId;

                    string[] values = s.Split(',');

                    values = values.Take(values.Count() - 1).ToArray();

                    var jsonObj = new StringBuilder();

                    jsonObj.Append("[");

                    string[] chartColors = { "#1274bb", "#f37c1e", "#09a64f", "#4b308f", "#e1058b", "#fad405", "#0ca9d2", "#eb1e25", "#a5cd38", "#76777b", "#f5abcc", "#044d80", "#e9eca5", "#aad6f1", "#b3dbc0", "#dcdddf", "#fef3d3", "#08733b", "#e9b81d", "#f9bda5" };

                    var colorCounter = 0;
                    foreach (string i in values)
                    {
                        var id = i.ToValidMsgInt();
                        var Result = sql.GetFundIndustries(startDate.ToValidMsgDate(), endDate.ToValidMsgDate(), i.ToValidMsgInt())
                            .Where(c => c.Name == ShareIndustriesType)
                            .OrderBy(c => c.RegDate).ToList();

                        if (Result.Count == 0)
                            continue;

                        var fundName = sql.GetFundsName(id);
                        var name = fundName;

                        var sb = new StringBuilder();
                        sb.Append("{\"name\":");
                        sb.Append($"\"{name}\",");
                        sb.Append("\"color\":");
                        sb.Append($"\"{chartColors[colorCounter]}\",");

                        sb.Append("\"data\":[");
                        foreach (var x1 in Result)
                        {
                            sb.Append($"[{x1._RegDate},{x1.Value}],");
                        }
                        sb.Length--;
                        sb.Append("]},");
                        jsonObj.Append(sb);

                        colorCounter++;
                    }

                    if (jsonObj[jsonObj.Length - 1] == ',') jsonObj.Length--;
                    jsonObj.Append("]");

                    string Obj;
                    Obj = jsonObj.ToString();

                    return Json(Obj);
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public ActionResult LoadFundData(string Id)
        {
            using (var sql = new LinqHelper())
            {

                var result = sql.GetFundDataByFundId(Id.TryParseInt32());

                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult LoadFundProperties(string Id)
        {
            using (var sql = new LinqHelper())
            {
                var result = sql.GetFundPropertiesByFundId(Id.TryParseInt32());

                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult LoadFundSymbols(string Id)
        {
            using (var sql = new LinqHelper())
            {
                var result = sql.GetFundSymbolsByFundId(Id.TryParseInt32(), Assistant.TodayDateInt()).OrderBy(c => c.Symbol);

                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }

        public string LoadFundSymbolsCompare(string fundId)
        {
            string s = fundId;
            string[] values = s.Split(',');
            values = values.Take(values.Count() - 1).ToArray();
            List<object> fundsSymbols = new List<object>();
            List<string> funds = new List<string>();
            List<string> symbols = new List<string>();
            using (var sql = new LinqHelper())
            {
                foreach (string id in values)
                {
                    var result = sql.GetFundSymbolsByFundId(id.TryParseInt32(), Assistant.TodayDateInt()).OrderBy(c => c.Symbol).ToList();
                    symbols.AddRange(result.Select(c => c.Symbol).ToList());
                    fundsSymbols.Add(result);

                    var fundName = sql.GetFundsName(id.TryParseInt32());
                    funds.Add(fundName);
                }
            }

            symbols = symbols.Distinct().OrderBy(c => c).ToList();
            string[,] resultArrayStrings = new string[values.Length + 2, symbols.Count + 1];
            int shareCountCol = values.Length + 1;
            resultArrayStrings[0, 0] = "نماد ها";

            //set fund name
            int t = 1;
            foreach (var value in funds)
            {
                resultArrayStrings[t++, 0] = value;
            }

            //set symbol name
            t = 1;
            foreach (var value in symbols)
            {
                //set zero in share count
                resultArrayStrings[shareCountCol, t] = "0";

                //set symbol name
                resultArrayStrings[0, t++] = value;
            }


            //create fund symbol values
            int max = 0;
            int i = 1;
            foreach (List<GetMajorSymbolsByFundId_Result> fundsSymbol in fundsSymbols)
            {
                var q =
                    from s1 in symbols
                    join f1 in fundsSymbol on s1 equals f1.Symbol into sf
                    from p in sf.DefaultIfEmpty()
                    select new { symbols = s1, Share = p == null ? "-" : p._Percent };
                int j = 1;
                foreach (var value in q)
                {
                    resultArrayStrings[shareCountCol, j] =
                        (resultArrayStrings[shareCountCol, j].ToValidMsgInt() + (value.Share != "-" ? 1 : 0)).ToString();
                    max = max < resultArrayStrings[shareCountCol, j].ToValidMsgInt()
                        ? resultArrayStrings[shareCountCol, j].ToValidMsgInt()
                        : max;
                    resultArrayStrings[i, j++] = value.Share;

                }
                i++;
            }


            //sort with share symbols count 
            i = 0;
            string[,] sortedResultArrayStrings = new string[values.Length + 2, symbols.Count + 1];

            sortedResultArrayStrings[0, 0] = "نماد ها";

            //set fund name
            t = 1;
            foreach (var value in funds)
            {
                sortedResultArrayStrings[t++, 0] = value;
            }

            for (int m = max; m > 0; m--)
            {
                for (int k = 1; k < symbols.Count + 1; k++)
                {
                    if (resultArrayStrings[shareCountCol, k].ToValidMsgInt() == m)
                    {
                        i++;
                        for (int j = 0; j < values.Length + 2; j++)
                        {
                            sortedResultArrayStrings[j, i] = resultArrayStrings[j, k];
                        }

                    }
                }
            }
            var r1 = JsonConvert.SerializeObject(sortedResultArrayStrings);
            return r1;
        }

        public JsonResult GetFundsName(string fundsType)
        {
            fundsType = fundsType == "0" ? "%%" : fundsType.ToValidMsgString();
            using (var sql = new LinqHelper())
            {

                var result = sql.GetFunds(fundsType)
                    .Select(x => new
                    {
                        Name = x.Name,
                        Id = x.Id,
                    }).OrderBy(c => c.Name).ToList(); ;

                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }
    }
}