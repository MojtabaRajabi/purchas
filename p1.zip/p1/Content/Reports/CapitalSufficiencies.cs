﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Data;
using Stimulsoft.Controls;
using Stimulsoft.Base.Drawing;
using Stimulsoft.Report;
using Stimulsoft.Report.Dialogs;
using Stimulsoft.Report.Components;

namespace Reports
{
    public class Report : Stimulsoft.Report.StiReport
    {
        public Report()        {
            this.InitializeComponent();
        }

		
		public string DateToshamsi(object date)
		{
			System.Globalization.PersianCalendar shamsi = new        System.Globalization.PersianCalendar();

			DateTime da = (DateTime)date;
			int year = shamsi.GetYear(da);
			int month = shamsi.GetMonth(da);
			int day = shamsi.GetDayOfMonth(da);
			return year.ToString()+ "/"+ month.ToString() + "/"+day.ToString()  ;

		}
		
        #region StiReport Designer generated code - do not modify
        public string _StartDate;
        public Stimulsoft.Report.Components.StiPage Page1;
        public Stimulsoft.Report.Components.StiPageFooterBand PageFooterBand2;
        public Stimulsoft.Report.Components.StiText Text18;
        public Stimulsoft.Report.Components.StiText Text19;
        public Stimulsoft.Report.Components.StiText Text12;
        public Stimulsoft.Report.Components.StiText Text15;
        public Stimulsoft.Report.Components.StiText Text11;
        public Stimulsoft.Report.Components.StiText Text14;
        public Stimulsoft.Report.Components.StiPanel Panel1;
        public Stimulsoft.Report.Components.StiText Text1;
        public Stimulsoft.Report.Components.StiText Text3;
        public Stimulsoft.Report.Components.StiText Text4;
        public Stimulsoft.Report.Components.StiText Text5;
        public Stimulsoft.Report.Components.StiText Text6;
        public Stimulsoft.Report.Components.StiText Text7;
        public Stimulsoft.Report.Components.StiText Text8;
        public Stimulsoft.Report.Components.StiText Text9;
        public Stimulsoft.Report.Components.StiText Text10;
        public Stimulsoft.Report.Components.StiText Text13;
        public Stimulsoft.Report.Components.StiText Text16;
        public Stimulsoft.Report.Components.StiText Text17;
        public Stimulsoft.Report.Components.StiText Text20;
        public Stimulsoft.Report.Components.StiText Text21;
        public Stimulsoft.Report.Components.StiText Text22;
        public Stimulsoft.Report.Components.StiText Text23;
        public Stimulsoft.Report.Components.StiText Text24;
        public Stimulsoft.Report.Components.StiText Text25;
        public Stimulsoft.Report.Components.StiText Text26;
        public Stimulsoft.Report.Components.StiText Text27;
        public Stimulsoft.Report.Components.StiText Text28;
        public Stimulsoft.Report.Components.StiText Text29;
        public Stimulsoft.Report.Components.StiText Text30;
        public Stimulsoft.Report.Components.StiText Text31;
        public Stimulsoft.Report.Components.StiText Text32;
        public Stimulsoft.Report.Components.StiText Text33;
        public Stimulsoft.Report.Components.StiText Text35;
        public Stimulsoft.Report.Components.StiText Text36;
        public Stimulsoft.Report.Components.StiText Text37;
        public Stimulsoft.Report.Components.StiText Text38;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine1;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive1;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive2;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive3;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive4;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine2;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine3;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine4;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine5;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine6;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine7;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine8;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine9;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive3;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive4;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive2;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive1;
        public Stimulsoft.Report.Components.StiPanel Panel6;
        public Stimulsoft.Report.Components.StiText Text82;
        public Stimulsoft.Report.Components.StiText Text83;
        public Stimulsoft.Report.Components.StiText Text84;
        public Stimulsoft.Report.Components.StiText Text85;
        public Stimulsoft.Report.Components.StiText Text86;
        public Stimulsoft.Report.Components.StiText Text87;
        public Stimulsoft.Report.Components.StiText Text88;
        public Stimulsoft.Report.Components.StiText Text89;
        public Stimulsoft.Report.Components.StiText Text90;
        public Stimulsoft.Report.Components.StiText Text91;
        public Stimulsoft.Report.Components.StiText Text101;
        public Stimulsoft.Report.Components.StiText Text102;
        public Stimulsoft.Report.Components.StiText Text103;
        public Stimulsoft.Report.Components.StiText Text104;
        public Stimulsoft.Report.Components.StiText Text105;
        public Stimulsoft.Report.Components.StiText Text106;
        public Stimulsoft.Report.Components.StiText Text92;
        public Stimulsoft.Report.Components.StiText Text107;
        public Stimulsoft.Report.Components.StiText Text93;
        public Stimulsoft.Report.Components.StiText Text94;
        public Stimulsoft.Report.Components.StiText Text95;
        public Stimulsoft.Report.Components.StiText Text96;
        public Stimulsoft.Report.Components.StiText Text97;
        public Stimulsoft.Report.Components.StiText Text98;
        public Stimulsoft.Report.Components.StiText Text99;
        public Stimulsoft.Report.Components.StiText Text100;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine17;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine18;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine19;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine20;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine21;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine22;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine23;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine24;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive59;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive60;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive61;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive62;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive31;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive31;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive32;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive30;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive55;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive51;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive56;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive52;
        public Stimulsoft.Report.Components.StiReportTitleBand ReportTitleBand2;
        public Stimulsoft.Report.Components.StiPanel Panel2;
        public Stimulsoft.Report.Components.StiText Text2;
        public Stimulsoft.Report.Components.StiText Text34;
        public Stimulsoft.Report.Components.StiVerticalLinePrimitive VerticalLine1;
        public Stimulsoft.Report.Components.StiVerticalLinePrimitive VerticalLine2;
        public Stimulsoft.Report.Components.StiVerticalLinePrimitive VerticalLine3;
        public Stimulsoft.Report.Components.StiVerticalLinePrimitive VerticalLine4;
        public Stimulsoft.Report.Components.StiVerticalLinePrimitive VerticalLine21;
        public Stimulsoft.Report.Components.StiVerticalLinePrimitive VerticalLine22;
        public Stimulsoft.Report.Components.StiWatermark Page1_Watermark;
        public Stimulsoft.Report.Components.StiPage Page2;
        public Stimulsoft.Report.Components.StiPageFooterBand PageFooter1;
        public Stimulsoft.Report.Components.StiText Text76;
        public Stimulsoft.Report.Components.StiText Text77;
        public Stimulsoft.Report.Components.StiText Text78;
        public Stimulsoft.Report.Components.StiText Text79;
        public Stimulsoft.Report.Components.StiText Text80;
        public Stimulsoft.Report.Components.StiText Text81;
        public Stimulsoft.Report.Components.StiPanel Panel7;
        public Stimulsoft.Report.Components.StiText Text108;
        public Stimulsoft.Report.Components.StiText Text110;
        public Stimulsoft.Report.Components.StiText Text111;
        public Stimulsoft.Report.Components.StiText Text112;
        public Stimulsoft.Report.Components.StiText Text113;
        public Stimulsoft.Report.Components.StiText Text114;
        public Stimulsoft.Report.Components.StiText Text115;
        public Stimulsoft.Report.Components.StiText Text116;
        public Stimulsoft.Report.Components.StiText Text117;
        public Stimulsoft.Report.Components.StiText Text124;
        public Stimulsoft.Report.Components.StiText Text118;
        public Stimulsoft.Report.Components.StiText Text119;
        public Stimulsoft.Report.Components.StiText Text120;
        public Stimulsoft.Report.Components.StiText Text121;
        public Stimulsoft.Report.Components.StiText Text122;
        public Stimulsoft.Report.Components.StiText Text123;
        public Stimulsoft.Report.Components.StiText Text125;
        public Stimulsoft.Report.Components.StiText Text126;
        public Stimulsoft.Report.Components.StiText Text127;
        public Stimulsoft.Report.Components.StiText Text128;
        public Stimulsoft.Report.Components.StiText Text129;
        public Stimulsoft.Report.Components.StiText Text130;
        public Stimulsoft.Report.Components.StiText Text131;
        public Stimulsoft.Report.Components.StiText Text132;
        public Stimulsoft.Report.Components.StiText Text133;
        public Stimulsoft.Report.Components.StiText Text134;
        public Stimulsoft.Report.Components.StiText Text135;
        public Stimulsoft.Report.Components.StiText Text109;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine25;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine26;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine27;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine28;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine29;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine30;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine31;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine32;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive34;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive35;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive36;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive37;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive63;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive63;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive64;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive64;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive65;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive65;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive66;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive66;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive67;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive67;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive68;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive68;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive69;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive69;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive70;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive70;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive71;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive72;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive72;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive73;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive74;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive74;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive75;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive75;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive76;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive76;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive77;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive77;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive38;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive34;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive39;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive35;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive71;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive73;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive33;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive33;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine33;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive30;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive32;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive59;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive60;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive61;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive62;
        public Stimulsoft.Report.Components.StiPanel Panel3;
        public Stimulsoft.Report.Components.StiText Text39;
        public Stimulsoft.Report.Components.StiText Text40;
        public Stimulsoft.Report.Components.StiText Text41;
        public Stimulsoft.Report.Components.StiText Text42;
        public Stimulsoft.Report.Components.StiText Text43;
        public Stimulsoft.Report.Components.StiText Text44;
        public Stimulsoft.Report.Components.StiText Text45;
        public Stimulsoft.Report.Components.StiText Text60;
        public Stimulsoft.Report.Components.StiText Text48;
        public Stimulsoft.Report.Components.StiText Text49;
        public Stimulsoft.Report.Components.StiText Text55;
        public Stimulsoft.Report.Components.StiText Text61;
        public Stimulsoft.Report.Components.StiText Text72;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine10;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine11;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive57;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive58;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive54;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive78;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive55;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive79;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive56;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive80;
        public Stimulsoft.Report.Components.StiPanel Panel4;
        public Stimulsoft.Report.Components.StiText Text47;
        public Stimulsoft.Report.Components.StiText Text51;
        public Stimulsoft.Report.Components.StiText Text46;
        public Stimulsoft.Report.Components.StiText Text62;
        public Stimulsoft.Report.Components.StiText Text52;
        public Stimulsoft.Report.Components.StiText Text64;
        public Stimulsoft.Report.Components.StiText Text66;
        public Stimulsoft.Report.Components.StiText Text70;
        public Stimulsoft.Report.Components.StiText Text71;
        public Stimulsoft.Report.Components.StiText Text50;
        public Stimulsoft.Report.Components.StiText Text68;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine13;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine14;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive15;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive15;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive16;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive16;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive17;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive17;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive18;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive18;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive19;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive19;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive81;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive82;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive78;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive83;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive87;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive83;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive89;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive85;
        public Stimulsoft.Report.Components.StiPanel Panel5;
        public Stimulsoft.Report.Components.StiText Text54;
        public Stimulsoft.Report.Components.StiText Text58;
        public Stimulsoft.Report.Components.StiText Text59;
        public Stimulsoft.Report.Components.StiText Text53;
        public Stimulsoft.Report.Components.StiText Text63;
        public Stimulsoft.Report.Components.StiText Text56;
        public Stimulsoft.Report.Components.StiText Text65;
        public Stimulsoft.Report.Components.StiText Text67;
        public Stimulsoft.Report.Components.StiText Text73;
        public Stimulsoft.Report.Components.StiText Text74;
        public Stimulsoft.Report.Components.StiText Text75;
        public Stimulsoft.Report.Components.StiText Text57;
        public Stimulsoft.Report.Components.StiText Text69;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine15;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLine16;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive25;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive25;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive26;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive26;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive27;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive27;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive28;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive28;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive29;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive29;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive84;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive85;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive81;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive86;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive88;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive84;
        public Stimulsoft.Report.Components.StiStartPointPrimitive StartPointPrimitive90;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive86;
        public Stimulsoft.Report.Components.StiReportTitleBand ReportTitle1;
        public Stimulsoft.Report.Components.StiPanel Panel10;
        public Stimulsoft.Report.Components.StiText Text149;
        public Stimulsoft.Report.Components.StiText Text150;
        public Stimulsoft.Report.Components.StiVerticalLinePrimitive VerticalLine23;
        public Stimulsoft.Report.Components.StiVerticalLinePrimitive VerticalLine20;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive53;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive57;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive58;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive79;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive80;
        public Stimulsoft.Report.Components.StiEndPointPrimitive EndPointPrimitive82;
        public Stimulsoft.Report.Components.StiWatermark Page2_Watermark;
        public Stimulsoft.Report.Components.StiPage Page3;
        public Stimulsoft.Report.Components.StiPageFooterBand PageFooter2;
        public Stimulsoft.Report.Components.StiText Text136;
        public Stimulsoft.Report.Components.StiText Text137;
        public Stimulsoft.Report.Components.StiText Text138;
        public Stimulsoft.Report.Components.StiText Text139;
        public Stimulsoft.Report.Components.StiText Text140;
        public Stimulsoft.Report.Components.StiText Text141;
        public Stimulsoft.Report.Components.StiPanel Panel8;
        public Stimulsoft.Report.Components.StiText Text142;
        public Stimulsoft.Report.Components.StiText Text143;
        public Stimulsoft.Report.Components.StiText Text148;
        public Stimulsoft.Report.Components.StiText Text144;
        public Stimulsoft.Report.Components.StiText Text145;
        public Stimulsoft.Report.Components.StiText Text146;
        public Stimulsoft.Report.Components.StiText Text147;
        public Stimulsoft.Report.Components.StiText Text151;
        public Stimulsoft.Report.Components.StiImage Image2;
        public Stimulsoft.Report.Components.StiImage Image3;
        public Stimulsoft.Report.Components.StiImage Image4;
        public Stimulsoft.Report.Components.StiImage Image5;
        public Stimulsoft.Report.Components.StiImage Image6;
        public Stimulsoft.Report.Components.StiImage Image7;
        public Stimulsoft.Report.Components.StiImage Image8;
        public Stimulsoft.Report.Components.StiReportTitleBand ReportTitle2;
        public Stimulsoft.Report.Components.StiPanel Panel13;
        public Stimulsoft.Report.Components.StiText Text209;
        public Stimulsoft.Report.Components.StiText Text210;
        public Stimulsoft.Report.Components.StiWatermark Page3_Watermark;
        public Stimulsoft.Report.Print.StiPrinterSettings Report_PrinterSettings;
        public new InfoBusinessObject Info;
        public ObjectsBusinessObject Objects;
        
        public void Text18__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "سامانه مدیریت ریسک ";
        }
        
        public void Text19__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "#%#صفحه‌ی {PageNumber} از {TotalPageCount}";
            e.StoreToPrinted = true;
        }
        
        public System.String Text19_GetValue_End(Stimulsoft.Report.Components.StiComponent sender)
        {
            return "صفحه‌ی " + ToString(sender, PageNumber, true) + " از " + ToString(sender, TotalPageCount, true);
        }
        
        public void Text12__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "_StartDate";
        }
        
        public void Text15__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "_EndDate";
        }
        
        public void Text11__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Info._StartDate, true);
        }
        
        public void Text14__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Info._EndDate, true);
        }
        
        public void Text1__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "شرح";
        }
        
        public void Text3__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "تعدیل شده برای\r\n محاسبۀ نسبت جاری";
        }
        
        public void Text4__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "تعدیل شده برای محاسبۀ\r\n نسبت بدهی و تعهدات";
        }
        
        public void Text5__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "دارایی جاری";
        }
        
        public void Text6__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "دارایی غیر جاری";
        }
        
        public void Text7__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "کل دارایی ها";
        }
        
        public void Text8__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "بدهی های جاری";
        }
        
        public void Text9__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "بدهی های غیر جاری";
        }
        
        public void Text10__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "کل بدهی ها";
        }
        
        public void Text13__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "کل تعهدات";
        }
        
        public void Text16__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "نسبت جاری";
        }
        
        public void Text17__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "نسبت بدهی (و تعهدات)";
        }
        
        public void Text20__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text20.TextFormat.Format(CheckExcelValue(sender, Objects.C_CurrentAssets));
        }
        
        public void Text21__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text21.TextFormat.Format(CheckExcelValue(sender, " " + Objects.C_NonCurrentAssets));
        }
        
        public void Text22__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text22.TextFormat.Format(CheckExcelValue(sender, Objects.C_TotalAssets));
        }
        
        public void Text23__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text23.TextFormat.Format(CheckExcelValue(sender, Objects.C_CurrentDebts));
        }
        
        public void Text24__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text24.TextFormat.Format(CheckExcelValue(sender, Objects.C_NonCurrentDebts));
        }
        
        public void Text25__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text25.TextFormat.Format(CheckExcelValue(sender, Objects.C_TotalDebt));
        }
        
        public void Text26__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text26.TextFormat.Format(CheckExcelValue(sender, Objects.C_TotalCommitments));
        }
        
        public void Text27__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text27.TextFormat.Format(CheckExcelValue(sender, Objects.D_CurrentAssets));
        }
        
        public void Text28__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text28.TextFormat.Format(CheckExcelValue(sender, Objects.D_NonCurrentAssets));
        }
        
        public void Text29__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text29.TextFormat.Format(CheckExcelValue(sender, Objects.D_TotalAssets));
        }
        
        public void Text30__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text30.TextFormat.Format(CheckExcelValue(sender, Objects.D_NonCurrentDebts));
        }
        
        public void Text31__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text31.TextFormat.Format(CheckExcelValue(sender, Objects.D_CurrentDebts));
        }
        
        public void Text32__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text32.TextFormat.Format(CheckExcelValue(sender, Objects.D_TotalDebt));
        }
        
        public void Text33__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text33.TextFormat.Format(CheckExcelValue(sender, Objects.D_TotalCommitments));
        }
        
        public void Text35__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text35.TextFormat.Format(CheckExcelValue(sender, Objects.CurrentRatio));
        }
        
        public void Text36__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text36.TextFormat.Format(CheckExcelValue(sender, Objects.DebtRatio));
        }
        
        public void Text37__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "حداقل";
        }
        
        public void Text38__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "حداکثر";
        }
        
        public void Text82__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "شرح";
        }
        
        public void Text83__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "تعدیل شده برای محاسبۀ نسبت بدهی و تعهدات";
        }
        
        public void Text84__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = " تعدیل جدید";
        }
        
        public void Text85__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "دارایی جاری";
        }
        
        public void Text86__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "دارایی غیر جاری";
        }
        
        public void Text87__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "کل دارایی ها";
        }
        
        public void Text88__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "بدهی های جاری";
        }
        
        public void Text89__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "بدهی های غیر جاری";
        }
        
        public void Text90__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "کل بدهی ها";
        }
        
        public void Text91__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "کل تعهدات";
        }
        
        public void Text101__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text101.TextFormat.Format(CheckExcelValue(sender, Objects.D_CurrentAssets));
        }
        
        public void Text102__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text102.TextFormat.Format(CheckExcelValue(sender, Objects.D_NonCurrentAssets));
        }
        
        public void Text103__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text103.TextFormat.Format(CheckExcelValue(sender, Objects.D_TotalAssets));
        }
        
        public void Text104__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text104.TextFormat.Format(CheckExcelValue(sender, Objects.D_NonCurrentDebts));
        }
        
        public void Text105__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text105.TextFormat.Format(CheckExcelValue(sender, Objects.D_CurrentDebts));
        }
        
        public void Text106__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text106.TextFormat.Format(CheckExcelValue(sender, Objects.D_TotalDebt));
        }
        
        public void Text92__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "حداکثر میزان قابل قبول تعهدات تعدیل شده- مازاد بر اساس نسبت بدهی ";
        }
        
        public void Text107__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text107.TextFormat.Format(CheckExcelValue(sender, Objects.DebtNewAdjusted));
        }
        
        public void Text93__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text93.TextFormat.Format(CheckExcelValue(sender, Objects.DebtMaximumAcceptable));
        }
        
        public void Text94__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text94.TextFormat.Format(CheckExcelValue(sender, Objects.D_CurrentAssets));
        }
        
        public void Text95__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text95.TextFormat.Format(CheckExcelValue(sender, Objects.D_NonCurrentAssets));
        }
        
        public void Text96__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text96.TextFormat.Format(CheckExcelValue(sender, Objects.D_TotalAssets));
        }
        
        public void Text97__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text97.TextFormat.Format(CheckExcelValue(sender, Objects.D_NonCurrentDebts));
        }
        
        public void Text98__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text98.TextFormat.Format(CheckExcelValue(sender, Objects.D_CurrentDebts));
        }
        
        public void Text99__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text99.TextFormat.Format(CheckExcelValue(sender, Objects.D_TotalDebt));
        }
        
        public void Text100__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text100.TextFormat.Format(CheckExcelValue(sender, Objects.D_TotalCommitments));
        }
        
        public void Text2__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "ظرفیت تعهدات آتی بر اساس کفایت";
        }
        
        public void Text34__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, DateToshamsi(Today), true);
        }
        
        public void Text76__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "سامانه مدیریت ریسک ";
        }
        
        public void Text77__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "#%#صفحه‌ی {PageNumber} از {TotalPageCount}";
            e.StoreToPrinted = true;
        }
        
        public System.String Text77_GetValue_End(Stimulsoft.Report.Components.StiComponent sender)
        {
            return "صفحه‌ی " + ToString(sender, PageNumber, true) + " از " + ToString(sender, TotalPageCount, true);
        }
        
        public void Text78__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "_StartDate";
        }
        
        public void Text79__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "_EndDate";
        }
        
        public void Text80__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Info._StartDate, true);
        }
        
        public void Text81__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Info._EndDate, true);
        }
        
        public void Text108__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "شرح";
        }
        
        public void Text110__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = " تعدیل جدید";
        }
        
        public void Text111__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "دارایی جاری";
        }
        
        public void Text112__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "دارایی غیر جاری";
        }
        
        public void Text113__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "کل دارایی ها";
        }
        
        public void Text114__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "بدهی های جاری";
        }
        
        public void Text115__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "بدهی های غیر جاری";
        }
        
        public void Text116__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "کل بدهی ها";
        }
        
        public void Text117__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "کل تعهدات";
        }
        
        public void Text124__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "حداقل میزان قابل قبول تعهدات تعدیل شده- مازاد بر اساس نسبت جاری ";
        }
        
        public void Text118__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text118.TextFormat.Format(CheckExcelValue(sender, Objects.C_CurrentAssets));
        }
        
        public void Text119__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text119.TextFormat.Format(CheckExcelValue(sender, " " + Objects.C_NonCurrentAssets));
        }
        
        public void Text120__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text120.TextFormat.Format(CheckExcelValue(sender, Objects.C_TotalAssets));
        }
        
        public void Text121__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text121.TextFormat.Format(CheckExcelValue(sender, Objects.C_CurrentDebts));
        }
        
        public void Text122__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text122.TextFormat.Format(CheckExcelValue(sender, Objects.C_NonCurrentDebts));
        }
        
        public void Text123__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text123.TextFormat.Format(CheckExcelValue(sender, Objects.C_TotalDebt));
        }
        
        public void Text125__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text125.TextFormat.Format(CheckExcelValue(sender, Objects.C_TotalCommitments));
        }
        
        public void Text126__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text126.TextFormat.Format(CheckExcelValue(sender, Objects.C_CurrentAssets));
        }
        
        public void Text127__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text127.TextFormat.Format(CheckExcelValue(sender, " " + Objects.C_NonCurrentAssets));
        }
        
        public void Text128__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text128.TextFormat.Format(CheckExcelValue(sender, Objects.C_TotalAssets));
        }
        
        public void Text129__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text129.TextFormat.Format(CheckExcelValue(sender, Objects.C_CurrentDebts));
        }
        
        public void Text130__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text130.TextFormat.Format(CheckExcelValue(sender, Objects.C_NonCurrentDebts));
        }
        
        public void Text131__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text131.TextFormat.Format(CheckExcelValue(sender, Objects.C_TotalDebt));
        }
        
        public void Text132__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "نسبت جاری";
        }
        
        public void Text133__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text133.TextFormat.Format(CheckExcelValue(sender, Objects.CurrentRatio));
        }
        
        public void Text134__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text134.TextFormat.Format(CheckExcelValue(sender, Objects.CurrentNewAdjusted));
        }
        
        public void Text135__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text135.TextFormat.Format(CheckExcelValue(sender, Objects.CurrentMaximumAcceptable));
        }
        
        public void Text109__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "تعدیل شده برای محاسبۀ نسبت جاری";
        }
        
        public void Text39__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "ظرفیت مازاد بدهی";
        }
        
        public void Text40__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "ارزش بازاری حداقل معاملات روزانه تعهد شده در غیر اینصورت ارزش\r\n معاملات روزانه بازارگردان ظرف یک هفته اخیر";
        }
        
        public void Text41__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "ضریب\r\n نسبت جاری";
        }
        
        public void Text42__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "ضریب\r\n نسبت بدهی";
        }
        
        public void Text43__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "مازاد تعدیل شده";
        }
        
        public void Text44__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "اوراق بهادار با درآمد ثابت\r\n پذیرش بازارگردانی";
        }
        
        public void Text45__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "حداکثر ظرفیت پذیرش\r\n اوراق بدهی مازاد";
        }
        
        public void Text60__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text60.TextFormat.Format(CheckExcelValue(sender, Objects.DebtMaximumAcceptable));
        }
        
        public void Text48__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "20%";
        }
        
        public void Text49__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Info.DF1, true) + "%";
        }
        
        public void Text55__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text55.TextFormat.Format(CheckExcelValue(sender, Objects.DebtMaximumAcceptable / (Info.DF1/100) ));
        }
        
        public void Text61__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "از منظر نسبت بدهی";
        }
        
        public void Text72__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text72.TextFormat.Format(CheckExcelValue(sender, (Objects.DebtMaximumAcceptable / (Info.DF1/100))*10 ));
        }
        
        public void Text47__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "ارزش کل سهام در تعهد پذیره نویسی در حال عرضه\r\n بر اساس قیمت عرضه ";
        }
        
        public void Text51__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "حداکثر پذیره نویسی\r\n سرمایه ای مازاد";
        }
        
        public void Text46__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "ظرفیت مازاد سرمایه ای";
        }
        
        public void Text62__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "از منظر نسبت بدهی";
        }
        
        public void Text52__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "30%";
        }
        
        public void Text64__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Info.DF2, true) + "%";
        }
        
        public void Text66__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "ضریب\r\n نسبت جاری";
        }
        
        public void Text70__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text70.TextFormat.Format(CheckExcelValue(sender, Objects.DebtMaximumAcceptable));
        }
        
        public void Text71__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text71.TextFormat.Format(CheckExcelValue(sender, Objects.DebtMaximumAcceptable / (Info.DF2/100) ));
        }
        
        public void Text50__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "مازاد تعدیل شده";
        }
        
        public void Text68__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "ضریب\r\n نسبت بدهی";
        }
        
        public void Text54__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "ارزش بازاری حداقل معاملات روزانه تعهد شده در غیر اینصورت ارزش\r\n معاملات روزانه بازارگردان ظرف یک هفته اخیر";
        }
        
        public void Text58__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "اوراق بهادار با درآمد ثابت\r\n پذیرش بازارگردانی";
        }
        
        public void Text59__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "حداقل ظرفیت پذیرش\r\n اوراق بدهی مازاد";
        }
        
        public void Text53__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "الزام حداقل ظرفیت \r\nمازاد بدهی";
        }
        
        public void Text63__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "از منظر نسبت جاری";
        }
        
        public void Text56__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "20%";
        }
        
        public void Text65__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Info.DF3, true) + "%";
        }
        
        public void Text67__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "ضریب\r\n نسبت جاری";
        }
        
        public void Text73__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text73.TextFormat.Format(CheckExcelValue(sender, Objects.CurrentMaximumAcceptable));
        }
        
        public void Text74__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text74.TextFormat.Format(CheckExcelValue(sender, Objects.CurrentMaximumAcceptable / (Info.DF3/100) ));
        }
        
        public void Text75__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text75.TextFormat.Format(CheckExcelValue(sender, (Objects.CurrentMaximumAcceptable / (Info.DF3/100))*10 ));
        }
        
        public void Text57__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "مازاد تعدیل شده";
        }
        
        public void Text69__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "ضریب\r\n نسبت بدهی";
        }
        
        public void Text149__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "ظرفیت تعهدات آتی بر اساس کفایت";
        }
        
        public void Text150__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, DateToshamsi(Today), true);
        }
        
        public void Text136__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "سامانه مدیریت ریسک ";
        }
        
        public void Text137__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "#%#صفحه‌ی {PageNumber} از {TotalPageCount}";
            e.StoreToPrinted = true;
        }
        
        public System.String Text137_GetValue_End(Stimulsoft.Report.Components.StiComponent sender)
        {
            return "صفحه‌ی " + ToString(sender, PageNumber, true) + " از " + ToString(sender, TotalPageCount, true);
        }
        
        public void Text138__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "_StartDate";
        }
        
        public void Text139__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "_EndDate";
        }
        
        public void Text140__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Info._StartDate, true);
        }
        
        public void Text141__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Info._EndDate, true);
        }
        
        public void Text142__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "بر اساس این گزارش اطلاعات زیر قابل مشاهده است:";
        }
        
        public void Text143__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "شکاف نقدینگی مهر ماه به میزان 78,381,545,508 ریال بر آورد شده است.";
        }
        
        public void Text148__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = " منفی ترین شکاف نقدینگی مربوط به شهریور ماه و به مبلغ  1,130,649,714,495- ریال می باشد و شکاف نقدینگی تجمعی در \r\nپایان سال به مبلغ 2,288,523,255,832  ریال می باشد.\r\n";
        }
        
        public void Text144__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "میزان کل منابع شرکت بر اساس اطلاعات اخذ شده تا انتهای مرداد ماه به میزان  121,951,574,569,567  ریال می باشد که از \r\nاین مبلغ  4,028,250,988,828 ریال مربوط به سپرده ها و 117,923,323,580,739  ریال مربوط به صندوق های تحت مالکیت \r\nو 480,000,000,000 ریال مربوط به انتشار اوراق از اجاره شرکت است .";
        }
        
        public void Text145__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "میزان تعهدات قراردادهای بازارگردانی فعلی شرکت 12,115,871,235,589  ریال می باشد.";
        }
        
        public void Text146__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "میزان پیش بینی تعهدات آتی بدهی و سرمایه ای تا انتهای سال به ترتیب 9,500,000,000,000 و 2,088,136,361,107\r\nریال می باشد.";
        }
        
        public void Text147__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "میزان پیش بینی تعهدات آتی سرمایه ای تا انتهای سال 218,552,327,000  ریال می باشد";
        }
        
        public void Text151__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "شرکت به میزان 480,000,000,000  ریال اوراق اجاره با نرخ 16% منتشر می نماید ";
        }
        
        public void Text209__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "ظرفیت تعهدات آتی بر اساس کفایت";
        }
        
        public void Text210__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, DateToshamsi(Today), true);
        }
        
        public void ReportWordsToEnd__EndRender(object sender, System.EventArgs e)
        {
            this.Text19.SetText(new Stimulsoft.Report.Components.StiGetValue(this.Text19_GetValue_End));
            this.Text77.SetText(new Stimulsoft.Report.Components.StiGetValue(this.Text77_GetValue_End));
            this.Text137.SetText(new Stimulsoft.Report.Components.StiGetValue(this.Text137_GetValue_End));
        }
        
        private void InitializeComponent()
        {
            this.Objects = new ObjectsBusinessObject();
            this.Info = new InfoBusinessObject();
            this.Dictionary.Variables.Add(new Stimulsoft.Report.Dictionary.StiVariable("", "_StartDate", "_StartDate", "", typeof(string), "", false, Stimulsoft.Report.Dictionary.StiVariableInitBy.Value, false));
            this.NeedsCompiling = false;
            // 
            // Variables init
            // 
            this._StartDate = "";
            this.EngineVersion = Stimulsoft.Report.Engine.StiEngineVersion.EngineV2;
            this.ReferencedAssemblies = new System.String[] {
                    "System.Dll",
                    "System.Drawing.Dll",
                    "System.Windows.Forms.Dll",
                    "System.Data.Dll",
                    "System.Xml.Dll",
                    "Stimulsoft.Controls.Dll",
                    "Stimulsoft.Base.Dll",
                    "Stimulsoft.Report.Dll"};
            this.ReportAlias = "Report";
            // 
            // ReportChanged
            // 
            this.ReportChanged = new DateTime(2019, 3, 16, 13, 46, 11, 0);
            // 
            // ReportCreated
            // 
            this.ReportCreated = new DateTime(2018, 7, 1, 16, 48, 34, 0);
            this.ReportFile = "C:\\x_ErmN\\erm\\Sanay.Lotus.Erm\\Content\\Reports\\CapitalSufficiencies.mrt";
            this.ReportGuid = "d9bb0fec521e41ad99bd7799d793c95c";
            this.ReportName = "Report";
            this.ReportUnit = Stimulsoft.Report.StiReportUnitType.Inches;
            this.ReportVersion = "2013.1.1600";
            this.ScriptLanguage = Stimulsoft.Report.StiReportLanguageType.CSharp;
            // 
            // Page1
            // 
            this.Page1 = new Stimulsoft.Report.Components.StiPage();
            this.Page1.Guid = "3212fef088394d08bce68018b3efe5a2";
            this.Page1.Name = "Page1";
            this.Page1.PageHeight = 11;
            this.Page1.PageWidth = 8.5;
            this.Page1.PaperSize = System.Drawing.Printing.PaperKind.Letter;
            this.Page1.RightToLeft = true;
            this.Page1.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 2, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Page1.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // PageFooterBand2
            // 
            this.PageFooterBand2 = new Stimulsoft.Report.Components.StiPageFooterBand();
            this.PageFooterBand2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 9.82, 7.72, 0.4);
            this.PageFooterBand2.Guid = "da5b68cbe4e0acdcd2b855c8c978488e";
            this.PageFooterBand2.Name = "PageFooterBand2";
            this.PageFooterBand2.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.PageFooterBand2.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // Text18
            // 
            this.Text18 = new Stimulsoft.Report.Components.StiText();
            this.Text18.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.8, 0.1, 2.9, 0.3);
            this.Text18.ComponentStyle = "Collection_Page_Footer";
            this.Text18.Guid = "6db6baa646d85bff23b555c8c9783cfc";
            this.Text18.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text18.Name = "Text18";
            this.Text18.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text18__GetValue);
            this.Text18.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text18.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text18.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text18.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text18.Font = new System.Drawing.Font("B Nazanin", 11F, System.Drawing.FontStyle.Bold);
            this.Text18.Indicator = null;
            this.Text18.Interaction = null;
            this.Text18.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text18.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 112, 48, 160));
            this.Text18.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text19
            // 
            this.Text19 = new Stimulsoft.Report.Components.StiText();
            this.Text19.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.2, 3.4, 0.3);
            this.Text19.ComponentStyle = "Collection_Page_Footer";
            this.Text19.Guid = "d884f12a77449fe3aa8555c8c978348f";
            this.Text19.Name = "Text19";
            this.Text19.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text19__GetValue);
            this.Text19.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text19.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text19.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text19.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text19.Indicator = null;
            this.Text19.Interaction = null;
            this.Text19.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text19.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text19.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            this.PageFooterBand2.Interaction = null;
            // 
            // Text12
            // 
            this.Text12 = new Stimulsoft.Report.Components.StiText();
            this.Text12.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(8.7, 3.5, 1, 0.3);
            this.Text12.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text12.Name = "Text12";
            this.Text12.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text12__GetValue);
            this.Text12.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text12.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.All, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text12.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 181, 204, 136));
            this.Text12.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text12.Guid = null;
            this.Text12.Indicator = null;
            this.Text12.Interaction = null;
            this.Text12.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text12.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text12.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text15
            // 
            this.Text15 = new Stimulsoft.Report.Components.StiText();
            this.Text15.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(9.7, 3.5, 1, 0.3);
            this.Text15.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text15.Name = "Text15";
            this.Text15.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text15__GetValue);
            this.Text15.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text15.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.All, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text15.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 181, 204, 136));
            this.Text15.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text15.Guid = null;
            this.Text15.Indicator = null;
            this.Text15.Interaction = null;
            this.Text15.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text15.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text15.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text11
            // 
            this.Text11 = new Stimulsoft.Report.Components.StiText();
            this.Text11.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(8.7, 4.2, 1, 0.3);
            this.Text11.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text11.Name = "Text11";
            this.Text11.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text11__GetValue);
            this.Text11.Type = Stimulsoft.Report.Components.StiSystemTextType.DataColumn;
            this.Text11.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text11.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text11.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text11.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text11.Guid = null;
            this.Text11.Indicator = null;
            this.Text11.Interaction = null;
            this.Text11.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text11.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text11.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text14
            // 
            this.Text14 = new Stimulsoft.Report.Components.StiText();
            this.Text14.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(9.7, 4.2, 1, 0.3);
            this.Text14.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text14.Name = "Text14";
            this.Text14.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text14__GetValue);
            this.Text14.Type = Stimulsoft.Report.Components.StiSystemTextType.DataColumn;
            this.Text14.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text14.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text14.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text14.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text14.Guid = null;
            this.Text14.Indicator = null;
            this.Text14.Interaction = null;
            this.Text14.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text14.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text14.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Panel1
            // 
            this.Panel1 = new Stimulsoft.Report.Components.StiPanel();
            this.Panel1.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.1, 1, 7.6, 4.1);
            this.Panel1.Name = "Panel1";
            this.Panel1.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.All, System.Drawing.Color.FromArgb(255, 191, 191, 191), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, true, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Panel1.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // Text1
            // 
            this.Text1 = new Stimulsoft.Report.Components.StiText();
            this.Text1.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.4, 0.1, 0.6, 0.2);
            this.Text1.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text1.Name = "Text1";
            this.Text1.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text1__GetValue);
            this.Text1.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text1.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text1.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text1.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text1.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text1.Guid = null;
            this.Text1.Indicator = null;
            this.Text1.Interaction = null;
            this.Text1.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text1.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text1.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text3
            // 
            this.Text3 = new Stimulsoft.Report.Components.StiText();
            this.Text3.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.8, 0, 1.6, 0.5);
            this.Text3.Guid = "c33d90869213477d9ae90cde1a75c9ca";
            this.Text3.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text3.Name = "Text3";
            this.Text3.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text3__GetValue);
            this.Text3.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text3.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text3.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text3.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text3.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text3.Indicator = null;
            this.Text3.Interaction = null;
            this.Text3.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text3.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text3.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text4
            // 
            this.Text4 = new Stimulsoft.Report.Components.StiText();
            this.Text4.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.9, 0, 1.7, 0.5);
            this.Text4.Guid = "4eadb79ee2a3483e84ceeb6771cdc438";
            this.Text4.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text4.Name = "Text4";
            this.Text4.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text4__GetValue);
            this.Text4.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text4.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text4.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text4.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text4.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text4.Indicator = null;
            this.Text4.Interaction = null;
            this.Text4.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text4.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text4.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text5
            // 
            this.Text5 = new Stimulsoft.Report.Components.StiText();
            this.Text5.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 0.6, 1.6, 0.2);
            this.Text5.Guid = "b1015f1e68b742ef831078da87c18f9a";
            this.Text5.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text5.Name = "Text5";
            this.Text5.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text5__GetValue);
            this.Text5.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text5.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text5.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text5.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text5.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text5.Indicator = null;
            this.Text5.Interaction = null;
            this.Text5.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text5.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text5.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text6
            // 
            this.Text6 = new Stimulsoft.Report.Components.StiText();
            this.Text6.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 1, 1.6, 0.2);
            this.Text6.Guid = "03a7f8ec2afe4ea19e4354676bf4d272";
            this.Text6.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text6.Name = "Text6";
            this.Text6.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text6__GetValue);
            this.Text6.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text6.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text6.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text6.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text6.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text6.Indicator = null;
            this.Text6.Interaction = null;
            this.Text6.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text6.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text6.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text7
            // 
            this.Text7 = new Stimulsoft.Report.Components.StiText();
            this.Text7.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 1.4, 1.6, 0.2);
            this.Text7.Guid = "71a960b748f2404aa911ecb6b6ecabb1";
            this.Text7.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text7.Name = "Text7";
            this.Text7.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text7__GetValue);
            this.Text7.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text7.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text7.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text7.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text7.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text7.Indicator = null;
            this.Text7.Interaction = null;
            this.Text7.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text7.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text7.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text8
            // 
            this.Text8 = new Stimulsoft.Report.Components.StiText();
            this.Text8.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 1.8, 1.6, 0.2);
            this.Text8.Guid = "b5c31a49fc8e4c4eb895c1aa12dc7bd0";
            this.Text8.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text8.Name = "Text8";
            this.Text8.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text8__GetValue);
            this.Text8.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text8.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text8.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text8.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text8.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text8.Indicator = null;
            this.Text8.Interaction = null;
            this.Text8.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text8.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text8.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text9
            // 
            this.Text9 = new Stimulsoft.Report.Components.StiText();
            this.Text9.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 2.2, 1.6, 0.2);
            this.Text9.Guid = "bf5f088e0ed041a29761f7472d94c08e";
            this.Text9.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text9.Name = "Text9";
            this.Text9.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text9__GetValue);
            this.Text9.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text9.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text9.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text9.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text9.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text9.Indicator = null;
            this.Text9.Interaction = null;
            this.Text9.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text9.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text9.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text10
            // 
            this.Text10 = new Stimulsoft.Report.Components.StiText();
            this.Text10.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 2.6, 1.6, 0.2);
            this.Text10.Guid = "3a3db45b58c14922b9e30a3d3eaaf81b";
            this.Text10.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text10.Name = "Text10";
            this.Text10.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text10__GetValue);
            this.Text10.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text10.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text10.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text10.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text10.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text10.Indicator = null;
            this.Text10.Interaction = null;
            this.Text10.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text10.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text10.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text13
            // 
            this.Text13 = new Stimulsoft.Report.Components.StiText();
            this.Text13.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 3, 1.6, 0.2);
            this.Text13.Guid = "80940c984370492cbcbf6014ef9789e7";
            this.Text13.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text13.Name = "Text13";
            this.Text13.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text13__GetValue);
            this.Text13.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text13.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text13.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text13.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text13.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text13.Indicator = null;
            this.Text13.Interaction = null;
            this.Text13.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text13.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text13.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text16
            // 
            this.Text16 = new Stimulsoft.Report.Components.StiText();
            this.Text16.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 3.4, 1.6, 0.2);
            this.Text16.Guid = "aeab2749fa3647d19057d6a265c05b90";
            this.Text16.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text16.Name = "Text16";
            this.Text16.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text16__GetValue);
            this.Text16.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text16.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text16.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text16.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text16.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text16.Indicator = null;
            this.Text16.Interaction = null;
            this.Text16.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text16.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text16.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text17
            // 
            this.Text17 = new Stimulsoft.Report.Components.StiText();
            this.Text17.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 3.8, 1.6, 0.2);
            this.Text17.Guid = "540d070c76974b438a06264f4bc01f69";
            this.Text17.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text17.Name = "Text17";
            this.Text17.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text17__GetValue);
            this.Text17.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text17.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text17.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text17.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text17.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text17.Indicator = null;
            this.Text17.Interaction = null;
            this.Text17.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text17.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text17.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text20
            // 
            this.Text20 = new Stimulsoft.Report.Components.StiText();
            this.Text20.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.8, 0.6, 1.8, 0.2);
            this.Text20.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text20.Name = "Text20";
            this.Text20.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text20__GetValue);
            this.Text20.Type = Stimulsoft.Report.Components.StiSystemTextType.DataColumn;
            this.Text20.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text20.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text20.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text20.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text20.Guid = null;
            this.Text20.Indicator = null;
            this.Text20.Interaction = null;
            this.Text20.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text20.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text20.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text20.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text21
            // 
            this.Text21 = new Stimulsoft.Report.Components.StiText();
            this.Text21.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.8, 1, 1.8, 0.2);
            this.Text21.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text21.Name = "Text21";
            this.Text21.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text21__GetValue);
            this.Text21.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text21.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text21.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text21.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text21.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text21.Guid = null;
            this.Text21.Indicator = null;
            this.Text21.Interaction = null;
            this.Text21.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text21.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text21.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text21.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text22
            // 
            this.Text22 = new Stimulsoft.Report.Components.StiText();
            this.Text22.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.8, 1.4, 1.8, 0.2);
            this.Text22.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text22.Name = "Text22";
            this.Text22.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text22__GetValue);
            this.Text22.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text22.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text22.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text22.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text22.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text22.Guid = null;
            this.Text22.Indicator = null;
            this.Text22.Interaction = null;
            this.Text22.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text22.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text22.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text22.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text23
            // 
            this.Text23 = new Stimulsoft.Report.Components.StiText();
            this.Text23.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.8, 1.8, 1.8, 0.2);
            this.Text23.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text23.Name = "Text23";
            this.Text23.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text23__GetValue);
            this.Text23.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text23.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text23.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text23.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text23.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text23.Guid = null;
            this.Text23.Indicator = null;
            this.Text23.Interaction = null;
            this.Text23.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text23.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text23.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text23.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text24
            // 
            this.Text24 = new Stimulsoft.Report.Components.StiText();
            this.Text24.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.8, 2.2, 1.8, 0.2);
            this.Text24.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text24.Name = "Text24";
            this.Text24.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text24__GetValue);
            this.Text24.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text24.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text24.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text24.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text24.Guid = null;
            this.Text24.Indicator = null;
            this.Text24.Interaction = null;
            this.Text24.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text24.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text24.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text24.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text25
            // 
            this.Text25 = new Stimulsoft.Report.Components.StiText();
            this.Text25.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.8, 2.6, 1.8, 0.2);
            this.Text25.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text25.Name = "Text25";
            this.Text25.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text25__GetValue);
            this.Text25.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text25.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text25.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text25.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text25.Guid = null;
            this.Text25.Indicator = null;
            this.Text25.Interaction = null;
            this.Text25.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text25.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text25.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text25.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text26
            // 
            this.Text26 = new Stimulsoft.Report.Components.StiText();
            this.Text26.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.8, 3, 1.8, 0.2);
            this.Text26.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text26.Name = "Text26";
            this.Text26.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text26__GetValue);
            this.Text26.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text26.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text26.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text26.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text26.Guid = null;
            this.Text26.Indicator = null;
            this.Text26.Interaction = null;
            this.Text26.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text26.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text26.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text26.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text27
            // 
            this.Text27 = new Stimulsoft.Report.Components.StiText();
            this.Text27.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.6, 0.6, 2, 0.2);
            this.Text27.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text27.Name = "Text27";
            this.Text27.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text27__GetValue);
            this.Text27.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text27.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text27.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text27.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text27.Guid = null;
            this.Text27.Indicator = null;
            this.Text27.Interaction = null;
            this.Text27.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text27.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text27.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text27.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text28
            // 
            this.Text28 = new Stimulsoft.Report.Components.StiText();
            this.Text28.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.6, 1, 2, 0.2);
            this.Text28.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text28.Name = "Text28";
            this.Text28.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text28__GetValue);
            this.Text28.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text28.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text28.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text28.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text28.Guid = null;
            this.Text28.Indicator = null;
            this.Text28.Interaction = null;
            this.Text28.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text28.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text28.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text28.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text29
            // 
            this.Text29 = new Stimulsoft.Report.Components.StiText();
            this.Text29.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.6, 1.4, 2, 0.2);
            this.Text29.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text29.Name = "Text29";
            this.Text29.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text29__GetValue);
            this.Text29.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text29.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text29.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text29.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text29.Guid = null;
            this.Text29.Indicator = null;
            this.Text29.Interaction = null;
            this.Text29.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text29.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text29.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text29.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text30
            // 
            this.Text30 = new Stimulsoft.Report.Components.StiText();
            this.Text30.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.6, 2.2, 2, 0.2);
            this.Text30.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text30.Name = "Text30";
            this.Text30.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text30__GetValue);
            this.Text30.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text30.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text30.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text30.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text30.Guid = null;
            this.Text30.Indicator = null;
            this.Text30.Interaction = null;
            this.Text30.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text30.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text30.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text30.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text31
            // 
            this.Text31 = new Stimulsoft.Report.Components.StiText();
            this.Text31.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.6, 1.8, 2, 0.2);
            this.Text31.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text31.Name = "Text31";
            this.Text31.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text31__GetValue);
            this.Text31.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text31.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text31.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text31.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text31.Guid = null;
            this.Text31.Indicator = null;
            this.Text31.Interaction = null;
            this.Text31.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text31.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text31.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text31.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text32
            // 
            this.Text32 = new Stimulsoft.Report.Components.StiText();
            this.Text32.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.6, 2.6, 2, 0.2);
            this.Text32.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text32.Name = "Text32";
            this.Text32.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text32__GetValue);
            this.Text32.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text32.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text32.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text32.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text32.Guid = null;
            this.Text32.Indicator = null;
            this.Text32.Interaction = null;
            this.Text32.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text32.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text32.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text32.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text33
            // 
            this.Text33 = new Stimulsoft.Report.Components.StiText();
            this.Text33.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.6, 3, 2, 0.2);
            this.Text33.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text33.Name = "Text33";
            this.Text33.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text33__GetValue);
            this.Text33.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text33.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text33.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text33.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text33.Guid = null;
            this.Text33.Indicator = null;
            this.Text33.Interaction = null;
            this.Text33.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text33.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text33.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text33.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text35
            // 
            this.Text35 = new Stimulsoft.Report.Components.StiText();
            this.Text35.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.8, 3.4, 1.8, 0.2);
            this.Text35.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text35.Name = "Text35";
            this.Text35.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text35__GetValue);
            this.Text35.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text35.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text35.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text35.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text35.Guid = null;
            this.Text35.Indicator = null;
            this.Text35.Interaction = null;
            this.Text35.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text35.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text35.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 2, ",", 3, true, false, " ");
            this.Text35.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text36
            // 
            this.Text36 = new Stimulsoft.Report.Components.StiText();
            this.Text36.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.6, 3.8, 2, 0.2);
            this.Text36.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text36.Name = "Text36";
            this.Text36.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text36__GetValue);
            this.Text36.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text36.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text36.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text36.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text36.Guid = null;
            this.Text36.Indicator = null;
            this.Text36.Interaction = null;
            this.Text36.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text36.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text36.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiPercentageFormatService(1, 1, ".", 0, ",", 3, "%", true, false, " ");
            this.Text36.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text37
            // 
            this.Text37 = new Stimulsoft.Report.Components.StiText();
            this.Text37.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.8, 0.1, 0.6, 0.2);
            this.Text37.Guid = "23d6c0e49dcf4fddb9e7ec12045ff569";
            this.Text37.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text37.Name = "Text37";
            this.Text37.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text37__GetValue);
            this.Text37.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text37.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text37.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text37.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text37.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text37.Indicator = null;
            this.Text37.Interaction = null;
            this.Text37.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text37.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text37.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text38
            // 
            this.Text38 = new Stimulsoft.Report.Components.StiText();
            this.Text38.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.1, 0.6, 0.2);
            this.Text38.Guid = "fb067910806646afa98cdb926f9b2c31";
            this.Text38.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text38.Name = "Text38";
            this.Text38.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text38__GetValue);
            this.Text38.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text38.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text38.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text38.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text38.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text38.Indicator = null;
            this.Text38.Interaction = null;
            this.Text38.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text38.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text38.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // HorizontalLine1
            // 
            this.HorizontalLine1 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine1.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.5, 7.5, 0.01);
            this.HorizontalLine1.Color = System.Drawing.Color.FromArgb(255, 81, 104, 36);
            this.HorizontalLine1.Name = "HorizontalLine1";
            this.HorizontalLine1.Size = 2F;
            this.HorizontalLine1.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine1.Guid = null;
            this.HorizontalLine1.Interaction = null;
            this.HorizontalLine1.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // StartPointPrimitive1
            // 
            this.StartPointPrimitive1 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive1.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.8, 0, 0, 0);
            this.StartPointPrimitive1.Name = "StartPointPrimitive1";
            this.StartPointPrimitive1.ReferenceToGuid = "bc31bb40bb6046478b072e9f7d25b4e0";
            this.StartPointPrimitive1.Guid = null;
            this.StartPointPrimitive1.Interaction = null;
            // 
            // StartPointPrimitive2
            // 
            this.StartPointPrimitive2 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.5, 0, 0, 0);
            this.StartPointPrimitive2.Name = "StartPointPrimitive2";
            this.StartPointPrimitive2.ReferenceToGuid = "c3cd63edc0e74e7e9851e40598aa4203";
            this.StartPointPrimitive2.Guid = null;
            this.StartPointPrimitive2.Interaction = null;
            // 
            // StartPointPrimitive3
            // 
            this.StartPointPrimitive3 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive3.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.7, 0, 0, 0);
            this.StartPointPrimitive3.Name = "StartPointPrimitive3";
            this.StartPointPrimitive3.ReferenceToGuid = "7e66c1508f684b68b904e7de8f1641ac";
            this.StartPointPrimitive3.Guid = null;
            this.StartPointPrimitive3.Interaction = null;
            // 
            // StartPointPrimitive4
            // 
            this.StartPointPrimitive4 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive4.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.7, 0, 0, 0);
            this.StartPointPrimitive4.Name = "StartPointPrimitive4";
            this.StartPointPrimitive4.ReferenceToGuid = "6722d6104787442fb4a9e84f6bbccc1d";
            this.StartPointPrimitive4.Guid = null;
            this.StartPointPrimitive4.Interaction = null;
            // 
            // HorizontalLine2
            // 
            this.HorizontalLine2 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.9, 7.5, 0.01);
            this.HorizontalLine2.Color = System.Drawing.Color.DarkGray;
            this.HorizontalLine2.Guid = "c5c496699363410baef2059f1bbd459b";
            this.HorizontalLine2.Name = "HorizontalLine2";
            this.HorizontalLine2.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine2.Interaction = null;
            this.HorizontalLine2.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine3
            // 
            this.HorizontalLine3 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine3.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 1.3, 7.5, 0.01);
            this.HorizontalLine3.Color = System.Drawing.Color.DarkGray;
            this.HorizontalLine3.Guid = "79defb0e89bb4c7eb970d977ea9a9ae1";
            this.HorizontalLine3.Name = "HorizontalLine3";
            this.HorizontalLine3.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine3.Interaction = null;
            this.HorizontalLine3.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine4
            // 
            this.HorizontalLine4 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine4.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 1.7, 7.5, 0.01);
            this.HorizontalLine4.Color = System.Drawing.Color.DarkGray;
            this.HorizontalLine4.Guid = "bfcd2939a9e54b8b9778a3801d648c80";
            this.HorizontalLine4.Name = "HorizontalLine4";
            this.HorizontalLine4.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine4.Interaction = null;
            this.HorizontalLine4.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine5
            // 
            this.HorizontalLine5 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine5.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 2.1, 7.5, 0.01);
            this.HorizontalLine5.Color = System.Drawing.Color.DarkGray;
            this.HorizontalLine5.Guid = "3975d57ca31d47acaf57b89616671570";
            this.HorizontalLine5.Name = "HorizontalLine5";
            this.HorizontalLine5.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine5.Interaction = null;
            this.HorizontalLine5.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine6
            // 
            this.HorizontalLine6 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine6.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 2.5, 7.5, 0.01);
            this.HorizontalLine6.Color = System.Drawing.Color.DarkGray;
            this.HorizontalLine6.Guid = "50bdb60c0db64cb9943b11e5681791c0";
            this.HorizontalLine6.Name = "HorizontalLine6";
            this.HorizontalLine6.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine6.Interaction = null;
            this.HorizontalLine6.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine7
            // 
            this.HorizontalLine7 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine7.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 2.9, 7.5, 0.01);
            this.HorizontalLine7.Color = System.Drawing.Color.DarkGray;
            this.HorizontalLine7.Guid = "7bea54b3346f4eb68df6dfdb107f943e";
            this.HorizontalLine7.Name = "HorizontalLine7";
            this.HorizontalLine7.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine7.Interaction = null;
            this.HorizontalLine7.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine8
            // 
            this.HorizontalLine8 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine8.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 3.3, 7.5, 0.01);
            this.HorizontalLine8.Color = System.Drawing.Color.DarkGray;
            this.HorizontalLine8.Guid = "7e801a72424f4511b9d82e3d6834ba40";
            this.HorizontalLine8.Name = "HorizontalLine8";
            this.HorizontalLine8.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine8.Interaction = null;
            this.HorizontalLine8.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine9
            // 
            this.HorizontalLine9 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine9.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 3.7, 7.5, 0.01);
            this.HorizontalLine9.Color = System.Drawing.Color.DarkGray;
            this.HorizontalLine9.Guid = "3ffe2e0bedc5405b964388b8c3d269b3";
            this.HorizontalLine9.Name = "HorizontalLine9";
            this.HorizontalLine9.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine9.Interaction = null;
            this.HorizontalLine9.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // EndPointPrimitive3
            // 
            this.EndPointPrimitive3 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive3.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.7, 4.1, 0, 0);
            this.EndPointPrimitive3.Name = "EndPointPrimitive3";
            this.EndPointPrimitive3.ReferenceToGuid = "7e66c1508f684b68b904e7de8f1641ac";
            this.EndPointPrimitive3.Guid = null;
            this.EndPointPrimitive3.Interaction = null;
            // 
            // EndPointPrimitive4
            // 
            this.EndPointPrimitive4 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive4.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.7, 4.1, 0, 0);
            this.EndPointPrimitive4.Name = "EndPointPrimitive4";
            this.EndPointPrimitive4.ReferenceToGuid = "6722d6104787442fb4a9e84f6bbccc1d";
            this.EndPointPrimitive4.Guid = null;
            this.EndPointPrimitive4.Interaction = null;
            // 
            // EndPointPrimitive2
            // 
            this.EndPointPrimitive2 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.5, 4.1, 0, 0);
            this.EndPointPrimitive2.Name = "EndPointPrimitive2";
            this.EndPointPrimitive2.ReferenceToGuid = "c3cd63edc0e74e7e9851e40598aa4203";
            this.EndPointPrimitive2.Guid = null;
            this.EndPointPrimitive2.Interaction = null;
            // 
            // EndPointPrimitive1
            // 
            this.EndPointPrimitive1 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive1.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.8, 4.1, 0, 0);
            this.EndPointPrimitive1.Name = "EndPointPrimitive1";
            this.EndPointPrimitive1.ReferenceToGuid = "bc31bb40bb6046478b072e9f7d25b4e0";
            this.EndPointPrimitive1.Guid = null;
            this.EndPointPrimitive1.Interaction = null;
            this.Panel1.Guid = null;
            this.Panel1.Interaction = null;
            // 
            // Panel6
            // 
            this.Panel6 = new Stimulsoft.Report.Components.StiPanel();
            this.Panel6.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.1, 5.6, 7.6, 3.8);
            this.Panel6.Guid = "8bf3e36e8cdc48848cfb68f0b086a0f7";
            this.Panel6.Name = "Panel6";
            this.Panel6.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.All, System.Drawing.Color.FromArgb(255, 191, 191, 191), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, true, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Panel6.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // Text82
            // 
            this.Text82 = new Stimulsoft.Report.Components.StiText();
            this.Text82.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.4, 0.1, 0.6, 0.2);
            this.Text82.Guid = "e34ac3eb38cc41a7a01c44f246bb3ecd";
            this.Text82.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text82.Name = "Text82";
            this.Text82.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text82__GetValue);
            this.Text82.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text82.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text82.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text82.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text82.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text82.Indicator = null;
            this.Text82.Interaction = null;
            this.Text82.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text82.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text82.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text83
            // 
            this.Text83 = new Stimulsoft.Report.Components.StiText();
            this.Text83.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.8, 0, 2.8, 0.5);
            this.Text83.Guid = "1656c4398843484795351eba15e608c2";
            this.Text83.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text83.Name = "Text83";
            this.Text83.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text83__GetValue);
            this.Text83.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text83.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text83.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text83.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text83.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text83.Indicator = null;
            this.Text83.Interaction = null;
            this.Text83.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text83.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 192, 0, 0));
            this.Text83.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text84
            // 
            this.Text84 = new Stimulsoft.Report.Components.StiText();
            this.Text84.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.5, 0, 1.7, 0.5);
            this.Text84.Guid = "420b92d06dd74b508760efdff5dd0b43";
            this.Text84.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text84.Name = "Text84";
            this.Text84.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text84__GetValue);
            this.Text84.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text84.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text84.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text84.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text84.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text84.Indicator = null;
            this.Text84.Interaction = null;
            this.Text84.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text84.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text84.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text85
            // 
            this.Text85 = new Stimulsoft.Report.Components.StiText();
            this.Text85.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 0.6, 1.6, 0.2);
            this.Text85.Guid = "f69666dadd834fd7bf5a031b7a2a7ad7";
            this.Text85.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text85.Name = "Text85";
            this.Text85.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text85__GetValue);
            this.Text85.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text85.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text85.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text85.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text85.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text85.Indicator = null;
            this.Text85.Interaction = null;
            this.Text85.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text85.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text85.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            this.InitializeComponent2();
        }
        
        public void InitializeComponent2()
        {
            // 
            // Text86
            // 
            this.Text86 = new Stimulsoft.Report.Components.StiText();
            this.Text86.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 1, 1.6, 0.2);
            this.Text86.Guid = "13111494ca2a4c868d3bd23edecd0be6";
            this.Text86.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text86.Name = "Text86";
            this.Text86.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text86__GetValue);
            this.Text86.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text86.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text86.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text86.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text86.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text86.Indicator = null;
            this.Text86.Interaction = null;
            this.Text86.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text86.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text86.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text87
            // 
            this.Text87 = new Stimulsoft.Report.Components.StiText();
            this.Text87.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 1.4, 1.6, 0.2);
            this.Text87.Guid = "17a63730b15d4af982fae58645029630";
            this.Text87.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text87.Name = "Text87";
            this.Text87.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text87__GetValue);
            this.Text87.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text87.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text87.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text87.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text87.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text87.Indicator = null;
            this.Text87.Interaction = null;
            this.Text87.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text87.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text87.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text88
            // 
            this.Text88 = new Stimulsoft.Report.Components.StiText();
            this.Text88.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 1.8, 1.6, 0.2);
            this.Text88.Guid = "32d7d3c409234b68860782a35366dc56";
            this.Text88.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text88.Name = "Text88";
            this.Text88.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text88__GetValue);
            this.Text88.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text88.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text88.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text88.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text88.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text88.Indicator = null;
            this.Text88.Interaction = null;
            this.Text88.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text88.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text88.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text89
            // 
            this.Text89 = new Stimulsoft.Report.Components.StiText();
            this.Text89.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 2.2, 1.6, 0.2);
            this.Text89.Guid = "2b1eea1b48bb4658a58123be5b8ea3e8";
            this.Text89.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text89.Name = "Text89";
            this.Text89.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text89__GetValue);
            this.Text89.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text89.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text89.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text89.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text89.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text89.Indicator = null;
            this.Text89.Interaction = null;
            this.Text89.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text89.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text89.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text90
            // 
            this.Text90 = new Stimulsoft.Report.Components.StiText();
            this.Text90.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 2.6, 1.6, 0.2);
            this.Text90.Guid = "9f087d9c097f42abb91eff01370850f9";
            this.Text90.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text90.Name = "Text90";
            this.Text90.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text90__GetValue);
            this.Text90.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text90.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text90.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text90.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text90.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text90.Indicator = null;
            this.Text90.Interaction = null;
            this.Text90.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text90.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text90.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text91
            // 
            this.Text91 = new Stimulsoft.Report.Components.StiText();
            this.Text91.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 3, 1.6, 0.2);
            this.Text91.Guid = "ece4cf8f86f849bd94e6c16e1a1d7e3a";
            this.Text91.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text91.Name = "Text91";
            this.Text91.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text91__GetValue);
            this.Text91.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text91.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text91.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text91.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text91.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text91.Indicator = null;
            this.Text91.Interaction = null;
            this.Text91.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text91.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text91.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text101
            // 
            this.Text101 = new Stimulsoft.Report.Components.StiText();
            this.Text101.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.4, 0.6, 1.9, 0.2);
            this.Text101.Guid = "2a592b918bea4b359144a097fa2dc942";
            this.Text101.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text101.Name = "Text101";
            this.Text101.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text101__GetValue);
            this.Text101.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text101.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text101.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text101.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text101.Indicator = null;
            this.Text101.Interaction = null;
            this.Text101.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text101.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text101.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text101.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text102
            // 
            this.Text102 = new Stimulsoft.Report.Components.StiText();
            this.Text102.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.4, 1, 1.9, 0.2);
            this.Text102.Guid = "bd451d5ca253411eb6346d0ba63aeb50";
            this.Text102.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text102.Name = "Text102";
            this.Text102.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text102__GetValue);
            this.Text102.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text102.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text102.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text102.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text102.Indicator = null;
            this.Text102.Interaction = null;
            this.Text102.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text102.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text102.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text102.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text103
            // 
            this.Text103 = new Stimulsoft.Report.Components.StiText();
            this.Text103.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.4, 1.4, 1.9, 0.2);
            this.Text103.Guid = "3db88bd16c6b43bca8fd584d676d5e45";
            this.Text103.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text103.Name = "Text103";
            this.Text103.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text103__GetValue);
            this.Text103.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text103.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text103.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text103.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text103.Indicator = null;
            this.Text103.Interaction = null;
            this.Text103.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text103.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text103.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text103.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text104
            // 
            this.Text104 = new Stimulsoft.Report.Components.StiText();
            this.Text104.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.4, 2.2, 1.9, 0.2);
            this.Text104.Guid = "f95db7e1b8be417389592c5d31a78692";
            this.Text104.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text104.Name = "Text104";
            this.Text104.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text104__GetValue);
            this.Text104.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text104.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text104.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text104.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text104.Indicator = null;
            this.Text104.Interaction = null;
            this.Text104.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text104.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text104.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text104.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text105
            // 
            this.Text105 = new Stimulsoft.Report.Components.StiText();
            this.Text105.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.4, 1.8, 1.9, 0.2);
            this.Text105.Guid = "57f86799ba0e4e2ba4c69a791747735e";
            this.Text105.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text105.Name = "Text105";
            this.Text105.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text105__GetValue);
            this.Text105.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text105.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text105.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text105.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text105.Indicator = null;
            this.Text105.Interaction = null;
            this.Text105.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text105.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text105.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text105.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text106
            // 
            this.Text106 = new Stimulsoft.Report.Components.StiText();
            this.Text106.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.4, 2.6, 1.9, 0.2);
            this.Text106.Guid = "c1f09874b7124875a91d72276802845a";
            this.Text106.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text106.Name = "Text106";
            this.Text106.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text106__GetValue);
            this.Text106.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text106.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text106.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text106.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text106.Indicator = null;
            this.Text106.Interaction = null;
            this.Text106.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text106.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text106.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text106.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text92
            // 
            this.Text92 = new Stimulsoft.Report.Components.StiText();
            this.Text92.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.3, 3.5, 4.1, 0.2);
            this.Text92.Guid = "025bff0210914f278485bfa163ed0084";
            this.Text92.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text92.Name = "Text92";
            this.Text92.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text92__GetValue);
            this.Text92.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text92.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text92.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text92.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text92.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text92.Indicator = null;
            this.Text92.Interaction = null;
            this.Text92.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text92.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text92.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text107
            // 
            this.Text107 = new Stimulsoft.Report.Components.StiText();
            this.Text107.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.3, 3, 2, 0.2);
            this.Text107.Guid = "346c3f2a334b40b989959be124a4416c";
            this.Text107.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text107.Name = "Text107";
            this.Text107.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text107__GetValue);
            this.Text107.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text107.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 2, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text107.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text107.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text107.Indicator = null;
            this.Text107.Interaction = null;
            this.Text107.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text107.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 192, 0, 0));
            this.Text107.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text107.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text93
            // 
            this.Text93 = new Stimulsoft.Report.Components.StiText();
            this.Text93.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.3, 3.4, 2, 0.3);
            this.Text93.Guid = "5d49e11670504574bca2eebd9b53b42a";
            this.Text93.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text93.Name = "Text93";
            this.Text93.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text93__GetValue);
            this.Text93.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text93.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 2, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text93.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text93.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text93.Indicator = null;
            this.Text93.Interaction = null;
            this.Text93.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text93.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 192, 0, 0));
            this.Text93.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text93.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text94
            // 
            this.Text94 = new Stimulsoft.Report.Components.StiText();
            this.Text94.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.4, 0.6, 1.9, 0.2);
            this.Text94.Guid = "1ea085f78be44da0ab61a3531befab06";
            this.Text94.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text94.Name = "Text94";
            this.Text94.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text94__GetValue);
            this.Text94.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text94.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text94.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text94.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text94.Indicator = null;
            this.Text94.Interaction = null;
            this.Text94.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text94.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text94.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text94.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text95
            // 
            this.Text95 = new Stimulsoft.Report.Components.StiText();
            this.Text95.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.4, 1, 1.9, 0.2);
            this.Text95.Guid = "d968d936413041a79d03cffbdc2b4eb1";
            this.Text95.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text95.Name = "Text95";
            this.Text95.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text95__GetValue);
            this.Text95.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text95.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text95.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text95.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text95.Indicator = null;
            this.Text95.Interaction = null;
            this.Text95.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text95.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text95.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text95.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text96
            // 
            this.Text96 = new Stimulsoft.Report.Components.StiText();
            this.Text96.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.4, 1.4, 1.9, 0.2);
            this.Text96.Guid = "f90161c336634dfcad49da764eab37dc";
            this.Text96.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text96.Name = "Text96";
            this.Text96.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text96__GetValue);
            this.Text96.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text96.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text96.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text96.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text96.Indicator = null;
            this.Text96.Interaction = null;
            this.Text96.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text96.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text96.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text96.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text97
            // 
            this.Text97 = new Stimulsoft.Report.Components.StiText();
            this.Text97.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.4, 2.2, 1.9, 0.2);
            this.Text97.Guid = "e4afb2eae9ee427285c5b75f107c363e";
            this.Text97.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text97.Name = "Text97";
            this.Text97.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text97__GetValue);
            this.Text97.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text97.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text97.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text97.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text97.Indicator = null;
            this.Text97.Interaction = null;
            this.Text97.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text97.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text97.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text97.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text98
            // 
            this.Text98 = new Stimulsoft.Report.Components.StiText();
            this.Text98.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.4, 1.8, 1.9, 0.2);
            this.Text98.Guid = "5b942f2f7e2c41b2a07a16225b7c4f28";
            this.Text98.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text98.Name = "Text98";
            this.Text98.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text98__GetValue);
            this.Text98.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text98.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text98.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text98.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text98.Indicator = null;
            this.Text98.Interaction = null;
            this.Text98.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text98.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text98.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text98.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text99
            // 
            this.Text99 = new Stimulsoft.Report.Components.StiText();
            this.Text99.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.4, 2.6, 1.9, 0.2);
            this.Text99.Guid = "946344e2b6c848f9bdea9579ee3cebaa";
            this.Text99.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text99.Name = "Text99";
            this.Text99.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text99__GetValue);
            this.Text99.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text99.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text99.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text99.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text99.Indicator = null;
            this.Text99.Interaction = null;
            this.Text99.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text99.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text99.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text99.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text100
            // 
            this.Text100 = new Stimulsoft.Report.Components.StiText();
            this.Text100.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.4, 3, 1.9, 0.2);
            this.Text100.Guid = "5e5da093ae954f6abb16f6981ce06ed6";
            this.Text100.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text100.Name = "Text100";
            this.Text100.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text100__GetValue);
            this.Text100.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text100.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 2, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text100.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text100.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text100.Indicator = null;
            this.Text100.Interaction = null;
            this.Text100.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text100.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text100.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text100.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // HorizontalLine17
            // 
            this.HorizontalLine17 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine17.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.5, 7.5, 0.01);
            this.HorizontalLine17.Color = System.Drawing.Color.FromArgb(255, 81, 104, 36);
            this.HorizontalLine17.Guid = "1b3f30d18cfe41f8b1eb82579f32f0d3";
            this.HorizontalLine17.Name = "HorizontalLine17";
            this.HorizontalLine17.Size = 2F;
            this.HorizontalLine17.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine17.Interaction = null;
            this.HorizontalLine17.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine18
            // 
            this.HorizontalLine18 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine18.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.9, 7.5, 0.01);
            this.HorizontalLine18.Color = System.Drawing.Color.DarkGray;
            this.HorizontalLine18.Guid = "68a5e31295a643aabf2633ae214d82a1";
            this.HorizontalLine18.Name = "HorizontalLine18";
            this.HorizontalLine18.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine18.Interaction = null;
            this.HorizontalLine18.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine19
            // 
            this.HorizontalLine19 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine19.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 1.3, 7.5, 0.01);
            this.HorizontalLine19.Color = System.Drawing.Color.DarkGray;
            this.HorizontalLine19.Guid = "9be6637344724670b02905f3b2ceef69";
            this.HorizontalLine19.Name = "HorizontalLine19";
            this.HorizontalLine19.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine19.Interaction = null;
            this.HorizontalLine19.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine20
            // 
            this.HorizontalLine20 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine20.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 1.7, 7.5, 0.01);
            this.HorizontalLine20.Color = System.Drawing.Color.DarkGray;
            this.HorizontalLine20.Guid = "3a05aa224eb74afab9182f7e3a4d9a58";
            this.HorizontalLine20.Name = "HorizontalLine20";
            this.HorizontalLine20.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine20.Interaction = null;
            this.HorizontalLine20.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine21
            // 
            this.HorizontalLine21 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine21.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 2.1, 7.5, 0.01);
            this.HorizontalLine21.Color = System.Drawing.Color.DarkGray;
            this.HorizontalLine21.Guid = "49cd4c9d14f941fe9d9746b72c3863c9";
            this.HorizontalLine21.Name = "HorizontalLine21";
            this.HorizontalLine21.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine21.Interaction = null;
            this.HorizontalLine21.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine22
            // 
            this.HorizontalLine22 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine22.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 2.5, 7.5, 0.01);
            this.HorizontalLine22.Color = System.Drawing.Color.DarkGray;
            this.HorizontalLine22.Guid = "d632a0ec7c3b41c8abea2d4a846bc68f";
            this.HorizontalLine22.Name = "HorizontalLine22";
            this.HorizontalLine22.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine22.Interaction = null;
            this.HorizontalLine22.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine23
            // 
            this.HorizontalLine23 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine23.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 2.9, 7.5, 0.01);
            this.HorizontalLine23.Color = System.Drawing.Color.DarkGray;
            this.HorizontalLine23.Guid = "cf1ac5721082473d81a961ddda73231d";
            this.HorizontalLine23.Name = "HorizontalLine23";
            this.HorizontalLine23.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine23.Interaction = null;
            this.HorizontalLine23.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine24
            // 
            this.HorizontalLine24 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine24.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 3.3, 7.5, 0.01);
            this.HorizontalLine24.Color = System.Drawing.Color.DarkGray;
            this.HorizontalLine24.Guid = "eaabb4b14a244fde870c281626a3e42d";
            this.HorizontalLine24.Name = "HorizontalLine24";
            this.HorizontalLine24.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine24.Interaction = null;
            this.HorizontalLine24.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // StartPointPrimitive59
            // 
            this.StartPointPrimitive59 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive59.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.8, 0.1, 0, 0);
            this.StartPointPrimitive59.Guid = "9243131498e84dc5985b48c4053291f8";
            this.StartPointPrimitive59.Name = "StartPointPrimitive59";
            this.StartPointPrimitive59.ReferenceToGuid = "0943070b136e424bb165a45d58341196";
            this.StartPointPrimitive59.Interaction = null;
            // 
            // StartPointPrimitive60
            // 
            this.StartPointPrimitive60 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive60.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.5, 0.1, 0, 0);
            this.StartPointPrimitive60.Guid = "dbd76e6694b04a158d0ca0c814bf0844";
            this.StartPointPrimitive60.Name = "StartPointPrimitive60";
            this.StartPointPrimitive60.ReferenceToGuid = "0109a5544f5c4ed1b9a17feb6dadca44";
            this.StartPointPrimitive60.Interaction = null;
            // 
            // StartPointPrimitive61
            // 
            this.StartPointPrimitive61 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive61.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.7, 0.1, 0, 0);
            this.StartPointPrimitive61.Guid = "528e76eb0ee24ae68b4c19b7a1424995";
            this.StartPointPrimitive61.Name = "StartPointPrimitive61";
            this.StartPointPrimitive61.ReferenceToGuid = "c4adc3e1b67b40a1812803a282203438";
            this.StartPointPrimitive61.Interaction = null;
            // 
            // StartPointPrimitive62
            // 
            this.StartPointPrimitive62 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive62.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.7, 0.1, 0, 0);
            this.StartPointPrimitive62.Guid = "106da6d57e634758b6ed7e8b31d00987";
            this.StartPointPrimitive62.Name = "StartPointPrimitive62";
            this.StartPointPrimitive62.ReferenceToGuid = "c5315537de2742ff86d36a8e95a3b6bc";
            this.StartPointPrimitive62.Interaction = null;
            // 
            // StartPointPrimitive31
            // 
            this.StartPointPrimitive31 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive31.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.7, 0, 0, 0);
            this.StartPointPrimitive31.Guid = "f660737788b842f8b8b2bbc809d31836";
            this.StartPointPrimitive31.Name = "StartPointPrimitive31";
            this.StartPointPrimitive31.ReferenceToGuid = "0c53e83333414df9a6c02f4166fef557";
            this.StartPointPrimitive31.Interaction = null;
            // 
            // EndPointPrimitive31
            // 
            this.EndPointPrimitive31 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive31.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.7, 3.3, 0, 0);
            this.EndPointPrimitive31.Guid = "41d3ba01239f4703a9f7a71c09bc5c4e";
            this.EndPointPrimitive31.Name = "EndPointPrimitive31";
            this.EndPointPrimitive31.ReferenceToGuid = "0c53e83333414df9a6c02f4166fef557";
            this.EndPointPrimitive31.Interaction = null;
            // 
            // StartPointPrimitive32
            // 
            this.StartPointPrimitive32 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive32.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 0, 0, 0);
            this.StartPointPrimitive32.Guid = "dc5d6a64cd524eb380a896566322f168";
            this.StartPointPrimitive32.Name = "StartPointPrimitive32";
            this.StartPointPrimitive32.ReferenceToGuid = "4f73fc6e933149ce9f57ef7f51a5bab7";
            this.StartPointPrimitive32.Interaction = null;
            // 
            // EndPointPrimitive30
            // 
            this.EndPointPrimitive30 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive30.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 3.3, 0, 0);
            this.EndPointPrimitive30.Guid = "db4a6266d8a04b8999c118210b0ee15d";
            this.EndPointPrimitive30.Name = "EndPointPrimitive30";
            this.EndPointPrimitive30.ReferenceToGuid = "4f73fc6e933149ce9f57ef7f51a5bab7";
            this.EndPointPrimitive30.Interaction = null;
            // 
            // StartPointPrimitive55
            // 
            this.StartPointPrimitive55 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive55.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.7, 0, 0, 0);
            this.StartPointPrimitive55.Name = "StartPointPrimitive55";
            this.StartPointPrimitive55.ReferenceToGuid = "0c53e83333414df9a6c02f4166fef557";
            this.StartPointPrimitive55.Guid = null;
            this.StartPointPrimitive55.Interaction = null;
            // 
            // EndPointPrimitive51
            // 
            this.EndPointPrimitive51 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive51.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.7, 3.3, 0, 0);
            this.EndPointPrimitive51.Name = "EndPointPrimitive51";
            this.EndPointPrimitive51.ReferenceToGuid = "0c53e83333414df9a6c02f4166fef557";
            this.EndPointPrimitive51.Guid = null;
            this.EndPointPrimitive51.Interaction = null;
            // 
            // StartPointPrimitive56
            // 
            this.StartPointPrimitive56 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive56.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 0, 0, 0);
            this.StartPointPrimitive56.Name = "StartPointPrimitive56";
            this.StartPointPrimitive56.ReferenceToGuid = "4f73fc6e933149ce9f57ef7f51a5bab7";
            this.StartPointPrimitive56.Guid = null;
            this.StartPointPrimitive56.Interaction = null;
            // 
            // EndPointPrimitive52
            // 
            this.EndPointPrimitive52 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive52.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 3.3, 0, 0);
            this.EndPointPrimitive52.Name = "EndPointPrimitive52";
            this.EndPointPrimitive52.ReferenceToGuid = "4f73fc6e933149ce9f57ef7f51a5bab7";
            this.EndPointPrimitive52.Guid = null;
            this.EndPointPrimitive52.Interaction = null;
            this.Panel6.Interaction = null;
            // 
            // ReportTitleBand2
            // 
            this.ReportTitleBand2 = new Stimulsoft.Report.Components.StiReportTitleBand();
            this.ReportTitleBand2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.2, 7.72, 0.7);
            this.ReportTitleBand2.Guid = "b60594cb8fe4cc69fad155c8c979b8ee";
            this.ReportTitleBand2.Name = "ReportTitleBand2";
            this.ReportTitleBand2.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.ReportTitleBand2.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // Panel2
            // 
            this.Panel2 = new Stimulsoft.Report.Components.StiPanel();
            this.Panel2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0, 7.7, 0.7);
            this.Panel2.Guid = "851d049ab4370bd84ee855c8c979886e";
            this.Panel2.Name = "Panel2";
            this.Panel2.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.DashDotDot, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Panel2.Brush = new Stimulsoft.Base.Drawing.StiEmptyBrush();
            // 
            // Text2
            // 
            this.Text2 = new Stimulsoft.Report.Components.StiText();
            this.Text2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.4, 0.2, 2.6, 0.3);
            this.Text2.Guid = "4d4a609c752f4e31a29e55c8c979bf76";
            this.Text2.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text2.Name = "Text2";
            this.Text2.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text2__GetValue);
            this.Text2.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text2.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text2.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text2.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text2.Font = new System.Drawing.Font("B Nazanin", 14F, System.Drawing.FontStyle.Bold);
            this.Text2.Indicator = null;
            this.Text2.Interaction = null;
            this.Text2.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text2.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 112, 192));
            this.Text2.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text34
            // 
            this.Text34 = new Stimulsoft.Report.Components.StiText();
            this.Text34.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0, 2, 0.4);
            this.Text34.Name = "Text34";
            this.Text34.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text34__GetValue);
            this.Text34.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text34.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.Right, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.None, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text34.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text34.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text34.Guid = null;
            this.Text34.Indicator = null;
            this.Text34.Interaction = null;
            this.Text34.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text34.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text34.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            this.Panel2.Interaction = null;
            this.ReportTitleBand2.Interaction = null;
            // 
            // VerticalLine1
            // 
            this.VerticalLine1 = new Stimulsoft.Report.Components.StiVerticalLinePrimitive();
            this.VerticalLine1.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.9, 1, 0.01, 4.1);
            this.VerticalLine1.Color = System.Drawing.Color.FromArgb(255, 81, 104, 36);
            this.VerticalLine1.Guid = "bc31bb40bb6046478b072e9f7d25b4e0";
            this.VerticalLine1.Name = "VerticalLine1";
            this.VerticalLine1.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.VerticalLine1.Interaction = null;
            this.VerticalLine1.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // VerticalLine2
            // 
            this.VerticalLine2 = new Stimulsoft.Report.Components.StiVerticalLinePrimitive();
            this.VerticalLine2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.6, 1, 0.01, 4.1);
            this.VerticalLine2.Color = System.Drawing.Color.FromArgb(255, 81, 104, 36);
            this.VerticalLine2.Guid = "c3cd63edc0e74e7e9851e40598aa4203";
            this.VerticalLine2.Name = "VerticalLine2";
            this.VerticalLine2.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.VerticalLine2.Interaction = null;
            this.VerticalLine2.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // VerticalLine3
            // 
            this.VerticalLine3 = new Stimulsoft.Report.Components.StiVerticalLinePrimitive();
            this.VerticalLine3.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 1, 0.01, 4.1);
            this.VerticalLine3.Color = System.Drawing.Color.FromArgb(255, 81, 104, 36);
            this.VerticalLine3.Guid = "7e66c1508f684b68b904e7de8f1641ac";
            this.VerticalLine3.Name = "VerticalLine3";
            this.VerticalLine3.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.VerticalLine3.Interaction = null;
            this.VerticalLine3.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // VerticalLine4
            // 
            this.VerticalLine4 = new Stimulsoft.Report.Components.StiVerticalLinePrimitive();
            this.VerticalLine4.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.8, 1, 0.01, 4.1);
            this.VerticalLine4.Color = System.Drawing.Color.FromArgb(255, 81, 104, 36);
            this.VerticalLine4.Guid = "6722d6104787442fb4a9e84f6bbccc1d";
            this.VerticalLine4.Name = "VerticalLine4";
            this.VerticalLine4.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.VerticalLine4.Interaction = null;
            this.VerticalLine4.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // VerticalLine21
            // 
            this.VerticalLine21 = new Stimulsoft.Report.Components.StiVerticalLinePrimitive();
            this.VerticalLine21.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.8, 5.6, 0.01, 3.3);
            this.VerticalLine21.Color = System.Drawing.Color.FromArgb(255, 81, 104, 36);
            this.VerticalLine21.Guid = "0c53e83333414df9a6c02f4166fef557";
            this.VerticalLine21.Name = "VerticalLine21";
            this.VerticalLine21.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.VerticalLine21.Interaction = null;
            this.VerticalLine21.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // VerticalLine22
            // 
            this.VerticalLine22 = new Stimulsoft.Report.Components.StiVerticalLinePrimitive();
            this.VerticalLine22.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.9, 5.6, 0.01, 3.3);
            this.VerticalLine22.Color = System.Drawing.Color.FromArgb(255, 81, 104, 36);
            this.VerticalLine22.Guid = "4f73fc6e933149ce9f57ef7f51a5bab7";
            this.VerticalLine22.Name = "VerticalLine22";
            this.VerticalLine22.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.VerticalLine22.Interaction = null;
            this.VerticalLine22.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.Page1.ExcelSheetValue = null;
            this.Page1.Interaction = null;
            this.Page1.Margins = new Stimulsoft.Report.Components.StiMargins(0.39, 0.39, 0.39, 0.39);
            this.Page1_Watermark = new Stimulsoft.Report.Components.StiWatermark();
            this.Page1_Watermark.Font = new System.Drawing.Font("Arial", 100F);
            this.Page1_Watermark.Image = null;
            this.Page1_Watermark.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(50, 0, 0, 0));
            // 
            // Page2
            // 
            this.Page2 = new Stimulsoft.Report.Components.StiPage();
            this.Page2.Guid = "73f100f50c8240dfa8a7c364ac61aff1";
            this.Page2.Name = "Page2";
            this.Page2.PageHeight = 11;
            this.Page2.PageWidth = 8.5;
            this.Page2.PaperSize = System.Drawing.Printing.PaperKind.Letter;
            this.Page2.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 2, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Page2.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // PageFooter1
            // 
            this.PageFooter1 = new Stimulsoft.Report.Components.StiPageFooterBand();
            this.PageFooter1.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 9.82, 7.72, 0.4);
            this.PageFooter1.Guid = "11a085f5371d458db94af4a13051b0a3";
            this.PageFooter1.Name = "PageFooter1";
            this.PageFooter1.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.PageFooter1.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // Text76
            // 
            this.Text76 = new Stimulsoft.Report.Components.StiText();
            this.Text76.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.8, 0.1, 2.9, 0.3);
            this.Text76.ComponentStyle = "Collection_Page_Footer";
            this.Text76.Guid = "5d9a8f483c5d4205a5f667fd60edd26c";
            this.Text76.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text76.Name = "Text76";
            this.Text76.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text76__GetValue);
            this.Text76.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text76.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text76.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text76.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text76.Font = new System.Drawing.Font("B Nazanin", 11F, System.Drawing.FontStyle.Bold);
            this.Text76.Indicator = null;
            this.Text76.Interaction = null;
            this.Text76.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text76.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 112, 48, 160));
            this.Text76.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text77
            // 
            this.Text77 = new Stimulsoft.Report.Components.StiText();
            this.Text77.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.2, 3.4, 0.3);
            this.Text77.ComponentStyle = "Collection_Page_Footer";
            this.Text77.Guid = "035b8156d63c4fb4a9b42a2b95089c80";
            this.Text77.Name = "Text77";
            this.Text77.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text77__GetValue);
            this.Text77.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text77.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text77.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text77.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text77.Indicator = null;
            this.Text77.Interaction = null;
            this.Text77.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text77.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text77.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            this.PageFooter1.Interaction = null;
            // 
            // Text78
            // 
            this.Text78 = new Stimulsoft.Report.Components.StiText();
            this.Text78.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(8.6, 3.5, 1, 0.3);
            this.Text78.Guid = "70889c27d06d4bc8849054761c192fd5";
            this.Text78.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text78.Name = "Text78";
            this.Text78.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text78__GetValue);
            this.Text78.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text78.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.All, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text78.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 181, 204, 136));
            this.Text78.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text78.Indicator = null;
            this.Text78.Interaction = null;
            this.Text78.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text78.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text78.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text79
            // 
            this.Text79 = new Stimulsoft.Report.Components.StiText();
            this.Text79.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(9.6, 3.5, 1, 0.3);
            this.Text79.Guid = "b9d84c2efa234e27972eef5ebc1ba4d8";
            this.Text79.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text79.Name = "Text79";
            this.Text79.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text79__GetValue);
            this.Text79.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text79.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.All, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text79.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 181, 204, 136));
            this.Text79.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text79.Indicator = null;
            this.Text79.Interaction = null;
            this.Text79.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text79.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text79.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text80
            // 
            this.Text80 = new Stimulsoft.Report.Components.StiText();
            this.Text80.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(8.6, 4.2, 1, 0.3);
            this.Text80.Guid = "20d0ae866df94020b182fe65b8c55346";
            this.Text80.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text80.Name = "Text80";
            this.Text80.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text80__GetValue);
            this.Text80.Type = Stimulsoft.Report.Components.StiSystemTextType.DataColumn;
            this.Text80.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text80.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text80.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text80.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text80.Indicator = null;
            this.Text80.Interaction = null;
            this.Text80.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text80.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text80.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text81
            // 
            this.Text81 = new Stimulsoft.Report.Components.StiText();
            this.Text81.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(9.6, 4.2, 1, 0.3);
            this.Text81.Guid = "105744559423449d8959ba214e9988fb";
            this.Text81.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text81.Name = "Text81";
            this.Text81.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text81__GetValue);
            this.Text81.Type = Stimulsoft.Report.Components.StiSystemTextType.DataColumn;
            this.Text81.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text81.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text81.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text81.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text81.Indicator = null;
            this.Text81.Interaction = null;
            this.Text81.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text81.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text81.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Panel7
            // 
            this.Panel7 = new Stimulsoft.Report.Components.StiPanel();
            this.Panel7.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.1, 1.2, 7.6, 4.2);
            this.Panel7.Guid = "a8be33adfb284778ae84d309b8b6172d";
            this.Panel7.Name = "Panel7";
            this.Panel7.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.All, System.Drawing.Color.FromArgb(255, 191, 191, 191), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, true, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Panel7.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // Text108
            // 
            this.Text108 = new Stimulsoft.Report.Components.StiText();
            this.Text108.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.4, 0.1, 0.6, 0.2);
            this.Text108.Guid = "a5a90f61a10f4095b2108d3c6efd487b";
            this.Text108.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text108.Name = "Text108";
            this.Text108.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text108__GetValue);
            this.Text108.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text108.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text108.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text108.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text108.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text108.Indicator = null;
            this.Text108.Interaction = null;
            this.Text108.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text108.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text108.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text110
            // 
            this.Text110 = new Stimulsoft.Report.Components.StiText();
            this.Text110.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.5, 0, 1.7, 0.5);
            this.Text110.Guid = "309cc4b345d24df48d1ac5ff36d4008a";
            this.Text110.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text110.Name = "Text110";
            this.Text110.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text110__GetValue);
            this.Text110.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text110.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text110.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text110.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text110.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text110.Indicator = null;
            this.Text110.Interaction = null;
            this.Text110.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text110.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text110.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text111
            // 
            this.Text111 = new Stimulsoft.Report.Components.StiText();
            this.Text111.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 0.6, 1.6, 0.2);
            this.Text111.Guid = "23bc18b42b8f4dbb9c2ad75455f5311b";
            this.Text111.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text111.Name = "Text111";
            this.Text111.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text111__GetValue);
            this.Text111.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text111.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text111.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text111.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text111.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text111.Indicator = null;
            this.Text111.Interaction = null;
            this.Text111.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text111.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text111.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text112
            // 
            this.Text112 = new Stimulsoft.Report.Components.StiText();
            this.Text112.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 1, 1.6, 0.2);
            this.Text112.Guid = "1fb28da5c13b459d9ca953afb21a9ddb";
            this.Text112.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text112.Name = "Text112";
            this.Text112.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text112__GetValue);
            this.Text112.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text112.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text112.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text112.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text112.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text112.Indicator = null;
            this.Text112.Interaction = null;
            this.Text112.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text112.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text112.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text113
            // 
            this.Text113 = new Stimulsoft.Report.Components.StiText();
            this.Text113.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 1.4, 1.6, 0.2);
            this.Text113.Guid = "8367daf401aa483bb98f673d4eb2a50b";
            this.Text113.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text113.Name = "Text113";
            this.Text113.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text113__GetValue);
            this.Text113.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text113.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text113.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text113.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text113.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text113.Indicator = null;
            this.Text113.Interaction = null;
            this.Text113.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text113.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text113.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text114
            // 
            this.Text114 = new Stimulsoft.Report.Components.StiText();
            this.Text114.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 1.8, 1.6, 0.2);
            this.Text114.Guid = "53040c0717274597a337f442fdb92c0b";
            this.Text114.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text114.Name = "Text114";
            this.Text114.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text114__GetValue);
            this.Text114.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text114.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text114.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text114.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text114.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text114.Indicator = null;
            this.Text114.Interaction = null;
            this.Text114.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text114.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.InitializeComponent3();
        }
        
        public void InitializeComponent3()
        {
            this.Text114.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text115
            // 
            this.Text115 = new Stimulsoft.Report.Components.StiText();
            this.Text115.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 2.2, 1.6, 0.2);
            this.Text115.Guid = "1409900cbe5a460cb7905e5a593e2f01";
            this.Text115.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text115.Name = "Text115";
            this.Text115.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text115__GetValue);
            this.Text115.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text115.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text115.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text115.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text115.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text115.Indicator = null;
            this.Text115.Interaction = null;
            this.Text115.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text115.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text115.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text116
            // 
            this.Text116 = new Stimulsoft.Report.Components.StiText();
            this.Text116.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 2.6, 1.6, 0.2);
            this.Text116.Guid = "f1280f058f624835a001e1c963910c73";
            this.Text116.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text116.Name = "Text116";
            this.Text116.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text116__GetValue);
            this.Text116.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text116.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text116.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text116.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text116.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text116.Indicator = null;
            this.Text116.Interaction = null;
            this.Text116.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text116.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text116.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text117
            // 
            this.Text117 = new Stimulsoft.Report.Components.StiText();
            this.Text117.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 3, 1.6, 0.2);
            this.Text117.Guid = "cc2e28f353a94b6190c2215bc46ec4f2";
            this.Text117.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text117.Name = "Text117";
            this.Text117.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text117__GetValue);
            this.Text117.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text117.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text117.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text117.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text117.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text117.Indicator = null;
            this.Text117.Interaction = null;
            this.Text117.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text117.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text117.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text124
            // 
            this.Text124 = new Stimulsoft.Report.Components.StiText();
            this.Text124.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.3, 3.9, 4.1, 0.2);
            this.Text124.Guid = "91258e69e6824780a85c53bcded24088";
            this.Text124.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text124.Name = "Text124";
            this.Text124.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text124__GetValue);
            this.Text124.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text124.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text124.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text124.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text124.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text124.Indicator = null;
            this.Text124.Interaction = null;
            this.Text124.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text124.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text124.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text118
            // 
            this.Text118 = new Stimulsoft.Report.Components.StiText();
            this.Text118.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.3, 0.6, 1.8, 0.2);
            this.Text118.Guid = "c1faeb14be634a6a907311398c132806";
            this.Text118.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text118.Name = "Text118";
            this.Text118.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text118__GetValue);
            this.Text118.Type = Stimulsoft.Report.Components.StiSystemTextType.DataColumn;
            this.Text118.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text118.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text118.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text118.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text118.Indicator = null;
            this.Text118.Interaction = null;
            this.Text118.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text118.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text118.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text118.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text119
            // 
            this.Text119 = new Stimulsoft.Report.Components.StiText();
            this.Text119.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.3, 1, 1.8, 0.2);
            this.Text119.Guid = "db5ff5ab52734e03be44383d1b87bac8";
            this.Text119.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text119.Name = "Text119";
            this.Text119.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text119__GetValue);
            this.Text119.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text119.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text119.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text119.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text119.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text119.Indicator = null;
            this.Text119.Interaction = null;
            this.Text119.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text119.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text119.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text119.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text120
            // 
            this.Text120 = new Stimulsoft.Report.Components.StiText();
            this.Text120.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.3, 1.4, 1.8, 0.2);
            this.Text120.Guid = "58095a48a6eb4a7995785002d4d5b150";
            this.Text120.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text120.Name = "Text120";
            this.Text120.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text120__GetValue);
            this.Text120.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text120.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text120.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text120.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text120.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text120.Indicator = null;
            this.Text120.Interaction = null;
            this.Text120.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text120.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text120.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text120.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text121
            // 
            this.Text121 = new Stimulsoft.Report.Components.StiText();
            this.Text121.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.3, 1.8, 1.8, 0.2);
            this.Text121.Guid = "337f7ac709e44183984c6ca606216b50";
            this.Text121.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text121.Name = "Text121";
            this.Text121.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text121__GetValue);
            this.Text121.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text121.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text121.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text121.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text121.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text121.Indicator = null;
            this.Text121.Interaction = null;
            this.Text121.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text121.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text121.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text121.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text122
            // 
            this.Text122 = new Stimulsoft.Report.Components.StiText();
            this.Text122.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.3, 2.2, 1.8, 0.2);
            this.Text122.Guid = "7943a79535d841e2a126bc40b51bf67e";
            this.Text122.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text122.Name = "Text122";
            this.Text122.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text122__GetValue);
            this.Text122.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text122.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text122.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text122.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text122.Indicator = null;
            this.Text122.Interaction = null;
            this.Text122.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text122.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text122.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text122.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text123
            // 
            this.Text123 = new Stimulsoft.Report.Components.StiText();
            this.Text123.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.3, 2.6, 1.8, 0.2);
            this.Text123.Guid = "f695a81716714964b23d204a820c51f7";
            this.Text123.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text123.Name = "Text123";
            this.Text123.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text123__GetValue);
            this.Text123.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text123.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text123.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text123.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text123.Indicator = null;
            this.Text123.Interaction = null;
            this.Text123.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text123.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text123.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text123.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text125
            // 
            this.Text125 = new Stimulsoft.Report.Components.StiText();
            this.Text125.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.3, 3, 1.8, 0.2);
            this.Text125.Guid = "2291c340ebe94b0e8e5859db52f8413c";
            this.Text125.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text125.Name = "Text125";
            this.Text125.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text125__GetValue);
            this.Text125.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text125.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text125.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text125.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text125.Indicator = null;
            this.Text125.Interaction = null;
            this.Text125.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text125.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text125.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text125.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text126
            // 
            this.Text126 = new Stimulsoft.Report.Components.StiText();
            this.Text126.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.4, 0.6, 1.8, 0.2);
            this.Text126.Guid = "6c3ba70b4fef4590aa432fc851b01f0c";
            this.Text126.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text126.Name = "Text126";
            this.Text126.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text126__GetValue);
            this.Text126.Type = Stimulsoft.Report.Components.StiSystemTextType.DataColumn;
            this.Text126.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text126.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text126.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text126.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text126.Indicator = null;
            this.Text126.Interaction = null;
            this.Text126.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text126.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text126.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text126.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text127
            // 
            this.Text127 = new Stimulsoft.Report.Components.StiText();
            this.Text127.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.4, 1, 1.8, 0.2);
            this.Text127.Guid = "52aa62a6bf824525a86f4aadd5128f0b";
            this.Text127.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text127.Name = "Text127";
            this.Text127.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text127__GetValue);
            this.Text127.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text127.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text127.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text127.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text127.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text127.Indicator = null;
            this.Text127.Interaction = null;
            this.Text127.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text127.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text127.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text127.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text128
            // 
            this.Text128 = new Stimulsoft.Report.Components.StiText();
            this.Text128.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.4, 1.4, 1.8, 0.2);
            this.Text128.Guid = "7a80a365ff38434cb2507e519b126ab8";
            this.Text128.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text128.Name = "Text128";
            this.Text128.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text128__GetValue);
            this.Text128.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text128.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text128.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text128.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text128.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text128.Indicator = null;
            this.Text128.Interaction = null;
            this.Text128.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text128.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text128.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text128.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text129
            // 
            this.Text129 = new Stimulsoft.Report.Components.StiText();
            this.Text129.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.4, 1.8, 1.8, 0.2);
            this.Text129.Guid = "4710f081fcdb468ebb0f3e62d8a9947f";
            this.Text129.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text129.Name = "Text129";
            this.Text129.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text129__GetValue);
            this.Text129.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text129.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text129.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text129.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text129.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text129.Indicator = null;
            this.Text129.Interaction = null;
            this.Text129.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text129.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text129.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text129.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text130
            // 
            this.Text130 = new Stimulsoft.Report.Components.StiText();
            this.Text130.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.4, 2.2, 1.8, 0.2);
            this.Text130.Guid = "e419775208454ae3b8a67253897c5c95";
            this.Text130.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text130.Name = "Text130";
            this.Text130.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text130__GetValue);
            this.Text130.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text130.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text130.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text130.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text130.Indicator = null;
            this.Text130.Interaction = null;
            this.Text130.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text130.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text130.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text130.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text131
            // 
            this.Text131 = new Stimulsoft.Report.Components.StiText();
            this.Text131.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.4, 2.6, 1.8, 0.2);
            this.Text131.Guid = "d241a8ed8d5b408f9ea012ee35697c51";
            this.Text131.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text131.Name = "Text131";
            this.Text131.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text131__GetValue);
            this.Text131.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text131.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text131.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text131.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text131.Indicator = null;
            this.Text131.Interaction = null;
            this.Text131.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text131.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text131.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text131.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text132
            // 
            this.Text132 = new Stimulsoft.Report.Components.StiText();
            this.Text132.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 3.5, 1.6, 0.2);
            this.Text132.Guid = "62a9c8f919634bd1b04cea6a6d9dc2b1";
            this.Text132.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text132.Name = "Text132";
            this.Text132.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text132__GetValue);
            this.Text132.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text132.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text132.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text132.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text132.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text132.Indicator = null;
            this.Text132.Interaction = null;
            this.Text132.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text132.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text132.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text133
            // 
            this.Text133 = new Stimulsoft.Report.Components.StiText();
            this.Text133.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.3, 3.4, 1.8, 0.2);
            this.Text133.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text133.Name = "Text133";
            this.Text133.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text133__GetValue);
            this.Text133.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text133.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 2, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text133.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text133.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text133.Guid = null;
            this.Text133.Indicator = null;
            this.Text133.Interaction = null;
            this.Text133.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text133.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text133.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 2, ",", 3, true, false, " ");
            this.Text133.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text134
            // 
            this.Text134 = new Stimulsoft.Report.Components.StiText();
            this.Text134.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.3, 3, 1.9, 0.3);
            this.Text134.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text134.Name = "Text134";
            this.Text134.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text134__GetValue);
            this.Text134.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text134.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 2, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text134.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text134.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text134.Guid = null;
            this.Text134.Indicator = null;
            this.Text134.Interaction = null;
            this.Text134.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text134.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 192, 0, 0));
            this.Text134.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text134.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text135
            // 
            this.Text135 = new Stimulsoft.Report.Components.StiText();
            this.Text135.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.3, 3.8, 1.9, 0.3);
            this.Text135.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text135.Name = "Text135";
            this.Text135.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text135__GetValue);
            this.Text135.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text135.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 2, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text135.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text135.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text135.Guid = null;
            this.Text135.Indicator = null;
            this.Text135.Interaction = null;
            this.Text135.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text135.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 192, 0, 0));
            this.Text135.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text135.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text109
            // 
            this.Text109 = new Stimulsoft.Report.Components.StiText();
            this.Text109.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.8, 0, 2.8, 0.5);
            this.Text109.Guid = "d46dbc37f49b48a9a59061188e00fc15";
            this.Text109.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text109.Name = "Text109";
            this.Text109.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text109__GetValue);
            this.Text109.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text109.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text109.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text109.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text109.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text109.Indicator = null;
            this.Text109.Interaction = null;
            this.Text109.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text109.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 192, 0, 0));
            this.Text109.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // HorizontalLine25
            // 
            this.HorizontalLine25 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine25.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.5, 7.5, 0.01);
            this.HorizontalLine25.Color = System.Drawing.Color.FromArgb(255, 81, 104, 36);
            this.HorizontalLine25.Guid = "deea08a37cc749e7a611f157564b2099";
            this.HorizontalLine25.Name = "HorizontalLine25";
            this.HorizontalLine25.Size = 2F;
            this.HorizontalLine25.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine25.Interaction = null;
            this.HorizontalLine25.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine26
            // 
            this.HorizontalLine26 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine26.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.9, 7.5, 0.01);
            this.HorizontalLine26.Color = System.Drawing.Color.DarkGray;
            this.HorizontalLine26.Guid = "c2f30d5c49384a9594a0aed36d0daa02";
            this.HorizontalLine26.Name = "HorizontalLine26";
            this.HorizontalLine26.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine26.Interaction = null;
            this.HorizontalLine26.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine27
            // 
            this.HorizontalLine27 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine27.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 1.3, 7.5, 0.01);
            this.HorizontalLine27.Color = System.Drawing.Color.DarkGray;
            this.HorizontalLine27.Guid = "14e4f3a0e56a4acba759809452aa6eaa";
            this.HorizontalLine27.Name = "HorizontalLine27";
            this.HorizontalLine27.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine27.Interaction = null;
            this.HorizontalLine27.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine28
            // 
            this.HorizontalLine28 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine28.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 1.7, 7.5, 0.01);
            this.HorizontalLine28.Color = System.Drawing.Color.DarkGray;
            this.HorizontalLine28.Guid = "742f4091e90648b6929035a1775be026";
            this.HorizontalLine28.Name = "HorizontalLine28";
            this.HorizontalLine28.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine28.Interaction = null;
            this.HorizontalLine28.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine29
            // 
            this.HorizontalLine29 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine29.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 2.1, 7.5, 0.01);
            this.HorizontalLine29.Color = System.Drawing.Color.DarkGray;
            this.HorizontalLine29.Guid = "09ae1dbab3a649b3853bcc0932c1aef9";
            this.HorizontalLine29.Name = "HorizontalLine29";
            this.HorizontalLine29.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine29.Interaction = null;
            this.HorizontalLine29.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine30
            // 
            this.HorizontalLine30 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine30.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 2.5, 7.5, 0.01);
            this.HorizontalLine30.Color = System.Drawing.Color.DarkGray;
            this.HorizontalLine30.Guid = "8ff3535b3b3c453d8b440d8d59c48f53";
            this.HorizontalLine30.Name = "HorizontalLine30";
            this.HorizontalLine30.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine30.Interaction = null;
            this.HorizontalLine30.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine31
            // 
            this.HorizontalLine31 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine31.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 2.9, 7.5, 0.01);
            this.HorizontalLine31.Color = System.Drawing.Color.DarkGray;
            this.HorizontalLine31.Guid = "19eae666f1f24c60a566e25feda1a6d8";
            this.HorizontalLine31.Name = "HorizontalLine31";
            this.HorizontalLine31.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine31.Interaction = null;
            this.HorizontalLine31.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine32
            // 
            this.HorizontalLine32 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine32.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 3.3, 7.5, 0.01);
            this.HorizontalLine32.Color = System.Drawing.Color.DarkGray;
            this.HorizontalLine32.Guid = "230dc0d5f7854c34a2e8ea139ad3db96";
            this.HorizontalLine32.Name = "HorizontalLine32";
            this.HorizontalLine32.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine32.Interaction = null;
            this.HorizontalLine32.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // StartPointPrimitive34
            // 
            this.StartPointPrimitive34 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive34.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.8, 0.1, 0, 0);
            this.StartPointPrimitive34.Guid = "b6cf66179d614515a20b79dd4f2e2238";
            this.StartPointPrimitive34.Name = "StartPointPrimitive34";
            this.StartPointPrimitive34.ReferenceToGuid = "0943070b136e424bb165a45d58341196";
            this.StartPointPrimitive34.Interaction = null;
            // 
            // StartPointPrimitive35
            // 
            this.StartPointPrimitive35 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive35.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.5, 0.1, 0, 0);
            this.StartPointPrimitive35.Guid = "eeef60bfc0c54b0682372685e707f8de";
            this.StartPointPrimitive35.Name = "StartPointPrimitive35";
            this.StartPointPrimitive35.ReferenceToGuid = "0109a5544f5c4ed1b9a17feb6dadca44";
            this.StartPointPrimitive35.Interaction = null;
            // 
            // StartPointPrimitive36
            // 
            this.StartPointPrimitive36 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive36.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.7, 0.1, 0, 0);
            this.StartPointPrimitive36.Guid = "7f773fd745db4dfaae6b54a2a48c4962";
            this.StartPointPrimitive36.Name = "StartPointPrimitive36";
            this.StartPointPrimitive36.ReferenceToGuid = "586b3c0ee6494ce7b3d8b9939fb66fa6";
            this.StartPointPrimitive36.Interaction = null;
            // 
            // StartPointPrimitive37
            // 
            this.StartPointPrimitive37 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive37.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.7, 0.1, 0, 0);
            this.StartPointPrimitive37.Guid = "8bd3192cbb1c4a7ab020af8d72de92cb";
            this.StartPointPrimitive37.Name = "StartPointPrimitive37";
            this.StartPointPrimitive37.ReferenceToGuid = "b5312f470616440ca2d53b8e508cf342";
            this.StartPointPrimitive37.Interaction = null;
            // 
            // StartPointPrimitive63
            // 
            this.StartPointPrimitive63 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive63.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.3, 0.2, 0, 0);
            this.StartPointPrimitive63.Name = "StartPointPrimitive63";
            this.StartPointPrimitive63.ReferenceToGuid = "cab6f21f3a03408d9e1469688eecbac6";
            this.StartPointPrimitive63.Guid = null;
            this.StartPointPrimitive63.Interaction = null;
            // 
            // EndPointPrimitive63
            // 
            this.EndPointPrimitive63 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive63.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.3, 1.3, 0, 0);
            this.EndPointPrimitive63.Name = "EndPointPrimitive63";
            this.EndPointPrimitive63.ReferenceToGuid = "cab6f21f3a03408d9e1469688eecbac6";
            this.EndPointPrimitive63.Guid = null;
            this.EndPointPrimitive63.Interaction = null;
            // 
            // StartPointPrimitive64
            // 
            this.StartPointPrimitive64 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive64.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3, 0.2, 0, 0);
            this.StartPointPrimitive64.Name = "StartPointPrimitive64";
            this.StartPointPrimitive64.ReferenceToGuid = "3f9bd81a9f0443dcb47625d903a4d0d6";
            this.StartPointPrimitive64.Guid = null;
            this.StartPointPrimitive64.Interaction = null;
            // 
            // EndPointPrimitive64
            // 
            this.EndPointPrimitive64 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive64.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3, 1, 0, 0);
            this.EndPointPrimitive64.Name = "EndPointPrimitive64";
            this.EndPointPrimitive64.ReferenceToGuid = "3f9bd81a9f0443dcb47625d903a4d0d6";
            this.EndPointPrimitive64.Guid = null;
            this.EndPointPrimitive64.Interaction = null;
            // 
            // StartPointPrimitive65
            // 
            this.StartPointPrimitive65 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive65.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.3, 0.2, 0, 0);
            this.StartPointPrimitive65.Name = "StartPointPrimitive65";
            this.StartPointPrimitive65.ReferenceToGuid = "a7338ba4b94b498ca34baabc438c10f5";
            this.StartPointPrimitive65.Guid = null;
            this.StartPointPrimitive65.Interaction = null;
            // 
            // EndPointPrimitive65
            // 
            this.EndPointPrimitive65 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive65.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.3, 1, 0, 0);
            this.EndPointPrimitive65.Name = "EndPointPrimitive65";
            this.EndPointPrimitive65.ReferenceToGuid = "a7338ba4b94b498ca34baabc438c10f5";
            this.EndPointPrimitive65.Guid = null;
            this.EndPointPrimitive65.Interaction = null;
            // 
            // StartPointPrimitive66
            // 
            this.StartPointPrimitive66 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive66.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.6, 0.2, 0, 0);
            this.StartPointPrimitive66.Name = "StartPointPrimitive66";
            this.StartPointPrimitive66.ReferenceToGuid = "958787c42c534cc0ae0dfecc7a94cf12";
            this.StartPointPrimitive66.Guid = null;
            this.StartPointPrimitive66.Interaction = null;
            // 
            // EndPointPrimitive66
            // 
            this.EndPointPrimitive66 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive66.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.6, 1, 0, 0);
            this.EndPointPrimitive66.Name = "EndPointPrimitive66";
            this.EndPointPrimitive66.ReferenceToGuid = "958787c42c534cc0ae0dfecc7a94cf12";
            this.EndPointPrimitive66.Guid = null;
            this.EndPointPrimitive66.Interaction = null;
            // 
            // StartPointPrimitive67
            // 
            this.StartPointPrimitive67 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive67.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.6, 0.7, 0, 0);
            this.StartPointPrimitive67.Name = "StartPointPrimitive67";
            this.StartPointPrimitive67.ReferenceToGuid = "f71ad467270e4d7a92f6359706fa23ad";
            this.StartPointPrimitive67.Guid = null;
            this.StartPointPrimitive67.Interaction = null;
            // 
            // EndPointPrimitive67
            // 
            this.EndPointPrimitive67 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive67.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.6, 1.3, 0, 0);
            this.EndPointPrimitive67.Name = "EndPointPrimitive67";
            this.EndPointPrimitive67.ReferenceToGuid = "f71ad467270e4d7a92f6359706fa23ad";
            this.EndPointPrimitive67.Guid = null;
            this.EndPointPrimitive67.Interaction = null;
            // 
            // StartPointPrimitive68
            // 
            this.StartPointPrimitive68 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive68.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.3, 1.5, 0, 0);
            this.StartPointPrimitive68.Name = "StartPointPrimitive68";
            this.StartPointPrimitive68.ReferenceToGuid = "61140f53f07949de98ff93ac4c8bce08";
            this.StartPointPrimitive68.Guid = null;
            this.StartPointPrimitive68.Interaction = null;
            // 
            // EndPointPrimitive68
            // 
            this.EndPointPrimitive68 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive68.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.3, 2.6, 0, 0);
            this.EndPointPrimitive68.Name = "EndPointPrimitive68";
            this.EndPointPrimitive68.ReferenceToGuid = "61140f53f07949de98ff93ac4c8bce08";
            this.EndPointPrimitive68.Guid = null;
            this.EndPointPrimitive68.Interaction = null;
            // 
            // StartPointPrimitive69
            // 
            this.StartPointPrimitive69 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive69.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3, 1.5, 0, 0);
            this.StartPointPrimitive69.Name = "StartPointPrimitive69";
            this.StartPointPrimitive69.ReferenceToGuid = "3ebd4a4dcab94145a9be78d9bff0289c";
            this.StartPointPrimitive69.Guid = null;
            this.StartPointPrimitive69.Interaction = null;
            // 
            // EndPointPrimitive69
            // 
            this.EndPointPrimitive69 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive69.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3, 2.3, 0, 0);
            this.EndPointPrimitive69.Name = "EndPointPrimitive69";
            this.EndPointPrimitive69.ReferenceToGuid = "3ebd4a4dcab94145a9be78d9bff0289c";
            this.EndPointPrimitive69.Guid = null;
            this.EndPointPrimitive69.Interaction = null;
            // 
            // StartPointPrimitive70
            // 
            this.StartPointPrimitive70 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive70.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.6, 2, 0, 0);
            this.StartPointPrimitive70.Name = "StartPointPrimitive70";
            this.StartPointPrimitive70.ReferenceToGuid = "9ec04c38393a4285a5a50e7883da7573";
            this.StartPointPrimitive70.Guid = null;
            this.StartPointPrimitive70.Interaction = null;
            // 
            // EndPointPrimitive70
            // 
            this.EndPointPrimitive70 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive70.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.6, 2.6, 0, 0);
            this.EndPointPrimitive70.Name = "EndPointPrimitive70";
            this.EndPointPrimitive70.ReferenceToGuid = "9ec04c38393a4285a5a50e7883da7573";
            this.EndPointPrimitive70.Guid = null;
            this.EndPointPrimitive70.Interaction = null;
            // 
            // StartPointPrimitive71
            // 
            this.StartPointPrimitive71 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive71.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.3, 2.8, 0, 0);
            this.StartPointPrimitive71.Name = "StartPointPrimitive71";
            this.StartPointPrimitive71.ReferenceToGuid = "965240aa865243d18453cbbe04a5c41d";
            this.StartPointPrimitive71.Guid = null;
            this.StartPointPrimitive71.Interaction = null;
            // 
            // StartPointPrimitive72
            // 
            this.StartPointPrimitive72 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive72.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3, 2.8, 0, 0);
            this.StartPointPrimitive72.Name = "StartPointPrimitive72";
            this.StartPointPrimitive72.ReferenceToGuid = "5c03581ad0fc40efbcbfbf6dcf27a14c";
            this.StartPointPrimitive72.Guid = null;
            this.StartPointPrimitive72.Interaction = null;
            // 
            // EndPointPrimitive72
            // 
            this.EndPointPrimitive72 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive72.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3, 3.6, 0, 0);
            this.EndPointPrimitive72.Name = "EndPointPrimitive72";
            this.EndPointPrimitive72.ReferenceToGuid = "5c03581ad0fc40efbcbfbf6dcf27a14c";
            this.EndPointPrimitive72.Guid = null;
            this.EndPointPrimitive72.Interaction = null;
            // 
            // StartPointPrimitive73
            // 
            this.StartPointPrimitive73 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive73.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.6, 3.3, 0, 0);
            this.StartPointPrimitive73.Name = "StartPointPrimitive73";
            this.StartPointPrimitive73.ReferenceToGuid = "342c53b985784f33a446bda24052024f";
            this.StartPointPrimitive73.Guid = null;
            this.StartPointPrimitive73.Interaction = null;
            // 
            // StartPointPrimitive74
            // 
            this.StartPointPrimitive74 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive74.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.6, 1.5, 0, 0);
            this.StartPointPrimitive74.Name = "StartPointPrimitive74";
            this.StartPointPrimitive74.ReferenceToGuid = "bfbd764a9f9c4e2689e0bd18faba9733";
            this.StartPointPrimitive74.Guid = null;
            this.StartPointPrimitive74.Interaction = null;
            // 
            // EndPointPrimitive74
            // 
            this.EndPointPrimitive74 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive74.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.6, 2.3, 0, 0);
            this.EndPointPrimitive74.Name = "EndPointPrimitive74";
            this.EndPointPrimitive74.ReferenceToGuid = "bfbd764a9f9c4e2689e0bd18faba9733";
            this.EndPointPrimitive74.Guid = null;
            this.EndPointPrimitive74.Interaction = null;
            // 
            // StartPointPrimitive75
            // 
            this.StartPointPrimitive75 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive75.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.6, 2.8, 0, 0);
            this.StartPointPrimitive75.Name = "StartPointPrimitive75";
            this.StartPointPrimitive75.ReferenceToGuid = "6451319cc9cb485a9c3b4c8e604875a4";
            this.StartPointPrimitive75.Guid = null;
            this.StartPointPrimitive75.Interaction = null;
            // 
            // EndPointPrimitive75
            // 
            this.EndPointPrimitive75 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive75.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.6, 3.6, 0, 0);
            this.EndPointPrimitive75.Name = "EndPointPrimitive75";
            this.EndPointPrimitive75.ReferenceToGuid = "6451319cc9cb485a9c3b4c8e604875a4";
            this.EndPointPrimitive75.Guid = null;
            this.EndPointPrimitive75.Interaction = null;
            // 
            // StartPointPrimitive76
            // 
            this.StartPointPrimitive76 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive76.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.3, 1.5, 0, 0);
            this.StartPointPrimitive76.Name = "StartPointPrimitive76";
            this.StartPointPrimitive76.ReferenceToGuid = "1400a767cf3b4608bd14c02e980046ed";
            this.StartPointPrimitive76.Guid = null;
            this.StartPointPrimitive76.Interaction = null;
            // 
            // EndPointPrimitive76
            // 
            this.EndPointPrimitive76 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive76.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.3, 2.3, 0, 0);
            this.EndPointPrimitive76.Name = "EndPointPrimitive76";
            this.EndPointPrimitive76.ReferenceToGuid = "1400a767cf3b4608bd14c02e980046ed";
            this.EndPointPrimitive76.Guid = null;
            this.EndPointPrimitive76.Interaction = null;
            // 
            // StartPointPrimitive77
            // 
            this.StartPointPrimitive77 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive77.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.3, 2.8, 0, 0);
            this.StartPointPrimitive77.Name = "StartPointPrimitive77";
            this.StartPointPrimitive77.ReferenceToGuid = "c632e2124b344890929d38f3187efc15";
            this.StartPointPrimitive77.Guid = null;
            this.StartPointPrimitive77.Interaction = null;
            // 
            // EndPointPrimitive77
            // 
            this.EndPointPrimitive77 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive77.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.3, 3.6, 0, 0);
            this.EndPointPrimitive77.Name = "EndPointPrimitive77";
            this.EndPointPrimitive77.ReferenceToGuid = "c632e2124b344890929d38f3187efc15";
            this.EndPointPrimitive77.Guid = null;
            this.EndPointPrimitive77.Interaction = null;
            // 
            // StartPointPrimitive38
            // 
            this.StartPointPrimitive38 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive38.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.7, 0.1, 0, 0);
            this.StartPointPrimitive38.Name = "StartPointPrimitive38";
            this.StartPointPrimitive38.ReferenceToGuid = "586b3c0ee6494ce7b3d8b9939fb66fa6";
            this.StartPointPrimitive38.Guid = null;
            this.StartPointPrimitive38.Interaction = null;
            // 
            // EndPointPrimitive34
            // 
            this.EndPointPrimitive34 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive34.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.7, 3.3, 0, 0);
            this.EndPointPrimitive34.Name = "EndPointPrimitive34";
            this.EndPointPrimitive34.ReferenceToGuid = "586b3c0ee6494ce7b3d8b9939fb66fa6";
            this.EndPointPrimitive34.Guid = null;
            this.EndPointPrimitive34.Interaction = null;
            // 
            // StartPointPrimitive39
            // 
            this.StartPointPrimitive39 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive39.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.7, 0.2, 0, 0);
            this.StartPointPrimitive39.Name = "StartPointPrimitive39";
            this.StartPointPrimitive39.ReferenceToGuid = "b5312f470616440ca2d53b8e508cf342";
            this.StartPointPrimitive39.Guid = null;
            this.StartPointPrimitive39.Interaction = null;
            // 
            // EndPointPrimitive35
            // 
            this.EndPointPrimitive35 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive35.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.7, 3.3, 0, 0);
            this.EndPointPrimitive35.Name = "EndPointPrimitive35";
            this.EndPointPrimitive35.ReferenceToGuid = "b5312f470616440ca2d53b8e508cf342";
            this.EndPointPrimitive35.Guid = null;
            this.EndPointPrimitive35.Interaction = null;
            // 
            // EndPointPrimitive71
            // 
            this.EndPointPrimitive71 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive71.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.3, 3.9, 0, 0);
            this.EndPointPrimitive71.Name = "EndPointPrimitive71";
            this.EndPointPrimitive71.ReferenceToGuid = "965240aa865243d18453cbbe04a5c41d";
            this.EndPointPrimitive71.Guid = null;
            this.EndPointPrimitive71.Interaction = null;
            // 
            // EndPointPrimitive73
            // 
            this.EndPointPrimitive73 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive73.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.6, 3.9, 0, 0);
            this.EndPointPrimitive73.Name = "EndPointPrimitive73";
            this.EndPointPrimitive73.ReferenceToGuid = "342c53b985784f33a446bda24052024f";
            this.EndPointPrimitive73.Guid = null;
            this.EndPointPrimitive73.Interaction = null;
            // 
            // StartPointPrimitive33
            // 
            this.StartPointPrimitive33 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive33.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.7, 0, 0, 0);
            this.StartPointPrimitive33.Name = "StartPointPrimitive33";
            this.StartPointPrimitive33.ReferenceToGuid = "de1a2db545064addaf8da20c591edf58";
            this.StartPointPrimitive33.Guid = null;
            this.StartPointPrimitive33.Interaction = null;
            // 
            // EndPointPrimitive33
            // 
            this.EndPointPrimitive33 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive33.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.7, 3.7, 0, 0);
            this.EndPointPrimitive33.Name = "EndPointPrimitive33";
            this.EndPointPrimitive33.ReferenceToGuid = "de1a2db545064addaf8da20c591edf58";
            this.EndPointPrimitive33.Guid = null;
            this.EndPointPrimitive33.Interaction = null;
            // 
            // HorizontalLine33
            // 
            this.HorizontalLine33 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine33.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 3.7, 7.5, 0.01);
            this.HorizontalLine33.Color = System.Drawing.Color.DarkGray;
            this.HorizontalLine33.Guid = "7ba684890e1f4895987d60ae932dc6e1";
            this.HorizontalLine33.Name = "HorizontalLine33";
            this.HorizontalLine33.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine33.Interaction = null;
            this.HorizontalLine33.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // StartPointPrimitive30
            // 
            this.StartPointPrimitive30 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive30.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 0, 0, 0);
            this.StartPointPrimitive30.Name = "StartPointPrimitive30";
            this.StartPointPrimitive30.ReferenceToGuid = "59a33bda2af7406da402b888263db083";
            this.StartPointPrimitive30.Guid = null;
            this.StartPointPrimitive30.Interaction = null;
            // 
            // EndPointPrimitive32
            // 
            this.EndPointPrimitive32 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive32.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 3.7, 0, 0);
            this.EndPointPrimitive32.Name = "EndPointPrimitive32";
            this.EndPointPrimitive32.ReferenceToGuid = "59a33bda2af7406da402b888263db083";
            this.EndPointPrimitive32.Guid = null;
            this.EndPointPrimitive32.Interaction = null;
            // 
            // EndPointPrimitive59
            // 
            this.EndPointPrimitive59 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive59.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.9, 3.9, 0, 0);
            this.EndPointPrimitive59.Name = "EndPointPrimitive59";
            this.EndPointPrimitive59.ReferenceToGuid = "0943070b136e424bb165a45d58341196";
            this.EndPointPrimitive59.Guid = null;
            this.EndPointPrimitive59.Interaction = null;
            // 
            // EndPointPrimitive60
            // 
            this.EndPointPrimitive60 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive60.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.6, 3.9, 0, 0);
            this.EndPointPrimitive60.Name = "EndPointPrimitive60";
            this.EndPointPrimitive60.ReferenceToGuid = "0109a5544f5c4ed1b9a17feb6dadca44";
            this.EndPointPrimitive60.Guid = null;
            this.EndPointPrimitive60.Interaction = null;
            // 
            // EndPointPrimitive61
            // 
            this.EndPointPrimitive61 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive61.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 3.9, 0, 0);
            this.EndPointPrimitive61.Name = "EndPointPrimitive61";
            this.EndPointPrimitive61.ReferenceToGuid = "c4adc3e1b67b40a1812803a282203438";
            this.EndPointPrimitive61.Guid = null;
            this.EndPointPrimitive61.Interaction = null;
            // 
            // EndPointPrimitive62
            // 
            this.EndPointPrimitive62 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive62.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.8, 3.9, 0, 0);
            this.EndPointPrimitive62.Name = "EndPointPrimitive62";
            this.EndPointPrimitive62.ReferenceToGuid = "c5315537de2742ff86d36a8e95a3b6bc";
            this.EndPointPrimitive62.Guid = null;
            this.EndPointPrimitive62.Interaction = null;
            this.Panel7.Interaction = null;
            // 
            // Panel3
            // 
            this.Panel3 = new Stimulsoft.Report.Components.StiPanel();
            this.Panel3.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 5.6, 7.7, 1.1);
            this.Panel3.Guid = "547d99265c984b4aa0a48b78a7fa7f82";
            this.Panel3.Name = "Panel3";
            this.Panel3.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.All, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, true, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Panel3.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // Text39
            // 
            this.Text39 = new Stimulsoft.Report.Components.StiText();
            this.Text39.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.5, 0.1, 1.2, 0.3);
            this.Text39.Guid = "e12f980e86e047c39e217c3a5e177a91";
            this.Text39.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text39.Name = "Text39";
            this.Text39.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text39__GetValue);
            this.Text39.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text39.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text39.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text39.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text39.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text39.Indicator = null;
            this.Text39.Interaction = null;
            this.Text39.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text39.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text39.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text40
            // 
            this.Text40 = new Stimulsoft.Report.Components.StiText();
            this.Text40.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.2, 0.1, 3.3, 0.4);
            this.Text40.Guid = "99c12366ba6743c5861b9eb1082f053b";
            this.Text40.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text40.Name = "Text40";
            this.Text40.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text40__GetValue);
            this.Text40.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text40.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text40.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text40.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text40.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text40.Indicator = null;
            this.Text40.Interaction = null;
            this.Text40.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text40.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text40.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text41
            // 
            this.Text41 = new Stimulsoft.Report.Components.StiText();
            this.Text41.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.5, 0, 0.7, 0.5);
            this.Text41.Guid = "6cc582caf6a74d299b2257a92923dd17";
            this.Text41.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text41.Name = "Text41";
            this.Text41.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text41__GetValue);
            this.Text41.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text41.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.InitializeComponent4();
        }
        
        public void InitializeComponent4()
        {
            this.Text41.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text41.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text41.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text41.Indicator = null;
            this.Text41.Interaction = null;
            this.Text41.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text41.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text41.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text42
            // 
            this.Text42 = new Stimulsoft.Report.Components.StiText();
            this.Text42.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.8, 0, 0.7, 0.5);
            this.Text42.Guid = "7369af90a13f4f74966d64236472fc9f";
            this.Text42.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text42.Name = "Text42";
            this.Text42.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text42__GetValue);
            this.Text42.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text42.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text42.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text42.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text42.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text42.Indicator = null;
            this.Text42.Interaction = null;
            this.Text42.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text42.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text42.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text43
            // 
            this.Text43 = new Stimulsoft.Report.Components.StiText();
            this.Text43.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.1, 1.8, 0.3);
            this.Text43.Guid = "9a184539afb04a07b8e6a697eb00c605";
            this.Text43.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text43.Name = "Text43";
            this.Text43.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text43__GetValue);
            this.Text43.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text43.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text43.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text43.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text43.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text43.Indicator = null;
            this.Text43.Interaction = null;
            this.Text43.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text43.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text43.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text44
            // 
            this.Text44 = new Stimulsoft.Report.Components.StiText();
            this.Text44.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.5, 0.5, 1.1, 0.3);
            this.Text44.Guid = "4531713a55554d4383b57b0cd16e60a9";
            this.Text44.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text44.Name = "Text44";
            this.Text44.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text44__GetValue);
            this.Text44.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text44.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text44.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text44.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text44.Font = new System.Drawing.Font("B Nazanin", 8F, System.Drawing.FontStyle.Bold);
            this.Text44.Indicator = null;
            this.Text44.Interaction = null;
            this.Text44.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text44.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text44.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text45
            // 
            this.Text45 = new Stimulsoft.Report.Components.StiText();
            this.Text45.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.5, 0.8, 1.1, 0.3);
            this.Text45.Guid = "ed895de1d5f849d28a29ef459e5b9515";
            this.Text45.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text45.Name = "Text45";
            this.Text45.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text45__GetValue);
            this.Text45.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text45.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text45.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text45.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text45.Font = new System.Drawing.Font("B Nazanin", 8F, System.Drawing.FontStyle.Bold);
            this.Text45.Indicator = null;
            this.Text45.Interaction = null;
            this.Text45.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text45.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text45.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text60
            // 
            this.Text60 = new Stimulsoft.Report.Components.StiText();
            this.Text60.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.5, 1.8, 0.3);
            this.Text60.Guid = "9f9cfa6c61534bf7a53c2f458a542d76";
            this.Text60.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text60.Name = "Text60";
            this.Text60.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text60__GetValue);
            this.Text60.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text60.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 2, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text60.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text60.Font = new System.Drawing.Font("B Nazanin", 11F, System.Drawing.FontStyle.Bold);
            this.Text60.Indicator = null;
            this.Text60.Interaction = null;
            this.Text60.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text60.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text60.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text60.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text48
            // 
            this.Text48 = new Stimulsoft.Report.Components.StiText();
            this.Text48.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.5, 0.5, 0.7, 0.3);
            this.Text48.Guid = "87800dfda3bd47ea8384a8e569ba5e7b";
            this.Text48.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text48.Name = "Text48";
            this.Text48.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text48__GetValue);
            this.Text48.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text48.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text48.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text48.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text48.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text48.Indicator = null;
            this.Text48.Interaction = null;
            this.Text48.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text48.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text48.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text49
            // 
            this.Text49 = new Stimulsoft.Report.Components.StiText();
            this.Text49.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.8, 0.5, 0.7, 0.3);
            this.Text49.Guid = "a250455c354d4546acc4d1ab6a9a8ab5";
            this.Text49.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text49.Name = "Text49";
            this.Text49.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text49__GetValue);
            this.Text49.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text49.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text49.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text49.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text49.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text49.Indicator = null;
            this.Text49.Interaction = null;
            this.Text49.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text49.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text49.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text55
            // 
            this.Text55 = new Stimulsoft.Report.Components.StiText();
            this.Text55.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.8, 0.5, 1.7, 0.3);
            this.Text55.Guid = "210a33225b674799b3c5ca9d5f4c4b00";
            this.Text55.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text55.Name = "Text55";
            this.Text55.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text55__GetValue);
            this.Text55.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text55.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text55.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 2, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text55.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text55.Font = new System.Drawing.Font("B Nazanin", 11F, System.Drawing.FontStyle.Bold);
            this.Text55.Indicator = null;
            this.Text55.Interaction = null;
            this.Text55.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text55.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text55.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text55.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text61
            // 
            this.Text61 = new Stimulsoft.Report.Components.StiText();
            this.Text61.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.4, 0.5, 1.2, 0.3);
            this.Text61.Guid = "d909a1faa0aa411f9e168941632b899b";
            this.Text61.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text61.Name = "Text61";
            this.Text61.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text61__GetValue);
            this.Text61.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text61.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text61.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text61.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text61.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text61.Indicator = null;
            this.Text61.Interaction = null;
            this.Text61.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text61.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 192, 0, 0));
            this.Text61.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text72
            // 
            this.Text72 = new Stimulsoft.Report.Components.StiText();
            this.Text72.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.8, 0.8, 1.7, 0.3);
            this.Text72.Guid = "f34be03a0d6b44469890897d14653e9d";
            this.Text72.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text72.Name = "Text72";
            this.Text72.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text72__GetValue);
            this.Text72.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text72.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text72.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 2, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text72.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text72.Font = new System.Drawing.Font("B Nazanin", 11F, System.Drawing.FontStyle.Bold);
            this.Text72.Indicator = null;
            this.Text72.Interaction = null;
            this.Text72.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text72.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text72.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text72.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // HorizontalLine10
            // 
            this.HorizontalLine10 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine10.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.5, 7.7, 0.01);
            this.HorizontalLine10.Color = System.Drawing.Color.FromArgb(255, 81, 104, 36);
            this.HorizontalLine10.Guid = "ac1f0bd9bc2c4ffe849d9fd927c7f747";
            this.HorizontalLine10.Name = "HorizontalLine10";
            this.HorizontalLine10.Size = 2F;
            this.HorizontalLine10.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine10.Interaction = null;
            this.HorizontalLine10.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine11
            // 
            this.HorizontalLine11 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine11.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.8, 7.7, 0.01);
            this.HorizontalLine11.Color = System.Drawing.Color.FromArgb(255, 81, 104, 36);
            this.HorizontalLine11.Guid = "6280fd7e5b3540a2926d6bcec4eeb860";
            this.HorizontalLine11.Name = "HorizontalLine11";
            this.HorizontalLine11.Size = 2F;
            this.HorizontalLine11.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine11.Interaction = null;
            this.HorizontalLine11.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // StartPointPrimitive57
            // 
            this.StartPointPrimitive57 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive57.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.5, 0.1, 0, 0);
            this.StartPointPrimitive57.Name = "StartPointPrimitive57";
            this.StartPointPrimitive57.ReferenceToGuid = "b4507f6424854fd691280bbe4ba42fed";
            this.StartPointPrimitive57.Guid = null;
            this.StartPointPrimitive57.Interaction = null;
            // 
            // StartPointPrimitive58
            // 
            this.StartPointPrimitive58 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive58.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.2, 0.1, 0, 0);
            this.StartPointPrimitive58.Name = "StartPointPrimitive58";
            this.StartPointPrimitive58.ReferenceToGuid = "65de1fde58474671b852806afd5ae4de";
            this.StartPointPrimitive58.Guid = null;
            this.StartPointPrimitive58.Interaction = null;
            // 
            // EndPointPrimitive54
            // 
            this.EndPointPrimitive54 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive54.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.2, 0.9, 0, 0);
            this.EndPointPrimitive54.Name = "EndPointPrimitive54";
            this.EndPointPrimitive54.ReferenceToGuid = "65de1fde58474671b852806afd5ae4de";
            this.EndPointPrimitive54.Guid = null;
            this.EndPointPrimitive54.Interaction = null;
            // 
            // StartPointPrimitive78
            // 
            this.StartPointPrimitive78 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive78.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.5, 0.1, 0, 0);
            this.StartPointPrimitive78.Name = "StartPointPrimitive78";
            this.StartPointPrimitive78.ReferenceToGuid = "e656ad3910f14c2d9a2399407863dcff";
            this.StartPointPrimitive78.Guid = null;
            this.StartPointPrimitive78.Interaction = null;
            // 
            // EndPointPrimitive55
            // 
            this.EndPointPrimitive55 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive55.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.5, 0.9, 0, 0);
            this.EndPointPrimitive55.Name = "EndPointPrimitive55";
            this.EndPointPrimitive55.ReferenceToGuid = "e656ad3910f14c2d9a2399407863dcff";
            this.EndPointPrimitive55.Guid = null;
            this.EndPointPrimitive55.Interaction = null;
            // 
            // StartPointPrimitive79
            // 
            this.StartPointPrimitive79 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive79.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.8, 0.1, 0, 0);
            this.StartPointPrimitive79.Name = "StartPointPrimitive79";
            this.StartPointPrimitive79.ReferenceToGuid = "70e34d008d64475b9250d804b7e1a1da";
            this.StartPointPrimitive79.Guid = null;
            this.StartPointPrimitive79.Interaction = null;
            // 
            // EndPointPrimitive56
            // 
            this.EndPointPrimitive56 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive56.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.8, 0.9, 0, 0);
            this.EndPointPrimitive56.Name = "EndPointPrimitive56";
            this.EndPointPrimitive56.ReferenceToGuid = "70e34d008d64475b9250d804b7e1a1da";
            this.EndPointPrimitive56.Guid = null;
            this.EndPointPrimitive56.Interaction = null;
            // 
            // StartPointPrimitive80
            // 
            this.StartPointPrimitive80 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive80.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.8, 0.6, 0, 0);
            this.StartPointPrimitive80.Name = "StartPointPrimitive80";
            this.StartPointPrimitive80.ReferenceToGuid = "8f0a41934484495c9e39dd8c0cd61455";
            this.StartPointPrimitive80.Guid = null;
            this.StartPointPrimitive80.Interaction = null;
            this.Panel3.Interaction = null;
            // 
            // Panel4
            // 
            this.Panel4 = new Stimulsoft.Report.Components.StiPanel();
            this.Panel4.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 6.9, 7.7, 1.1);
            this.Panel4.Guid = "875fa77f3df647039ac090d99e0de152";
            this.Panel4.Name = "Panel4";
            this.Panel4.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.All, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, true, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Panel4.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // Text47
            // 
            this.Text47 = new Stimulsoft.Report.Components.StiText();
            this.Text47.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.2, 0.1, 3.3, 0.4);
            this.Text47.Guid = "b7206d62001b4fcf9038688490474173";
            this.Text47.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text47.Name = "Text47";
            this.Text47.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text47__GetValue);
            this.Text47.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text47.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text47.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text47.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text47.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text47.Indicator = null;
            this.Text47.Interaction = null;
            this.Text47.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text47.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text47.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text51
            // 
            this.Text51 = new Stimulsoft.Report.Components.StiText();
            this.Text51.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.5, 0.5, 1.1, 0.3);
            this.Text51.Guid = "5aa3fc71f6044aea8b0509efedb3fa99";
            this.Text51.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text51.Name = "Text51";
            this.Text51.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text51__GetValue);
            this.Text51.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text51.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text51.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text51.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text51.Font = new System.Drawing.Font("B Nazanin", 8F, System.Drawing.FontStyle.Bold);
            this.Text51.Indicator = null;
            this.Text51.Interaction = null;
            this.Text51.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text51.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text51.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text46
            // 
            this.Text46 = new Stimulsoft.Report.Components.StiText();
            this.Text46.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.5, 0.1, 1.2, 0.3);
            this.Text46.Guid = "c37900f5735e4774a15a1ac504e62869";
            this.Text46.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text46.Name = "Text46";
            this.Text46.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text46__GetValue);
            this.Text46.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text46.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text46.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text46.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text46.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text46.Indicator = null;
            this.Text46.Interaction = null;
            this.Text46.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text46.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text46.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text62
            // 
            this.Text62 = new Stimulsoft.Report.Components.StiText();
            this.Text62.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.4, 0.5, 1.2, 0.3);
            this.Text62.Guid = "38cd62a7479a4da4bebc2bd02b664470";
            this.Text62.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text62.Name = "Text62";
            this.Text62.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text62__GetValue);
            this.Text62.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text62.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text62.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text62.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text62.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text62.Indicator = null;
            this.Text62.Interaction = null;
            this.Text62.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text62.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 192, 0, 0));
            this.Text62.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text52
            // 
            this.Text52 = new Stimulsoft.Report.Components.StiText();
            this.Text52.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.5, 0.5, 0.7, 0.3);
            this.Text52.Guid = "2bac34425dc94f81ac00d48ed279bad2";
            this.Text52.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text52.Name = "Text52";
            this.Text52.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text52__GetValue);
            this.Text52.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text52.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text52.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text52.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text52.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text52.Indicator = null;
            this.Text52.Interaction = null;
            this.Text52.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text52.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text52.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text64
            // 
            this.Text64 = new Stimulsoft.Report.Components.StiText();
            this.Text64.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.8, 0.5, 0.7, 0.3);
            this.Text64.Guid = "ab8c498c46694e8397467428133df353";
            this.Text64.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text64.Name = "Text64";
            this.Text64.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text64__GetValue);
            this.Text64.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text64.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text64.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text64.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text64.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text64.Indicator = null;
            this.Text64.Interaction = null;
            this.Text64.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text64.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text64.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text66
            // 
            this.Text66 = new Stimulsoft.Report.Components.StiText();
            this.Text66.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.5, 0, 0.7, 0.5);
            this.Text66.Guid = "15e598f2abb54b13a4e67ae46fcfc945";
            this.Text66.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text66.Name = "Text66";
            this.Text66.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text66__GetValue);
            this.Text66.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text66.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text66.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text66.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text66.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text66.Indicator = null;
            this.Text66.Interaction = null;
            this.Text66.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text66.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text66.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text70
            // 
            this.Text70 = new Stimulsoft.Report.Components.StiText();
            this.Text70.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.5, 1.8, 0.3);
            this.Text70.Guid = "cd11ebe0785542d190acae9fbeb675ef";
            this.Text70.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text70.Name = "Text70";
            this.Text70.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text70__GetValue);
            this.Text70.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text70.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 2, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text70.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text70.Font = new System.Drawing.Font("B Nazanin", 11F, System.Drawing.FontStyle.Bold);
            this.Text70.Indicator = null;
            this.Text70.Interaction = null;
            this.Text70.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text70.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text70.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text70.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text71
            // 
            this.Text71 = new Stimulsoft.Report.Components.StiText();
            this.Text71.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.8, 0.5, 1.7, 0.3);
            this.Text71.Guid = "a4efadc3769f401897b1cd32fc6f802a";
            this.Text71.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text71.Name = "Text71";
            this.Text71.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text71__GetValue);
            this.Text71.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text71.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text71.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 2, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text71.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text71.Font = new System.Drawing.Font("B Nazanin", 11F, System.Drawing.FontStyle.Bold);
            this.Text71.Indicator = null;
            this.Text71.Interaction = null;
            this.Text71.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text71.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text71.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text71.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text50
            // 
            this.Text50 = new Stimulsoft.Report.Components.StiText();
            this.Text50.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.1, 1.8, 0.3);
            this.Text50.Guid = "59fe84710b014637a6b8942b3d8939dc";
            this.Text50.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text50.Name = "Text50";
            this.Text50.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text50__GetValue);
            this.Text50.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text50.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text50.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text50.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text50.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text50.Indicator = null;
            this.Text50.Interaction = null;
            this.Text50.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text50.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text50.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text68
            // 
            this.Text68 = new Stimulsoft.Report.Components.StiText();
            this.Text68.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.8, 0, 0.7, 0.5);
            this.Text68.Guid = "b524ec105ae54233936f2aab18f844ec";
            this.Text68.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text68.Name = "Text68";
            this.Text68.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text68__GetValue);
            this.Text68.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text68.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text68.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text68.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text68.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text68.Indicator = null;
            this.Text68.Interaction = null;
            this.Text68.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text68.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text68.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // HorizontalLine13
            // 
            this.HorizontalLine13 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine13.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.5, 7.7, 0.01);
            this.HorizontalLine13.Color = System.Drawing.Color.FromArgb(255, 81, 104, 36);
            this.HorizontalLine13.Guid = "12e0cacc41074942b3bf9c35dfaea8be";
            this.HorizontalLine13.Name = "HorizontalLine13";
            this.HorizontalLine13.Size = 2F;
            this.HorizontalLine13.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine13.Interaction = null;
            this.HorizontalLine13.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine14
            // 
            this.HorizontalLine14 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine14.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.8, 7.7, 0.01);
            this.HorizontalLine14.Color = System.Drawing.Color.FromArgb(255, 81, 104, 36);
            this.HorizontalLine14.Guid = "485c25058e6346b1ad9cf0edb57533b9";
            this.HorizontalLine14.Name = "HorizontalLine14";
            this.HorizontalLine14.Size = 2F;
            this.HorizontalLine14.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine14.Interaction = null;
            this.HorizontalLine14.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // StartPointPrimitive15
            // 
            this.StartPointPrimitive15 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive15.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.5, 0, 0, 0);
            this.StartPointPrimitive15.Guid = "074f499ce5ba4ef9b684d2a907223aea";
            this.StartPointPrimitive15.Name = "StartPointPrimitive15";
            this.StartPointPrimitive15.ReferenceToGuid = "6ebc0f02dbd141109231c22a314afcbb";
            this.StartPointPrimitive15.Interaction = null;
            // 
            // EndPointPrimitive15
            // 
            this.EndPointPrimitive15 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive15.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.5, 1.1, 0, 0);
            this.EndPointPrimitive15.Guid = "959d2073e2e44ded86f0b3baab06b0fd";
            this.EndPointPrimitive15.Name = "EndPointPrimitive15";
            this.EndPointPrimitive15.ReferenceToGuid = "6ebc0f02dbd141109231c22a314afcbb";
            this.EndPointPrimitive15.Interaction = null;
            // 
            // StartPointPrimitive16
            // 
            this.StartPointPrimitive16 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive16.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.2, 0, 0, 0);
            this.StartPointPrimitive16.Guid = "b9a8061377154580a79c060a8554f91f";
            this.StartPointPrimitive16.Name = "StartPointPrimitive16";
            this.StartPointPrimitive16.ReferenceToGuid = "c94558de10bc40c199c78cf368a369e9";
            this.StartPointPrimitive16.Interaction = null;
            // 
            // EndPointPrimitive16
            // 
            this.EndPointPrimitive16 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive16.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.2, 0.8, 0, 0);
            this.EndPointPrimitive16.Guid = "fa8cfd4c308646f19304351fb5691358";
            this.EndPointPrimitive16.Name = "EndPointPrimitive16";
            this.EndPointPrimitive16.ReferenceToGuid = "c94558de10bc40c199c78cf368a369e9";
            this.EndPointPrimitive16.Interaction = null;
            // 
            // StartPointPrimitive17
            // 
            this.StartPointPrimitive17 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive17.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.3, 0, 0, 0);
            this.StartPointPrimitive17.Guid = "123cb89c6bde4fe584a3e7d011bf0bc2";
            this.StartPointPrimitive17.Name = "StartPointPrimitive17";
            this.StartPointPrimitive17.ReferenceToGuid = "7f5b52a1d9c541d29d2ef8e33a32a591";
            this.StartPointPrimitive17.Interaction = null;
            // 
            // EndPointPrimitive17
            // 
            this.EndPointPrimitive17 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive17.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.3, 0.8, 0, 0);
            this.EndPointPrimitive17.Guid = "aa474edd164240a58d97dcc3b325ad8c";
            this.EndPointPrimitive17.Name = "EndPointPrimitive17";
            this.EndPointPrimitive17.ReferenceToGuid = "7f5b52a1d9c541d29d2ef8e33a32a591";
            this.EndPointPrimitive17.Interaction = null;
            // 
            // StartPointPrimitive18
            // 
            this.StartPointPrimitive18 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive18.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.3, 0, 0, 0);
            this.StartPointPrimitive18.Guid = "247830629407498baf2deb59a07cf800";
            this.StartPointPrimitive18.Name = "StartPointPrimitive18";
            this.StartPointPrimitive18.ReferenceToGuid = "01b8b83d7ef64e1f83fd6064fae85427";
            this.StartPointPrimitive18.Interaction = null;
            // 
            // EndPointPrimitive18
            // 
            this.EndPointPrimitive18 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive18.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.3, 0.8, 0, 0);
            this.EndPointPrimitive18.Guid = "b7d67da4f7374c6f9dc64474c748dbab";
            this.EndPointPrimitive18.Name = "EndPointPrimitive18";
            this.EndPointPrimitive18.ReferenceToGuid = "01b8b83d7ef64e1f83fd6064fae85427";
            this.EndPointPrimitive18.Interaction = null;
            // 
            // StartPointPrimitive19
            // 
            this.StartPointPrimitive19 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive19.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.8, 0.5, 0, 0);
            this.StartPointPrimitive19.Guid = "bbbdbd847bc54d389f648b6f6680672b";
            this.StartPointPrimitive19.Name = "StartPointPrimitive19";
            this.StartPointPrimitive19.ReferenceToGuid = "63803171f34a4f4eb405fc19ff8c90f1";
            this.StartPointPrimitive19.Interaction = null;
            // 
            // EndPointPrimitive19
            // 
            this.EndPointPrimitive19 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive19.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.8, 1.1, 0, 0);
            this.EndPointPrimitive19.Guid = "11df6da6b06843efa08133a2b44a5270";
            this.EndPointPrimitive19.Name = "EndPointPrimitive19";
            this.EndPointPrimitive19.ReferenceToGuid = "63803171f34a4f4eb405fc19ff8c90f1";
            this.EndPointPrimitive19.Interaction = null;
            // 
            // StartPointPrimitive81
            // 
            this.StartPointPrimitive81 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive81.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.5, 0.1, 0, 0);
            this.StartPointPrimitive81.Name = "StartPointPrimitive81";
            this.StartPointPrimitive81.ReferenceToGuid = "6ebc0f02dbd141109231c22a314afcbb";
            this.StartPointPrimitive81.Guid = null;
            this.StartPointPrimitive81.Interaction = null;
            // 
            // StartPointPrimitive82
            // 
            this.StartPointPrimitive82 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive82.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.2, 0.1, 0, 0);
            this.StartPointPrimitive82.Name = "StartPointPrimitive82";
            this.StartPointPrimitive82.ReferenceToGuid = "c94558de10bc40c199c78cf368a369e9";
            this.StartPointPrimitive82.Guid = null;
            this.StartPointPrimitive82.Interaction = null;
            // 
            // EndPointPrimitive78
            // 
            this.EndPointPrimitive78 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive78.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.2, 0.9, 0, 0);
            this.EndPointPrimitive78.Name = "EndPointPrimitive78";
            this.EndPointPrimitive78.ReferenceToGuid = "c94558de10bc40c199c78cf368a369e9";
            this.EndPointPrimitive78.Guid = null;
            this.EndPointPrimitive78.Interaction = null;
            // 
            // StartPointPrimitive83
            // 
            this.StartPointPrimitive83 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive83.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.8, 0.6, 0, 0);
            this.StartPointPrimitive83.Name = "StartPointPrimitive83";
            this.StartPointPrimitive83.ReferenceToGuid = "63803171f34a4f4eb405fc19ff8c90f1";
            this.StartPointPrimitive83.Guid = null;
            this.StartPointPrimitive83.Interaction = null;
            // 
            // StartPointPrimitive87
            // 
            this.StartPointPrimitive87 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive87.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.8, 0.1, 0, 0);
            this.StartPointPrimitive87.Name = "StartPointPrimitive87";
            this.StartPointPrimitive87.ReferenceToGuid = "3694e711d7c54cbcbe05fc1e553971d7";
            this.StartPointPrimitive87.Guid = null;
            this.StartPointPrimitive87.Interaction = null;
            // 
            // EndPointPrimitive83
            // 
            this.EndPointPrimitive83 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive83.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.8, 0.9, 0, 0);
            this.EndPointPrimitive83.Name = "EndPointPrimitive83";
            this.EndPointPrimitive83.ReferenceToGuid = "3694e711d7c54cbcbe05fc1e553971d7";
            this.EndPointPrimitive83.Guid = null;
            this.EndPointPrimitive83.Interaction = null;
            // 
            // StartPointPrimitive89
            // 
            this.StartPointPrimitive89 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive89.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.5, 0.1, 0, 0);
            this.StartPointPrimitive89.Name = "StartPointPrimitive89";
            this.StartPointPrimitive89.ReferenceToGuid = "c3abc60fe1be4772b5fba7532c9a4944";
            this.StartPointPrimitive89.Guid = null;
            this.StartPointPrimitive89.Interaction = null;
            // 
            // EndPointPrimitive85
            // 
            this.EndPointPrimitive85 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive85.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.5, 0.9, 0, 0);
            this.EndPointPrimitive85.Name = "EndPointPrimitive85";
            this.EndPointPrimitive85.ReferenceToGuid = "c3abc60fe1be4772b5fba7532c9a4944";
            this.EndPointPrimitive85.Guid = null;
            this.EndPointPrimitive85.Interaction = null;
            this.Panel4.Interaction = null;
            // 
            // Panel5
            // 
            this.Panel5 = new Stimulsoft.Report.Components.StiPanel();
            this.Panel5.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 8.2, 7.7, 1.1);
            this.Panel5.Guid = "b4c83db8b3f24c4f8e230e0738d0c0dc";
            this.Panel5.Name = "Panel5";
            this.Panel5.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.All, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, true, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Panel5.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // Text54
            // 
            this.Text54 = new Stimulsoft.Report.Components.StiText();
            this.Text54.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.2, 0.1, 3.3, 0.4);
            this.Text54.Guid = "9b0bf01f6a9145b58a061cf114107234";
            this.Text54.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text54.Name = "Text54";
            this.Text54.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text54__GetValue);
            this.Text54.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text54.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text54.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text54.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text54.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text54.Indicator = null;
            this.Text54.Interaction = null;
            this.Text54.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text54.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text54.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text58
            // 
            this.Text58 = new Stimulsoft.Report.Components.StiText();
            this.Text58.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.5, 0.5, 1.1, 0.3);
            this.Text58.Guid = "5edcaf48256846608e759660250eda45";
            this.Text58.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text58.Name = "Text58";
            this.Text58.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text58__GetValue);
            this.Text58.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text58.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text58.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text58.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text58.Font = new System.Drawing.Font("B Nazanin", 8F, System.Drawing.FontStyle.Bold);
            this.Text58.Indicator = null;
            this.Text58.Interaction = null;
            this.Text58.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text58.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text58.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text59
            // 
            this.Text59 = new Stimulsoft.Report.Components.StiText();
            this.Text59.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.5, 0.8, 1.1, 0.3);
            this.Text59.Guid = "49436c0c890c4094b776b23a9f2d1eed";
            this.Text59.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text59.Name = "Text59";
            this.Text59.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text59__GetValue);
            this.Text59.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text59.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text59.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text59.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text59.Font = new System.Drawing.Font("B Nazanin", 8F, System.Drawing.FontStyle.Bold);
            this.Text59.Indicator = null;
            this.Text59.Interaction = null;
            this.Text59.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text59.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text59.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text53
            // 
            this.Text53 = new Stimulsoft.Report.Components.StiText();
            this.Text53.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.5, 0.1, 1.2, 0.4);
            this.Text53.Guid = "628d641d30e344dab91563b06ed16b88";
            this.Text53.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text53.Name = "Text53";
            this.Text53.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text53__GetValue);
            this.Text53.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text53.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text53.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text53.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text53.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text53.Indicator = null;
            this.Text53.Interaction = null;
            this.Text53.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text53.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text53.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text63
            // 
            this.Text63 = new Stimulsoft.Report.Components.StiText();
            this.Text63.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.4, 0.5, 1.2, 0.3);
            this.Text63.Guid = "0a70a1197f534bb58cab6782adc6e01e";
            this.Text63.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text63.Name = "Text63";
            this.Text63.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text63__GetValue);
            this.Text63.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text63.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text63.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text63.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text63.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text63.Indicator = null;
            this.Text63.Interaction = null;
            this.Text63.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text63.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 192, 0, 0));
            this.Text63.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text56
            // 
            this.Text56 = new Stimulsoft.Report.Components.StiText();
            this.Text56.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.5, 0.5, 0.7, 0.3);
            this.Text56.Guid = "f5fea9c563a74e7589f95ffa13a06c19";
            this.Text56.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text56.Name = "Text56";
            this.Text56.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text56__GetValue);
            this.Text56.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text56.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text56.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text56.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text56.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text56.Indicator = null;
            this.Text56.Interaction = null;
            this.Text56.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text56.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text56.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text65
            // 
            this.Text65 = new Stimulsoft.Report.Components.StiText();
            this.Text65.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.8, 0.5, 0.7, 0.3);
            this.Text65.Guid = "13c5ae7ffa7f45d69f69b7db7e624ffd";
            this.Text65.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text65.Name = "Text65";
            this.Text65.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text65__GetValue);
            this.Text65.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text65.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text65.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text65.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text65.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text65.Indicator = null;
            this.Text65.Interaction = null;
            this.Text65.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text65.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text65.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text67
            // 
            this.Text67 = new Stimulsoft.Report.Components.StiText();
            this.Text67.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.5, 0, 0.7, 0.5);
            this.Text67.Guid = "470aa0297a704575951a9041f9baa642";
            this.Text67.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text67.Name = "Text67";
            this.Text67.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text67__GetValue);
            this.Text67.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text67.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text67.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text67.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text67.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text67.Indicator = null;
            this.Text67.Interaction = null;
            this.Text67.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text67.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text67.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text73
            // 
            this.Text73 = new Stimulsoft.Report.Components.StiText();
            this.Text73.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.5, 1.8, 0.3);
            this.Text73.Guid = "143f3c6aff904cfe8a401788ea2f7adb";
            this.Text73.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text73.Name = "Text73";
            this.Text73.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text73__GetValue);
            this.Text73.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text73.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text73.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 2, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text73.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text73.Font = new System.Drawing.Font("B Nazanin", 11F, System.Drawing.FontStyle.Bold);
            this.Text73.Indicator = null;
            this.Text73.Interaction = null;
            this.Text73.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text73.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text73.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text73.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text74
            // 
            this.Text74 = new Stimulsoft.Report.Components.StiText();
            this.Text74.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.8, 0.5, 1.7, 0.3);
            this.Text74.Guid = "848fbdd18c4743f8ade1ee1a07ca86da";
            this.Text74.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text74.Name = "Text74";
            this.Text74.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text74__GetValue);
            this.Text74.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text74.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text74.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 2, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text74.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text74.Font = new System.Drawing.Font("B Nazanin", 11F, System.Drawing.FontStyle.Bold);
            this.Text74.Indicator = null;
            this.Text74.Interaction = null;
            this.Text74.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text74.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text74.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text74.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text75
            // 
            this.Text75 = new Stimulsoft.Report.Components.StiText();
            this.Text75.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.8, 0.8, 1.7, 0.3);
            this.Text75.Guid = "3e29cbcb7f9c4d57a54360244849aa7d";
            this.Text75.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text75.Name = "Text75";
            this.Text75.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text75__GetValue);
            this.Text75.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text75.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text75.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 2, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text75.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text75.Font = new System.Drawing.Font("B Nazanin", 11F, System.Drawing.FontStyle.Bold);
            this.Text75.Indicator = null;
            this.Text75.Interaction = null;
            this.Text75.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text75.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text75.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text75.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text57
            // 
            this.Text57 = new Stimulsoft.Report.Components.StiText();
            this.Text57.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.1, 1.8, 0.3);
            this.Text57.Guid = "b201b3fd9ddf4aa2bdd13bb8147941a3";
            this.Text57.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text57.Name = "Text57";
            this.Text57.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text57__GetValue);
            this.Text57.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text57.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text57.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text57.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text57.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text57.Indicator = null;
            this.Text57.Interaction = null;
            this.Text57.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text57.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text57.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text69
            // 
            this.Text69 = new Stimulsoft.Report.Components.StiText();
            this.Text69.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.8, 0, 0.7, 0.5);
            this.Text69.Guid = "de5f315eb8994c4baf63fb1be21750f9";
            this.Text69.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text69.Name = "Text69";
            this.Text69.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text69__GetValue);
            this.Text69.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text69.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text69.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text69.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text69.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text69.Indicator = null;
            this.Text69.Interaction = null;
            this.Text69.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text69.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 12, 12, 12));
            this.Text69.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // HorizontalLine15
            // 
            this.HorizontalLine15 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine15.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.5, 7.7, 0.01);
            this.HorizontalLine15.Color = System.Drawing.Color.FromArgb(255, 81, 104, 36);
            this.HorizontalLine15.Guid = "fb2f8af0a19d4bf992bdb475ca18507f";
            this.HorizontalLine15.Name = "HorizontalLine15";
            this.HorizontalLine15.Size = 2F;
            this.HorizontalLine15.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine15.Interaction = null;
            this.HorizontalLine15.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // HorizontalLine16
            // 
            this.HorizontalLine16 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLine16.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.8, 7.7, 0.01);
            this.HorizontalLine16.Color = System.Drawing.Color.FromArgb(255, 81, 104, 36);
            this.HorizontalLine16.Guid = "8275c63d424840c8aee402baf448a223";
            this.HorizontalLine16.Name = "HorizontalLine16";
            this.HorizontalLine16.Size = 2F;
            this.HorizontalLine16.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLine16.Interaction = null;
            this.HorizontalLine16.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // StartPointPrimitive25
            // 
            this.StartPointPrimitive25 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive25.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.5, 0, 0, 0);
            this.StartPointPrimitive25.Guid = "29d99cf73e084330802cfa1ada328e08";
            this.StartPointPrimitive25.Name = "StartPointPrimitive25";
            this.StartPointPrimitive25.ReferenceToGuid = "047a6d30ee984ac5b8e55fc58e08cd6b";
            this.StartPointPrimitive25.Interaction = null;
            // 
            // EndPointPrimitive25
            // 
            this.EndPointPrimitive25 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive25.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.5, 1.1, 0, 0);
            this.InitializeComponent5();
        }
        
        public void InitializeComponent5()
        {
            this.EndPointPrimitive25.Guid = "d57b89c3a1074a8687f5e4e3a0e5791d";
            this.EndPointPrimitive25.Name = "EndPointPrimitive25";
            this.EndPointPrimitive25.ReferenceToGuid = "047a6d30ee984ac5b8e55fc58e08cd6b";
            this.EndPointPrimitive25.Interaction = null;
            // 
            // StartPointPrimitive26
            // 
            this.StartPointPrimitive26 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive26.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.2, 0, 0, 0);
            this.StartPointPrimitive26.Guid = "38f45d61cfac49ac9010c1fc09a90908";
            this.StartPointPrimitive26.Name = "StartPointPrimitive26";
            this.StartPointPrimitive26.ReferenceToGuid = "72c7c0222e254997baf17887d6247bbf";
            this.StartPointPrimitive26.Interaction = null;
            // 
            // EndPointPrimitive26
            // 
            this.EndPointPrimitive26 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive26.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.2, 0.8, 0, 0);
            this.EndPointPrimitive26.Guid = "462bb89250084fc9a7aa5cd0ba56363f";
            this.EndPointPrimitive26.Name = "EndPointPrimitive26";
            this.EndPointPrimitive26.ReferenceToGuid = "72c7c0222e254997baf17887d6247bbf";
            this.EndPointPrimitive26.Interaction = null;
            // 
            // StartPointPrimitive27
            // 
            this.StartPointPrimitive27 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive27.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.3, 0, 0, 0);
            this.StartPointPrimitive27.Guid = "7c8a8fbd7e574d5da96ad3ff7796966f";
            this.StartPointPrimitive27.Name = "StartPointPrimitive27";
            this.StartPointPrimitive27.ReferenceToGuid = "e20564259eff40ee96e413caa3ff6b15";
            this.StartPointPrimitive27.Interaction = null;
            // 
            // EndPointPrimitive27
            // 
            this.EndPointPrimitive27 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive27.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.3, 0.8, 0, 0);
            this.EndPointPrimitive27.Guid = "7d9b124e4da9416f81fd07539f12ea80";
            this.EndPointPrimitive27.Name = "EndPointPrimitive27";
            this.EndPointPrimitive27.ReferenceToGuid = "e20564259eff40ee96e413caa3ff6b15";
            this.EndPointPrimitive27.Interaction = null;
            // 
            // StartPointPrimitive28
            // 
            this.StartPointPrimitive28 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive28.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.3, 0, 0, 0);
            this.StartPointPrimitive28.Guid = "5ea28af64f3246bcad2f6d23a99c5b2b";
            this.StartPointPrimitive28.Name = "StartPointPrimitive28";
            this.StartPointPrimitive28.ReferenceToGuid = "d6a391599b944d88923cce6d574fdc4c";
            this.StartPointPrimitive28.Interaction = null;
            // 
            // EndPointPrimitive28
            // 
            this.EndPointPrimitive28 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive28.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.3, 0.8, 0, 0);
            this.EndPointPrimitive28.Guid = "177a53a5ff4645a7b3b07a26a0b544c9";
            this.EndPointPrimitive28.Name = "EndPointPrimitive28";
            this.EndPointPrimitive28.ReferenceToGuid = "d6a391599b944d88923cce6d574fdc4c";
            this.EndPointPrimitive28.Interaction = null;
            // 
            // StartPointPrimitive29
            // 
            this.StartPointPrimitive29 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive29.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.8, 0.5, 0, 0);
            this.StartPointPrimitive29.Guid = "71bcb8e956584ecbb10f541ca61971b8";
            this.StartPointPrimitive29.Name = "StartPointPrimitive29";
            this.StartPointPrimitive29.ReferenceToGuid = "b83912ac6f9e483e9862e7387caa07a6";
            this.StartPointPrimitive29.Interaction = null;
            // 
            // EndPointPrimitive29
            // 
            this.EndPointPrimitive29 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive29.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.8, 1.1, 0, 0);
            this.EndPointPrimitive29.Guid = "beddc20234d6436088f074c8b916a833";
            this.EndPointPrimitive29.Name = "EndPointPrimitive29";
            this.EndPointPrimitive29.ReferenceToGuid = "b83912ac6f9e483e9862e7387caa07a6";
            this.EndPointPrimitive29.Interaction = null;
            // 
            // StartPointPrimitive84
            // 
            this.StartPointPrimitive84 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive84.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.5, 0.1, 0, 0);
            this.StartPointPrimitive84.Name = "StartPointPrimitive84";
            this.StartPointPrimitive84.ReferenceToGuid = "047a6d30ee984ac5b8e55fc58e08cd6b";
            this.StartPointPrimitive84.Guid = null;
            this.StartPointPrimitive84.Interaction = null;
            // 
            // StartPointPrimitive85
            // 
            this.StartPointPrimitive85 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive85.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.2, 0.1, 0, 0);
            this.StartPointPrimitive85.Name = "StartPointPrimitive85";
            this.StartPointPrimitive85.ReferenceToGuid = "72c7c0222e254997baf17887d6247bbf";
            this.StartPointPrimitive85.Guid = null;
            this.StartPointPrimitive85.Interaction = null;
            // 
            // EndPointPrimitive81
            // 
            this.EndPointPrimitive81 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive81.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.2, 0.9, 0, 0);
            this.EndPointPrimitive81.Name = "EndPointPrimitive81";
            this.EndPointPrimitive81.ReferenceToGuid = "72c7c0222e254997baf17887d6247bbf";
            this.EndPointPrimitive81.Guid = null;
            this.EndPointPrimitive81.Interaction = null;
            // 
            // StartPointPrimitive86
            // 
            this.StartPointPrimitive86 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive86.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.8, 0.6, 0, 0);
            this.StartPointPrimitive86.Name = "StartPointPrimitive86";
            this.StartPointPrimitive86.ReferenceToGuid = "b83912ac6f9e483e9862e7387caa07a6";
            this.StartPointPrimitive86.Guid = null;
            this.StartPointPrimitive86.Interaction = null;
            // 
            // StartPointPrimitive88
            // 
            this.StartPointPrimitive88 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive88.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.8, 0.1, 0, 0);
            this.StartPointPrimitive88.Name = "StartPointPrimitive88";
            this.StartPointPrimitive88.ReferenceToGuid = "2fcaa5a9eca24fa3abb2076b952d3064";
            this.StartPointPrimitive88.Guid = null;
            this.StartPointPrimitive88.Interaction = null;
            // 
            // EndPointPrimitive84
            // 
            this.EndPointPrimitive84 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive84.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.8, 0.9, 0, 0);
            this.EndPointPrimitive84.Name = "EndPointPrimitive84";
            this.EndPointPrimitive84.ReferenceToGuid = "2fcaa5a9eca24fa3abb2076b952d3064";
            this.EndPointPrimitive84.Guid = null;
            this.EndPointPrimitive84.Interaction = null;
            // 
            // StartPointPrimitive90
            // 
            this.StartPointPrimitive90 = new Stimulsoft.Report.Components.StiStartPointPrimitive();
            this.StartPointPrimitive90.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.5, 0.1, 0, 0);
            this.StartPointPrimitive90.Name = "StartPointPrimitive90";
            this.StartPointPrimitive90.ReferenceToGuid = "815bbe224e0648219b94e49abd67fa90";
            this.StartPointPrimitive90.Guid = null;
            this.StartPointPrimitive90.Interaction = null;
            // 
            // EndPointPrimitive86
            // 
            this.EndPointPrimitive86 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive86.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.5, 0.9, 0, 0);
            this.EndPointPrimitive86.Name = "EndPointPrimitive86";
            this.EndPointPrimitive86.ReferenceToGuid = "815bbe224e0648219b94e49abd67fa90";
            this.EndPointPrimitive86.Guid = null;
            this.EndPointPrimitive86.Interaction = null;
            this.Panel5.Interaction = null;
            // 
            // ReportTitle1
            // 
            this.ReportTitle1 = new Stimulsoft.Report.Components.StiReportTitleBand();
            this.ReportTitle1.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.2, 7.72, 0.7);
            this.ReportTitle1.Guid = "50de75dc9ade4fe990b1a95cbe5469ef";
            this.ReportTitle1.Name = "ReportTitle1";
            this.ReportTitle1.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.ReportTitle1.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // Panel10
            // 
            this.Panel10 = new Stimulsoft.Report.Components.StiPanel();
            this.Panel10.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0, 7.7, 0.7);
            this.Panel10.Guid = "a8245371fcaf4bdaa69bc4b702587488";
            this.Panel10.Name = "Panel10";
            this.Panel10.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.DashDotDot, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Panel10.Brush = new Stimulsoft.Base.Drawing.StiEmptyBrush();
            // 
            // Text149
            // 
            this.Text149 = new Stimulsoft.Report.Components.StiText();
            this.Text149.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.4, 0.2, 2.6, 0.3);
            this.Text149.Guid = "f0e9278eb9714662a8a7aad8a8827326";
            this.Text149.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text149.Name = "Text149";
            this.Text149.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text149__GetValue);
            this.Text149.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text149.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text149.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text149.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text149.Font = new System.Drawing.Font("B Nazanin", 14F, System.Drawing.FontStyle.Bold);
            this.Text149.Indicator = null;
            this.Text149.Interaction = null;
            this.Text149.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text149.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 112, 192));
            this.Text149.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text150
            // 
            this.Text150 = new Stimulsoft.Report.Components.StiText();
            this.Text150.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0, 2, 0.4);
            this.Text150.Guid = "e7d5fb4658b9456180e31d46bb41c3d0";
            this.Text150.Name = "Text150";
            this.Text150.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text150__GetValue);
            this.Text150.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text150.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.Right, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.None, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text150.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text150.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text150.Indicator = null;
            this.Text150.Interaction = null;
            this.Text150.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text150.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text150.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            this.Panel10.Interaction = null;
            this.ReportTitle1.Interaction = null;
            // 
            // VerticalLine23
            // 
            this.VerticalLine23 = new Stimulsoft.Report.Components.StiVerticalLinePrimitive();
            this.VerticalLine23.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.8, 1.2, 0.01, 3.7);
            this.VerticalLine23.Color = System.Drawing.Color.FromArgb(255, 81, 104, 36);
            this.VerticalLine23.Guid = "de1a2db545064addaf8da20c591edf58";
            this.VerticalLine23.Name = "VerticalLine23";
            this.VerticalLine23.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.VerticalLine23.Interaction = null;
            this.VerticalLine23.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // VerticalLine20
            // 
            this.VerticalLine20 = new Stimulsoft.Report.Components.StiVerticalLinePrimitive();
            this.VerticalLine20.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.9, 1.2, 0.01, 3.7);
            this.VerticalLine20.Color = System.Drawing.Color.FromArgb(255, 81, 104, 36);
            this.VerticalLine20.Guid = "59a33bda2af7406da402b888263db083";
            this.VerticalLine20.Name = "VerticalLine20";
            this.VerticalLine20.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.VerticalLine20.Interaction = null;
            this.VerticalLine20.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            // 
            // EndPointPrimitive53
            // 
            this.EndPointPrimitive53 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive53.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.5, 6.8, 0, 0);
            this.EndPointPrimitive53.Name = "EndPointPrimitive53";
            this.EndPointPrimitive53.ReferenceToGuid = "b4507f6424854fd691280bbe4ba42fed";
            this.EndPointPrimitive53.Guid = null;
            this.EndPointPrimitive53.Interaction = null;
            // 
            // EndPointPrimitive57
            // 
            this.EndPointPrimitive57 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive57.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.8, 6.8, 0, 0);
            this.EndPointPrimitive57.Name = "EndPointPrimitive57";
            this.EndPointPrimitive57.ReferenceToGuid = "8f0a41934484495c9e39dd8c0cd61455";
            this.EndPointPrimitive57.Guid = null;
            this.EndPointPrimitive57.Interaction = null;
            // 
            // EndPointPrimitive58
            // 
            this.EndPointPrimitive58 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive58.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.5, 8.1, 0, 0);
            this.EndPointPrimitive58.Name = "EndPointPrimitive58";
            this.EndPointPrimitive58.ReferenceToGuid = "6ebc0f02dbd141109231c22a314afcbb";
            this.EndPointPrimitive58.Guid = null;
            this.EndPointPrimitive58.Interaction = null;
            // 
            // EndPointPrimitive79
            // 
            this.EndPointPrimitive79 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive79.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.8, 8.1, 0, 0);
            this.EndPointPrimitive79.Name = "EndPointPrimitive79";
            this.EndPointPrimitive79.ReferenceToGuid = "63803171f34a4f4eb405fc19ff8c90f1";
            this.EndPointPrimitive79.Guid = null;
            this.EndPointPrimitive79.Interaction = null;
            // 
            // EndPointPrimitive80
            // 
            this.EndPointPrimitive80 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive80.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.5, 9.4, 0, 0);
            this.EndPointPrimitive80.Name = "EndPointPrimitive80";
            this.EndPointPrimitive80.ReferenceToGuid = "047a6d30ee984ac5b8e55fc58e08cd6b";
            this.EndPointPrimitive80.Guid = null;
            this.EndPointPrimitive80.Interaction = null;
            // 
            // EndPointPrimitive82
            // 
            this.EndPointPrimitive82 = new Stimulsoft.Report.Components.StiEndPointPrimitive();
            this.EndPointPrimitive82.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.8, 9.4, 0, 0);
            this.EndPointPrimitive82.Name = "EndPointPrimitive82";
            this.EndPointPrimitive82.ReferenceToGuid = "b83912ac6f9e483e9862e7387caa07a6";
            this.EndPointPrimitive82.Guid = null;
            this.EndPointPrimitive82.Interaction = null;
            this.Page2.ExcelSheetValue = null;
            this.Page2.Interaction = null;
            this.Page2.Margins = new Stimulsoft.Report.Components.StiMargins(0.39, 0.39, 0.39, 0.39);
            this.Page2_Watermark = new Stimulsoft.Report.Components.StiWatermark();
            this.Page2_Watermark.Font = new System.Drawing.Font("Arial", 100F);
            this.Page2_Watermark.Image = null;
            this.Page2_Watermark.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(50, 0, 0, 0));
            // 
            // Page3
            // 
            this.Page3 = new Stimulsoft.Report.Components.StiPage();
            this.Page3.Guid = "2a1f779d9fd14295af1f5a4a8d1c0fb1";
            this.Page3.Name = "Page3";
            this.Page3.PageHeight = 11;
            this.Page3.PageWidth = 8.5;
            this.Page3.PaperSize = System.Drawing.Printing.PaperKind.Letter;
            this.Page3.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 2, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Page3.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // PageFooter2
            // 
            this.PageFooter2 = new Stimulsoft.Report.Components.StiPageFooterBand();
            this.PageFooter2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 9.82, 7.72, 0.4);
            this.PageFooter2.Guid = "2867e5c9106848e088e36a1eb3b2514c";
            this.PageFooter2.Name = "PageFooter2";
            this.PageFooter2.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.PageFooter2.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // Text136
            // 
            this.Text136 = new Stimulsoft.Report.Components.StiText();
            this.Text136.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.8, 0.1, 2.9, 0.3);
            this.Text136.ComponentStyle = "Collection_Page_Footer";
            this.Text136.Guid = "27c34b1e09054d0e9db65b3855920c02";
            this.Text136.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text136.Name = "Text136";
            this.Text136.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text136__GetValue);
            this.Text136.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text136.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text136.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text136.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text136.Font = new System.Drawing.Font("B Nazanin", 11F, System.Drawing.FontStyle.Bold);
            this.Text136.Indicator = null;
            this.Text136.Interaction = null;
            this.Text136.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text136.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 112, 48, 160));
            this.Text136.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text137
            // 
            this.Text137 = new Stimulsoft.Report.Components.StiText();
            this.Text137.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.2, 3.4, 0.3);
            this.Text137.ComponentStyle = "Collection_Page_Footer";
            this.Text137.Guid = "0ecffabb17b44ae2b0cccfed23445df6";
            this.Text137.Name = "Text137";
            this.Text137.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text137__GetValue);
            this.Text137.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text137.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text137.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text137.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text137.Indicator = null;
            this.Text137.Interaction = null;
            this.Text137.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text137.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text137.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            this.PageFooter2.Interaction = null;
            // 
            // Text138
            // 
            this.Text138 = new Stimulsoft.Report.Components.StiText();
            this.Text138.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(8.6, 3.5, 1, 0.3);
            this.Text138.Guid = "aa7bb6a49b8a447ea50d3085dfd1dd64";
            this.Text138.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text138.Name = "Text138";
            this.Text138.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text138__GetValue);
            this.Text138.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text138.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.All, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text138.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 181, 204, 136));
            this.Text138.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text138.Indicator = null;
            this.Text138.Interaction = null;
            this.Text138.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text138.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text138.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text139
            // 
            this.Text139 = new Stimulsoft.Report.Components.StiText();
            this.Text139.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(9.6, 3.5, 1, 0.3);
            this.Text139.Guid = "c8e69664fbe64468b1fdf452bb50dbdd";
            this.Text139.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text139.Name = "Text139";
            this.Text139.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text139__GetValue);
            this.Text139.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text139.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.All, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text139.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 181, 204, 136));
            this.Text139.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text139.Indicator = null;
            this.Text139.Interaction = null;
            this.Text139.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text139.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text139.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text140
            // 
            this.Text140 = new Stimulsoft.Report.Components.StiText();
            this.Text140.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(8.6, 4.2, 1, 0.3);
            this.Text140.Guid = "e2d18b9c27cc42679a010e31081de702";
            this.Text140.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text140.Name = "Text140";
            this.Text140.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text140__GetValue);
            this.Text140.Type = Stimulsoft.Report.Components.StiSystemTextType.DataColumn;
            this.Text140.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text140.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text140.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text140.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text140.Indicator = null;
            this.Text140.Interaction = null;
            this.Text140.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text140.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text140.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text141
            // 
            this.Text141 = new Stimulsoft.Report.Components.StiText();
            this.Text141.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(9.6, 4.2, 1, 0.3);
            this.Text141.Guid = "4acb3b2aad69434fbc3ee6ebf69bdace";
            this.Text141.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text141.Name = "Text141";
            this.Text141.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text141__GetValue);
            this.Text141.Type = Stimulsoft.Report.Components.StiSystemTextType.DataColumn;
            this.Text141.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text141.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text141.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text141.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text141.Indicator = null;
            this.Text141.Interaction = null;
            this.Text141.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text141.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text141.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Panel8
            // 
            this.Panel8 = new Stimulsoft.Report.Components.StiPanel();
            this.Panel8.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 1.1, 7.7, 6);
            this.Panel8.Name = "Panel8";
            this.Panel8.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Panel8.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // Text142
            // 
            this.Text142 = new Stimulsoft.Report.Components.StiText();
            this.Text142.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.2, 0.2, 3.4, 0.2);
            this.Text142.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text142.Name = "Text142";
            this.Text142.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text142__GetValue);
            this.Text142.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text142.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text142.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text142.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text142.Font = new System.Drawing.Font("B Nazanin", 14F, System.Drawing.FontStyle.Bold);
            this.Text142.Guid = null;
            this.Text142.Indicator = null;
            this.Text142.Interaction = null;
            this.Text142.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text142.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text142.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text143
            // 
            this.Text143 = new Stimulsoft.Report.Components.StiText();
            this.Text143.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.2, 1.3, 5.3, 0.4);
            this.Text143.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text143.Name = "Text143";
            this.Text143.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text143__GetValue);
            this.Text143.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text143.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text143.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text143.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text143.Font = new System.Drawing.Font("B Nazanin", 14F);
            this.Text143.Guid = null;
            this.Text143.Indicator = null;
            this.Text143.Interaction = null;
            this.Text143.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text143.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text143.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text148
            // 
            this.Text148 = new Stimulsoft.Report.Components.StiText();
            this.Text148.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.6, 7.5, 0.8);
            this.Text148.Guid = "2ff51e4b4ff94e0a91927ebfe56e5811";
            this.Text148.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text148.Name = "Text148";
            this.Text148.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text148__GetValue);
            this.Text148.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text148.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text148.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text148.Font = new System.Drawing.Font("B Nazanin", 14F);
            this.Text148.Indicator = null;
            this.Text148.Interaction = null;
            this.Text148.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text148.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text148.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text144
            // 
            this.Text144 = new Stimulsoft.Report.Components.StiText();
            this.Text144.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 1.7, 7.5, 0.9);
            this.Text144.Guid = "6c9fca4a6e3145c7a173de40cbdc1f95";
            this.Text144.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text144.Name = "Text144";
            this.Text144.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text144__GetValue);
            this.Text144.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text144.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text144.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text144.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text144.Font = new System.Drawing.Font("B Nazanin", 14F);
            this.Text144.Indicator = null;
            this.Text144.Interaction = null;
            this.Text144.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text144.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text144.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text145
            // 
            this.Text145 = new Stimulsoft.Report.Components.StiText();
            this.Text145.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.2, 2.8, 5.3, 0.3);
            this.Text145.Guid = "8895e12e646d4dbbb516f21e406baf10";
            this.Text145.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text145.Name = "Text145";
            this.Text145.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text145__GetValue);
            this.Text145.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text145.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text145.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text145.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text145.Font = new System.Drawing.Font("B Nazanin", 14F);
            this.Text145.Indicator = null;
            this.Text145.Interaction = null;
            this.Text145.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text145.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text145.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text146
            // 
            this.Text146 = new Stimulsoft.Report.Components.StiText();
            this.Text146.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 3.2, 7.5, 0.5);
            this.Text146.Guid = "fa23363f427b4c0fa5d2562bd6a1cc73";
            this.Text146.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text146.Name = "Text146";
            this.Text146.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text146__GetValue);
            this.Text146.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text146.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text146.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text146.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text146.Font = new System.Drawing.Font("B Nazanin", 14F);
            this.Text146.Indicator = null;
            this.Text146.Interaction = null;
            this.Text146.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text146.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text146.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text147
            // 
            this.Text147 = new Stimulsoft.Report.Components.StiText();
            this.Text147.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.2, 3.8, 5.3, 0.3);
            this.Text147.Guid = "618f927c369b41f49ced9d86def1d037";
            this.Text147.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text147.Name = "Text147";
            this.Text147.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text147__GetValue);
            this.Text147.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text147.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text147.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text147.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text147.Font = new System.Drawing.Font("B Nazanin", 14F);
            this.Text147.Indicator = null;
            this.Text147.Interaction = null;
            this.Text147.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text147.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text147.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text151
            // 
            this.Text151 = new Stimulsoft.Report.Components.StiText();
            this.Text151.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.2, 4.2, 5.3, 0.3);
            this.Text151.Guid = "282d9c5973994fc6af78afc67823ed52";
            this.Text151.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text151.Name = "Text151";
            this.Text151.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text151__GetValue);
            this.Text151.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text151.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text151.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text151.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text151.Font = new System.Drawing.Font("B Nazanin", 14F);
            this.Text151.Indicator = null;
            this.Text151.Interaction = null;
            this.Text151.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text151.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text151.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Image2
            // 
            this.Image2 = new Stimulsoft.Report.Components.StiImage();
            this.Image2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(7.5, 0.6, 0.2, 0.3);
            this.Image2.Guid = "e7c67f014dcd49409ce24887dc2ab692";
            this.Image2.HorAlignment = Stimulsoft.Base.Drawing.StiHorAlignment.Right;
            this.Image2.Image = StiImageConverter.StringToImage("iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAABGdBTUEAALGPC/xhBQAAAHVQTFRF////AAAA09PTxcXFoKCgaGholJSUo6Oj2NjYr6+vzs7O5OTkfn5++vr6b29vqampKioq3t7e9PT0v7+/6urqU1NTmZmZt7e3Xl5egoKCOjo6dXV1QkJC7u7u9vb2CgoKV1dXGxsbSkpKFRUVMDAwioqKRkZGVfFAEAAAA6hJREFUeF7t3OlS4kAUBWAGAwJiQAFRFsUF3/8Rp5g5KUZlSUjfc2+mzvdX6dNdgSS9tkRERERERERERERERERERERERERERESqu2/Pu8vN4v3XzsvHLO/2B2v8rfl6WedPw37aPAzwP8313D/WusJm1ORrOZ+hGaetRrf4QLPcDNGAMvIePtUc7XKXb29xhU82Q+8T9a5i3Jw2Tjeoc1WrO5QQ3Bb1vcQSZUTWfkFlLzRBOWE9oaKX66CkmKZjVLOWwE+OCapY1wjlhdNFBevLUWIw595Aq/hEmaG8oXJpjOO9qi5QtVTen1FwFKkbGK6Jl7yHnvOKskN4RKXSWqD0AOq/yBz2iPLd9VGh9LpIcHaH6liI0WVEZWzcI8RTyleZnwLcbVK9bR/zgBw3t6iInSmSvNh+R3dWSHLSRjUszZHlI0mf/hxkuZijDrY8n/uogjW/vqLd69pXW+Tx1RwaLc/rIlo/7PcyJLKtkE+ARLIbpDP49DHqzMBU5dMXRjiHx71mgGyOPlKZqkzT1zdDKhOiWfhfU8vRmUP4d9NrJLM8IZfHZhD4uDFyeRDMw/4hTpHLw17kx3vrLlwjmeUBuTzspTY5cnnYY27EnlMBySxIZSLfTJHKxB38vkcqE3epFLN/X+C+mfaQysRdtciYr/iOO3+hFlpQC9Ni9/B3uPdSfueJ3X3yeOKTtyoglYm8A4w2sbaHZJa0K4JLQTILd8R7hz3qzR4u5Q+YcudldthzM/zHBX0nDf1milyeJYJZ+HtMWGtpCvyFU" +
"Wsks7SRS0RZtLeHVKZ0O9XK8NjNxu0iuiyoeUU4BTK5MoQzDJHJxXytcdqob7+KveC164I38O22SZ82iYg8PlYXymNRG5AuItI8cIa+XbeUMFZGfSDLB6OH4XxMhv26Gvcja8w7UcjxYz2j77NK/wvb72mIY5UsB/hjnKtguVHWe4ss2PX2A/wI/7JabOq+j3vPprvv07E/wmIPVLBjzdLPJ4Y52KSQ+gSXcA1MPUIc8gDFlHM1QQ6m+S7doIZrn/eUdaKORuRjTFPMmwa8x/zrCtW8nOPAWjm39UbC3yIcm3TOoMakVPgTaGGE+lYV9Blx0CWP/6doZ0GeUbW70W1Y+3Ym5Y9lX4R9xJ+xzj7QhFNeuzf4/0aajk4P/M+yRjcPeqPloWs5zq8dlgHZmQ7m2XaYdzqdfLjN5oP/4dKJiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIFW6zfFADwrMxMCHQAAAABJRU5ErkJggg==");
            this.Image2.Name = "Image2";
            this.Image2.Stretch = true;
            this.Image2.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Image2.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Image2.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Image2.Interaction = null;
            // 
            // Image3
            // 
            this.Image3 = new Stimulsoft.Report.Components.StiImage();
            this.Image3.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(7.5, 1.4, 0.2, 0.3);
            this.Image3.Guid = "5fc7a385474647f4b87797410e1ebe90";
            this.Image3.HorAlignment = Stimulsoft.Base.Drawing.StiHorAlignment.Right;
            this.Image3.Image = StiImageConverter.StringToImage("iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAABGdBTUEAALGPC/xhBQAAAHVQTFRF////AAAA09PTxcXFoKCgaGholJSUo6Oj2NjYr6+vzs7O5OTkfn5++vr6b29vqampKioq3t7e9PT0v7+/6urqU1NTmZmZt7e3Xl5egoKCOjo6dXV1QkJC7u7u9vb2CgoKV1dXGxsbSkpKFRUVMDAwioqKRkZGVfFAEAAAA6hJREFUeF7t3OlS4kAUBWAGAwJiQAFRFsUF3/8Rp5g5KUZlSUjfc2+mzvdX6dNdgSS9tkRERERERERERERERERERERERERERESqu2/Pu8vN4v3XzsvHLO/2B2v8rfl6WedPw37aPAzwP8313D/WusJm1ORrOZ+hGaetRrf4QLPcDNGAMvIePtUc7XKXb29xhU82Q+8T9a5i3Jw2Tjeoc1WrO5QQ3Bb1vcQSZUTWfkFlLzRBOWE9oaKX66CkmKZjVLOWwE+OCapY1wjlhdNFBevLUWIw595Aq/hEmaG8oXJpjOO9qi5QtVTen1FwFKkbGK6Jl7yHnvOKskN4RKXSWqD0AOq/yBz2iPLd9VGh9LpIcHaH6liI0WVEZWzcI8RTyleZnwLcbVK9bR/zgBw3t6iInSmSvNh+R3dWSHLSRjUszZHlI0mf/hxkuZijDrY8n/uogjW/vqLd69pXW+Tx1RwaLc/rIlo/7PcyJLKtkE+ARLIbpDP49DHqzMBU5dMXRjiHx71mgGyOPlKZqkzT1zdDKhOiWfhfU8vRmUP4d9NrJLM8IZfHZhD4uDFyeRDMw/4hTpHLw17kx3vrLlwjmeUBuTzspTY5cnnYY27EnlMBySxIZSLfTJHKxB38vkcqE3epFLN/X+C+mfaQysRdtciYr/iOO3+hFlpQC9Ni9/B3uPdSfueJ3X3yeOKTtyoglYm8A4w2sbaHZJa0K4JLQTILd8R7hz3qzR4u5Q+YcudldthzM/zHBX0nDf1milyeJYJZ+HtMWGtpCvyFU" +
"Wsks7SRS0RZtLeHVKZ0O9XK8NjNxu0iuiyoeUU4BTK5MoQzDJHJxXytcdqob7+KveC164I38O22SZ82iYg8PlYXymNRG5AuItI8cIa+XbeUMFZGfSDLB6OH4XxMhv26Gvcja8w7UcjxYz2j77NK/wvb72mIY5UsB/hjnKtguVHWe4ss2PX2A/wI/7JabOq+j3vPprvv07E/wmIPVLBjzdLPJ4Y52KSQ+gSXcA1MPUIc8gDFlHM1QQ6m+S7doIZrn/eUdaKORuRjTFPMmwa8x/zrCtW8nOPAWjm39UbC3yIcm3TOoMakVPgTaGGE+lYV9Blx0CWP/6doZ0GeUbW70W1Y+3Ym5Y9lX4R9xJ+xzj7QhFNeuzf4/0aajk4P/M+yRjcPeqPloWs5zq8dlgHZmQ7m2XaYdzqdfLjN5oP/4dKJiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIFW6zfFADwrMxMCHQAAAABJRU5ErkJggg==");
            this.Image3.Name = "Image3";
            this.Image3.Stretch = true;
            this.Image3.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Image3.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Image3.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Image3.Interaction = null;
            // 
            // Image4
            // 
            this.Image4 = new Stimulsoft.Report.Components.StiImage();
            this.Image4.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(7.5, 1.7, 0.2, 0.3);
            this.Image4.Guid = "779ff8ad6f5543569e8064ad088bf3c3";
            this.Image4.HorAlignment = Stimulsoft.Base.Drawing.StiHorAlignment.Right;
            this.Image4.Image = StiImageConverter.StringToImage("iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAABGdBTUEAALGPC/xhBQAAAHVQTFRF////AAAA09PTxcXFoKCgaGholJSUo6Oj2NjYr6+vzs7O5OTkfn5++vr6b29vqampKioq3t7e9PT0v7+/6urqU1NTmZmZt7e3Xl5egoKCOjo6dXV1QkJC7u7u9vb2CgoKV1dXGxsbSkpKFRUVMDAwioqKRkZGVfFAEAAAA6hJREFUeF7t3OlS4kAUBWAGAwJiQAFRFsUF3/8Rp5g5KUZlSUjfc2+mzvdX6dNdgSS9tkRERERERERERERERERERERERERERESqu2/Pu8vN4v3XzsvHLO/2B2v8rfl6WedPw37aPAzwP8313D/WusJm1ORrOZ+hGaetRrf4QLPcDNGAMvIePtUc7XKXb29xhU82Q+8T9a5i3Jw2Tjeoc1WrO5QQ3Bb1vcQSZUTWfkFlLzRBOWE9oaKX66CkmKZjVLOWwE+OCapY1wjlhdNFBevLUWIw595Aq/hEmaG8oXJpjOO9qi5QtVTen1FwFKkbGK6Jl7yHnvOKskN4RKXSWqD0AOq/yBz2iPLd9VGh9LpIcHaH6liI0WVEZWzcI8RTyleZnwLcbVK9bR/zgBw3t6iInSmSvNh+R3dWSHLSRjUszZHlI0mf/hxkuZijDrY8n/uogjW/vqLd69pXW+Tx1RwaLc/rIlo/7PcyJLKtkE+ARLIbpDP49DHqzMBU5dMXRjiHx71mgGyOPlKZqkzT1zdDKhOiWfhfU8vRmUP4d9NrJLM8IZfHZhD4uDFyeRDMw/4hTpHLw17kx3vrLlwjmeUBuTzspTY5cnnYY27EnlMBySxIZSLfTJHKxB38vkcqE3epFLN/X+C+mfaQysRdtciYr/iOO3+hFlpQC9Ni9/B3uPdSfueJ3X3yeOKTtyoglYm8A4w2sbaHZJa0K4JLQTILd8R7hz3qzR4u5Q+YcudldthzM/zHBX0nDf1milyeJYJZ+HtMWGtpCvyFU" +
"Wsks7SRS0RZtLeHVKZ0O9XK8NjNxu0iuiyoeUU4BTK5MoQzDJHJxXytcdqob7+KveC164I38O22SZ82iYg8PlYXymNRG5AuItI8cIa+XbeUMFZGfSDLB6OH4XxMhv26Gvcja8w7UcjxYz2j77NK/wvb72mIY5UsB/hjnKtguVHWe4ss2PX2A/wI/7JabOq+j3vPprvv07E/wmIPVLBjzdLPJ4Y52KSQ+gSXcA1MPUIc8gDFlHM1QQ6m+S7doIZrn/eUdaKORuRjTFPMmwa8x/zrCtW8nOPAWjm39UbC3yIcm3TOoMakVPgTaGGE+lYV9Blx0CWP/6doZ0GeUbW70W1Y+3Ym5Y9lX4R9xJ+xzj7QhFNeuzf4/0aajk4P/M+yRjcPeqPloWs5zq8dlgHZmQ7m2XaYdzqdfLjN5oP/4dKJiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIFW6zfFADwrMxMCHQAAAABJRU5ErkJggg==");
            this.Image4.Name = "Image4";
            this.Image4.Stretch = true;
            this.Image4.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Image4.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Image4.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Image4.Interaction = null;
            // 
            // Image5
            // 
            this.Image5 = new Stimulsoft.Report.Components.StiImage();
            this.Image5.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(7.5, 2.8, 0.2, 0.3);
            this.Image5.Guid = "43ca223731744068ae443f124f978331";
            this.Image5.HorAlignment = Stimulsoft.Base.Drawing.StiHorAlignment.Right;
            this.Image5.Image = StiImageConverter.StringToImage("iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAABGdBTUEAALGPC/xhBQAAAHVQTFRF////AAAA09PTxcXFoKCgaGholJSUo6Oj2NjYr6+vzs7O5OTkfn5++vr6b29vqampKioq3t7e9PT0v7+/6urqU1NTmZmZt7e3Xl5egoKCOjo6dXV1QkJC7u7u9vb2CgoKV1dXGxsbSkpKFRUVMDAwioqKRkZGVfFAEAAAA6hJREFUeF7t3OlS4kAUBWAGAwJiQAFRFsUF3/8Rp5g5KUZlSUjfc2+mzvdX6dNdgSS9tkRERERERERERERERERERERERERERESqu2/Pu8vN4v3XzsvHLO/2B2v8rfl6WedPw37aPAzwP8313D/WusJm1ORrOZ+hGaetRrf4QLPcDNGAMvIePtUc7XKXb29xhU82Q+8T9a5i3Jw2Tjeoc1WrO5QQ3Bb1vcQSZUTWfkFlLzRBOWE9oaKX66CkmKZjVLOWwE+OCapY1wjlhdNFBevLUWIw595Aq/hEmaG8oXJpjOO9qi5QtVTen1FwFKkbGK6Jl7yHnvOKskN4RKXSWqD0AOq/yBz2iPLd9VGh9LpIcHaH6liI0WVEZWzcI8RTyleZnwLcbVK9bR/zgBw3t6iInSmSvNh+R3dWSHLSRjUszZHlI0mf/hxkuZijDrY8n/uogjW/vqLd69pXW+Tx1RwaLc/rIlo/7PcyJLKtkE+ARLIbpDP49DHqzMBU5dMXRjiHx71mgGyOPlKZqkzT1zdDKhOiWfhfU8vRmUP4d9NrJLM8IZfHZhD4uDFyeRDMw/4hTpHLw17kx3vrLlwjmeUBuTzspTY5cnnYY27EnlMBySxIZSLfTJHKxB38vkcqE3epFLN/X+C+mfaQysRdtciYr/iOO3+hFlpQC9Ni9/B3uPdSfueJ3X3yeOKTtyoglYm8A4w2sbaHZJa0K4JLQTILd8R7hz3qzR4u5Q+YcudldthzM/zHBX0nDf1milyeJYJZ+HtMWGtpCvyFU" +
"Wsks7SRS0RZtLeHVKZ0O9XK8NjNxu0iuiyoeUU4BTK5MoQzDJHJxXytcdqob7+KveC164I38O22SZ82iYg8PlYXymNRG5AuItI8cIa+XbeUMFZGfSDLB6OH4XxMhv26Gvcja8w7UcjxYz2j77NK/wvb72mIY5UsB/hjnKtguVHWe4ss2PX2A/wI/7JabOq+j3vPprvv07E/wmIPVLBjzdLPJ4Y52KSQ+gSXcA1MPUIc8gDFlHM1QQ6m+S7doIZrn/eUdaKORuRjTFPMmwa8x/zrCtW8nOPAWjm39UbC3yIcm3TOoMakVPgTaGGE+lYV9Blx0CWP/6doZ0GeUbW70W1Y+3Ym5Y9lX4R9xJ+xzj7QhFNeuzf4/0aajk4P/M+yRjcPeqPloWs5zq8dlgHZmQ7m2XaYdzqdfLjN5oP/4dKJiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIFW6zfFADwrMxMCHQAAAABJRU5ErkJggg==");
            this.Image5.Name = "Image5";
            this.Image5.Stretch = true;
            this.Image5.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Image5.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Image5.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Image5.Interaction = null;
            // 
            // Image6
            // 
            this.Image6 = new Stimulsoft.Report.Components.StiImage();
            this.Image6.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(7.5, 3.2, 0.2, 0.3);
            this.Image6.Guid = "ea785fdab5cb4ac7a39a7f33d8d6bb74";
            this.Image6.HorAlignment = Stimulsoft.Base.Drawing.StiHorAlignment.Right;
            this.Image6.Image = StiImageConverter.StringToImage("iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAABGdBTUEAALGPC/xhBQAAAHVQTFRF////AAAA09PTxcXFoKCgaGholJSUo6Oj2NjYr6+vzs7O5OTkfn5++vr6b29vqampKioq3t7e9PT0v7+/6urqU1NTmZmZt7e3Xl5egoKCOjo6dXV1QkJC7u7u9vb2CgoKV1dXGxsbSkpKFRUVMDAwioqKRkZGVfFAEAAAA6hJREFUeF7t3OlS4kAUBWAGAwJiQAFRFsUF3/8Rp5g5KUZlSUjfc2+mzvdX6dNdgSS9tkRERERERERERERERERERERERERERESqu2/Pu8vN4v3XzsvHLO/2B2v8rfl6WedPw37aPAzwP8313D/WusJm1ORrOZ+hGaetRrf4QLPcDNGAMvIePtUc7XKXb29xhU82Q+8T9a5i3Jw2Tjeoc1WrO5QQ3Bb1vcQSZUTWfkFlLzRBOWE9oaKX66CkmKZjVLOWwE+OCapY1wjlhdNFBevLUWIw595Aq/hEmaG8oXJpjOO9qi5QtVTen1FwFKkbGK6Jl7yHnvOKskN4RKXSWqD0AOq/yBz2iPLd9VGh9LpIcHaH6liI0WVEZWzcI8RTyleZnwLcbVK9bR/zgBw3t6iInSmSvNh+R3dWSHLSRjUszZHlI0mf/hxkuZijDrY8n/uogjW/vqLd69pXW+Tx1RwaLc/rIlo/7PcyJLKtkE+ARLIbpDP49DHqzMBU5dMXRjiHx71mgGyOPlKZqkzT1zdDKhOiWfhfU8vRmUP4d9NrJLM8IZfHZhD4uDFyeRDMw/4hTpHLw17kx3vrLlwjmeUBuTzspTY5cnnYY27EnlMBySxIZSLfTJHKxB38vkcqE3epFLN/X+C+mfaQysRdtciYr/iOO3+hFlpQC9Ni9/B3uPdSfueJ3X3yeOKTtyoglYm8A4w2sbaHZJa0K4JLQTILd8R7hz3qzR4u5Q+YcudldthzM/zHBX0nDf1milyeJYJZ+HtMWGtpCvyFU" +
"Wsks7SRS0RZtLeHVKZ0O9XK8NjNxu0iuiyoeUU4BTK5MoQzDJHJxXytcdqob7+KveC164I38O22SZ82iYg8PlYXymNRG5AuItI8cIa+XbeUMFZGfSDLB6OH4XxMhv26Gvcja8w7UcjxYz2j77NK/wvb72mIY5UsB/hjnKtguVHWe4ss2PX2A/wI/7JabOq+j3vPprvv07E/wmIPVLBjzdLPJ4Y52KSQ+gSXcA1MPUIc8gDFlHM1QQ6m+S7doIZrn/eUdaKORuRjTFPMmwa8x/zrCtW8nOPAWjm39UbC3yIcm3TOoMakVPgTaGGE+lYV9Blx0CWP/6doZ0GeUbW70W1Y+3Ym5Y9lX4R9xJ+xzj7QhFNeuzf4/0aajk4P/M+yRjcPeqPloWs5zq8dlgHZmQ7m2XaYdzqdfLjN5oP/4dKJiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIFW6zfFADwrMxMCHQAAAABJRU5ErkJggg==");
            this.Image6.Name = "Image6";
            this.Image6.Stretch = true;
            this.Image6.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Image6.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Image6.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Image6.Interaction = null;
            // 
            // Image7
            // 
            this.Image7 = new Stimulsoft.Report.Components.StiImage();
            this.Image7.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(7.5, 3.8, 0.2, 0.3);
            this.Image7.Guid = "7e995af2e71944c4b204c5bab31c0dd2";
            this.Image7.HorAlignment = Stimulsoft.Base.Drawing.StiHorAlignment.Right;
            this.Image7.Image = StiImageConverter.StringToImage("iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAABGdBTUEAALGPC/xhBQAAAHVQTFRF////AAAA09PTxcXFoKCgaGholJSUo6Oj2NjYr6+vzs7O5OTkfn5++vr6b29vqampKioq3t7e9PT0v7+/6urqU1NTmZmZt7e3Xl5egoKCOjo6dXV1QkJC7u7u9vb2CgoKV1dXGxsbSkpKFRUVMDAwioqKRkZGVfFAEAAAA6hJREFUeF7t3OlS4kAUBWAGAwJiQAFRFsUF3/8Rp5g5KUZlSUjfc2+mzvdX6dNdgSS9tkRERERERERERERERERERERERERERESqu2/Pu8vN4v3XzsvHLO/2B2v8rfl6WedPw37aPAzwP8313D/WusJm1ORrOZ+hGaetRrf4QLPcDNGAMvIePtUc7XKXb29xhU82Q+8T9a5i3Jw2Tjeoc1WrO5QQ3Bb1vcQSZUTWfkFlLzRBOWE9oaKX66CkmKZjVLOWwE+OCapY1wjlhdNFBevLUWIw595Aq/hEmaG8oXJpjOO9qi5QtVTen1FwFKkbGK6Jl7yHnvOKskN4RKXSWqD0AOq/yBz2iPLd9VGh9LpIcHaH6liI0WVEZWzcI8RTyleZnwLcbVK9bR/zgBw3t6iInSmSvNh+R3dWSHLSRjUszZHlI0mf/hxkuZijDrY8n/uogjW/vqLd69pXW+Tx1RwaLc/rIlo/7PcyJLKtkE+ARLIbpDP49DHqzMBU5dMXRjiHx71mgGyOPlKZqkzT1zdDKhOiWfhfU8vRmUP4d9NrJLM8IZfHZhD4uDFyeRDMw/4hTpHLw17kx3vrLlwjmeUBuTzspTY5cnnYY27EnlMBySxIZSLfTJHKxB38vkcqE3epFLN/X+C+mfaQysRdtciYr/iOO3+hFlpQC9Ni9/B3uPdSfueJ3X3yeOKTtyoglYm8A4w2sbaHZJa0K4JLQTILd8R7hz3qzR4u5Q+YcudldthzM/zHBX0nDf1milyeJYJZ+HtMWGtpCvyFU" +
"Wsks7SRS0RZtLeHVKZ0O9XK8NjNxu0iuiyoeUU4BTK5MoQzDJHJxXytcdqob7+KveC164I38O22SZ82iYg8PlYXymNRG5AuItI8cIa+XbeUMFZGfSDLB6OH4XxMhv26Gvcja8w7UcjxYz2j77NK/wvb72mIY5UsB/hjnKtguVHWe4ss2PX2A/wI/7JabOq+j3vPprvv07E/wmIPVLBjzdLPJ4Y52KSQ+gSXcA1MPUIc8gDFlHM1QQ6m+S7doIZrn/eUdaKORuRjTFPMmwa8x/zrCtW8nOPAWjm39UbC3yIcm3TOoMakVPgTaGGE+lYV9Blx0CWP/6doZ0GeUbW70W1Y+3Ym5Y9lX4R9xJ+xzj7QhFNeuzf4/0aajk4P/M+yRjcPeqPloWs5zq8dlgHZmQ7m2XaYdzqdfLjN5oP/4dKJiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIFW6zfFADwrMxMCHQAAAABJRU5ErkJggg==");
            this.Image7.Name = "Image7";
            this.Image7.Stretch = true;
            this.Image7.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Image7.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Image7.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Image7.Interaction = null;
            // 
            // Image8
            // 
            this.Image8 = new Stimulsoft.Report.Components.StiImage();
            this.Image8.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(7.5, 4.2, 0.2, 0.3);
            this.Image8.Guid = "84e47bc34712446985dfa6838836f0c4";
            this.Image8.HorAlignment = Stimulsoft.Base.Drawing.StiHorAlignment.Right;
            this.Image8.Image = StiImageConverter.StringToImage("iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAABGdBTUEAALGPC/xhBQAAAHVQTFRF////AAAA09PTxcXFoKCgaGholJSUo6Oj2NjYr6+vzs7O5OTkfn5++vr6b29vqampKioq3t7e9PT0v7+/6urqU1NTmZmZt7e3Xl5egoKCOjo6dXV1QkJC7u7u9vb2CgoKV1dXGxsbSkpKFRUVMDAwioqKRkZGVfFAEAAAA6hJREFUeF7t3OlS4kAUBWAGAwJiQAFRFsUF3/8Rp5g5KUZlSUjfc2+mzvdX6dNdgSS9tkRERERERERERERERERERERERERERESqu2/Pu8vN4v3XzsvHLO/2B2v8rfl6WedPw37aPAzwP8313D/WusJm1ORrOZ+hGaetRrf4QLPcDNGAMvIePtUc7XKXb29xhU82Q+8T9a5i3Jw2Tjeoc1WrO5QQ3Bb1vcQSZUTWfkFlLzRBOWE9oaKX66CkmKZjVLOWwE+OCapY1wjlhdNFBevLUWIw595Aq/hEmaG8oXJpjOO9qi5QtVTen1FwFKkbGK6Jl7yHnvOKskN4RKXSWqD0AOq/yBz2iPLd9VGh9LpIcHaH6liI0WVEZWzcI8RTyleZnwLcbVK9bR/zgBw3t6iInSmSvNh+R3dWSHLSRjUszZHlI0mf/hxkuZijDrY8n/uogjW/vqLd69pXW+Tx1RwaLc/rIlo/7PcyJLKtkE+ARLIbpDP49DHqzMBU5dMXRjiHx71mgGyOPlKZqkzT1zdDKhOiWfhfU8vRmUP4d9NrJLM8IZfHZhD4uDFyeRDMw/4hTpHLw17kx3vrLlwjmeUBuTzspTY5cnnYY27EnlMBySxIZSLfTJHKxB38vkcqE3epFLN/X+C+mfaQysRdtciYr/iOO3+hFlpQC9Ni9/B3uPdSfueJ3X3yeOKTtyoglYm8A4w2sbaHZJa0K4JLQTILd8R7hz3qzR4u5Q+YcudldthzM/zHBX0nDf1milyeJYJZ+HtMWGtpCvyFU" +
"Wsks7SRS0RZtLeHVKZ0O9XK8NjNxu0iuiyoeUU4BTK5MoQzDJHJxXytcdqob7+KveC164I38O22SZ82iYg8PlYXymNRG5AuItI8cIa+XbeUMFZGfSDLB6OH4XxMhv26Gvcja8w7UcjxYz2j77NK/wvb72mIY5UsB/hjnKtguVHWe4ss2PX2A/wI/7JabOq+j3vPprvv07E/wmIPVLBjzdLPJ4Y52KSQ+gSXcA1MPUIc8gDFlHM1QQ6m+S7doIZrn/eUdaKORuRjTFPMmwa8x/zrCtW8nOPAWjm39UbC3yIcm3TOoMakVPgTaGGE+lYV9Blx0CWP/6doZ0GeUbW70W1Y+3Ym5Y9lX4R9xJ+xzj7QhFNeuzf4/0aajk4P/M+yRjcPeqPloWs5zq8dlgHZmQ7m2XaYdzqdfLjN5oP/4dKJiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIFW6zfFADwrMxMCHQAAAABJRU5ErkJggg==");
            this.Image8.Name = "Image8";
            this.Image8.Stretch = true;
            this.Image8.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Image8.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Image8.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Image8.Interaction = null;
            this.Panel8.Guid = null;
            this.Panel8.Interaction = null;
            // 
            // ReportTitle2
            // 
            this.ReportTitle2 = new Stimulsoft.Report.Components.StiReportTitleBand();
            this.ReportTitle2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.2, 7.72, 0.7);
            this.ReportTitle2.Guid = "bb8be3884f104367aab770660b4d7b80";
            this.ReportTitle2.Name = "ReportTitle2";
            this.ReportTitle2.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.ReportTitle2.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // Panel13
            // 
            this.Panel13 = new Stimulsoft.Report.Components.StiPanel();
            this.Panel13.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0, 7.7, 0.7);
            this.Panel13.Guid = "91b4eef7a7314be3986fb10611e316fa";
            this.Panel13.Name = "Panel13";
            this.Panel13.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.DashDotDot, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Panel13.Brush = new Stimulsoft.Base.Drawing.StiEmptyBrush();
            // 
            // Text209
            // 
            this.Text209 = new Stimulsoft.Report.Components.StiText();
            this.Text209.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.4, 0.2, 2.6, 0.3);
            this.Text209.Guid = "1974ef6bf54141eaa0cce8fd1c3bc661";
            this.Text209.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text209.Name = "Text209";
            this.Text209.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text209__GetValue);
            this.Text209.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text209.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text209.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text209.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text209.Font = new System.Drawing.Font("B Nazanin", 14F, System.Drawing.FontStyle.Bold);
            this.Text209.Indicator = null;
            this.Text209.Interaction = null;
            this.Text209.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text209.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 112, 192));
            this.Text209.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text210
            // 
            this.Text210 = new Stimulsoft.Report.Components.StiText();
            this.Text210.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0, 2, 0.4);
            this.Text210.Guid = "4727f97a734b40f1bb13f620f77aaaa0";
            this.Text210.Name = "Text210";
            this.Text210.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text210__GetValue);
            this.Text210.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text210.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.Right, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.None, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text210.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text210.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text210.Indicator = null;
            this.Text210.Interaction = null;
            this.Text210.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text210.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text210.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            this.Panel13.Interaction = null;
            this.ReportTitle2.Interaction = null;
            this.Page3.ExcelSheetValue = null;
            this.Page3.Interaction = null;
            this.Page3.Margins = new Stimulsoft.Report.Components.StiMargins(0.39, 0.39, 0.39, 0.39);
            this.Page3_Watermark = new Stimulsoft.Report.Components.StiWatermark();
            this.Page3_Watermark.Font = new System.Drawing.Font("Arial", 100F);
            this.Page3_Watermark.Image = null;
            this.Page3_Watermark.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(50, 0, 0, 0));
            this.Report_PrinterSettings = new Stimulsoft.Report.Print.StiPrinterSettings();
            this.PrinterSettings = this.Report_PrinterSettings;
            this.Page1.Report = this;
            this.Page1.Watermark = this.Page1_Watermark;
            this.PageFooterBand2.Page = this.Page1;
            this.PageFooterBand2.Parent = this.Page1;
            this.Text18.Page = this.Page1;
            this.Text18.Parent = this.PageFooterBand2;
            this.Text19.Page = this.Page1;
            this.Text19.Parent = this.PageFooterBand2;
            this.Text12.Page = this.Page1;
            this.Text12.Parent = this.Page1;
            this.Text15.Page = this.Page1;
            this.Text15.Parent = this.Page1;
            this.Text11.Page = this.Page1;
            this.Text11.Parent = this.Page1;
            this.Text14.Page = this.Page1;
            this.Text14.Parent = this.Page1;
            this.Panel1.Page = this.Page1;
            this.Panel1.Parent = this.Page1;
            this.Text1.Page = this.Page1;
            this.Text1.Parent = this.Panel1;
            this.Text3.Page = this.Page1;
            this.Text3.Parent = this.Panel1;
            this.Text4.Page = this.Page1;
            this.Text4.Parent = this.Panel1;
            this.Text5.Page = this.Page1;
            this.Text5.Parent = this.Panel1;
            this.Text6.Page = this.Page1;
            this.Text6.Parent = this.Panel1;
            this.Text7.Page = this.Page1;
            this.Text7.Parent = this.Panel1;
            this.Text8.Page = this.Page1;
            this.Text8.Parent = this.Panel1;
            this.Text9.Page = this.Page1;
            this.Text9.Parent = this.Panel1;
            this.Text10.Page = this.Page1;
            this.Text10.Parent = this.Panel1;
            this.Text13.Page = this.Page1;
            this.Text13.Parent = this.Panel1;
            this.Text16.Page = this.Page1;
            this.Text16.Parent = this.Panel1;
            this.Text17.Page = this.Page1;
            this.Text17.Parent = this.Panel1;
            this.Text20.Page = this.Page1;
            this.Text20.Parent = this.Panel1;
            this.Text21.Page = this.Page1;
            this.Text21.Parent = this.Panel1;
            this.Text22.Page = this.Page1;
            this.Text22.Parent = this.Panel1;
            this.Text23.Page = this.Page1;
            this.Text23.Parent = this.Panel1;
            this.Text24.Page = this.Page1;
            this.Text24.Parent = this.Panel1;
            this.Text25.Page = this.Page1;
            this.Text25.Parent = this.Panel1;
            this.Text26.Page = this.Page1;
            this.Text26.Parent = this.Panel1;
            this.Text27.Page = this.Page1;
            this.Text27.Parent = this.Panel1;
            this.Text28.Page = this.Page1;
            this.Text28.Parent = this.Panel1;
            this.Text29.Page = this.Page1;
            this.Text29.Parent = this.Panel1;
            this.Text30.Page = this.Page1;
            this.Text30.Parent = this.Panel1;
            this.Text31.Page = this.Page1;
            this.Text31.Parent = this.Panel1;
            this.Text32.Page = this.Page1;
            this.Text32.Parent = this.Panel1;
            this.Text33.Page = this.Page1;
            this.Text33.Parent = this.Panel1;
            this.Text35.Page = this.Page1;
            this.Text35.Parent = this.Panel1;
            this.Text36.Page = this.Page1;
            this.Text36.Parent = this.Panel1;
            this.Text37.Page = this.Page1;
            this.Text37.Parent = this.Panel1;
            this.Text38.Page = this.Page1;
            this.Text38.Parent = this.Panel1;
            this.HorizontalLine1.Page = this.Page1;
            this.HorizontalLine1.Parent = this.Panel1;
            this.StartPointPrimitive1.Page = this.Page1;
            this.StartPointPrimitive1.Parent = this.Panel1;
            this.StartPointPrimitive2.Page = this.Page1;
            this.StartPointPrimitive2.Parent = this.Panel1;
            this.StartPointPrimitive3.Page = this.Page1;
            this.StartPointPrimitive3.Parent = this.Panel1;
            this.StartPointPrimitive4.Page = this.Page1;
            this.StartPointPrimitive4.Parent = this.Panel1;
            this.HorizontalLine2.Page = this.Page1;
            this.HorizontalLine2.Parent = this.Panel1;
            this.HorizontalLine3.Page = this.Page1;
            this.HorizontalLine3.Parent = this.Panel1;
            this.HorizontalLine4.Page = this.Page1;
            this.HorizontalLine4.Parent = this.Panel1;
            this.HorizontalLine5.Page = this.Page1;
            this.HorizontalLine5.Parent = this.Panel1;
            this.HorizontalLine6.Page = this.Page1;
            this.HorizontalLine6.Parent = this.Panel1;
            this.HorizontalLine7.Page = this.Page1;
            this.HorizontalLine7.Parent = this.Panel1;
            this.HorizontalLine8.Page = this.Page1;
            this.HorizontalLine8.Parent = this.Panel1;
            this.HorizontalLine9.Page = this.Page1;
            this.HorizontalLine9.Parent = this.Panel1;
            this.EndPointPrimitive3.Page = this.Page1;
            this.EndPointPrimitive3.Parent = this.Panel1;
            this.EndPointPrimitive4.Page = this.Page1;
            this.EndPointPrimitive4.Parent = this.Panel1;
            this.EndPointPrimitive2.Page = this.Page1;
            this.EndPointPrimitive2.Parent = this.Panel1;
            this.EndPointPrimitive1.Page = this.Page1;
            this.EndPointPrimitive1.Parent = this.Panel1;
            this.Panel6.Page = this.Page1;
            this.Panel6.Parent = this.Page1;
            this.Text82.Page = this.Page1;
            this.Text82.Parent = this.Panel6;
            this.Text83.Page = this.Page1;
            this.Text83.Parent = this.Panel6;
            this.Text84.Page = this.Page1;
            this.Text84.Parent = this.Panel6;
            this.Text85.Page = this.Page1;
            this.Text85.Parent = this.Panel6;
            this.Text86.Page = this.Page1;
            this.Text86.Parent = this.Panel6;
            this.Text87.Page = this.Page1;
            this.Text87.Parent = this.Panel6;
            this.Text88.Page = this.Page1;
            this.Text88.Parent = this.Panel6;
            this.Text89.Page = this.Page1;
            this.Text89.Parent = this.Panel6;
            this.Text90.Page = this.Page1;
            this.Text90.Parent = this.Panel6;
            this.Text91.Page = this.Page1;
            this.Text91.Parent = this.Panel6;
            this.Text101.Page = this.Page1;
            this.Text101.Parent = this.Panel6;
            this.Text102.Page = this.Page1;
            this.Text102.Parent = this.Panel6;
            this.Text103.Page = this.Page1;
            this.Text103.Parent = this.Panel6;
            this.Text104.Page = this.Page1;
            this.Text104.Parent = this.Panel6;
            this.Text105.Page = this.Page1;
            this.Text105.Parent = this.Panel6;
            this.Text106.Page = this.Page1;
            this.Text106.Parent = this.Panel6;
            this.Text92.Page = this.Page1;
            this.Text92.Parent = this.Panel6;
            this.Text107.Page = this.Page1;
            this.Text107.Parent = this.Panel6;
            this.Text93.Page = this.Page1;
            this.Text93.Parent = this.Panel6;
            this.Text94.Page = this.Page1;
            this.Text94.Parent = this.Panel6;
            this.Text95.Page = this.Page1;
            this.Text95.Parent = this.Panel6;
            this.Text96.Page = this.Page1;
            this.Text96.Parent = this.Panel6;
            this.Text97.Page = this.Page1;
            this.Text97.Parent = this.Panel6;
            this.Text98.Page = this.Page1;
            this.Text98.Parent = this.Panel6;
            this.Text99.Page = this.Page1;
            this.Text99.Parent = this.Panel6;
            this.Text100.Page = this.Page1;
            this.Text100.Parent = this.Panel6;
            this.HorizontalLine17.Page = this.Page1;
            this.HorizontalLine17.Parent = this.Panel6;
            this.HorizontalLine18.Page = this.Page1;
            this.HorizontalLine18.Parent = this.Panel6;
            this.HorizontalLine19.Page = this.Page1;
            this.HorizontalLine19.Parent = this.Panel6;
            this.HorizontalLine20.Page = this.Page1;
            this.HorizontalLine20.Parent = this.Panel6;
            this.HorizontalLine21.Page = this.Page1;
            this.HorizontalLine21.Parent = this.Panel6;
            this.HorizontalLine22.Page = this.Page1;
            this.HorizontalLine22.Parent = this.Panel6;
            this.HorizontalLine23.Page = this.Page1;
            this.HorizontalLine23.Parent = this.Panel6;
            this.HorizontalLine24.Page = this.Page1;
            this.HorizontalLine24.Parent = this.Panel6;
            this.StartPointPrimitive59.Page = this.Page1;
            this.StartPointPrimitive59.Parent = this.Panel6;
            this.StartPointPrimitive60.Page = this.Page1;
            this.StartPointPrimitive60.Parent = this.Panel6;
            this.StartPointPrimitive61.Page = this.Page1;
            this.StartPointPrimitive61.Parent = this.Panel6;
            this.StartPointPrimitive62.Page = this.Page1;
            this.StartPointPrimitive62.Parent = this.Panel6;
            this.StartPointPrimitive31.Page = this.Page1;
            this.StartPointPrimitive31.Parent = this.Panel6;
            this.EndPointPrimitive31.Page = this.Page1;
            this.EndPointPrimitive31.Parent = this.Panel6;
            this.StartPointPrimitive32.Page = this.Page1;
            this.StartPointPrimitive32.Parent = this.Panel6;
            this.EndPointPrimitive30.Page = this.Page1;
            this.EndPointPrimitive30.Parent = this.Panel6;
            this.StartPointPrimitive55.Page = this.Page1;
            this.StartPointPrimitive55.Parent = this.Panel6;
            this.EndPointPrimitive51.Page = this.Page1;
            this.EndPointPrimitive51.Parent = this.Panel6;
            this.StartPointPrimitive56.Page = this.Page1;
            this.StartPointPrimitive56.Parent = this.Panel6;
            this.EndPointPrimitive52.Page = this.Page1;
            this.EndPointPrimitive52.Parent = this.Panel6;
            this.ReportTitleBand2.Page = this.Page1;
            this.ReportTitleBand2.Parent = this.Page1;
            this.Panel2.Page = this.Page1;
            this.Panel2.Parent = this.ReportTitleBand2;
            this.Text2.Page = this.Page1;
            this.Text2.Parent = this.Panel2;
            this.Text34.Page = this.Page1;
            this.Text34.Parent = this.Panel2;
            this.VerticalLine1.Page = this.Page1;
            this.VerticalLine1.Parent = this.Page1;
            this.VerticalLine2.Page = this.Page1;
            this.VerticalLine2.Parent = this.Page1;
            this.VerticalLine3.Page = this.Page1;
            this.VerticalLine3.Parent = this.Page1;
            this.VerticalLine4.Page = this.Page1;
            this.VerticalLine4.Parent = this.Page1;
            this.VerticalLine21.Page = this.Page1;
            this.VerticalLine21.Parent = this.Page1;
            this.VerticalLine22.Page = this.Page1;
            this.VerticalLine22.Parent = this.Page1;
            this.Page2.Report = this;
            this.Page2.Watermark = this.Page2_Watermark;
            this.PageFooter1.Page = this.Page2;
            this.PageFooter1.Parent = this.Page2;
            this.Text76.Page = this.Page2;
            this.Text76.Parent = this.PageFooter1;
            this.Text77.Page = this.Page2;
            this.Text77.Parent = this.PageFooter1;
            this.Text78.Page = this.Page2;
            this.Text78.Parent = this.Page2;
            this.Text79.Page = this.Page2;
            this.Text79.Parent = this.Page2;
            this.Text80.Page = this.Page2;
            this.Text80.Parent = this.Page2;
            this.Text81.Page = this.Page2;
            this.Text81.Parent = this.Page2;
            this.Panel7.Page = this.Page2;
            this.Panel7.Parent = this.Page2;
            this.Text108.Page = this.Page2;
            this.Text108.Parent = this.Panel7;
            this.Text110.Page = this.Page2;
            this.Text110.Parent = this.Panel7;
            this.Text111.Page = this.Page2;
            this.Text111.Parent = this.Panel7;
            this.Text112.Page = this.Page2;
            this.Text112.Parent = this.Panel7;
            this.Text113.Page = this.Page2;
            this.Text113.Parent = this.Panel7;
            this.Text114.Page = this.Page2;
            this.InitializeComponent6();
        }
        
        public void InitializeComponent6()
        {
            this.Text114.Parent = this.Panel7;
            this.Text115.Page = this.Page2;
            this.Text115.Parent = this.Panel7;
            this.Text116.Page = this.Page2;
            this.Text116.Parent = this.Panel7;
            this.Text117.Page = this.Page2;
            this.Text117.Parent = this.Panel7;
            this.Text124.Page = this.Page2;
            this.Text124.Parent = this.Panel7;
            this.Text118.Page = this.Page2;
            this.Text118.Parent = this.Panel7;
            this.Text119.Page = this.Page2;
            this.Text119.Parent = this.Panel7;
            this.Text120.Page = this.Page2;
            this.Text120.Parent = this.Panel7;
            this.Text121.Page = this.Page2;
            this.Text121.Parent = this.Panel7;
            this.Text122.Page = this.Page2;
            this.Text122.Parent = this.Panel7;
            this.Text123.Page = this.Page2;
            this.Text123.Parent = this.Panel7;
            this.Text125.Page = this.Page2;
            this.Text125.Parent = this.Panel7;
            this.Text126.Page = this.Page2;
            this.Text126.Parent = this.Panel7;
            this.Text127.Page = this.Page2;
            this.Text127.Parent = this.Panel7;
            this.Text128.Page = this.Page2;
            this.Text128.Parent = this.Panel7;
            this.Text129.Page = this.Page2;
            this.Text129.Parent = this.Panel7;
            this.Text130.Page = this.Page2;
            this.Text130.Parent = this.Panel7;
            this.Text131.Page = this.Page2;
            this.Text131.Parent = this.Panel7;
            this.Text132.Page = this.Page2;
            this.Text132.Parent = this.Panel7;
            this.Text133.Page = this.Page2;
            this.Text133.Parent = this.Panel7;
            this.Text134.Page = this.Page2;
            this.Text134.Parent = this.Panel7;
            this.Text135.Page = this.Page2;
            this.Text135.Parent = this.Panel7;
            this.Text109.Page = this.Page2;
            this.Text109.Parent = this.Panel7;
            this.HorizontalLine25.Page = this.Page2;
            this.HorizontalLine25.Parent = this.Panel7;
            this.HorizontalLine26.Page = this.Page2;
            this.HorizontalLine26.Parent = this.Panel7;
            this.HorizontalLine27.Page = this.Page2;
            this.HorizontalLine27.Parent = this.Panel7;
            this.HorizontalLine28.Page = this.Page2;
            this.HorizontalLine28.Parent = this.Panel7;
            this.HorizontalLine29.Page = this.Page2;
            this.HorizontalLine29.Parent = this.Panel7;
            this.HorizontalLine30.Page = this.Page2;
            this.HorizontalLine30.Parent = this.Panel7;
            this.HorizontalLine31.Page = this.Page2;
            this.HorizontalLine31.Parent = this.Panel7;
            this.HorizontalLine32.Page = this.Page2;
            this.HorizontalLine32.Parent = this.Panel7;
            this.StartPointPrimitive34.Page = this.Page2;
            this.StartPointPrimitive34.Parent = this.Panel7;
            this.StartPointPrimitive35.Page = this.Page2;
            this.StartPointPrimitive35.Parent = this.Panel7;
            this.StartPointPrimitive36.Page = this.Page2;
            this.StartPointPrimitive36.Parent = this.Panel7;
            this.StartPointPrimitive37.Page = this.Page2;
            this.StartPointPrimitive37.Parent = this.Panel7;
            this.StartPointPrimitive63.Page = this.Page2;
            this.StartPointPrimitive63.Parent = this.Panel7;
            this.EndPointPrimitive63.Page = this.Page2;
            this.EndPointPrimitive63.Parent = this.Panel7;
            this.StartPointPrimitive64.Page = this.Page2;
            this.StartPointPrimitive64.Parent = this.Panel7;
            this.EndPointPrimitive64.Page = this.Page2;
            this.EndPointPrimitive64.Parent = this.Panel7;
            this.StartPointPrimitive65.Page = this.Page2;
            this.StartPointPrimitive65.Parent = this.Panel7;
            this.EndPointPrimitive65.Page = this.Page2;
            this.EndPointPrimitive65.Parent = this.Panel7;
            this.StartPointPrimitive66.Page = this.Page2;
            this.StartPointPrimitive66.Parent = this.Panel7;
            this.EndPointPrimitive66.Page = this.Page2;
            this.EndPointPrimitive66.Parent = this.Panel7;
            this.StartPointPrimitive67.Page = this.Page2;
            this.StartPointPrimitive67.Parent = this.Panel7;
            this.EndPointPrimitive67.Page = this.Page2;
            this.EndPointPrimitive67.Parent = this.Panel7;
            this.StartPointPrimitive68.Page = this.Page2;
            this.StartPointPrimitive68.Parent = this.Panel7;
            this.EndPointPrimitive68.Page = this.Page2;
            this.EndPointPrimitive68.Parent = this.Panel7;
            this.StartPointPrimitive69.Page = this.Page2;
            this.StartPointPrimitive69.Parent = this.Panel7;
            this.EndPointPrimitive69.Page = this.Page2;
            this.EndPointPrimitive69.Parent = this.Panel7;
            this.StartPointPrimitive70.Page = this.Page2;
            this.StartPointPrimitive70.Parent = this.Panel7;
            this.EndPointPrimitive70.Page = this.Page2;
            this.EndPointPrimitive70.Parent = this.Panel7;
            this.StartPointPrimitive71.Page = this.Page2;
            this.StartPointPrimitive71.Parent = this.Panel7;
            this.StartPointPrimitive72.Page = this.Page2;
            this.StartPointPrimitive72.Parent = this.Panel7;
            this.EndPointPrimitive72.Page = this.Page2;
            this.EndPointPrimitive72.Parent = this.Panel7;
            this.StartPointPrimitive73.Page = this.Page2;
            this.StartPointPrimitive73.Parent = this.Panel7;
            this.StartPointPrimitive74.Page = this.Page2;
            this.StartPointPrimitive74.Parent = this.Panel7;
            this.EndPointPrimitive74.Page = this.Page2;
            this.EndPointPrimitive74.Parent = this.Panel7;
            this.StartPointPrimitive75.Page = this.Page2;
            this.StartPointPrimitive75.Parent = this.Panel7;
            this.EndPointPrimitive75.Page = this.Page2;
            this.EndPointPrimitive75.Parent = this.Panel7;
            this.StartPointPrimitive76.Page = this.Page2;
            this.StartPointPrimitive76.Parent = this.Panel7;
            this.EndPointPrimitive76.Page = this.Page2;
            this.EndPointPrimitive76.Parent = this.Panel7;
            this.StartPointPrimitive77.Page = this.Page2;
            this.StartPointPrimitive77.Parent = this.Panel7;
            this.EndPointPrimitive77.Page = this.Page2;
            this.EndPointPrimitive77.Parent = this.Panel7;
            this.StartPointPrimitive38.Page = this.Page2;
            this.StartPointPrimitive38.Parent = this.Panel7;
            this.EndPointPrimitive34.Page = this.Page2;
            this.EndPointPrimitive34.Parent = this.Panel7;
            this.StartPointPrimitive39.Page = this.Page2;
            this.StartPointPrimitive39.Parent = this.Panel7;
            this.EndPointPrimitive35.Page = this.Page2;
            this.EndPointPrimitive35.Parent = this.Panel7;
            this.EndPointPrimitive71.Page = this.Page2;
            this.EndPointPrimitive71.Parent = this.Panel7;
            this.EndPointPrimitive73.Page = this.Page2;
            this.EndPointPrimitive73.Parent = this.Panel7;
            this.StartPointPrimitive33.Page = this.Page2;
            this.StartPointPrimitive33.Parent = this.Panel7;
            this.EndPointPrimitive33.Page = this.Page2;
            this.EndPointPrimitive33.Parent = this.Panel7;
            this.HorizontalLine33.Page = this.Page2;
            this.HorizontalLine33.Parent = this.Panel7;
            this.StartPointPrimitive30.Page = this.Page2;
            this.StartPointPrimitive30.Parent = this.Panel7;
            this.EndPointPrimitive32.Page = this.Page2;
            this.EndPointPrimitive32.Parent = this.Panel7;
            this.EndPointPrimitive59.Page = this.Page2;
            this.EndPointPrimitive59.Parent = this.Panel7;
            this.EndPointPrimitive60.Page = this.Page2;
            this.EndPointPrimitive60.Parent = this.Panel7;
            this.EndPointPrimitive61.Page = this.Page2;
            this.EndPointPrimitive61.Parent = this.Panel7;
            this.EndPointPrimitive62.Page = this.Page2;
            this.EndPointPrimitive62.Parent = this.Panel7;
            this.Panel3.Page = this.Page2;
            this.Panel3.Parent = this.Page2;
            this.Text39.Page = this.Page2;
            this.Text39.Parent = this.Panel3;
            this.Text40.Page = this.Page2;
            this.Text40.Parent = this.Panel3;
            this.Text41.Page = this.Page2;
            this.Text41.Parent = this.Panel3;
            this.Text42.Page = this.Page2;
            this.Text42.Parent = this.Panel3;
            this.Text43.Page = this.Page2;
            this.Text43.Parent = this.Panel3;
            this.Text44.Page = this.Page2;
            this.Text44.Parent = this.Panel3;
            this.Text45.Page = this.Page2;
            this.Text45.Parent = this.Panel3;
            this.Text60.Page = this.Page2;
            this.Text60.Parent = this.Panel3;
            this.Text48.Page = this.Page2;
            this.Text48.Parent = this.Panel3;
            this.Text49.Page = this.Page2;
            this.Text49.Parent = this.Panel3;
            this.Text55.Page = this.Page2;
            this.Text55.Parent = this.Panel3;
            this.Text61.Page = this.Page2;
            this.Text61.Parent = this.Panel3;
            this.Text72.Page = this.Page2;
            this.Text72.Parent = this.Panel3;
            this.HorizontalLine10.Page = this.Page2;
            this.HorizontalLine10.Parent = this.Panel3;
            this.HorizontalLine11.Page = this.Page2;
            this.HorizontalLine11.Parent = this.Panel3;
            this.StartPointPrimitive57.Page = this.Page2;
            this.StartPointPrimitive57.Parent = this.Panel3;
            this.StartPointPrimitive58.Page = this.Page2;
            this.StartPointPrimitive58.Parent = this.Panel3;
            this.EndPointPrimitive54.Page = this.Page2;
            this.EndPointPrimitive54.Parent = this.Panel3;
            this.StartPointPrimitive78.Page = this.Page2;
            this.StartPointPrimitive78.Parent = this.Panel3;
            this.EndPointPrimitive55.Page = this.Page2;
            this.EndPointPrimitive55.Parent = this.Panel3;
            this.StartPointPrimitive79.Page = this.Page2;
            this.StartPointPrimitive79.Parent = this.Panel3;
            this.EndPointPrimitive56.Page = this.Page2;
            this.EndPointPrimitive56.Parent = this.Panel3;
            this.StartPointPrimitive80.Page = this.Page2;
            this.StartPointPrimitive80.Parent = this.Panel3;
            this.Panel4.Page = this.Page2;
            this.Panel4.Parent = this.Page2;
            this.Text47.Page = this.Page2;
            this.Text47.Parent = this.Panel4;
            this.Text51.Page = this.Page2;
            this.Text51.Parent = this.Panel4;
            this.Text46.Page = this.Page2;
            this.Text46.Parent = this.Panel4;
            this.Text62.Page = this.Page2;
            this.Text62.Parent = this.Panel4;
            this.Text52.Page = this.Page2;
            this.Text52.Parent = this.Panel4;
            this.Text64.Page = this.Page2;
            this.Text64.Parent = this.Panel4;
            this.Text66.Page = this.Page2;
            this.Text66.Parent = this.Panel4;
            this.Text70.Page = this.Page2;
            this.Text70.Parent = this.Panel4;
            this.Text71.Page = this.Page2;
            this.Text71.Parent = this.Panel4;
            this.Text50.Page = this.Page2;
            this.Text50.Parent = this.Panel4;
            this.Text68.Page = this.Page2;
            this.Text68.Parent = this.Panel4;
            this.HorizontalLine13.Page = this.Page2;
            this.HorizontalLine13.Parent = this.Panel4;
            this.HorizontalLine14.Page = this.Page2;
            this.HorizontalLine14.Parent = this.Panel4;
            this.StartPointPrimitive15.Page = this.Page2;
            this.StartPointPrimitive15.Parent = this.Panel4;
            this.EndPointPrimitive15.Page = this.Page2;
            this.EndPointPrimitive15.Parent = this.Panel4;
            this.StartPointPrimitive16.Page = this.Page2;
            this.StartPointPrimitive16.Parent = this.Panel4;
            this.EndPointPrimitive16.Page = this.Page2;
            this.EndPointPrimitive16.Parent = this.Panel4;
            this.StartPointPrimitive17.Page = this.Page2;
            this.StartPointPrimitive17.Parent = this.Panel4;
            this.EndPointPrimitive17.Page = this.Page2;
            this.EndPointPrimitive17.Parent = this.Panel4;
            this.StartPointPrimitive18.Page = this.Page2;
            this.StartPointPrimitive18.Parent = this.Panel4;
            this.EndPointPrimitive18.Page = this.Page2;
            this.EndPointPrimitive18.Parent = this.Panel4;
            this.StartPointPrimitive19.Page = this.Page2;
            this.StartPointPrimitive19.Parent = this.Panel4;
            this.EndPointPrimitive19.Page = this.Page2;
            this.EndPointPrimitive19.Parent = this.Panel4;
            this.StartPointPrimitive81.Page = this.Page2;
            this.StartPointPrimitive81.Parent = this.Panel4;
            this.StartPointPrimitive82.Page = this.Page2;
            this.StartPointPrimitive82.Parent = this.Panel4;
            this.EndPointPrimitive78.Page = this.Page2;
            this.EndPointPrimitive78.Parent = this.Panel4;
            this.StartPointPrimitive83.Page = this.Page2;
            this.StartPointPrimitive83.Parent = this.Panel4;
            this.StartPointPrimitive87.Page = this.Page2;
            this.StartPointPrimitive87.Parent = this.Panel4;
            this.EndPointPrimitive83.Page = this.Page2;
            this.EndPointPrimitive83.Parent = this.Panel4;
            this.StartPointPrimitive89.Page = this.Page2;
            this.StartPointPrimitive89.Parent = this.Panel4;
            this.EndPointPrimitive85.Page = this.Page2;
            this.EndPointPrimitive85.Parent = this.Panel4;
            this.Panel5.Page = this.Page2;
            this.Panel5.Parent = this.Page2;
            this.Text54.Page = this.Page2;
            this.Text54.Parent = this.Panel5;
            this.Text58.Page = this.Page2;
            this.Text58.Parent = this.Panel5;
            this.Text59.Page = this.Page2;
            this.Text59.Parent = this.Panel5;
            this.Text53.Page = this.Page2;
            this.Text53.Parent = this.Panel5;
            this.Text63.Page = this.Page2;
            this.Text63.Parent = this.Panel5;
            this.Text56.Page = this.Page2;
            this.Text56.Parent = this.Panel5;
            this.Text65.Page = this.Page2;
            this.Text65.Parent = this.Panel5;
            this.Text67.Page = this.Page2;
            this.Text67.Parent = this.Panel5;
            this.Text73.Page = this.Page2;
            this.Text73.Parent = this.Panel5;
            this.Text74.Page = this.Page2;
            this.Text74.Parent = this.Panel5;
            this.Text75.Page = this.Page2;
            this.Text75.Parent = this.Panel5;
            this.Text57.Page = this.Page2;
            this.Text57.Parent = this.Panel5;
            this.Text69.Page = this.Page2;
            this.Text69.Parent = this.Panel5;
            this.HorizontalLine15.Page = this.Page2;
            this.HorizontalLine15.Parent = this.Panel5;
            this.HorizontalLine16.Page = this.Page2;
            this.HorizontalLine16.Parent = this.Panel5;
            this.StartPointPrimitive25.Page = this.Page2;
            this.StartPointPrimitive25.Parent = this.Panel5;
            this.EndPointPrimitive25.Page = this.Page2;
            this.EndPointPrimitive25.Parent = this.Panel5;
            this.StartPointPrimitive26.Page = this.Page2;
            this.StartPointPrimitive26.Parent = this.Panel5;
            this.EndPointPrimitive26.Page = this.Page2;
            this.EndPointPrimitive26.Parent = this.Panel5;
            this.StartPointPrimitive27.Page = this.Page2;
            this.StartPointPrimitive27.Parent = this.Panel5;
            this.EndPointPrimitive27.Page = this.Page2;
            this.EndPointPrimitive27.Parent = this.Panel5;
            this.StartPointPrimitive28.Page = this.Page2;
            this.StartPointPrimitive28.Parent = this.Panel5;
            this.EndPointPrimitive28.Page = this.Page2;
            this.EndPointPrimitive28.Parent = this.Panel5;
            this.StartPointPrimitive29.Page = this.Page2;
            this.StartPointPrimitive29.Parent = this.Panel5;
            this.EndPointPrimitive29.Page = this.Page2;
            this.EndPointPrimitive29.Parent = this.Panel5;
            this.StartPointPrimitive84.Page = this.Page2;
            this.StartPointPrimitive84.Parent = this.Panel5;
            this.StartPointPrimitive85.Page = this.Page2;
            this.StartPointPrimitive85.Parent = this.Panel5;
            this.EndPointPrimitive81.Page = this.Page2;
            this.EndPointPrimitive81.Parent = this.Panel5;
            this.StartPointPrimitive86.Page = this.Page2;
            this.StartPointPrimitive86.Parent = this.Panel5;
            this.StartPointPrimitive88.Page = this.Page2;
            this.StartPointPrimitive88.Parent = this.Panel5;
            this.EndPointPrimitive84.Page = this.Page2;
            this.EndPointPrimitive84.Parent = this.Panel5;
            this.StartPointPrimitive90.Page = this.Page2;
            this.StartPointPrimitive90.Parent = this.Panel5;
            this.EndPointPrimitive86.Page = this.Page2;
            this.EndPointPrimitive86.Parent = this.Panel5;
            this.ReportTitle1.Page = this.Page2;
            this.ReportTitle1.Parent = this.Page2;
            this.Panel10.Page = this.Page2;
            this.Panel10.Parent = this.ReportTitle1;
            this.Text149.Page = this.Page2;
            this.Text149.Parent = this.Panel10;
            this.Text150.Page = this.Page2;
            this.Text150.Parent = this.Panel10;
            this.VerticalLine23.Page = this.Page2;
            this.VerticalLine23.Parent = this.Page2;
            this.VerticalLine20.Page = this.Page2;
            this.VerticalLine20.Parent = this.Page2;
            this.EndPointPrimitive53.Page = this.Page2;
            this.EndPointPrimitive53.Parent = this.Page2;
            this.EndPointPrimitive57.Page = this.Page2;
            this.EndPointPrimitive57.Parent = this.Page2;
            this.EndPointPrimitive58.Page = this.Page2;
            this.EndPointPrimitive58.Parent = this.Page2;
            this.EndPointPrimitive79.Page = this.Page2;
            this.EndPointPrimitive79.Parent = this.Page2;
            this.EndPointPrimitive80.Page = this.Page2;
            this.EndPointPrimitive80.Parent = this.Page2;
            this.EndPointPrimitive82.Page = this.Page2;
            this.EndPointPrimitive82.Parent = this.Page2;
            this.Page3.Report = this;
            this.Page3.Watermark = this.Page3_Watermark;
            this.PageFooter2.Page = this.Page3;
            this.PageFooter2.Parent = this.Page3;
            this.Text136.Page = this.Page3;
            this.Text136.Parent = this.PageFooter2;
            this.Text137.Page = this.Page3;
            this.Text137.Parent = this.PageFooter2;
            this.Text138.Page = this.Page3;
            this.Text138.Parent = this.Page3;
            this.Text139.Page = this.Page3;
            this.Text139.Parent = this.Page3;
            this.Text140.Page = this.Page3;
            this.Text140.Parent = this.Page3;
            this.Text141.Page = this.Page3;
            this.Text141.Parent = this.Page3;
            this.Panel8.Page = this.Page3;
            this.Panel8.Parent = this.Page3;
            this.Text142.Page = this.Page3;
            this.Text142.Parent = this.Panel8;
            this.Text143.Page = this.Page3;
            this.Text143.Parent = this.Panel8;
            this.Text148.Page = this.Page3;
            this.Text148.Parent = this.Panel8;
            this.Text144.Page = this.Page3;
            this.Text144.Parent = this.Panel8;
            this.Text145.Page = this.Page3;
            this.Text145.Parent = this.Panel8;
            this.Text146.Page = this.Page3;
            this.Text146.Parent = this.Panel8;
            this.Text147.Page = this.Page3;
            this.Text147.Parent = this.Panel8;
            this.Text151.Page = this.Page3;
            this.Text151.Parent = this.Panel8;
            this.Image2.Page = this.Page3;
            this.Image2.Parent = this.Panel8;
            this.Image3.Page = this.Page3;
            this.Image3.Parent = this.Panel8;
            this.Image4.Page = this.Page3;
            this.Image4.Parent = this.Panel8;
            this.Image5.Page = this.Page3;
            this.Image5.Parent = this.Panel8;
            this.Image6.Page = this.Page3;
            this.Image6.Parent = this.Panel8;
            this.Image7.Page = this.Page3;
            this.Image7.Parent = this.Panel8;
            this.Image8.Page = this.Page3;
            this.Image8.Parent = this.Panel8;
            this.ReportTitle2.Page = this.Page3;
            this.ReportTitle2.Parent = this.Page3;
            this.Panel13.Page = this.Page3;
            this.Panel13.Parent = this.ReportTitle2;
            this.Text209.Page = this.Page3;
            this.Text209.Parent = this.Panel13;
            this.Text210.Page = this.Page3;
            this.Text210.Parent = this.Panel13;
            this.EndRender += new System.EventHandler(this.ReportWordsToEnd__EndRender);
            // 
            // Add to PageFooterBand2.Components
            // 
            this.PageFooterBand2.Components.Clear();
            this.PageFooterBand2.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Text18,
                        this.Text19});
            // 
            // Add to Panel1.Components
            // 
            this.Panel1.Components.Clear();
            this.Panel1.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Text1,
                        this.Text3,
                        this.Text4,
                        this.Text5,
                        this.Text6,
                        this.Text7,
                        this.Text8,
                        this.Text9,
                        this.Text10,
                        this.Text13,
                        this.Text16,
                        this.Text17,
                        this.Text20,
                        this.Text21,
                        this.Text22,
                        this.Text23,
                        this.Text24,
                        this.Text25,
                        this.Text26,
                        this.Text27,
                        this.Text28,
                        this.Text29,
                        this.Text30,
                        this.Text31,
                        this.Text32,
                        this.Text33,
                        this.Text35,
                        this.Text36,
                        this.Text37,
                        this.Text38,
                        this.HorizontalLine1,
                        this.StartPointPrimitive1,
                        this.StartPointPrimitive2,
                        this.StartPointPrimitive3,
                        this.StartPointPrimitive4,
                        this.HorizontalLine2,
                        this.HorizontalLine3,
                        this.HorizontalLine4,
                        this.HorizontalLine5,
                        this.HorizontalLine6,
                        this.HorizontalLine7,
                        this.HorizontalLine8,
                        this.HorizontalLine9,
                        this.EndPointPrimitive3,
                        this.EndPointPrimitive4,
                        this.EndPointPrimitive2,
                        this.EndPointPrimitive1});
            // 
            // Add to Panel6.Components
            // 
            this.Panel6.Components.Clear();
            this.Panel6.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Text82,
                        this.Text83,
                        this.Text84,
                        this.Text85,
                        this.Text86,
                        this.Text87,
                        this.Text88,
                        this.Text89,
                        this.Text90,
                        this.Text91,
                        this.Text101,
                        this.Text102,
                        this.Text103,
                        this.Text104,
                        this.Text105,
                        this.Text106,
                        this.Text92,
                        this.Text107,
                        this.Text93,
                        this.Text94,
                        this.Text95,
                        this.Text96,
                        this.Text97,
                        this.Text98,
                        this.Text99,
                        this.Text100,
                        this.HorizontalLine17,
                        this.HorizontalLine18,
                        this.HorizontalLine19,
                        this.HorizontalLine20,
                        this.HorizontalLine21,
                        this.HorizontalLine22,
                        this.HorizontalLine23,
                        this.HorizontalLine24,
                        this.StartPointPrimitive59,
                        this.StartPointPrimitive60,
                        this.StartPointPrimitive61,
                        this.StartPointPrimitive62,
                        this.StartPointPrimitive31,
                        this.EndPointPrimitive31,
                        this.StartPointPrimitive32,
                        this.EndPointPrimitive30,
                        this.StartPointPrimitive55,
                        this.EndPointPrimitive51,
                        this.StartPointPrimitive56,
                        this.EndPointPrimitive52});
            // 
            // Add to Panel2.Components
            // 
            this.Panel2.Components.Clear();
            this.Panel2.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Text2,
                        this.Text34});
            // 
            // Add to ReportTitleBand2.Components
            // 
            this.ReportTitleBand2.Components.Clear();
            this.ReportTitleBand2.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Panel2});
            // 
            // Add to Page1.Components
            // 
            this.Page1.Components.Clear();
            this.Page1.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.PageFooterBand2,
                        this.Text12,
                        this.Text15,
                        this.Text11,
                        this.Text14,
                        this.Panel1,
                        this.Panel6,
                        this.ReportTitleBand2,
                        this.VerticalLine1,
                        this.VerticalLine2,
                        this.VerticalLine3,
                        this.VerticalLine4,
                        this.VerticalLine21,
                        this.VerticalLine22});
            // 
            // Add to PageFooter1.Components
            // 
            this.PageFooter1.Components.Clear();
            this.PageFooter1.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Text76,
                        this.Text77});
            // 
            // Add to Panel7.Components
            // 
            this.Panel7.Components.Clear();
            this.Panel7.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Text108,
                        this.Text110,
                        this.Text111,
                        this.Text112,
                        this.Text113,
                        this.Text114,
                        this.Text115,
                        this.Text116,
                        this.Text117,
                        this.Text124,
                        this.Text118,
                        this.Text119,
                        this.Text120,
                        this.Text121,
                        this.Text122,
                        this.Text123,
                        this.Text125,
                        this.Text126,
                        this.Text127,
                        this.Text128,
                        this.Text129,
                        this.Text130,
                        this.Text131,
                        this.Text132,
                        this.Text133,
                        this.Text134,
                        this.Text135,
                        this.Text109,
                        this.HorizontalLine25,
                        this.HorizontalLine26,
                        this.HorizontalLine27,
                        this.HorizontalLine28,
                        this.HorizontalLine29,
                        this.HorizontalLine30,
                        this.HorizontalLine31,
                        this.HorizontalLine32,
                        this.StartPointPrimitive34,
                        this.StartPointPrimitive35,
                        this.StartPointPrimitive36,
                        this.StartPointPrimitive37,
                        this.StartPointPrimitive63,
                        this.EndPointPrimitive63,
                        this.StartPointPrimitive64,
                        this.EndPointPrimitive64,
                        this.StartPointPrimitive65,
                        this.EndPointPrimitive65,
                        this.StartPointPrimitive66,
                        this.EndPointPrimitive66,
                        this.StartPointPrimitive67,
                        this.EndPointPrimitive67,
                        this.StartPointPrimitive68,
                        this.EndPointPrimitive68,
                        this.StartPointPrimitive69,
                        this.EndPointPrimitive69,
                        this.StartPointPrimitive70,
                        this.EndPointPrimitive70,
                        this.StartPointPrimitive71,
                        this.StartPointPrimitive72,
                        this.EndPointPrimitive72,
                        this.StartPointPrimitive73,
                        this.StartPointPrimitive74,
                        this.EndPointPrimitive74,
                        this.StartPointPrimitive75,
                        this.EndPointPrimitive75,
                        this.StartPointPrimitive76,
                        this.EndPointPrimitive76,
                        this.StartPointPrimitive77,
                        this.EndPointPrimitive77,
                        this.StartPointPrimitive38,
                        this.EndPointPrimitive34,
                        this.StartPointPrimitive39,
                        this.EndPointPrimitive35,
                        this.EndPointPrimitive71,
                        this.EndPointPrimitive73,
                        this.StartPointPrimitive33,
                        this.EndPointPrimitive33,
                        this.HorizontalLine33,
                        this.StartPointPrimitive30,
                        this.EndPointPrimitive32,
                        this.EndPointPrimitive59,
                        this.EndPointPrimitive60,
                        this.EndPointPrimitive61,
                        this.EndPointPrimitive62});
            // 
            // Add to Panel3.Components
            // 
            this.Panel3.Components.Clear();
            this.Panel3.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Text39,
                        this.Text40,
                        this.Text41,
                        this.Text42,
                        this.Text43,
                        this.Text44,
                        this.Text45,
                        this.Text60,
                        this.Text48,
                        this.Text49,
                        this.Text55,
                        this.Text61,
                        this.Text72,
                        this.HorizontalLine10,
                        this.HorizontalLine11,
                        this.StartPointPrimitive57,
                        this.StartPointPrimitive58,
                        this.EndPointPrimitive54,
                        this.StartPointPrimitive78,
                        this.EndPointPrimitive55,
                        this.StartPointPrimitive79,
                        this.EndPointPrimitive56,
                        this.StartPointPrimitive80});
            // 
            // Add to Panel4.Components
            // 
            this.Panel4.Components.Clear();
            this.Panel4.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Text47,
                        this.Text51,
                        this.Text46,
                        this.Text62,
                        this.Text52,
                        this.Text64,
                        this.Text66,
                        this.Text70,
                        this.Text71,
                        this.Text50,
                        this.Text68,
                        this.HorizontalLine13,
                        this.HorizontalLine14,
                        this.StartPointPrimitive15,
                        this.EndPointPrimitive15,
                        this.StartPointPrimitive16,
                        this.EndPointPrimitive16,
                        this.StartPointPrimitive17,
                        this.EndPointPrimitive17,
                        this.StartPointPrimitive18,
                        this.EndPointPrimitive18,
                        this.StartPointPrimitive19,
                        this.EndPointPrimitive19,
                        this.StartPointPrimitive81,
                        this.StartPointPrimitive82,
                        this.EndPointPrimitive78,
                        this.StartPointPrimitive83,
                        this.StartPointPrimitive87,
                        this.EndPointPrimitive83,
                        this.StartPointPrimitive89,
                        this.EndPointPrimitive85});
            // 
            // Add to Panel5.Components
            // 
            this.Panel5.Components.Clear();
            this.Panel5.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Text54,
                        this.Text58,
                        this.Text59,
                        this.Text53,
                        this.Text63,
                        this.Text56,
                        this.Text65,
                        this.Text67,
                        this.Text73,
                        this.Text74,
                        this.Text75,
                        this.Text57,
                        this.Text69,
                        this.HorizontalLine15,
                        this.HorizontalLine16,
                        this.StartPointPrimitive25,
                        this.EndPointPrimitive25,
                        this.StartPointPrimitive26,
                        this.EndPointPrimitive26,
                        this.StartPointPrimitive27,
                        this.EndPointPrimitive27,
                        this.StartPointPrimitive28,
                        this.EndPointPrimitive28,
                        this.StartPointPrimitive29,
                        this.EndPointPrimitive29,
                        this.StartPointPrimitive84,
                        this.StartPointPrimitive85,
                        this.EndPointPrimitive81,
                        this.StartPointPrimitive86,
                        this.StartPointPrimitive88,
                        this.EndPointPrimitive84,
                        this.StartPointPrimitive90,
                        this.EndPointPrimitive86});
            // 
            // Add to Panel10.Components
            // 
            this.Panel10.Components.Clear();
            this.Panel10.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Text149,
                        this.Text150});
            // 
            // Add to ReportTitle1.Components
            // 
            this.ReportTitle1.Components.Clear();
            this.ReportTitle1.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Panel10});
            // 
            // Add to Page2.Components
            // 
            this.Page2.Components.Clear();
            this.Page2.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.PageFooter1,
                        this.Text78,
                        this.Text79,
                        this.Text80,
                        this.Text81,
                        this.Panel7,
                        this.Panel3,
                        this.Panel4,
                        this.Panel5,
                        this.ReportTitle1,
                        this.VerticalLine23,
                        this.VerticalLine20,
                        this.EndPointPrimitive53,
                        this.EndPointPrimitive57,
                        this.EndPointPrimitive58,
                        this.EndPointPrimitive79,
                        this.EndPointPrimitive80,
                        this.EndPointPrimitive82});
            // 
            // Add to PageFooter2.Components
            // 
            this.PageFooter2.Components.Clear();
            this.PageFooter2.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Text136,
                        this.Text137});
            // 
            // Add to Panel8.Components
            // 
            this.Panel8.Components.Clear();
            this.Panel8.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Text142,
                        this.Text143,
                        this.Text148,
                        this.Text144,
                        this.Text145,
                        this.Text146,
                        this.Text147,
                        this.Text151,
                        this.Image2,
                        this.Image3,
                        this.Image4,
                        this.Image5,
                        this.Image6,
                        this.Image7,
                        this.Image8});
            // 
            // Add to Panel13.Components
            // 
            this.Panel13.Components.Clear();
            this.Panel13.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Text209,
                        this.Text210});
            // 
            // Add to ReportTitle2.Components
            // 
            this.ReportTitle2.Components.Clear();
            this.ReportTitle2.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Panel13});
            // 
            // Add to Page3.Components
            // 
            this.Page3.Components.Clear();
            this.Page3.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.PageFooter2,
                        this.Text138,
                        this.Text139,
                        this.Text140,
                        this.Text141,
                        this.Panel8,
                        this.ReportTitle2});
            // 
            // Add to Pages
            // 
            this.Pages.Clear();
            this.Pages.AddRange(new Stimulsoft.Report.Components.StiPage[] {
                        this.Page1,
                        this.Page2,
                        this.Page3});
            this.Info.Columns.AddRange(new Stimulsoft.Report.Dictionary.StiDataColumn[] {
                        new Stimulsoft.Report.Dictionary.StiDataColumn("Id", "Id", "Id", typeof(int)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("Title", "Title", "Title", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("StartDate", "StartDate", "StartDate", typeof(int?)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("EndDate", "EndDate", "EndDate", typeof(int?)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("UserId", "UserId", "UserId", typeof(int?)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("_StartDate", "_StartDate", "_StartDate", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("_EndDate", "_EndDate", "_EndDate", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("DF1", "DF1", "DF1", typeof(float)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("DF2", "DF2", "DF2", typeof(float)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("DF3", "DF3", "DF3", typeof(float))});
            this.Dictionary.BusinessObjects.Add(this.Info);
            this.Objects.Columns.AddRange(new Stimulsoft.Report.Dictionary.StiDataColumn[] {
                        new Stimulsoft.Report.Dictionary.StiDataColumn("Id", "Id", "Id", typeof(int?)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("C_CurrentAssets", "C_CurrentAssets", "C_CurrentAssets", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("C_NonCurrentAssets", "C_NonCurrentAssets", "C_NonCurrentAssets", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("C_TotalAssets", "C_TotalAssets", "C_TotalAssets", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("C_CurrentDebts", "C_CurrentDebts", "C_CurrentDebts", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("C_NonCurrentDebts", "C_NonCurrentDebts", "C_NonCurrentDebts", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("C_TotalDebt", "C_TotalDebt", "C_TotalDebt", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("C_TotalCommitments", "C_TotalCommitments", "C_TotalCommitments", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("D_CurrentAssets", "D_CurrentAssets", "D_CurrentAssets", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("D_NonCurrentAssets", "D_NonCurrentAssets", "D_NonCurrentAssets", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("D_TotalAssets", "D_TotalAssets", "D_TotalAssets", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("D_CurrentDebts", "D_CurrentDebts", "D_CurrentDebts", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("D_NonCurrentDebts", "D_NonCurrentDebts", "D_NonCurrentDebts", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("D_TotalDebt", "D_TotalDebt", "D_TotalDebt", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("D_TotalCommitments", "D_TotalCommitments", "D_TotalCommitments", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("CurrentRatio", "CurrentRatio", "CurrentRatio", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("DebtRatio", "DebtRatio", "DebtRatio", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("DebtNewAdjusted", "DebtNewAdjusted", "DebtNewAdjusted", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("DebtMaximumAcceptable", "DebtMaximumAcceptable", "DebtMaximumAcceptable", typeof(double)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("Column", "Column", "Column", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("CurrentNewAdjusted", "CurrentNewAdjusted", "CurrentNewAdjusted", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("CurrentMaximumAcceptable", "CurrentMaximumAcceptable", "CurrentMaximumAcceptable", typeof(double))});
            this.Dictionary.BusinessObjects.Add(this.Objects);
        }
        
        #region BusinessObject Info
        public class InfoBusinessObject : Stimulsoft.Report.Dictionary.StiBusinessObject
        {
            
            public InfoBusinessObject() : 
                    base("", "Info", "Info", "82b9ab83ffd64199ade1819baa747099")
            {
            }
            
            public virtual int Id
            {
                get
                {
                    return ((int)(StiReport.ChangeType(this["Id"], typeof(int), true)));
                }
            }
            
            public virtual string Title
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["Title"], typeof(string), true)));
                }
            }
            
            public virtual int? StartDate
            {
                get
                {
                    return ((int?)(StiReport.ChangeType(this["StartDate"], typeof(int?), true)));
                }
            }
            
            public virtual int? EndDate
            {
                get
                {
                    return ((int?)(StiReport.ChangeType(this["EndDate"], typeof(int?), true)));
                }
            }
            
            public virtual int? UserId
            {
                get
                {
                    return ((int?)(StiReport.ChangeType(this["UserId"], typeof(int?), true)));
                }
            }
            
            public virtual string _StartDate
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["_StartDate"], typeof(string), true)));
                }
            }
            
            public virtual string _EndDate
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["_EndDate"], typeof(string), true)));
                }
            }
            
            public virtual float DF1
            {
                get
                {
                    return ((float)(StiReport.ChangeType(this["DF1"], typeof(float), true)));
                }
            }
            
            public virtual float DF2
            {
                get
                {
                    return ((float)(StiReport.ChangeType(this["DF2"], typeof(float), true)));
                }
            }
            
            public virtual float DF3
            {
                get
                {
                    return ((float)(StiReport.ChangeType(this["DF3"], typeof(float), true)));
                }
            }
        }
        #endregion BusinessObject Info
        
        #region BusinessObject Objects
        public class ObjectsBusinessObject : Stimulsoft.Report.Dictionary.StiBusinessObject
        {
            
            public ObjectsBusinessObject() : 
                    base("", "Objects", "Objects", "0e798cde640646e09f2515086abda96b")
            {
            }
            
            public virtual int? Id
            {
                get
                {
                    return ((int?)(StiReport.ChangeType(this["Id"], typeof(int?), true)));
                }
            }
            
            public virtual string C_CurrentAssets
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["C_CurrentAssets"], typeof(string), true)));
                }
            }
            
            public virtual string C_NonCurrentAssets
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["C_NonCurrentAssets"], typeof(string), true)));
                }
            }
            
            public virtual string C_TotalAssets
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["C_TotalAssets"], typeof(string), true)));
                }
            }
            
            public virtual string C_CurrentDebts
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["C_CurrentDebts"], typeof(string), true)));
                }
            }
            
            public virtual string C_NonCurrentDebts
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["C_NonCurrentDebts"], typeof(string), true)));
                }
            }
            
            public virtual string C_TotalDebt
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["C_TotalDebt"], typeof(string), true)));
                }
            }
            
            public virtual string C_TotalCommitments
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["C_TotalCommitments"], typeof(string), true)));
                }
            }
            
            public virtual string D_CurrentAssets
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["D_CurrentAssets"], typeof(string), true)));
                }
            }
            
            public virtual string D_NonCurrentAssets
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["D_NonCurrentAssets"], typeof(string), true)));
                }
            }
            
            public virtual string D_TotalAssets
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["D_TotalAssets"], typeof(string), true)));
                }
            }
            
            public virtual string D_CurrentDebts
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["D_CurrentDebts"], typeof(string), true)));
                }
            }
            
            public virtual string D_NonCurrentDebts
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["D_NonCurrentDebts"], typeof(string), true)));
                }
            }
            
            public virtual string D_TotalDebt
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["D_TotalDebt"], typeof(string), true)));
                }
            }
            
            public virtual string D_TotalCommitments
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["D_TotalCommitments"], typeof(string), true)));
                }
            }
            
            public virtual string CurrentRatio
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["CurrentRatio"], typeof(string), true)));
                }
            }
            
            public virtual string DebtRatio
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["DebtRatio"], typeof(string), true)));
                }
            }
            
            public virtual string DebtNewAdjusted
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["DebtNewAdjusted"], typeof(string), true)));
                }
            }
            
            public virtual double DebtMaximumAcceptable
            {
                get
                {
                    return ((double)(StiReport.ChangeType(this["DebtMaximumAcceptable"], typeof(double), true)));
                }
            }
            
            public virtual string Column
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["Column"], typeof(string), true)));
                }
            }
            
            public virtual string CurrentNewAdjusted
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["CurrentNewAdjusted"], typeof(string), true)));
                }
            }
            
            public virtual double CurrentMaximumAcceptable
            {
                get
                {
                    return ((double)(StiReport.ChangeType(this["CurrentMaximumAcceptable"], typeof(double), true)));
                }
            }
        }
        #endregion BusinessObject Objects
        #endregion StiReport Designer generated code - do not modify
    }
	
	
}