﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Data;
using Stimulsoft.Controls;
using Stimulsoft.Base.Drawing;
using Stimulsoft.Report;
using Stimulsoft.Report.Dialogs;
using Stimulsoft.Report.Components;

namespace Reports
{
    public class Report : Stimulsoft.Report.StiReport
    {
        public Report()        {
            this.InitializeComponent();
        }

		
		public string DateToshamsi(object date)
		{
			System.Globalization.PersianCalendar shamsi = new        System.Globalization.PersianCalendar();

			DateTime da = (DateTime)date;
			int year = shamsi.GetYear(da);
			int month = shamsi.GetMonth(da);
			int day = shamsi.GetDayOfMonth(da);
			return year.ToString()+ "/"+ month.ToString() + "/"+day.ToString()  ;

		}
		
        #region StiReport Designer generated code - do not modify
        public string _StartDate;
        public Stimulsoft.Report.Components.StiPage Page1;
        public Stimulsoft.Report.Components.StiPageFooterBand PageFooterBand2;
        public Stimulsoft.Report.Components.StiText Text18;
        public Stimulsoft.Report.Components.StiText Text19;
        public Stimulsoft.Report.Components.StiImage Image1;
        public Stimulsoft.Report.Components.StiText Text12;
        public Stimulsoft.Report.Components.StiText Text15;
        public Stimulsoft.Report.Components.StiText Text11;
        public Stimulsoft.Report.Components.StiText Text14;
        public Stimulsoft.Report.Components.StiReportTitleBand ReportTitleBand2;
        public Stimulsoft.Report.Components.StiPanel Panel2;
        public Stimulsoft.Report.Components.StiText Text2;
        public Stimulsoft.Report.Components.StiText Text4;
        public Stimulsoft.Report.Components.StiText Text6;
        public Stimulsoft.Report.Components.StiText Text34;
        public Stimulsoft.Report.Components.StiText Text5;
        public Stimulsoft.Report.Components.StiText Text3;
        public Stimulsoft.Report.Components.StiText Text1;
        public Stimulsoft.Report.Components.StiText Text25;
        public Stimulsoft.Report.Components.StiText Text26;
        public Stimulsoft.Report.Components.StiText Text27;
        public Stimulsoft.Report.Components.StiHeaderBand HeaderBand2;
        public Stimulsoft.Report.Components.StiText Text13;
        public Stimulsoft.Report.Components.StiText Text7;
        public Stimulsoft.Report.Components.StiText Text8;
        public Stimulsoft.Report.Components.StiText Text9;
        public Stimulsoft.Report.Components.StiText Text10;
        public Stimulsoft.Report.Components.StiText Text16;
        public Stimulsoft.Report.Components.StiText Text20;
        public Stimulsoft.Report.Components.StiText Text21;
        public Stimulsoft.Report.Components.StiText Text22;
        public Stimulsoft.Report.Components.StiText Text23;
        public Stimulsoft.Report.Components.StiText Text24;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLinePrimitive2;
        public Stimulsoft.Report.Components.StiDataBand Data;
        public Stimulsoft.Report.Components.StiText DataObjects_Symbol;
        public Stimulsoft.Report.Components.StiText DataObjects_Account;
        public Stimulsoft.Report.Components.StiText Text28;
        public Stimulsoft.Report.Components.StiText Text29;
        public Stimulsoft.Report.Components.StiText Text31;
        public Stimulsoft.Report.Components.StiText Text32;
        public Stimulsoft.Report.Components.StiText Text33;
        public Stimulsoft.Report.Components.StiText Text35;
        public Stimulsoft.Report.Components.StiText Text36;
        public Stimulsoft.Report.Components.StiText Text37;
        public Stimulsoft.Report.Components.StiText Text30;
        public Stimulsoft.Report.Components.StiWatermark Page1_Watermark;
        public Stimulsoft.Report.Components.StiPage Page2;
        public Stimulsoft.Report.Components.StiWatermark Page2_Watermark;
        public Stimulsoft.Report.Print.StiPrinterSettings Report_PrinterSettings;
        public new InfoBusinessObject Info;
        public ObjectsBusinessObject Objects;
        
        public void Text18__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "ریسک";
        }
        
        public void Text19__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "#%#صفحه‌ی {PageNumber} از {TotalPageCount}";
            e.StoreToPrinted = true;
        }
        
        public System.String Text19_GetValue_End(Stimulsoft.Report.Components.StiComponent sender)
        {
            return "صفحه‌ی " + ToString(sender, PageNumber, true) + " از " + ToString(sender, TotalPageCount, true);
        }
        
        public void Text12__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "_StartDate";
        }
        
        public void Text15__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "_EndDate";
        }
        
        public void Text11__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Info._StartDate, true);
        }
        
        public void Text14__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Info._EndDate, true);
        }
        
        public void Text2__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "فروش اسناد خريد";
        }
        
        public void Text4__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ": تا تاریخ";
        }
        
        public void Text6__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ": از تاریخ";
        }
        
        public void Text34__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, DateToshamsi(Today), true);
        }
        
        public void Text5__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ": نماد";
        }
        
        public void Text3__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ":کد معاملاتي";
        }
        
        public void Text1__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Info.symbol, true);
        }
        
        public void Text25__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Info.Code, true);
        }
        
        public void Text26__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Info._StartDate, true);
        }
        
        public void Text27__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Info._EndDate, true);
        }
        
        public void Text13__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "نماد";
        }
        
        public void Text7__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "کد سهامداری";
        }
        
        public void Text8__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "ارزش";
        }
        
        public void Text9__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "تاریخ";
        }
        
        public void Text10__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "کارمزد";
        }
        
        public void Text16__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "سود";
        }
        
        public void Text20__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "ارزش+کارمزد";
        }
        
        public void Text21__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "ارزش فروش";
        }
        
        public void Text22__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "کارمزد فروش";
        }
        
        public void Text23__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "سود فروش";
        }
        
        public void Text24__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "مجموع ارزش \r\nو کارمزد فروش";
        }
        
        public void DataObjects_Symbol__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Objects.Symbol, true);
        }
        
        public void DataObjects_Account__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Objects.Account, true);
        }
        
        public void Text28__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text28.TextFormat.Format(CheckExcelValue(sender, Objects.Value));
        }
        
        public void Text29__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text29.TextFormat.Format(CheckExcelValue(sender, Objects.SumAllFee));
        }
        
        public void Text31__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text31.TextFormat.Format(CheckExcelValue(sender, Objects.SumValueWithFee));
        }
        
        public void Text32__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text32.TextFormat.Format(CheckExcelValue(sender, Objects.SellFee));
        }
        
        public void Text33__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text33.TextFormat.Format(CheckExcelValue(sender, Objects.SellInterest));
        }
        
        public void Text35__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text35.TextFormat.Format(CheckExcelValue(sender, Objects.SellTotal));
        }
        
        public void Text36__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text36.TextFormat.Format(CheckExcelValue(sender, Objects.SellTotalAndFee));
        }
        
        public void Text37__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Objects.TradeDate, true);
        }
        
        public void Text30__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text30.TextFormat.Format(CheckExcelValue(sender, Objects.BuyInterest));
        }
        
        public void ReportWordsToEnd__EndRender(object sender, System.EventArgs e)
        {
            this.Text19.SetText(new Stimulsoft.Report.Components.StiGetValue(this.Text19_GetValue_End));
        }
        
        private void InitializeComponent()
        {
            this.Objects = new ObjectsBusinessObject();
            this.Info = new InfoBusinessObject();
            this.Dictionary.Variables.Add(new Stimulsoft.Report.Dictionary.StiVariable("", "_StartDate", "_StartDate", "", typeof(string), "", false, Stimulsoft.Report.Dictionary.StiVariableInitBy.Value, false));
            this.NeedsCompiling = false;
            // 
            // Variables init
            // 
            this._StartDate = "";
            this.EngineVersion = Stimulsoft.Report.Engine.StiEngineVersion.EngineV2;
            this.ReferencedAssemblies = new System.String[] {
                    "System.Dll",
                    "System.Drawing.Dll",
                    "System.Windows.Forms.Dll",
                    "System.Data.Dll",
                    "System.Xml.Dll",
                    "Stimulsoft.Controls.Dll",
                    "Stimulsoft.Base.Dll",
                    "Stimulsoft.Report.Dll"};
            this.ReportAlias = "Report";
            // 
            // ReportChanged
            // 
            this.ReportChanged = new DateTime(2019, 1, 1, 20, 36, 32, 772);
            // 
            // ReportCreated
            // 
            this.ReportCreated = new DateTime(2018, 7, 1, 16, 48, 34, 0);
            this.ReportFile = "C:\\x_ErmN\\erm\\Sanay.Lotus.Erm\\Content\\Reports\\IssuanceSells.mrt";
            this.ReportGuid = "b86f8d2cceca463d98c54d6bebb0a6f4";
            this.ReportName = "Report";
            this.ReportUnit = Stimulsoft.Report.StiReportUnitType.Inches;
            this.ReportVersion = "2013.1.1600";
            this.ScriptLanguage = Stimulsoft.Report.StiReportLanguageType.CSharp;
            // 
            // Page1
            // 
            this.Page1 = new Stimulsoft.Report.Components.StiPage();
            this.Page1.Guid = "3212fef088394d08bce68018b3efe5a2";
            this.Page1.Name = "Page1";
            this.Page1.PageHeight = 11;
            this.Page1.PageWidth = 8.5;
            this.Page1.PaperSize = System.Drawing.Printing.PaperKind.Letter;
            this.Page1.RightToLeft = true;
            this.Page1.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 2, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Page1.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // PageFooterBand2
            // 
            this.PageFooterBand2 = new Stimulsoft.Report.Components.StiPageFooterBand();
            this.PageFooterBand2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 8.92, 7.72, 1.3);
            this.PageFooterBand2.Guid = "da5b68cbe4e0acdcd2b855c8c978488e";
            this.PageFooterBand2.Name = "PageFooterBand2";
            this.PageFooterBand2.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.PageFooterBand2.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // Text18
            // 
            this.Text18 = new Stimulsoft.Report.Components.StiText();
            this.Text18.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.8, 0.7, 1.8, 0.3);
            this.Text18.ComponentStyle = "Collection_Page_Footer";
            this.Text18.Guid = "6db6baa646d85bff23b555c8c9783cfc";
            this.Text18.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text18.Name = "Text18";
            this.Text18.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text18__GetValue);
            this.Text18.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text18.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text18.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text18.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text18.Font = new System.Drawing.Font("B Nazanin", 10F);
            this.Text18.Indicator = null;
            this.Text18.Interaction = null;
            this.Text18.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text18.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text18.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text19
            // 
            this.Text19 = new Stimulsoft.Report.Components.StiText();
            this.Text19.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.1, 0.7, 1.8, 0.3);
            this.Text19.ComponentStyle = "Collection_Page_Footer";
            this.Text19.Guid = "d884f12a77449fe3aa8555c8c978348f";
            this.Text19.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text19.Name = "Text19";
            this.Text19.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text19__GetValue);
            this.Text19.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text19.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text19.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text19.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text19.Font = new System.Drawing.Font("B Nazanin", 10F);
            this.Text19.Indicator = null;
            this.Text19.Interaction = null;
            this.Text19.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text19.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text19.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Image1
            // 
            this.Image1 = new Stimulsoft.Report.Components.StiImage();
            this.Image1.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.1, 0.3, 7.5, 0.3);
            this.Image1.ComponentStyle = "Collection_Page_Footer";
            this.Image1.Guid = "3beaca29357b188ce5d155c8c979a0e9";
            this.Image1.HorAlignment = Stimulsoft.Base.Drawing.StiHorAlignment.Center;
            this.Image1.Image = StiImageConverter.StringToImage("iVBORw0KGgoAAAANSUhEUgAACbAAAAA7CAIAAAAv76mXAAAABGdBTUEAALGPC/xhBQAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAHKBSURBVHhe7Z13nBVF9rffVZGckRwlKyigRAVBJQlIULKggAgsShYQySIgKDlLjiJBVFQk58wMOQwMGQaGDCKi7v7eZ+rbt/fOACrKuoLn+eN+qqur+3ZX1zl1Tp2u6v/3f4ZhGIZhGIZhGIZhGIZhGIZhGIZhGPcoFhA1DMMwDMMwDMMwDMMwDMMwDMMwDOOexQKihmEYhmEYhmEYhmEYhmEYhmEYhmHcs1hA1DAM4w7zL8e///1vb/v//o+0Mn92/OT4McD169evXr168eLF845Lly59//33FNCBJCjwww8/XLt2jWJXrlyhwIULF86ePXv69OmTJ08eO3bs8OHDhw4dCg8PDwsL27t37549e3bt2rVt27aQkJBNmzatW7du9erVq1atWrZs2dKlS9esWbN169b9+/dTnsI7duxgMzQ0dMuWLRs3bly/fv3atWsps3LlSsovWbJk0aJFCxYs+Oqrr7744ot58+bNmTNn1qxZn3zyyfTp06dOnTplypSJEydOmDBh/PjxY8eOHTNmzKhRo4YPHz5kyJBBgwZ99NFH/fr169Onz/vvv//ee+9169ata9eu7777bocOHdq1a9e+fftOnTqR2cPRs2dPfrsHwS7BUcF0dnAe4AzBvBNExwD8HfB34u1bwC6V9A4L4J3uBvg7XYnoEh3vWrt29e4hcJugu+MQ/ot64Jc0Jcns1asX1UWlUXWDBw8eNmzYiBEjRo8eTd2OGzeOqp48eTLVTuXPnDmTBzF37tzPP/98/vz533zzzbfffsvzXbFiBc+ah7hhwwae/ubNm2kGPGLaw/bt23fu3Ll7926eO9BaaAbk8NCXL1/O4+ZAWguQQ2PgWFoFxwYfuM/BgQcOHKAJ0fCOHDlCIzx+/Dit8dSpU5GRkTROW" +
"jJNmrZKi/3uu+9ourRqWjJSQMOmVavNnzt3Tm2eMjRyiYPkIkpIHJIaDkQchJMqDza1y9s2DMMwDMMwDMMwDMMwDMO4AQuIGoZx16CAoh/5UCCEnJ9ccPGHAFevXr106dK5c+fOnDkTGRl5/vz577//XiEWdrEZERFx5MiR8PDwPXv2bN26dfPmzWvXrl22bNnChQu//fbbxYsXr1y5cv369YoGbdiwYcWKFQsWLPj8889nz549ffr0CRMmjBkzZsSIEQMHDuzTp0+PHj06derUtm3bt956q7njzTffbNmyZatWrfgls2nTpq+//nq9evXq1KlTvXr1ypUrv/DCC+XKlXvuuedKlChRrFixQoUKPf744zlz5syaNWuG6KRPnz5t2rRp0qRJ7UiVKlVKx0MPPZQiRYrkyZMnTZo0SZIkiR2JEiVKmDBhggQJ4sePHy9evLgBYseOHStWrPvvv/8f//jH/zOMm0HbuO+++2gkNBVBs4kTJw7th7YkaFdAA6OZAe1N0PZohEBrpE0KmijQVmm0ggZMS06XLh2t2odGTrPPkSPHo48+mj9/fmQBiShZsuTzzz9ftmxZJOXFF1+sVq1ajRo16tat+9prrzVq1Khx48bNmjVr0aJF69at27Rpwy9pQRpJRB579uyJbH744YfDhg0bNWrUxx9/PHHixBkzZiDCX3zxBeK8ZMkS5BrBR8YV7t20adPy5cu/+eYb9i5atAiFgB5Yt24d+aGhoRRAXezbt+/AgQOHDh06duwYagQNc+HChcuXL3/33XfXrl1DF6GX0DPoH3adPn0aLXTx4sUrV66geSggBUUBRXmD47gklKNNwzAMwzAMwzAMwzAMwzDuLBYQNQzjNlAA0h/KB+X8+OOPmr94+fLlK1euXLhw4dSpUydPnoyMjLx06RKZCkMeOnRoz549ISEhq1evXrJkieYdfv3116RXOUh8/vnnU6ZMGTVq1KBBg/r06dOlS5e2bdu2aNGiSZMmDRyvv/56o0aNXnvttbp16" +
"1avXr1KlSoVKlQoU6ZMiRIlihYtWrBgwccffzxHjhwZM2ZMkyZNihQpkiVLpggNCT98qMBhPBc1jBMnjoUMDcPwUXjYjwoLhYQVD1YYWJFgtIqUDNpG7yso+gsZMmTIkiUL6ihv3rxPPPFE4cKFn3766WeffbZ8+fKVKlV66aWX6tSpU79+fdRaw4YN+X311VdJNG3aFI3Xvn37rl279urV66OPPhoxYsSECROmTZs2e/ZsdOayZctQoWvWrCHx7bffzp8//8svv0SRLlq0aMWKFevXr9+yZcuOHTvCwsIOHz584sSJs2fPopavO0iglslEIZPvh2w1ixc1ThnFa1HvUvskoibq/vSTn2MYhmEYhmEYhmEYhmEYdx0WEDWMe4d/uzlGP/30k6KV/F6/fv277767cOFCZGRkRETECceZM2cuOk6dOrV///7Q0NBVq1YtWrToq6++mjt37pw5c7744otvvvnm888/nzFjxpgxY/r379+1a9e33367efPmr732Wp06dWrUqFG1atUqjooVK5YpU6ZUqVLFihXLly9f7ty5s2XLljFjxlSpUiVPnjxx4sQJAsQPTFuMEyfOgw8++MADD1j00TAM448THMEVqFl/di+6183pjcKf0ZsiRYq0adNmyZIlZ86cefPmRXs/+eSTmp5bunTpF154oVKlSmj4atWqvfzyyy+99BJq/5VXXmnUqFHTpk1btmzZsWPHHj169O7de8CAASNHjhw/fvy0adPoQehHFjq+/vrrzz77TB2KFnNes2YN3c2ePXsOHjxIf3T+/PnLly/TE9E9HXNoQj8dlpZQvnbt2o8//qjQrHo0NoGE1+cZhmEYhmEYhmEYhmEYxm/GAqKG8Wfz888/a9VEDfKSuOq+pXfmzJmIiIjDhw/v37//0KFDJ06cOHLkyJ49ezZs2LBo0aLPPvts5syZU6ZMmTRp0tSpU2fMmEF6xIgRffr0eeedd5o3b96gQYNatWpVrly5XLlyZcuWLV26dIkSJYoUKZIvX" +
"76cOXMqQpk0adL48ePHdSgqKR544IH77rvPwpOGYRjGHcdfjVk9jhezddAZ0SslTpw4efLkadKk0RLKuXPnfvzxxwsWLFisWLFnnnnmueeeo0ejX6tQoUKVKlVq1qxJf/fPf/6zdevWnTt37t2796BBg0aNGjV58mR6ydkOdZHTpk2bM2eOYrSrV68OCQmhS6V71eoFQII+Nzw8nN729OnTZx10x/qird4uAnrt6+5DzvxaONYwDMMwDMMwDMMwDOMuxQKihvFL/MtNSdEwKAl+v//++0uXLp09e/bEiRPh4eF79+49cODAkSNHDh06tGvXrnXr1i1cuHDOnDnTpk0bP3786ABDhw7t3bt3hw4dmjRpUqtWrUqVKj3//PNPPfXUk08+mT9//rx582bLli1dunTJkydPkCBBbLd8q4KUGkcWpL3RZcMwDMMwfgP/cMToTwVdbdy4cel2kyZNmjJlSj8i+8gjj9AvFyhQoEiRIkWLFuVXax2XLVu2SpUqdevWbdSoUfPmzdu3b//ee+9pjuzYsWPp64cPHz5s2DA2x4wZM3ny5Llz53777berV6/eunVrWFjYsWPHTp48icGwb9++PXv2yHjAljh9+vSFCxf0rWsXgf3XTz/9hOGh787aYsWGYRiGYRiGYRiGYRh3BAuIGvcmfiDz+++/15Aiv5cvXz59+vSRI0f27t27e/fu/fv3HzhwYNu2batWrfrqq69mzJgxbtw4fbqyd+/eXbt2bdeuXZMmTWrWrFmuXLmiRYvmy5cvT548uXLlypIlS9q0aVOkSJEwYcLYsWPfbx+eNAzDMAwjgKKwwssKQM4DDzyA8RA8NTZz5sw5c+Z89NFHH3/88fz58z/xxBOFChUqUaJEmTJlXnzxxVdeeaVZs2bYJN26devbt2+/fv0+DDBgwIDhw4dPmjRp1qxZ8+fPX7lyZWhoKObN0aNH9dHurVu3bt++nURYWJhmx547d86fAvuz+wT41atXybl+/bpnQhmGYRiGYRiGYRiGY" +
"dyLWEDU+Cvyr6AV6q5evXrp0qVz586dPHkyPDx8165dISEha9asWb58+ZIlSxTIHDt27IABA3r27Nm5c+d33nmnZcuWDRo0qFq16rPPPvvkk0/myZMnd+7c2bNnz5AhQ6pUqZIkSRI3blzNv/SGJw3DMAzDMO4hFI7F1HnwwQfjxYuXMGHCZMmSYQWlT58+c+bMWbNmzeHIlStX3rx5CxUqVLJkyUqVKtWuXVsrErdr1w6bqnv37hhX0KNHj759+w4ePHj06NGTJ0/+7LPPsME2bty4c+fOPXv27NixA9sMQkNDSWs6LJYbJpyW1rh8+TK23JUrV/yJsPpqACafEiAL0DAMwzAMwzAMwzAM47+EBUSNO4xGtTTn4Nq1a1euXDl//vzZs2f1sS7NVwgNDV2zZs2yZcsWLlw4b968SZMmDR069P3333/77bffeuutJk2avPLKKxUqVChatGju3LkzZsyY1pEyZcrEiRPHjRv3/vvv90b7DMMwDMMwjL8A//jHP7QKMdZaihQptARxpkyZMmfOnCVLlmzZsuXJk8ePvNapU6dx48atWrVq78AC7NSpU/fu3Xv16jV48OAJEyYo5rp+/fotW7aEhITwu8FBAkvy8OHDERERFy5c+M5x6dKlixcvsnn58uUffvgBK1T4cVZZp6BNwzAMwzAMwzAMwzD+hlhA1IjGv//976ivV7k39/n96aefrl+/rqBmZGTkqVOnjh49um/fvq1bt65evXrJkiULFiyYO3fu+PHjP/roo86dOzdv3rxhw4avvfZarVq1ypQpU7BgwVy5cqVLly5FihQPPfRQ8uTJEyVKpDVmvcEzw/gN/OMf/6DNPHADsWLFetBBo/KJEyBuEPECxA8iQRAJAySOTpIASZMmTZYsGW1YjTmlw09AqlSp0qZNS2vPkCFDZkfWrFmzZ8+u+TePPPJInjx58kaHHHg0OpQEDvHJ6dBUHuCcwWSLDn/6sCNLAF0MZAoiYwCu1id9AO7CR68jQJog2OR+uWsqh" +
"JrhV1VBpnBVEgX5PhQT1KRqVZWMWghGD8J7MAkS8KT07PQovacbJ473vAOoJdAkwGsfDlrOfffdRxPyGpNhGIZxd4IyR6uj/+ka6DvoSuiRvc4mZUo6Jno6Ok2Mz2effbZixYo1atR49dVXGzdu3KRJkzfffLN169bt2rXr0qVLv379Ro4cOWXKlHnz5i1cuHCpA5t2kWPVqlUhISG7d+8+dOiQPu/63XffyRI+c+YMm1evXv3BoTWHXZjVM57Bs6cNwzAMwzAMwzAMw/jrYQHRexY/oim0ZNmFCxdOnjx59OjRw4cP79+/f/v27evWrfv222/nzp07c+bMKVOmDB8+vFevXm+//XaDBg0qVar07LPPPv300/ny5cuePXvatGmTJk0aL168WLFi2WKz/0OilsBz3H///TyL2LFjK+DnR/gSJkyowJIfxvNjeKlSpUodhEYPc+TI8eijjz722GNPPPFE0aJFixcv/swzzzz33HNlypSpUKFC5cqVX3755dq1a9etW7d+/fqNGjVq0qRJs2bN/vnPfzZt2vSNN97QUCObLVu2bN++fZcuXd57770PPvhg0KBBw4YNGzly5Pjx46dNm0YDmzdv3tdff017W7JkyYoVK1avXr1mzZq1a9euX79e0z42btwYGhpKs9y8efPy5csp/Pnnn3/55ZdfffUV6W+++WbhwoWLFi3icPauXLly1apV/uGbNm3asmULh2/dunXbtm2cZMeOHTt37ty1a9eePXv27t0bFhZ24MCB8PDwQ4cOHTly5NixYydOnIiIiDh9+nRkZOSZM2fOnTuHgFy8eFHL+sF333139epVBAf0JVrx448/Il9IGWkt5gxnz57l8PPnz+skglNdduiEv4oK3wrO9st4/3pruLZfhVv4ZXQqaozaow65d9L8O1WkoWF+qaIbQQuB6pDCqlgNNHN3nJOTU5+c7dSpU5yWZ8STOnjwIMqKx8dz5GnyTHmyPGKedUhICE2FZkMboCXQJGgYS5cupZHQzBYsW" +
"KAmRMOjCbGLkpSnqQiaDUfRCGlI/rGLFy+mmdHY5s+fz7Fz5syZNWvWJ598gnqcMGHC2LFjR48ePWLEiKFDhw4ZMmTgwIEffvhh//79afDvv/8+Lb979+6dO3fu0KFD69at33rrLWQEAUFqGjZsyC/ygqS8+eab/JJGzSJTderUqVmzZtWqVV988cUXXnihdOnSpUqVQgafeuqpwoULP/nkk/nz58+TJw9y+vDDD2d0M+bTpEmjcHX69OnZlDgj3Yo6I/IIPuKPEkAhoBkUSwZFjtEbFic2DMMIBn2IVpRlhbZEc2JNJXbvRcmUQseicrNmzYq9hHIuWbIkNtJLL71Uo0YNbCRFXps3b96xY8c+ffpgTtNrYF1jw8iMkSWDAUNPRF+GHY7tQZfHL50p0PHR/dEb0j/SV6o/VZAVZHUYhmEYhmEYhmEYhvFHsIDoXcPPP//8008/Kajw/fffX7p0KTIy8vjx44cOHdq7d++WLVtWrlz51VdfTZs2bdSoUYMHD+7du3fbtm1ff/31mjVrli1btlChQnny5MmSJUvq1KmTJUuWMGHCuHHjWmjzVviDYgo3JkiQQPFFqi558uSaiKAJdj7ZsmXLnTt3/vz5ixYtWqpUKer8xRdfrF69er169Ro2bNisWbOWLVu2adOGh8Jvq1atSHTq1KlHjx4ffPCBPso1YcKEKVOmzJo16/PPP//6668XL17MM123bt3GjRt5vtu3b9+1a9eOHTs2bNiwbNky9i5fvnzNmjWKBSqOSIF9+/aFh4cfPnz42LFjGlw7f/78lStXrl27RuNRdJwETejChQvsPXfuHHt/+OEHP1IFUWGr69f98rQ9DcYFj8eR1iCdt20Yxh8mhpTdCHuRTcXpkVAEUOFnMpFcxJxdSDQdBIKPgJ8+fRo9cOLECRSCAszoh/3796MoUBeKKytIjJJBvZCv2DNp7ULDrFq1atGiRSglvTozderUyZMnjx07duTIkcOGDRs4cGCfPn3ee++9rl27duzYsX379" +
"h06dOjcuXO3bt3IIUFmu3btUHqoQZQhKrF27dpVq1atUKECerJkyZLozAIFCuTNmzdnzpwoUk1xBjqsTJkypUuXjm4LrYvuTZw4MZ1X/Pjx0cwP2HegDcO4e/ADrg8++GCcOHH0HpvAyMTCTJUqFcbkI488gsX+zDPPlCtXrkqVKpUrV0Zb1qpVSx92Rbv27dsX3Tt9+vR58+Z99tln6GQggQuwxK0wvHv3brwDrLuzZ8+i/FH7bCr4StegvkN9DQkwQ84wDMMwDMMwDMP4+2AB0f8Z/3bzqK5fv37NfWjzwoULke4rmwcOHNi2bduaNWu+/vrr6dOnjxs3TrM2W7duXb9+/fLlyz/55JO5cuV6+OGHU6VKlShRovhuaPj++++/h+f6cHfcI3fK/Wq+Y+rUqdOnT58pUybqwS0Umi179ux58uShcooXL04tvfTSS7Vr127YsGHz5s3btWvXuXPn7t27d+vWTcP0vXv3/uijj4YNGzZx4sQ5c+YsWLBgxYoVmzdv3rlz5969e3ft2kVaUw9DQkK2b9++e/fu/fv3a1BJ66fx1BQm5Any+C66uXckNNLELh/KaODJe/CBmAd424bxa3gtxuFl3YD20t7Aa3zuLQrQoCfQXEFhb9qwoNH6ATb//DqVTnLTY3UUbT54cufZs2fPBEChAfKimBxERESg4k6cOIEcgUJ0R48eRbLg8OHDhwKQSQHKc6x3usAJg1E+f3pTuB5dEifhVH5Q8HbR1WourE/UdB53eTHQVekCgiGfvVQCx3IqnY0zqGaAAhS71QXrAlQ+6s4D/6J7pPLRPxA1dTeISwF4RjwpiPrUXgA9dB4lj9V/70FPX9AG9PT10IGSwY1B+Lv8NAV0Nr9BQlRLCrzWozOosGuD3nRhIK3D+SXNdXLZ3AK347cxbl9VRB1SOTQY+k1FecPCwkiwSQK9TWe6ceNGlPny5csXLlz41Vdfff7553Pnzv3000+nTZs2adKkMWPG0BEMGjRo4MCBdAoffvhhv3796" +
"CB69OhBZ9G+fftWrVrRibzxxhuvvvpq9erVX3zxxXLlypUsWbJIkSIFCxbMnz//Y489FrXydZ48uXPnzpEjB52Rgrh00HRVSZIkoeeKEycOvdh9NiXXMIz/GmiYBx54wC0eHwVmM5onrltBBEWUJk2aLFmyPProoygu1NdTTz31/PPPo80qVqyIZmvcuHHLli07der0wQcf4HSMHz9+6tSpKMnJkydPmTIFOxn9iWOydetWtCsdtOvEokKtgCoOfvEO1B2oW/GNCsMwDMMwDMMwDMP4K2AB0TsGbv8PP/zwvZu7ee7cuVOnTh05cmTv3r3bt2/fuHHjkiVLPvvss4kTJw4YMKBTp07Nmzd/9dVXK1euXLx48SeeeCJnzpzp0qVLlixZ/PjxH3jgAW9s4y5Bb7tz5UmSJEmZMmX69OmzZMmSI0eO3I5HH320QIECTz31VOnSpatVq9awYcMWLVq88847PXv21AqTvXv37tevH9UyfPjwyZMnz5s3b9myZVu2bNm1axe1t3v3biowJCQkNDSUnAMHDhw+fPj48eNnAquKRUV7AgsCa4ifp/CvwLD+vx1KG4agSShC47cN5fjRGpqT4jRqVLQ0UFRJDUwFSJNz0cXCz58/HxynOeFiflqb+qAjPDycXzbJPOaigNrlB3L89WBp8Jq3hxRoWdd169ZpZdfVQawKYuXKlSscy5cvR3zc19CiPocmoj6JtmjRQocWkhXffPPN14758+drTb8/yBd3Aq1wi7acO3funP8y/MUfwTvLncY7+9y51AO1AV7V3CZ6KDzcG4laujGAl+W48RDlgArTWmg2QPuhOdGuFi9eTBuj1dH21AhJq9WpyamA2iS7KEBzpdHSnmnVoCWvtZoxRK1lvGkTm2TGWA17x44dyAidAvKC4Gj5a+QIgULiTp48ifS5YHEUfnSZtETSD2PTO6sk/QhlEOEr7l0WhDp4NB9QAor6U4aS/iHIu0D2UQJoCQ4HFSZT/8sfcW1cIVerKbkScG4EeQ9zk" +
"CBHr+BQOVQX9cyjnz179owZMyZMmDBmzJhRo0aNGDFi2LBhQ4cOpa/84IMPevXq1aVLl3bt2r311ltNmjTRd7s16ZautmTJkiVKlNCSyxgYmnpLv5wxY8Y0adL4YVo67nv7VSrDMO4gmuEqZPnHiRMnceLEWP7oluzZs6NqChUqhNopUqTIM888U758eZRSvXr13nzzTfTVhx9+OHLkSBSalhb4+OOPp06dSl9PZ4HCRxNiF6Gl0erS8ChPVChqVqFWFDIqGjUry1/Gm2EYhmEYhmEYhnFv8C836+zy5cunT5/ev3//+vXr58+fP3PmzC+++GLDhg0nTpz4zuGV/mNYQPSX+LebH4MHjjd+5syZ48ePh4eH79y5k0eydOnSr7/+esaMGSNGjOjTp0+HDh00fbNo0aLZs2dPmTJl4sSJ9bnNv8KAY/D4RcKECZMlS5Y2bdosWbLkzJkzb968BQoUKFy4sJbn0nvibdu27dmz50cffTRo0KDBgwdzj2PGjJkwYcKsWbMWLlzI7e/evZuqOHDgwJ49e6gQBS/ZVKjy0qVLVNpP7t3wH90snxhxSuPvSXDckV/SQu1EQ100FbSbH2ikLSF9oJxz7gOTERERx9zin4cPH1Y7BBd2jIK0H2KkoWrlTwUXabprXWRxZQAXwYmKIyLRiwMscl+g9OOFX7mg0Ze/N+CnmNZNg3yKe5HvQzGho4Ih0yt0a3TsrfBOFB3vKh1e1u3gHWn8VfGe0x/GO10AL/cWeA3uN+A13FtAAe+M0bnpsZImT7SCkIhxFJet4O6N3HhHKozgKwwsFixYgGagE0RFBKMcVIdCv+gTdIuCvugcBXRDHOgi2Lp1q363bduGgvL7ULRWmJvh6r8/QZeKulMgll+MQjgVmGytty7cHK0o0IpkUuz8+fMoTF9ncohf+NChQ7565H8VY2aTfwR2scmFbd68mStfvXo198KtUQ/UJGbo1KlTxzsmTZo0ceLEcePGjR49esiQIf3791eMtn379m+99ZbWR" +
"q5du3a1atUqVKhQpkyZ5xwlS5YsVqxYoUKFHnvssRw5cmTIkCFVqlQYJAkSJIgTJw72iZZBthitYfw9UcwV1yl+/PjJkydPkyZNpkyZsmXLlitXrkceeQS9gfYoUaIEKkXeSrt27fBW0D/9HAMGDBg2bBgOC94ZJhz2HloOzYZZiDVIGr1HGm2JFsXCxObUiy+YnfxijnrWqmEYhmEYhmEYhnGH8MMBChJduXIlMjJSIc8vv/xy+PDhHTt2xL97+eWXn3vuueLFi5ctW7ZOnTpvvfVWjx49Jk2atHLlSty6S5cuKaDgnfSP8fcKiOoBUHeq/fPnz0dERBw8eBA/eePGjYsWLZo7d+6UKVMGDx7crVu3tm3bNmjQ4IUXXihSpAiuOG554sSJ48aN+98LcHJajQXwFxArVix9vZL/TZ06dZYsWfLkyVO4cOFSpUqVLl2aC6tevXqjRo1atWrVpUuX/v3704A+/vhjrn/atGlTp06dM2fO4sWLuS/u7rCbl8ad0oA0xqrXrr/77rvr16/7jZJfqsirLONeh2etx82vdAqQAIUnFclGUhSb5FeD7OggGo8G2Y8F1qvc59jrCAsLI73HTXnctm1b8EzHVatWaRaj4o5R4UcHaT8GGRyA9KITv8i8efNiBEKiAiO/IdDIprf7ZqFEleEaglGm8LIMw7hH8UQ9CG/HLVSTpztuwNMyAbzcgJLxNm5AhYOVG5uU967AESNkCzFe4FABVKtm6y5dunTFihX+DF2sT6FJugJ1vXnz5pCQEIVst2/fvnPnTgwJ6XYUPmpfYVp6ARJYFEeOHJGBofdRoqa+hoWRJhPbQ/aGJtnL7sIOoY9QiEIT4vk7TZzlKIVmSfPXXA9dBr0Dd8Htz5gxA/MGO8dHk2iHDRuGFYSt3KFDh9atWzdr1uzVV1+tVavWSy+9VLly5UqO8uXLP/vss9jWBQsWxJrKli2bH5HV1weCg7KeWWYYxr0Cch07duyECRMq1JoxY8aHH344e/bsfqgV37tKl" +
"Sp169Zt2rRpu3btOnXqhDPYq1cvrWQzYsSI6dOno4jQn1GrGbi3RgCFiQbD3EXdoev0SqjcTNIKtWJU42rJ5BbOADeHyzAMwzAMwzCMux5cG/wduH79+tWrVy9evBgREREWFoavtHjx4hkzZnzwwQdvvvlmtWrVFGLDEcuaNWvu3LnxwipXrtymTZthw4bNnTt33bp1Bw4c4Fg8qZ/+y8sC3QsBUWqcavJf8r1w4cLJkyf379+/devWFStWUKHjxo0bNGhQ165dmzVrVqdOnYoVKxYtWhQHOFOmTClSpPAXjvM85t/LP/7xD07CqeLFi5fAkSRJkrRp0+bIkSNfvnzFixcvXbp0uXLlcLbr169PO+jYsWPfvn2HDx8+YcKEmTNnzps378svv1ywYAGeNlceHh6OXx0ZGam1N0nQnr7//nuFrKIiV4E5duZR33u4cRIvVCkUpAQ9ehI/BC3Zet6t16q1H0FTgmg2mkCJDlJscrdjp1uzUXOANmzYoOmSWmcVPbUwgNZWVYRy/vz5GlvX2P1nQQP6MfIhePheUUmVhKixf4e3HYS3w6FzGoZhGHcW6VhP7d4aFRNeluNGJQ/KpGSMObV+aFbnEVyDigXHaLXkslZUXr16Nb0SdrDP+vXrN7oVlUPcJ739Ka1H3Fe9sZGOuXWJyVGQlQJ0eSrDrjNnztAt6lUeLfVx8OBB/5UdTgh0i+Qccl8v1ttjbO7YsQPzHZOMK1y0aBG3w41/6pg1axY3rmWN9SXawYMH9+7du0uXLh06dGjRokXjxo0bNmxYr169WrVq1ahRo3r16lj5ZcqUwRQsUKBAzpw5sT9Tp06NCZo4ceJEiRJhMWI6xo4d28KxhnF3gcwiuYhw0qRJU6ZMid+nUKu+HoIDqI+GvPTSSw0aNPjnP//Ztm3bTp06vfvuu507d0ZpDB06dOLEiSgTTG4UoDQev2vXrkXpodDQS5j0iq2CVBm/uAC4A74byK+5hIZhGIZhGIZh3HHka+B94IOcOXPm2LFjB" +
"w8e3LNnD54LXszUqVP79u2Lp1OtWrWiRYtmzpxZX4SMGzeu3kbFM3r66afr1KnTpUuXKVOm4PVs37796NGjFy9e/OGHH37++Wfvb/5c/roBUVU39ULtXLly5ezZs1QW1R0SEkLdzZs3b/LkyaNHj+7Tp0+bNm1ee+21ChUqFChQgFpOlSoV9Y6D+o/bnMd53333KZyZKFEiHl6KFCkUznziiSdKlixZqVIlHh7erL6FM2jQoAkTJsyZM0eDjLSANWvW7NixQy8Ia9oEcNk4rrQY7oKmw+34cHferRp3MzTUYNRof3RfoVP8Mkbw8pz7EJ2i3egREhrM3b9//969e/3pMpoxo4mV+racxmQXLlxIYxPffPONRpxpgZ8HhSSFG76OOa5N/twgggu44h5eVnTU1A3DMAzjTuF1MEF4/VB0vH1BPR1dmAvIRqHujLMpIhvcM6ow6CRkspfe89tvv10c9IFbUEQWVq1a5b7U7IVmFZHdsmXL1q1bMfPoqQ+4z5nDkSNHtAoxme6No92YqSrALoxAenxFL0gcP36cfAVi6euBRFhYGOdhF5YAp5KVq06fa+M6v3RwO0CCO8XfGDt27JAhQ/A6unXr1qFDh5YtWzZr1qyp4/XXX69fv37NmjUrVqxYqlQpHJL8+fPnypUL8zh9+vSaEZskSRJ/Uuxf5MsOhmH44JDixuKTIqSJEydGZh966KGUKVMiv2nSpMmcOXPu3LmffPLJ559/vmrVqjinjRo1+qejefPmbdu27d69e//+/UeOHDlt2jT0BsoElaJ3O5YvX442Q/ngrqKgcENwVEGJCxcu4K3gv/ih1hh4no9hGIZhGIZhGHc/MvJ//vlnXIDvvvvu4sWLp06dOnDgQGho6LJly2bOnKnPRLZr16527drFixfPnj170qRJY8WKFTyAgNuCt4KHQoFXXnkFZ2TMmDHz5s3bsGEDTkdkZOSVK1c4v/wL74//AvzZAVFunirA0VKIiLrGH6OCdu3ahYe2cOHC2bNnT5w48" +
"cMPP6S6X3311fLly+fPnz9Dhgx4g1TxLw/ZyIGMEyeOXtRVRJNHUrhw4eeee65atWr16tVr0KBBs2bN3n333Y8++mjs2LGzZs3S+No37mMzO3bsOHz4ME/rnPtUIc7hpUuXrl27FhzL/Es9P+N3EyX0AYKjmLRMnrj/MUsawPnz52kSNNQTJ06cPHmS36NHj4aHh+/du1frwW7evHlT4PuUq9ySsEuWLNEkS9qV5soIjWl+8cUX/pCuYDMGZEZFLAMzLKOGgR3a6204OJthGIZhGLeF14lGR50seNtBeDvcIu0+6qM5myKXQif3+3FQGQwAxWKxEMBfNx6bQdNkAStijfv6LFZx8KRYrUIMpHe7xR7I3xOYC3v8+HGZrJcD6xIfOXKEfI7CVgGKceyxY8f00h6WDLY359m6dStmDH/H/3IZuiQuY8WKFaS5F+zkKVOmfPzxx8OHD8c479mzJyZ0+/bt27Rp06pVqxYtWjRt2rR+/fo1atSoUKFCyZIlCxUqlC9fvkceeSRr1qwZM2ZMnz596tSpcZAw4xMmTIiJbrNgDeN/BaIXK1YsxBBhTBIAlxkJTZcuXfbs2QsUKFCiRAm8b7zm2rVr161bF+lu3Lhxy5YtO3To8N577w0dOhSFgELT6xooN3QdumL16tVoEvQMSgZdpBdApW1I40/pi62+H63RAHOrDcMwDMMwDOOOExzp8OcZnjhxIjw8fOvWrcuWLcOGHzduXI8ePZo1a/byyy8XK1YM/10zDG/qrSdIkADXvmDBgvgIXbp0GTFiBB7Bxo0bffsfg19RT+8K/vLcmYConBlVt4Kdly5dioiIOHTo0K5du9auXfv111/PnDlzyJAhb7/99quvvlq2bNk8efKkSZMGHwyv7KZ1reVneRIpUqTIkCFDzpw5qffnn3++cuXKderUadWqVbdu3T788EMFNb/66iseJ57Ynj17+NOTJ0/igEVGRvJILl++rM+30A6AKzTX6x6Ah6j2piYnCVcUU4FMueIa9UM4/" +
"ekXYWFhu3fv3rZtW/D8S9z4VatW0YQWL16sb5Upcilw+KOGQoMmpgBpHy/L4WXdbCwVooZgDcMwDMP4e+OZBb8BWRdzAx/GloHBGaJCr0Ef21YZFaMM+Rgw37iliRc5MG+EcpYsWbJ8+fKVK1diBWELbd68OTQ0FOsIG0kBVCCNGc+vIF/BVwzs8+fPY2jxi6FFDvbVAfcFWSBx8OBBjC52YYlRGEvscGAlDE6ID6bXyIC/5ned+8Q4l4S/wPVPnz4d837YsGEfffRR7969e/Xq9d577/nTYd944426devitr344oulS5cuWrRovnz5NAs2U6ZMCsEmT548UaJEfvzVpsAaxn8P5Au3PXbs2HHjxo3nwH/Xeks4+1mzZs2bN2+hQoVKlChRtmzZihUr4svXrFmzfv36TZo0ad26dc+ePYcOHTp58mQ8evjkk09mzpyJKkOD4ZehIvDuUTIoE4iIiEC3oFLOnDlz4cIFPD4cQMVW5Q/ya56+YRiGYRiGca/yLxfpvH79+pUrVzCJsY1xwHHk16xZg/E8e/bskSNH9ujRo0WLFjVq1ChevDjO8sMPP4yDjJWOd+xZ8NHBZU6QIAF+dP78+atUqdKsWTMc8IkTJ2r2INb4qVOnMLwVXPOu4y7nNwVEFXninnE5tPCXPtIZEhKiKbQDBgzo1KkTXg0eTpEiRR599NEMGTIkSZIEv+jBBx+MFSuWQpvUPvmaslmuXDkeDL5Qy5Yte/XqNWzYsOnTpyuuySPkzGFhYUePHj19+vT58+cvXbrEY9ZMTRcIi8K7OOMuRE+QRqVfSTKtC+niQdPG4OLFiwi2/N7Dhw8fOnRIkzJ37twZGhqKe7xu3TqaysqVK5cuXbpw4UKk9MZAJtx0oFCQ9lGOCt9I1OClYUTHaxzR8fZFx9t3r+Pd7e/FO0t0vH2GYRjG78JTpr8NmUayl0DWEfneuRzkeLtvCL4uWLAgauprgG/dx8iVqfirJr9u2rQJQ05fb4XdgaWG97mJsPgX2HtaS" +
"RgjMNK93YgvIEiTg3fALpwRwDcj88KFC9iNQIJNP0yrObKcf5dbqVhhXQVlN27cuGLFiq+//ppbmDVrFv7eqFGj8Edwavr169e3b9+ePXt27NixVatWb7zxRp06dSpVqlS6dGlcyieeeOLxxx/H2cmVK5cmwqZKlSpp0qT+FFiLvxrGH+e+wNLBQgFXSJAgQfLkydOlS5ctWzYksVChQkWLFkUwy5Qpg5C+/PLLr732WsuWLTt37owgjxw5csKECZMmTZo6deqMGTNmzpyJvOM5Iv5ogyNHjkiNHD16FJ0DGnxQqPXHH3+Ul0oCRxV+cosJe96sYRiGYRiGYdw5ZHZihZ5zH9zx42742tixQ4YM6d69e+vWrevXr1++fPmnnnoKhzRt2rSJEiXCVP5lD5S9WNEPPfQQDuxzzz3HGTgPpvK0adNwh3HS8Zfxr/Gmv//+e0U973mj9/9xh4B9f+3aNU3rDAsL0/zZTz/9dPTo0f3792/Tpk2tWrWef/55RZUhhyN79uz8kvn000/zMF555ZX27dtr1ubcuXM5w7p163h4+9z82cjISGqW56r5mvd8zf4dUONBToAmhKPIw+URK5yJAPPQ/YgmHHBfz9qxYwetYsOGDYhc8AKzCxYs+OqrrzTdATQ2BziuNw7PCdKCtFc6OjqVcSNeBd0mqvZgvAcQhPK9A6KjXV65ADxT7ytwNxD8uDncu/Q/hq7kjuCdMfpKiT4uKO9Bwxb0NPBNAI0U/z68U9wO+vffgne5t4l3t7eD6sqrx5vh1fXt4B15m+hYtc9fbpO/gGvRN0FtOAb6xxh4B0THOyA63gHR8W7G4WXdAq+QYRjGncbTMrdGSsxTcI6b6rSblqHLoLuhR9NUV+FvYk/ifdw47RV27tyJCYqPEx4efuTIEU0yOxn4DgKQPu2mtGLEanlPIKFPJ5APCrtS4GrgU4v8XrlyhQJnzpzhcDh16hTuK38BmL4HDx7kTzF9N23ahNG7aNEiqmj27Nn4tBMnThwzZszIk" +
"SP1RdguXbq0a9euSZMm+FMvv/xyxYoVn3nmmaJFiz7xxBOPPfbYI488ki1btvTp0ydPnjxBggSxY8e2sKth3C5ITTD33Xff/Y5YsWLFjRs3UaJEKVKkSJcuXdasWXPnzp0vX77ChQsXc5QqVap8+fJVq1atX79+ixYtunbt2r9//xEjRowePXr48OFDhw4dNWoUEo1co6NWrFiBzkH2UQKIP8pnl/tiNDkoB3QFOuSHH36QB/2jW+UINPbk+diGYRiGYRjGXcu///1vTDtcRWy8a9eu4TDiSyrGiWO4bt06XFfc28mTJw8aNKh79+5t2rTByHzhhReeeuop/L60adMmTpz4Viuq+sigVSJ+/PipUqXCiMV/rFGjRqtWrfr06cP5cZP5u927d+P2Bi+vooCOd7l/S/5f8+bNmzZtWr16daz8MmXKlCtXDg+8Vq1ajRs35nl06tSpd+/euOu47lSiVq3BvY+IiMD554n6XwShHnne3lmNuw3N1EQkfIm9evUq3tqlS5cU2jzt3rXHkdu3b59etMfT27Rp09q1a5cvX7548WKEWVMBvnZfygweEdOQlhcxuHVEEyjsBtPuMnSbvwXdJni3HR3yvXIOlQRvt4MK9CIzAfwq5RDvgm4HF5DyUIwKvnKhu29cxC54zBEWuQ+MLQ3A04eVK1eujs6aNWvQuVoNb/PmzVu2bAl1bN++He3vzwihOdEfaHk9OHTo0NGjR48cOaJfQT4FRLhDJQFdRAE3knn0mFsYGTTECagp0BeMINJxJsDZs2fd8OY5VBm9gkY5afA0e0C50U+AW4M5CnSdD/0ZMoKkSFjYpABHcQbQ4cHoVBDjVBz4u/FO8RvQn/5GvAu9Hbyb/L1QXVS7ap4LoD6D8e9U1+YdEziK2taz02g1z5QnqwfNE+fRC5oB7YGGQfOgnah10XjUimhOaldqY+Swl2IqGaOw0CEUpvWGOaQYgYaNeqSRCxq8G4rftnXrVokAhISEIBQbN27UTHe0qN4OQXD0q8SKF" +
"SskX8uWLUPWlgRAABFDhFEqVyjgjfB6whzAk/M/gHTRL+gfH5UBp7ei4VSaB5teuVugQ4R3zO3gXbdhGPc0nsDfgFSHp00CKNOHnGCtRY530uinZTPYIpI5hBJGJ6OZUdEoat/a8ae90gvQO9B3yA7hV8aJNume5EDRu2F1Q3BPJ6L6eAe7gi0NdtEV+j0g5+Fs9HGcmQ6Lroruae/evVyDgq90Ddzd9OnTx48f/7Fj9OjRuNzvv/8+/h0O4CuvvFKlShVNe3366adxvwsVKvT444/nzJkzc+bMqVOnTpIkCa517NixH3jggfvvv1/+tmEYvx2k5j736dZ48eIlTpzYD7jmypUrb968+fLlK1CgAHJXqlSpihUrVq9evVGjRm3atOnWrVv//v2RVk1YHzhw4KhRoyZMmDBr1iy0ENYjegZDFONTFiaWJxapP0SDrlCcFcsZpYEOwdMXnudvGIZhGIZh3CaYUrhvGFoXLlzAETvhvguD/4UbuHbtWhxGPK+RI0f27t27VatWderUwbrDycqTJ49ebE2WLFncuHFvdz0hvDDcsUSJEqVNmxY3rXDhwtWqVWvRogXmIvYh7iquKKYg/iBXpTFVLvJn+1T/r/H/NM6LF41HHVx3VnF3KTy4fwWW9+FRIqj4Qho3ORf4khOPGydqj5usiRO1ZcsW5GflypXLli3TV6YQY8338oeHNIQkNH4kvCyHxo9AR/3JeP/9a3Cd3qUHEXzx7laiIF/jZaChf7+kF2q4GVSaD3UICiviviqMoaG0FStWxAgirlmzBgWqMbWQkBCeC08HpcZjQr0qashTO+heN0bTHXeRP379UTDh78UlViBQwT8aAAKusNOVK1eQ9GvXruEh007UVPxRNn7lP2tUjl3gRuS8wlEDeE696jWIYF2h5gfetmEYvw0JTrA0gRMvT6WDRE9iKJGUeEYNnDv84XJQb65igk31COxF0hVOVtfgB5IVP5ZuCQ4G80uafH98X5oHFB5WbBhlpZDwzp07tzu2b" +
"duGdUgvg2YDxYAVBgb0nkAHohJRjH70F22p/sjvkoSnXm8I/f4CdBC+SpcyF1LvENUNBHDqPwr1CEDaK+eIUSwY74DbRF2YYRh3C4gt8i5VIKQBhHLQFb6eUYEYwu6k34NNdJpirtiKy5cvX+VAMSqBtty4cSPGIZbhvn37ZAqih6WK+VWoFWWOmYeGR88Lpekd6ALoPtTRkFCPIEjLtGOX+h3SHKLD6SzoJtQ1yJ7EsORPuQyuhyvEvuUGZ82a9emnn86cOXPGjBlTp04dN27cwIEDe/bs2a5du9dff71mzZpVq1Z94YUXypQp87yjRIkSOPN58+bNli0bvn2yZMkSJkz44IMPPvDAAzj8QDpWrFh+IPa2Rg0M42+CRAMxiRMnToIECZImTZo6deoMGTJkyZIFycqZM+ejjz6aP3/+YsWKlS5d+sUXX6xTp07Tpk2Ryq5du77//vv6QnPfvn0HDx48ZsyYadOmoYuwxLDZ9IYfMo7mwYrTex4IPkoAtRBlU16/jopA4fCLxpCZKqs12IIFbRqGYRiGYfx1wPHBdMEJwuvB38HCwaXav38/Zs+GDRvwvxYsWIBr8/HHH/fr1+/dd999++23mzdvXrt2bdyZJ598MnPmzPgviRIlihcvHm7L735zlKNwefCDUqZM+cgjjxQvXrxSpUqNGjXq1q3biBEjcKzwDbkkLozLw9fDDOOCMb1kYpmh9Uf4Td8QNf4nOCfiPxM3f3Cj3vI9zru1uSIiIo4ePXrQLca1y03ZxG9Zv3796tWrl7tZmwjwbc3X9PGK/uGBWu8svwH9LxcTjLcv+sCTf83k61++jD610Uc5eq//xpf6165du27dOjQdnh4EhyHx+vbt2xd+w6Jq/sATm6fcvEMFGjUpkEfDM9KgEl6iAg+gyGLwkBOgeXmyesR61mwqR0/fMAzj3uOmuo608t142n/ivm7A7T9BXylVBXqlS9UzKj84xItmjgxMnEJj01Giun1lTj7QgbILJY+qP3DgQHA0d/v27" +
"ZrRqziu300IOln6Dj+IqzguPYsfx6W70ZxdryuKjjqmGChqq87O7+/UR4M2hQq4jjEKFfbKBZVUMfDK3SbqWw3D+DPxxM/hCXB0EWZTAu4JvEPy7pWIDueUhYzmQSOB/36eVvhAfaHKUHHoOmxg/Aj/M6uoRL2Hd+jQIZQnFi+q1Q+1om9xRqRySUsto719ZR6s5JUj9a58P8dX49LknBPtjavPf/GLokZF651rtC4KlnvR/QL3/umnn06cOHHQoEG9evXq2LFj06ZN69evX6tWrWrVqr344ouVKlWqUKHC888//9RTTz3xxBOPPPJI5syZU6VKpWmv8RxKxI0bN3bs2LFixbLgq2EEgywET29Nnjx56tSp06VLlyFDhkyZMmXNmjVnzpz58+cvUaJE2bJlq1atWq9evcaNGzdv3rxNmzZvv/12hw4dunTp0qdPn6FDh06YMGH27NnYSBhRmFgYWqgdeeJoHsQcVYNhhkqR14ye0Yu8bKIlwFcgvlbxNw3DMAzD+BsS5VQ4kwA7AX8ErwQPArflxIkT2BW7du3avHnz2rVrMT/mzJmD1zBw4MDOnTu3bt26WbNmdevWfeGFF4oVK5YrVy5smxQpUuAj6LsktzuD86ZwBiwoffkeqwlPBJekZs2ab731Vs+ePT/++GOcGvwybKF9+/bJBFKwk3vhjrw7NP6bWED0T8IXVPn/GuTFxKfFX7x4Ef8/eHBWczfxExBdzZhBgBXdDA5wzrshguijwQLhD4v8Kip5UziPd+og/JOD+yuvjHI4oT8QA7r4YL4NLD6mERkUwUYXmNQKq354ktrYv3+/RmROBqGhbc2AROtpUIYqpW79ERaNofNLmhzyo8Zjoq/wrOfibxqGYRiGuGkHwabyQX0KnYugo6EPotNR7wP0PuSrJHvJx1in61cEl86LLoyODBuATk392in3wk2kW/lZtgE9oKbhYi7v3r2bntEP2Qr6TXpPP16L8RA86ZZ+lt6WPleRWh/1xXTQ9NQxCI7RKu7io" +
"95fqLv3IYe9XjmHMwqiUHnwigbwcm8W0XGGiWEYfwhJkydmtwYh9YQ2AJk6VqiM0C4UhW/MS8MI0rgty5cvx7ZHL8mY3+XYGQBVduDAAbweVBxOkCIfaEXx3XffSXlGvRQTeC2GhHRpDIX8y0hXS0vLNeDM/IX+EVVMApWrQRN0KSqUK0c9KnjM7aAhqY1JkyYNGTJEqw2/+eabr7/++muvvVavXr3atWvXrFnz5ZdfrlChwrPPPlukSJE8efJkzZo1Q4YMqVKlSpYsWZIkSZImTcovJEyYMF68eHHixNFcWIu/Gn9b1PJB01vjx4+vgGtKR9q0aTNmzPjwww/nypXriSeeKFGiRLly5ZAyJK5Ro0ZvvPFG8+bNW7Zs2bZt265du3744YejRo2aOnUqSglrR/Pp+dVraqtWrdqwYQP20p49e44dO4bRhQ0GCD4mFpCDKkDnYJ6hZNASqAspGV978Ct9YhiGYRjGHYSuln4WZKVjmdMva2DkuPtmH/Y53Tp9+pdffokPMmvWLL0N2a1bNywBrHFMcSyEsmXLFixYMHv27JjfWBSY3AkSJMDAwMz45W9w3i6YLhjwWPKJEiVKkyYNNn+BAgXwArgSzJJ+/fqNHz9+5syZ+BGYH9geODsYG1gdCnZyp76NoRowfiPUGGCSCS/3j2EB0d+P/zx86dVAJ1Y1Mkyjx+wOd5/3QIYxxPGx16xZg5u9ePFiHGwFOOe76KZGGfgVbrTBg003EBGT4GEOCC4WfAYNagBpv0xwAWWiXACfX4OkXBtwkYsCH4z0F+wKjlbqXfK9e/eip7jZU6dORTpIgPMyoqKV58+fp06oGaqIivKHNkCjG1Sg2jT16VVuoHq9DcMwDMMwonNjR6kcdalRvoVDJoogrW4XSJDzfWCKLT01xjoGjD/FVl05/Tg5fuZJ98HCQ4cOaWYthj5Gzo4dOzAJFKaVecAvpgI2A86AwrSYQCvd4vxL3KdwgyMosjrAhWijxWgxTny7xbdnhG/VAGmhMuAVc" +
"nj7ohtUXpbDywpCVpZhGL+MJzC3BgH0ZDK6MwJOOqPQLkE+p0X2UQXoBE9HBOKsaA9YsWIF+gSvRBNbt7vv02tu6/79++WVRLhlhFFcaDAlLl68eOXKFYVapQmBBKAPpTyD8bTqbcKBUq0a0+F/5QSxSZoLQ21yzWhFlCE3yE3pxVB+uUeqYvz48UOHDu3du3fHjh1btmzZtGnTRo0aNWzYsLHjtddeq1mzZqVKlUqWLFmwYMHHHnssR44cGTNmTJMmTapUqR5yJE+ePGnSpBoPih8/fpw4cfz5r95wjmHc69Da77vvvgceeODBBx+MHTt2vHjxEAe9oJAsWTJkBBCZTJky5cyZEzkqUqTIs88+W65cuSpVqiBiderUqVevHuKmOa9vv/12jx49+vXrN2LEiKlTp6LHMGOQ2eXLlyPFGC38KmfTpk0KvkrnnD9/Hjsq6lVu97obmZhbKIRr0aeAkEBvoIi0aRiGYRh/WbB11W0JujPsXi3tgNWtsQI4evRoeHg4VvratWvpJTFxZzumT58+bNiwnj17YuXWr19fEc3y5cvTEefKlStt2rQyYmXHKqj537ZgFebEWuBP06VLly1bNmzsihUrYga0bt0am3zMmDFcNu4JFjtmPMb88cACttw7lUCF/G7fwfBR08Icuu4W3cSOUos6dOgQjt6WLVs2bNiAoUXCO+CPYQHRaPi1D7RpPQMEWzFOrFi9pIC/rSX1eBirVq3SDM5v3GQLJESjA26ELVpoE5T5q1AyatjAoaPcuMF/Bu9IB8cvNUygkYKlS5dii69evZpr27x5c2hoKOKqV7M1UoBKQjFFuE8BCQ0TYK/7IwWKU6LXSAC1QbUA9QNeZRmGYRiGYUQn2E6Q2QCyIoLtK/CdBzLlSt0YnfWtFDaxUuRoaeKsvhqw332/VnHZnTt38quE5tFiCG3cuBGLSLNmsdlWrFiBpbTYfdVbthNGFE6akFnlR2QVjg02wHyUHwyZMew3cdPyygRvOzou0mQYf1M8MbgFS" +
"I0nWkEvSUiaggney1E6M0KNdAcjNwqFoDWEURSoC5SG9IZcbjQJPhQOFGpH74jIJTxx4gQJFBSaCpWF+kKPSb9dc7CJcpOWgxhaUZu/Ax3udGrUmfnHq1evoh7RnFwDcDFc1ZEjR/bt24cm5F5QfeAvxkMCNUi1TJs2bdSoUf379+/evXuHDh1at2791ltv8du2bdtWrVo1adLklVdeqVy5cunSpYsXL/7kk0/myZMnZ86cWbNmzZQpU4YMGdKlS5c6deqUKVMmS5YsceLEd3CdMcO4u9BYKo1fwVeIHz8+EiESJUqUPHnyNGnSPPzwwwhRgQIFihYtWrJkybJly1asWBERe/nllxWFbdy4MaL3zjvvvPfee4MGDRo/fvynn36K7vr6668xSHx1hypbsmTJmjVrMHLQTgg7Io8G0Hg0NhI52EjSUXo3nV3SUegNaRLZY/6mYRiGcW+DwpcDLjOStAxIBTvkWdN9HHMzu7Zt24bpSHcz0/HJJ59MnDhx+PDhffr0wWJ844036tat+9JLL9GRPfvss1iJdG3Zs2fHMsQg9PtBfZbiT34nj//SG1Fx4sRJmDAhNmratGlz5cpVqFAhrrZ+/fotWrTo3LnzgAEDuKNZs2YtWLAAw5j7xWzm3s+ePXsl8J1OWdrg1aDxB1CrA5kfCqLT9vx4JyYND2LFihUaqJF3hqmD5+KbOnK4wDvpH+NvERBVvWu4DZmn7rAXMRZp6NiLtHhqf//+/Tt37tRaSYg9XuLChQv9QTEMUCxROeHysecEkGEqnN8dBWmKRXntN8CpOKHeetZInP+kV69ezePnYYeGhm7fvn3Xrl179+7VolKHDx/GosUJp7noyzqKX9KAEFRuilsTNCzf9/bu3zAMwzAM4+9HlAcTHQwkLCXZS1EmecA+xCjHoNJELkxtTCzf3GKTTJDHqNkex91nDoIjsnrtDJRWRDYkJAS7TmuEYF5qEWPQRDc/LuuisVETZH2zE4tRNqePzMhgZHl69mjAIr2xsHKCU" +
"b6LEBnG3wi1/F8gyp2LjiczDufkRaFNyuu0CKwP8qs4KxL9rVtrB6cSwcfLk6OnOCu+nlbZwctDjeDoCcUwNL0VXxW1I0dPDiwKil/f9ZPH54N+8xTfHUVqU3qSC8D3RFuyCVwJ6hGVyGVzIyg9rQqge9y2bRvOLC4td01VfPrpp2PGjBk0aFDfvn27du36zjvvdO7cuXv37qQ7dOjQokWLhg0b1qpVq2rVqmXLln3qqacKFCjwyCOPZM+ePVu2bA8//LBCsGnTpk2VKlXSpEkTBK2EZvFX428FbV7B11hBPOhAKCBu3LgISJIkSR566CFERosP582bF5kqXLgwwlWqVKnnn3++TJky5cqVq1ixYvXq1evWrduoUSPEEGFEKjUXduLEiTNnzpw9eza/U6ZMmTRp0tSpU2fMmIG9gbmCJaMRZGQflSWTCfXFpmbqS5uhymRHoTpQXOgNKRa0CiqFHA1e/ZfUl2EYxt0FyhCV6Puq0o0kFLnE4pIHeujQIYxGdCygb3E5V65ciUWKip48eTLae+zYsR9//DF215AhQ95777127dq98cYbNWrUqFSpEpqfXqBYsWIFCxZ8/PHHMbSwr+gv6DhiB6BbubMrzf5x6Pjo3eja0qRJkzlz5ty5cyvAyU01btwYk3Lw4MHcOPY5hjcmNxYpZvaxY8fohqg67Gf1QfQ+qmrjzkJb9VsvVY2PgBeDYaCgW1hYGK0UswHjQUMfGBIgj4lHtn79evwITIiTJ0/iAdHg/eclKfhvcBcHRKkUuWegkSzMLEU6afGoCXTEvn37sNJwydauXYuCwCmlrnFT8Vd9v1eercaSNIMbSCvf94R9p9d3dOXlLlmyZPny5XrrFpHjGePf7t69e4/78iVKisd55swZrgowB/nV63sIJNfMlUvT/beftGEYhmEYhvE/IcpFCIRjZfUpR0YsPgNmoexYfDZsRX4vBb6qqEAsxi0m5dGjR7EtwwPflMW70OAjacUe/JWKMX0VgsVMdUHYZYsd2K5Ys" +
"NixOCEYtLKKZeLKNg5G+YAl7MJD0V7+A1nIPs5k/s8EPlCOt/vWeH9jGHctXlO+GZICTySCgqza9CTKob2czUVXPXR+EkgrYoszixQj0Yg2Ao6YK9qq6a1ogB07dijUqtf8cYr5JY32iHBLBKFS0DZ6/wOUVpzV90l9UFOeFvuz4B/RiqhE0CUBl4cyPHv27AkXcZG62+LA9VZQGe9748aNaDlqcurUqWPGjBkwYEDfvn379OmjX+jZs+c777zz5ptvNmzYsHr16uXLly9ZsmThwoXz5cuX1/Hoo49qFmzGjBn1IdjEiRPHjx//wQcf/JOnOBjGXxDNvIkBmcpXmDZOnDiKyKZIkSJdunSZM2fOli2bH5QtVKhQsWLFihcvXqJEiWeffbZChQrVqlXzZ8d27NgRIf3oo49GjBgxbty4iRMn8jty5MihQ4cOGTKEX9Ljx4+fNm3anDlzUIlLlixZuXLlunXrtm7dikWElsNSQtGh91AL6AT0ISoCpYGKQBOiQE6fPq3V0bCyNOSKhkHX+cqHTJQPmdJIhmH8zZFmkLP2g1sflRyUhtQFXhtaBd2CoYWqQe3wiwo6deoUmfhooaGhqCk8L7TW5MmTMU7QY8OGDRs+fPioUaP4HThwYK9evdq3b9+kSZPatWtXrVoV40TTLp966qkiRYqgOTFOsEzQqMmTJ/cXksUsAelhHylkT2X/JeEiuX6FNrkp9Q70CJUrV37ttdfatWtHbdALjB49eubMmfPnz8euQ8lj9eHtUsnUtqIqVD6P4H9iqf6tUGsHf9QC34FHoNfEeSI0cszyzZs3a27ht99+y1PzXCDn4+PC4L+wC1eFzhoBoafmcM6joJgGRrz/+xP5ywVEqQVVNzWCosFAQelQTdgrGC4aCaL6MGvw9/D6qHHEA+WCPURFU91yL3GEZs+ePctBghw9DKAYhTlk4cKFmFD4k3pvd/369fhUiBkqzB9jklGF66hYpsan8Bt9pxHkN/5Pnp9hGIZhGIZhxAC7FANVO" +
"C8mCtJ4HViw2LG4kQrBKvJKGpObTNIYvZGRkRpSxM85ePBgeHg4VjGQ1iam8u7du7dt26ZZsArBYk7j84MCsXg+WOnY27hGehVU81+jwju/CMa8Cw95LyySUKBIyJ73Nn5X/BW8fzKMvzBeY70BtXOv0btm7+0IcoRvFB/vpNFPGxVxDXyHRaFWvGMkF/TKL3K9ceNGfOQd7gssvpsM+wNfbNWynIqt8iutgtes4SqNHqJ/5Cz7nj6/Ulb/Q7gwLs8f4tSFoSG5C013QwGi7vbu3cvto/EOHTpEppb2olqoK2pv5syZ48eP17CmhjhHjx49btw4cgYNGtSnT5933323ZcuWTZo0efXVV1966aXy5cs///zzJUqUKFq0aJEiRQoXLlywYMF8+fI98sgj2bJly5gxY9q0aVOmTKmJsHHjxlUsVgOdoLHOG/EGGg3DCIC8xIoVK3bs2IhS4sSJkyVLliJFilSpUiFi6dOnz5w5c9asWXPmzIno5c2b97HHHnv88ceRRORRaxojqlWqVKlevXq9evVef/31pk2btmjRon379l27dn3//fc//PBDBFxh2oEDB37gIAfBR/ynTJkye/Zs9C16ddmyZRppRI2gNg8fPoxxBXrFDY2qt9lCQ0PRsb5qRflQgGInT548ffo0VtlZ9/0IGWz+aCQqyx+HRINp7JRf8slhl7/XTxjGXxC/fdKqacA0cvpl5YC6ZjVvpABZkJ8iIZJXgvjIKwG/v9bUNHLwUHBJcENmzZo1efLksWPH0lkjsIAIk+Z3wIABvXv37tKlS4cOHei133jjDWS/Ro0aFStWfPbZZ59++uknn3wSFSFdwa/WsUCToFIeeugheu348eOjcOiy7+1OGdXqQrHeRzdTp06dJUuWPHnyPPHEEyjP0qVLozYbNWrUtm1bVOXgwYPRitOnT8cNxKrcunUrzwvNhunIc5ShiELjcfOIgxWa8edAhdN3IHcSMUQPG/7MmTOIj3ooHhkWLxKE0UuPhhDhUwR7GYBDg" +
"R+B78AjprPjKGQTIeVUnJOHq6gnf/SXer5/akCUO/frmhrRmIsf5qTXx9mgrjds2LBy5Uq0lV5gV3X7rh2QlguHhYETglxRkvJU/Tr3cRROggbkGchJQ1HyJPBqFM5Eh0rkeN56Knowf7VnYxiGYRiGYRh3BTLyfXOaXwxs+VeY/QrBYoQDvhZpHCRlYpzrJVM8ArwvjW4ACTjiFobav38/bsLOnTsx8nG0sPbXr1+P2b/W4a9IvHz5crw1fxVi/AhFYcHFfW4CDsWNjoYgXx4HkBbePodyvBK/AReNMoy/HF4DdahV34javCck0YOs3pEOMvklE+FSnBU/HZHEVQdFW4NDrSEhIVpcFwHHeYcDBw4g8gi+P1524cIFtAQEv5qMF69gAL+k/c2/uDsvxcjVohiBa9YFk4lK5O5QhpFuPQAqISwsjApRBIUc8qkQ8tGEKEBqEi1Hhc+YMWPSpEkTJ06cPHny1KlTp0+fzu+4ceOGDx/ev3//bt26vf3222+99VajRo1q1apVpUqVChUqlClT5rnnnitVqtQzzzzz9NNPa46sIrJZsmRJnz79Qw89lCRJEj8iCw9E5/7oMVpvlNQwjNsHCUKgYsWKpeWOEyZMmChRoqRJkyZ3IIwpU6ZMkyaN4rgZM2bMnDnzww4EFnLkyJErVy7kFx599NHHHnssf/78BQsWLFasWIkSJZD0cuXKIfUK7qIE6tSp8+qrr77++utNmjR5880327Rpg4ro2LFjly5devTo8f777/fu3buvg3TPnj3J79q1K4k+ffooDDx69Ojx48ejc1A1M2fOnDNnDooIcwslv2zZMn9UdtOmTZs3bw4NDcVyQ89v374d3QUo/N1uRT29YQMKA4PevUPLof8xCElzLGfDzAMSG9x3vjktpiDdB3s5rc7sn9Y/IYeHOw4ePMg5ZVsq0nzMLZ/AX6BaIyIiUK0oWKDHQQmfd58nQyFfvnw52GoVpIFMdlFAfRP9FHAgh3OSM2fOcDYsW87M+fkX4O/4U" +
"/4aZN8Cl8S1Ca5TF8yVc/3cBXA79I/cF3fHPXKnOxzcNbVKDVDDUTFAt0IMdU796CVFamy1g01KckLdNf8Y44/0X/wLf8H5KUz16iT014sWLaIrp1un6//0008/+eQTnjudDm2AlqA4Yr9+/Xr16kX76d69OwkaDzkffPABCZqT35A6deqkD5bT8Gh+DRo0oDXWqFGjatWqNFG9KlSkSBGt2UBjpknnzp2b5p09e/asWbPSPWXKlAkpQBb0CXMEBEmht0Jq4sWLF9s+ZP6LUDN02dI2dOt6X0QRTaqXai9atGjx4sXRGCiKpk2b8rx4jsOGDeNBI+8YfjQGxJC2J5uNJkSrprUjBQiFgpq+PYZLKMvH+PPBtqT+eRA8EbSWwpxyt3lkKAEeH/oEvYE9iQeN9lb0DUmXza94J8jmJ58CFEOxcBQaCTXCqTgnapC/kE3rjwPcFdyxgGhwdeOi0DfQHyAY6H2qCcWKVqWi0afUIH4R/SU+UvAIBQkyMespsHLlSv8tKp4TChpJo7fgbPQrnJka54mCX+/Im0TuLqp9wzAMwzAMwzBuC6z9G8ELwBfwIw245Rq34lcuOh6KHMLz58/jpJxyi1lpZEqwqZxDLgSL/4IngguD4+ePMa1zaJgJh0Uh2EXuqxzybmIQ7OyA72e6oJIHmwomCRW4EfLBK3Rr+AvD+J/jNUeHmu6toG17kuC+z+odE0BlgDSnRYgQK2RNoVahgOvSpUsRSWRTcdbt27dr7BhI7N27F6FGtBFwZP+ce1X6gptoAugENMMVN7MKdaExHfQJCaU9LePw1JAjxuZfHA3XREWP3Xil7otfNrnxy255AGomMjJSavDIkSOoRDY1xB8REXHw4EEqkxrW++s8iNmzZ3/66af86hnxNGfNmjVlypTRo0cPHDjwvffe69SpU+vWrZs2baqpNtWqVatcuXIlxwsvvKAR8MKFCz/++OO5c+fWx8xSpUqVPHnyxIkTJ0yYMH78+PHixYsbN27U5zEdGsa931YwN" +
"oy/B8FRHEADxA6AQkA5AFoCXQEJHImCQJNAkgBJHckcLuIcRYoUKR5ypEyZEv2T2pHWkc6RPgjlaG+aADqEY4GT+HBm4f1T8uT8r67Bu6AAuk4frhwFCLoj3R1IHwL37tVC7NhRL61ER0rSXli5B1D754HyoPXcgZZAE6LhZcuW7bHHHitUqFCpUqW0AnnNmjUbNGjQqlWr7t27Dx48eMKECdMdM2fOxILCUsKXwbvxI5rHjx+nl8ciwmPCV3JWjwfmgWc9GH8NZLPxaOTV8sgwXOXVasK0vNetbp7hKreArfxTuaLYaTK25wR9L1K2NwY2xfRJjrVr12JFY+xxNqxBmgd/wR/55vHdZfr+Ar8eEOVW/Urn/v1xhNOnT1PdyA/VtGXLlnXr1qm6qUHcEiodSC9xy/pToZs3b1Z0k0M4ED8EqxqpU1BTvodvmquKwbsIwzAMwzAMwzCM/wVyTMDfxFvx4yWKv+Ka4tHwy6aLOER9ZwVPB3/n3LlzOKv+LFh+NWmANG7RwYMH8Tn3uK+dbdu2TS/7417hPflR2NWrV69YscJ3tb6JDk6s3F2hyKuCE360SWkFLQRpfy9ob3CBXyUq8GUYfxZes3OorYK3HUCZXpsOcNOWH5yJyCA4XwWWDhZ+qNX/wo5mtSKbCCmiisDCrl279rmJrYfdSpjINcKuCCKJSDflCCVwObCAsEY8fL3Bpt7q1gCINIyIsXm3ww3qxrnfKGXqIE09oDmvuG8kAVUn3UjVUW/KpybJoZJ37ty5adMmngUPhWdEq+DB8ZjQjVrMjWc6ffr0sWPHDh06tG/fvl27dm3fvn2LFi1ef/31V1999ZVXXqlbt27NmjWrV69etWpVPyJbsGDBvHnz5syZ8+GHH06fPn2aNGkeeughxS2SJEmSKFEiPyYRHJ1VyMEbtDYMwzD+9ih4qZilQtp0IsmTJ0+ZMmWGDBmyZ8+eL1++IkWKPPfccxUrVqQboj+qV69egwYNGjdu3LZt2169eg0fPnzq1KmyX" +
"ubMmUM3h+W/Zs2arVu3YmzovS78CDpKvd2Fo4EtIRNCjgkJr981/to4O8gLt2EN8hwV47xw4QImEI9YU7qDw5wrV67E4MHs8f0+WojMWjUYL84ZgEz2UgYTl6OwnTTFkxNyWpxQ/khzDnFafYv0b9KEogVEuWeM0fPnz1PvR9yXUTWzE298vcO9Eh0Fj4EaxB6VQGKe4uEjirJZEUiNBfBQqUrV5t+kQg3DMAzDMAzDMH4HcprA2w4EXwEfFU9VQRSQqyUXWpHXS+6lVYVhTjlw0BSSIY1Tjdd24MAB3Ldd7ktLuNaATwdbtmzZtGkT7h5+siKvWtTHBYb+g4KvONVfOhSj8sNLgk1QnAmU6QZ2otAmeLsdOiQG2sVfGMafg5rcTfEaZfR3CIBNb0cQroFHoWORFERGID7uHYYoECg/4Ko1hDe41SC1zqQfdkVa9+7dq+WyTpw4gSwj0QIB5xepR/Y1AiPNEENL3Di85XRMFN723wAqIUY9kJb+pKKuBhbA1Hv/1CpVSj5VevnyZYVjNT62Y8cOFCaPabX7nhZKEjQHAP0pLYoK5eHSAD755JNJkyaNHDlywIABffr06d69u79cZNOmTZs0afJPR7NmzV5//fUGDRrUrl27atWqlSpVKleunD5ZV7Ro0fz58+fMmTNLlizp0qVzU9Gi0Fw0TTtT1DZxYEItxHULHT/wwAP33XefN0hvGIbxNwZliEpEMWoyseKUyZIl07RgNCoKNnPmzDly5HjssccKFiyolWNRyKjlhg0bvvHGG40bN+YX7Y0O79SpEyp99OjRs2bNoh9H52ttYSC9bt06um867qNHj+qNKH5lkNOz+K9O0iWpI5aFz6/6JuPuJfiByrrgcWNFXLhw4VzggwjYEvhie/bs2b59O5YeNoNinDQeLAcMRd+9ApmUMjijlq8NoBx2UYDCHDJ//nwOlzWCiYKtongnDY9/x7zhSv5u8c5fxQuI+s+MByabL8KB3LJJxcme9iVWRxmGYRiGYRiGYRh3H" +
"TF8Onl5gFeoOIFPVNw1sECTH3nVHDggjbOtibA43lpsE28/LCwMh39X9E9ehYaG4v/701615vDixYsXBqFA7DeBT8BqXCA4zgQaKQiGAhog8IlRjAI3RXujAmKG8V9DzexWqCmqbQfj7Q68WABe4w4sL8yZ3QyBqOmtPn7YFWnyA65r3Bf41js0zzXEfcAVIUVUNenkeOD7diROnDgRERGhgKumDmho76rDH9JFP/jjazHwNItxC6g01Zs2SbBJZUr9qm6BqpZ29R8EmRTjlwdBpt53OXLkCM8RZbt161ZNokW7Ll261J8OgvqFzZs30xgUr/30008nT548atSowYMH9+vXr0ePHu+88067du1aO9q2bduhQwdyOnbsSGaLFi2aNWvWuHHjBg0avPLKKzVq1HjppZcqV65cvnz50qVLlypVqnjx4oULFy5QoMBjjz2mb/49/PDDWRyZM2fOkCGDv8po6tSpH3rooRQpUvhzcLVAqObgKpprSyIbxj1G8NRJ5N2PR6IQUAvoh4wZM2bKlEmfyEWHaCblM8888/zzz1esWLF69er16tVr2LDhP//5z1atWqGg2rdvj2pq06YNv++++27Pnj379u07fPjwKVOmoN+wJNF16uzQe7I56f7QkPR62KioTfQqWlRdm0JWwQFLVLF6N19F++ra+DugJ04DUKesdiIniNaC+0Pne/LkSUymgwcP7t27FzeHxqaWtsJ9lZNG6L9FisEmSy8Yz567ARqwCsjG4ySYc3To9Ob077Rh/u7w4cPYaRhpXAy2ARfGFXKpwXaF8cvcsW+IGoZhGIZhGIZhGMYvoCEGJTT6L0hr04+84uHj558PcPHixUsO0qdPnz7uFpLSgsN79+7dE0Ah2O3uzetNmzZt2LBhzZo1K1euXLZs2RL3wdfFDhIKvvqRV/ADVxqJAG0GExyUAn/YArwStwi+aldUcMww7jRqXbeCVhoDr1E62PRacwByOIrTatpBDPyYqyZHrnCsXr0aQQMtLLx58+aQk" +
"JAd7kNlBw4cOHLkyLFjx/gVR48eRX5PBT6idPXqVUReQ40QHHCVZpDS+JeDhDSJ8d9DFQ7etsPLCjwIaWzBY/ox8OoMD07jxTxKdulA8n3F7s+X0rxbqfF9+/bt3r1benu9W6uAhoQC95sQkKAAmeyiyaHDaY001FmzZk2dOnXcuHGjR48eOnTohx9+2Lt37/fee69r167dunUj0adPn759+77//vs9evTo0qVLp06d3n777datW7/11lt+lLdevXqvvPJK7dq1a9as+fLLL7/00ktVqlSpWLHiCy+8oIhviRIlihUrVrBgwQIFCuTPnz9PnjyPBHj00Uf5zZkzZzZH1qxZ/WAwZMqUKWPGjPr2ZJo0afSZSYWEY3xRUp+NTJAggb8yc+zYsWPFiqXJvhYh/luhb6bSAGgMNAk/gkiboeXQhBRHpF0piEhLo+HlyJEjd+7capY0UXj88cdptDTdZ555hpZcoUKFF198kRZOU6fNv/baa2+88Ubz5s1btmyJUCAaSA1igrAgNSCpUSabH3300ZAhQ0aNGoW4TZo0acaMGfQX9BR0B/QFq1atWrduHcofGywsLCw8PJxfZFZmmFZBQMC1F6mnUzhz5oy6AMVy0BgktFI6uoIcKRzypXacBvqPXtImeNuGcQM0DzUeUG9FZ0Qzo9XJy6A/ioiIoDXSGdHR0BPR74SGhvrug6b/LnAf49T0TR9ZUL8Dei5OBRhUmFJLly7FiEJ21OUhHX6wE3HgavUilO7CGvydwgKihmEYhmEYhmEYxj2LxkH80QTwB+ivug/2uEhrFJcvX2ZTOefPn4+MjDzhPvV66NCh8PDw/fv379u3LywsjIQCsTt37ty2bduWLVs2bty4du3alStXrlixYtmyZUsD+MFXDabMD/rIq48GVnzIUaRqbtAaWX6YykdlNLbiQ463+xZ4/2EYvxmv6dyCGxuhcM3T2xUVZQ1AJkdxWo0Ggv4FtKmAK/Liz3Bdvnw5kgWr3ZdcN2zYsGnTptDQ0F27d" +
"mnYHfGEg47Dhw8jsIjtafdRJyQaGdfQpy/j33333feBVdA0Cu8G1aOQoiDh6Q7jbua3PEf32H8dlVTfQcuhCalpsanzAHtpPOT86Ob4+mF+tb0LbgraGfdB8Qj3odzjbk42zZVGSwM+4FZWoFvRiDxs3bpVnQutnR5HHyD3A8kxDtm+fXtISAiisX79eiQFwUF81PVETRj/5hskSx0QSOJiyC/iqe5m9uzZs2bNmjlz5ieOGTNmTJ8+fdq0aVOnTp0yZcrkyZMnTZo0ceLECRMmjBs3buzYsR9//PGYMWNGjx49atSokSNHjhgxYtiwYUOHDh3sGDRo0MCBAwcMGPCRo3///h988EHfvn179+79/vvv9+rVi1/S5FCGwzkhZ9N5YLiDE/pwZh/lUIDyHMUFDBkyhH9RME9nJs2fksmVUJhzUpir5Y/Gjx/PjXBT3B33yJ1y19y7vr1HnVA/Uk3UHnXo6yU6d/p6lNKaNWuocCmlzZs386QwCXgWaCceyp49e3ybgYeFskJHOXV1iCfo3g+JekGEZ8rDpT2Qr8C/3ujSayWcgcM5UK+SUJhmQEPCRKFd0cD810fUUIF2KKXHL801eFdUa46O8g3jLwut1Fnu/1Gwer2GFi7QrkgEQoSMICnIGiKD9CFKSCUSiqjKOEd4fWtcalDEUIakfwGvUHTI5yToCs7M+VEUemOMf9ciDVwPAi7jBOHlsmWKILxmdfxPsICoYRiGYRiGYRiGYfxRNF4DJP4dmAJ73b2NrpHxK1euXHYx16tuGhyQ1pQpLX2pwfGDBw8qzKO0H3zVZ183bNiwdu3aNWvWrF69etWqVSvc96sUhfVHwL92+PHXX0CDOxoKjwpYuVFg4UZ+ovC2o6Ndn/8a3t8Yxi3wGsrNiNH21OSCUbv1oYwO9E4d/eRsarBSsY1vHYsWLVqyZIl7eyFqgVkFXxEupMwPb+zevTssLOzAgQMaaRWkEU8E9uTJk5GBj7ki3VFB10uXEGogIWH3IxbSDL5y4Je0p" +
"z4MwzAM496CPo6Oj/5OXR74EU31la7PvOSbwZi+9LD0uYpoyujF3FVEk/7at3Lp0GXien18kM0gaxZIy1oIxivtyt+IzuBDjiwH/lFhTuwEjHAsBGzyXbt2Ya4fO3YsIiJCqy4Hhzm5cXX6Xl0YfyUsIGoYhmEYhmEYhmEYdw0aYIrBT0EfOrp69ep3DgVjyNTw08VA8FXzURR/1TwVUPw1LCzMXzRsk1t2WItYCv9F+6VLly5atOhbt+yw5h75aJQqGI1Yzbvhm0lu9Ckan0WfUKjRKA1d/SpRETDD+DW85nKLwVBvX9BetUnFXGO0Se+M7sUCH+XT7JGFr91sV1DwdfHixUscCr4iSpr2iogha1u3bkXudu3atW/fvr0Of3oZgomEanLJuXPn/EFkEucdpP2XLfz4q0afQcoBSGtwll8hlWIYhmEYPvQOMix96Fb81/guOPxZ79iTGJAHDhygz9KnK/QOH/3aunXrVq1a5b+0p0VTsBv10h59pTrTYILtQNLqc4Pxyt0CCuioG/FKuD5ar0b5MU764o0bN6oX5i64HW5KHS7dK3etMCf1QDdKzVgHerdjAVHDMAzDMAzDMAzDMGKiETF/3EcJcn527/hfd5Nfr7mVhxWGUdDFD76eO3cuMjJSyzweD6D0UbcQ8YEDB/bs2aPFIUNCQrRO4AbH+vXr165dqymwmhag+KtmBnzlcOHX/6Dgq0a7NCLmjajdbJaAGxyLGXwFHf5biIqDGcat8RrKLSKv4O12qPmB1xwDDRKCS+rAYPgjGr8kArSwJ5KyMAg/HIso+YsPKwqL3CF927dv1xC2xrK14Oe+ffs0F1axWH+hzgvu684aChdsIu/+GoCoBfSABo6BBJsaSvb1iQ0oG4Zh3BYxFKZUKMgqQ8eCs8K8d+MUvEQ/nw2A3ubXn4upiZjofLqAbQ66AywxbDC9AOdHMWV9AV0MhpY6OPVB6puAtNdpBaEyMfAOuMGO8nKD8M5yM3QejpIFCPSAXCFXu3z5cq5fk" +
"zjpy/bv3x8eHk5HdvLkSTosujAFOKkldUzUnrokr2aNvwEWEDUMwzAMwzAMwzAM43+JxvWEn6Nhvp8cGuO75ia8klaOgq+X3DdfNcx30nHCfZUtIiJCOUePHg0PD9+7d++uXbt27Nixbdu20AD6Sp/ir/6ybP7iw984vg6gmNP8oFmwXwQtO6wglhvuu0kEyy8DUYN5Dq9QAK9oAC83CDdmaBjR8BpHEF4Dio63L4AyaYReowwiRmG/ZDAqw78jBRqJFoiJpObbIJCmRYsWLV26VIsSI2jr1q3b4NYlDgkJQQy3OpTYvn07QupHZA8dOoT8Hj9+HEE+ffo0Yu7mJl0gwSYyzm9kZOSZM2fOnTtHvh+avepWJpe60GA3v1IjoMgBaiQqZutgr3BK6D8j49oEb9swDCOIGPqBtKdKAl+sl84BqR1+/ffGZLqgvlBi0m+CtGKW+miC1u2QbuQXPYnyRIVq/iV61V+0A1zg0vt0AjoZFS017uluhxT4jflCuwQFfLys32CKeOUC6HDv7EFRUm/b5XAUl6p+BOhEsMS4NWwzjDR1Ftw+taHopv+aDmrffx0nRoAz+LkYRjAWEDUMwzAMwzAMwzAM429EjJEy0hq+hJ/d/Nfg4Us/HHv16tXLly9fCFopTjHXyMjIs25Mk/SxY8eCP4IVY+6FfkNCQjQXVrNgNaCpWbCazyeChzVBo4TzA6vMxRhPFMoEfxTSi3EF4RX9tXCsj/a6QU7D+CXUVILx2lDQSLpQJo3Qa5QONcsYhf2S4JVz+CX536h3E1xcNjg0KyQ7itECAsUvwoWgacosordixYqVK1cihv7cWX/8HUJDQ5UA0ogwQr179+69e/dq4pEWHtfovFQBkNDbGEID9+T7s2mvXLlyqwm1ipeA9E8w7BUqLKS4pNOEp9ccXpbDyzKMuwqv+d7QgJWp9i9Z8MQjsEg4IF9IGdJE2i+jTATQ79Als3ToSCu/fs9OLy9BRsYRdrp1/80qvcOxxSEtgdLQ+1Vr1qxBn" +
"6BYgj8uIF0UA3SU36eDr+Wk32Jwow5UMR17K5xuvm28gwP4F3Aj2uXDsdwRt+Y0bhRoXYU2tSwt1UXVoUX37dvnT9xUMJhngWLE0JJW1PPylZv31A3jTmABUcMwDMMwDMMwDMMwjD8PDfBpJJfEz4FViH8KTG7glzQ5Grq9cuWK/83Isy74yu+5c+fYBAVoTwXWwQsetxU7HTsCs2NDXETWH7dVOFbzYoNxYVlvJFfhJX/o1hv7DELDpsGQ+dktJiAKr5zDy4qOt8/hBmkN49fxWsxtoianIX7wGqtDOV65ACoP2iu8AwKHACV1VX7IVkigYuBCJFFI6BRLkBguCnyDdlkAxXH9UC6yvG7dOoQaNjqQcUF6w4YNytmyZQvir5czUAgoBwV39wU+WKt1kg8fPnz06NFjx46hUk6cOBERmInL78mTJ8lnb4wCCiAFqyZN2PU/cKtpu4BCAwV9ARWHovOJimJFJyrA5RSjEuRwCOfRCXUGnUqw6eOdNDo6bTA6843wp8FIY/92vMOC8M57M7xLuQXepUfHu8noeLUQHSpcNQakKcY5dZHe30cn+E91zqgnd/Uqz5Gnqc6I5wvqgNQr0QBoBjQGmkRwIwluQkBCZWg87D0S+IQ5bY92SGsMfpdIgUY1Y7VhpWnSNHXavB99pCNDLpYuXRr8dpHegfBlCjxhc3jS6EBCpT0Qak+Mg5A4s8tJ/39QPnjlgmKZXonfgFTEHUEn1AUI5QBpXaqIsVeQw0moCipH+kcqiCqlhqlqal4BYB4NqgOlgcnBc1Qg2Y9r0kjUzGg/NCRaFI2fxoa149lAhvE/xQKihmEYhmEYhmEYhmEYfxdcNPY/aEzcH7UUyvkhaCbNpUuXLrjJNOfdLDc2/Rw/HHvkyJGDBw/u379f49qKsgBpLfrnD3Brub/Vq1evXLlyuVvxT0FZ4Q9nf+PQKPZ8F47VMK7wBnFvxmduhHpOEBqqBq9EAM6jfKEzg7c7+mi1l+XwsgzjdvBazy/iFQ2gTK9d3" +
"oDXcINwcZn/4OXeeiVM4RW64XDhSVFAjjiDd3GBGbq/jGJOvxsXvboJCnEFoxAORIWRA7gXPDzQLeApGhdjBvTPjSjwjHYSfgRarLoF3u6VKykvvOMdOid4/+HQNdyIrlAXLLx7CFpIALwbDqzxLrzqCEI19gv1qV2/gPcsfzO0Db+lqV35TehGXNPz0CGunXooh11e6QDB5YV3wO2gZvzn4/39zYTR2+F2+XcdXHW6a6+QgxNS5zxHnj6tQg2GVkQDoxEqlknnSy+sF6QUztQcTfpuvdBAb06fTs9+JegrmxbRNO49LCBqGIZhGIZhGIZhGIZh/A/4t5sg64+3gjY1M0nhWE1L0pwkjdVqrhI5586di3TTkhSO1QTZ/fv3h4WFaa6bNjVfVlOOtgR9OHaVm1q0zIU9FKVYEn12kR9LmO/CscGj2EKZMdCueYGZRgoDgDaFG8m/+bxD7fJRZgy8A26GdxGG8b/Ga5H/Hbz/iI637zfgCdJt4snkb8A74A/jXe5t4lVHEN6OO4139nsF765uQM/Ce7QBlOmjTF+9k+MdHFRL3rbLUfyS/oWOhh5H4Xn6IDojeiX6pnXr1m3evDk0NHSH+6yy3jHSl5X9KOaZwEc09dISv3SOdJ0/Bi0RzK/FMg0jGAuIGoZhGIZhGIZhGIZhGH87FI4FDRb70VnNjtVSk5ogq+Hmq4ElOsknRxNkz549q6VEjx8/fvTo0cOHDx86dEixWK0+esRBptaE3L17987oKxj7AVot/7jSzT/TPDM3r+w/M2gXuS/SKVj7zTffxJjX5eZlRU3M+mU+D5p45IVqA7gh/f8M9GvsPgbkq1gMdEgw3gF/AO+KDcO4p/EE/jfgKZdbayGvXPSSilOCr+go4P13dKRFpVE14VJzLoMDllLOaGl/qeotW7Zs3759r/u0MGo/WP/TKegzmXQW9BpRSw+775EDnYv6lOvRF8xXQp2UYRh3HAuIGoZhGIZhGIZhGIZhGMb/jH8HvikLwVN5/BitwrSaO" +
"Ktg7VX3UcArDn9UXQXY1ILG591HZ/XRPn398Yj7Yh+//gcgQfnh4eH7HP76xv4XZzc41jr8b1UGR3BBq4MudUSt9enw59oqruDPuBWKOigC8asoXKE4hyIcim0IRTsgKioSQOEQFxyJhn+GGOioG9F5gvFOFB1doY+X+8fwzmUYQXiN406g9uw19BvwBCOACntHOpQD3gE3E6tgKEBhbsGT6pshtQCemnDTKBWV1ExKRSUFmkff0EUdSS+hqTZv3qxPXWpupdaGld7TZ02jvm7qEgpV+l++lCL1Vybgl01AqWrlWOlnkK4GbXr62jCMuwELiBqGYRiGYRiGYRiGYRiG8SvEGP3XpgIDmtjkx24VvvXxg7gKOSi64BfTritubWQ/lKvZt5FuSeSTJ08qcCsUyj19+jR7ISIiQtNzNRM3PDw8LCxsn/uQ7Y3zcTdv3rwxwKZNm5TYsGGDoinr1q1bu3bt6gAxpuqC/wFIf86uv8ayH/pV/MYFf2PiRXiC8II/t8CLEd0MPzamcJQXcboFLlZ127hQ1x1GgbTfje46GDI5bYwLDi7pjvslvGN+A/qXW+HV9R+GU3FV3mO+GV7jiI7Xnhxea4sOjRP8sKLmO2rB8BWBL6TS4Gn2a9askTggFxIT4acVbkSmkKxdu3YhaIDE7d+/P3hmJFKJ5CKeiCr4chpj15kzZ/T1SjTA999/jzZAJ0g5oDfIiZEpJYO2iRGPlC7yNw3DMG6KBUQNwzAMwzAMwzAMwzAMw/hbcKvACTna5aMobzAKxgiFZyAq5HtDCIcEZTgk+Dx+YbjmoKSCwX48GPTFXAWGNc0Xzpw5E+nCw36E+LiDNDnsooyiyJRUCArYFRERocIKJysidTiIQw630ud/CHccuBn7HWE34CYYR6EIGexx7I7Orl27dkZn+w1sc2wNItQREmBLAE0HJCfGXv+XfJ2BE+rkOxz8L1eiS+IivSveu9e7mbAw7tG7YYcqRJVDdanq/EmHgnrmcQB17h7UKe8xBOAx8" +
"XSCcc826sHpcZPDUZyBU/mwqVPpcMpTkvJqLf7iq2p1tDE1PEFabTI4pghRLdjhlXMNVUgQPKkIoEzhZRmGYdyFWEDUMAzDMAzDMAzDMAzDMAzDMAzDMIx7FguIGoZhGIZhGIZhGIZhGIZhGIZhGIZxz2IBUcMwDMMwDMMwDMMwDMMwDMMwDMMw7lksIGoYhmEYhmEYhmEYhmEYhmEYhmEYxj2LBUQNwzAMwzAMwzAMwzAMwzAMwzAMw7hnsYCoYRiGYRiGYRiGYRiGYRiGYRiGYRj3KP/3f/8fNIXMmxh+ekUAAAAASUVORK5CYII=");
            this.Image1.Name = "Image1";
            this.Image1.Stretch = true;
            this.Image1.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Image1.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Image1.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Image1.Interaction = null;
            this.PageFooterBand2.Interaction = null;
            // 
            // Text12
            // 
            this.Text12 = new Stimulsoft.Report.Components.StiText();
            this.Text12.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(8.7, 3.5, 1, 0.3);
            this.Text12.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text12.Name = "Text12";
            this.Text12.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text12__GetValue);
            this.Text12.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text12.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.All, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text12.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 181, 204, 136));
            this.Text12.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text12.Guid = null;
            this.Text12.Indicator = null;
            this.Text12.Interaction = null;
            this.Text12.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text12.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text12.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text15
            // 
            this.Text15 = new Stimulsoft.Report.Components.StiText();
            this.Text15.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(9.7, 3.5, 1, 0.3);
            this.Text15.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text15.Name = "Text15";
            this.Text15.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text15__GetValue);
            this.Text15.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text15.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.All, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text15.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 181, 204, 136));
            this.Text15.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text15.Guid = null;
            this.Text15.Indicator = null;
            this.Text15.Interaction = null;
            this.Text15.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text15.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text15.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text11
            // 
            this.Text11 = new Stimulsoft.Report.Components.StiText();
            this.Text11.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(8.7, 4.2, 1, 0.3);
            this.Text11.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text11.Name = "Text11";
            this.Text11.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text11__GetValue);
            this.Text11.Type = Stimulsoft.Report.Components.StiSystemTextType.DataColumn;
            this.Text11.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text11.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text11.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text11.Font = new System.Drawing.Font("Arial", 8F);
            this.Text11.Guid = null;
            this.Text11.Indicator = null;
            this.Text11.Interaction = null;
            this.Text11.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text11.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text11.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text14
            // 
            this.Text14 = new Stimulsoft.Report.Components.StiText();
            this.Text14.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(9.7, 4.2, 1, 0.3);
            this.Text14.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text14.Name = "Text14";
            this.Text14.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text14__GetValue);
            this.Text14.Type = Stimulsoft.Report.Components.StiSystemTextType.DataColumn;
            this.Text14.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text14.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text14.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text14.Font = new System.Drawing.Font("Arial", 8F);
            this.Text14.Guid = null;
            this.Text14.Indicator = null;
            this.Text14.Interaction = null;
            this.Text14.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text14.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text14.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // ReportTitleBand2
            // 
            this.ReportTitleBand2 = new Stimulsoft.Report.Components.StiReportTitleBand();
            this.ReportTitleBand2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.2, 7.72, 1.8);
            this.ReportTitleBand2.Guid = "b60594cb8fe4cc69fad155c8c979b8ee";
            this.ReportTitleBand2.Name = "ReportTitleBand2";
            this.ReportTitleBand2.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.ReportTitleBand2.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // Panel2
            // 
            this.Panel2 = new Stimulsoft.Report.Components.StiPanel();
            this.Panel2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0, 7.7, 1.7);
            this.Panel2.Guid = "851d049ab4370bd84ee855c8c979886e";
            this.Panel2.Name = "Panel2";
            this.Panel2.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 204, 193, 217), 1, Stimulsoft.Base.Drawing.StiPenStyle.DashDotDot, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Panel2.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 251, 213, 181));
            // 
            // Text2
            // 
            this.Text2 = new Stimulsoft.Report.Components.StiText();
            this.Text2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.1, 0, 1.6, 0.3);
            this.Text2.Guid = "4d4a609c752f4e31a29e55c8c979bf76";
            this.Text2.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text2.Name = "Text2";
            this.Text2.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text2__GetValue);
            this.Text2.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text2.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text2.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text2.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text2.Font = new System.Drawing.Font("B Nazanin", 14F, System.Drawing.FontStyle.Bold);
            this.Text2.Indicator = null;
            this.Text2.Interaction = null;
            this.Text2.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text2.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text2.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text4
            // 
            this.Text4 = new Stimulsoft.Report.Components.StiText();
            this.Text4.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.5, 1, 0.8, 0.4);
            this.Text4.Guid = "f32f6cce08f6787328d955c8c9799f81";
            this.Text4.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text4.Name = "Text4";
            this.Text4.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text4__GetValue);
            this.Text4.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text4.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Bottom;
            this.Text4.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 192, 80, 77), 1, Stimulsoft.Base.Drawing.StiPenStyle.DashDot, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text4.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text4.Font = new System.Drawing.Font("B Nazanin", 11F, System.Drawing.FontStyle.Bold);
            this.Text4.Indicator = null;
            this.Text4.Interaction = null;
            this.Text4.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text4.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text4.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text6
            // 
            this.Text6 = new Stimulsoft.Report.Components.StiText();
            this.Text6.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.9, 1, 1.1, 0.4);
            this.Text6.Guid = "87178007dd051f62ae5a55c8c97aa62a";
            this.Text6.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text6.Name = "Text6";
            this.Text6.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text6__GetValue);
            this.Text6.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text6.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Bottom;
            this.Text6.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 192, 80, 77), 1, Stimulsoft.Base.Drawing.StiPenStyle.DashDot, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text6.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text6.Font = new System.Drawing.Font("B Nazanin", 11F, System.Drawing.FontStyle.Bold);
            this.Text6.Indicator = null;
            this.Text6.Interaction = null;
            this.Text6.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text6.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text6.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text34
            // 
            this.Text34 = new Stimulsoft.Report.Components.StiText();
            this.Text34.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0, 2, 0.4);
            this.Text34.Name = "Text34";
            this.Text34.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text34__GetValue);
            this.Text34.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text34.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.Right, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.None, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text34.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text34.Font = new System.Drawing.Font("B Nazanin", 11F);
            this.Text34.Guid = null;
            this.Text34.Indicator = null;
            this.Text34.Interaction = null;
            this.Text34.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text34.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text34.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text5
            // 
            this.Text5 = new Stimulsoft.Report.Components.StiText();
            this.Text5.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.9, 0.5, 1.1, 0.4);
            this.Text5.Guid = "c5ea708eaa73447798918a75e45a773a";
            this.Text5.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text5.Name = "Text5";
            this.Text5.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text5__GetValue);
            this.Text5.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text5.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Bottom;
            this.Text5.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 192, 80, 77), 1, Stimulsoft.Base.Drawing.StiPenStyle.DashDot, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text5.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text5.Font = new System.Drawing.Font("B Nazanin", 11F, System.Drawing.FontStyle.Bold);
            this.Text5.Indicator = null;
            this.Text5.Interaction = null;
            this.Text5.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text5.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text5.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text3
            // 
            this.Text3 = new Stimulsoft.Report.Components.StiText();
            this.Text3.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.5, 0.5, 0.8, 0.4);
            this.Text3.Guid = "b4e31853cfec45f7945d1c36d0a7b892";
            this.Text3.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text3.Name = "Text3";
            this.Text3.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text3__GetValue);
            this.Text3.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text3.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Bottom;
            this.Text3.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 192, 80, 77), 1, Stimulsoft.Base.Drawing.StiPenStyle.DashDot, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text3.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text3.Font = new System.Drawing.Font("B Nazanin", 11F, System.Drawing.FontStyle.Bold);
            this.Text3.Indicator = null;
            this.Text3.Interaction = null;
            this.Text3.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text3.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text3.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text1
            // 
            this.Text1 = new Stimulsoft.Report.Components.StiText();
            this.Text1.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.4, 0.5, 1.5, 0.4);
            this.Text1.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text1.Name = "Text1";
            this.Text1.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text1__GetValue);
            this.Text1.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Bottom;
            this.Text1.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text1.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text1.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text1.Guid = null;
            this.Text1.Indicator = null;
            this.Text1.Interaction = null;
            this.Text1.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text1.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text1.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text25
            // 
            this.Text25 = new Stimulsoft.Report.Components.StiText();
            this.Text25.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1, 0.5, 1.5, 0.4);
            this.Text25.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text25.Name = "Text25";
            this.Text25.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text25__GetValue);
            this.Text25.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Bottom;
            this.Text25.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text25.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text25.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text25.Guid = null;
            this.Text25.Indicator = null;
            this.Text25.Interaction = null;
            this.Text25.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text25.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text25.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text26
            // 
            this.Text26 = new Stimulsoft.Report.Components.StiText();
            this.Text26.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.4, 1, 1.5, 0.4);
            this.Text26.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text26.Name = "Text26";
            this.Text26.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text26__GetValue);
            this.Text26.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Bottom;
            this.Text26.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 79, 129, 189), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text26.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text26.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.Text26.Guid = null;
            this.Text26.Indicator = null;
            this.Text26.Interaction = null;
            this.Text26.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text26.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text26.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text27
            // 
            this.Text27 = new Stimulsoft.Report.Components.StiText();
            this.Text27.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1, 1, 1.5, 0.4);
            this.Text27.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text27.Name = "Text27";
            this.Text27.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text27__GetValue);
            this.Text27.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Bottom;
            this.Text27.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 79, 129, 189), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text27.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text27.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.Text27.Guid = null;
            this.Text27.Indicator = null;
            this.Text27.Interaction = null;
            this.Text27.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text27.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text27.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            this.Panel2.Interaction = null;
            this.ReportTitleBand2.Interaction = null;
            // 
            // HeaderBand2
            // 
            this.HeaderBand2 = new Stimulsoft.Report.Components.StiHeaderBand();
            this.HeaderBand2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 2.4, 7.72, 0.3);
            this.HeaderBand2.ComponentStyle = "Collection_Header1";
            this.HeaderBand2.Guid = "39f29c7dcae0cf9ff22555c8c97a05b2";
            this.HeaderBand2.Name = "HeaderBand2";
            this.HeaderBand2.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.HeaderBand2.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 184, 204, 228));
            // 
            // Text13
            // 
            this.Text13 = new Stimulsoft.Report.Components.StiText();
            this.Text13.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(7.2, 0, 0.5, 0.3);
            this.Text13.ComponentStyle = "Collection_Header1";
            this.Text13.Guid = "adb07f73423ea317ea4f55c8c97bba13";
            this.Text13.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text13.Name = "Text13";
            this.Text13.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text13__GetValue);
            this.Text13.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text13.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text13.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text13.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 251, 213, 181));
            this.Text13.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text13.Indicator = null;
            this.Text13.Interaction = null;
            this.Text13.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text13.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text13.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text7
            // 
            this.Text7 = new Stimulsoft.Report.Components.StiText();
            this.Text7.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.7, 0, 0.5, 0.3);
            this.Text7.ComponentStyle = "Collection_Header1";
            this.Text7.Guid = "ad8834a8db4d40f1a6e294c9f96965fc";
            this.Text7.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text7.Name = "Text7";
            this.Text7.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text7__GetValue);
            this.Text7.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text7.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text7.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text7.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 251, 213, 181));
            this.Text7.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text7.Indicator = null;
            this.Text7.Interaction = null;
            this.Text7.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text7.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text7.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text8
            // 
            this.Text8 = new Stimulsoft.Report.Components.StiText();
            this.Text8.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6, 0, 0.7, 0.3);
            this.Text8.ComponentStyle = "Collection_Header1";
            this.Text8.Guid = "846660d756fb465dbabdfb11e5667543";
            this.Text8.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text8.Name = "Text8";
            this.Text8.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text8__GetValue);
            this.Text8.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text8.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text8.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text8.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 251, 213, 181));
            this.Text8.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text8.Indicator = null;
            this.Text8.Interaction = null;
            this.Text8.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text8.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text8.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text9
            // 
            this.Text9 = new Stimulsoft.Report.Components.StiText();
            this.Text9.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0, 0.5, 0.3);
            this.Text9.ComponentStyle = "Collection_Header1";
            this.Text9.Guid = "b59549c3b3184cc8a7e53390112df076";
            this.Text9.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text9.Name = "Text9";
            this.Text9.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text9__GetValue);
            this.Text9.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text9.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text9.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text9.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 251, 213, 181));
            this.Text9.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text9.Indicator = null;
            this.Text9.Interaction = null;
            this.Text9.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text9.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text9.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text10
            // 
            this.Text10 = new Stimulsoft.Report.Components.StiText();
            this.Text10.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.4, 0, 0.6, 0.3);
            this.Text10.ComponentStyle = "Collection_Header1";
            this.Text10.Guid = "413f0d5ba04f468a85d86802152c6fc5";
            this.Text10.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text10.Name = "Text10";
            this.Text10.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text10__GetValue);
            this.Text10.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text10.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text10.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text10.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 251, 213, 181));
            this.Text10.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text10.Indicator = null;
            this.Text10.Interaction = null;
            this.Text10.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text10.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text10.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text16
            // 
            this.Text16 = new Stimulsoft.Report.Components.StiText();
            this.Text16.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.7, 0, 0.7, 0.3);
            this.Text16.ComponentStyle = "Collection_Header1";
            this.Text16.Guid = "a1ea8093b1be48a6818fc51e1382fe0b";
            this.Text16.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text16.Name = "Text16";
            this.Text16.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text16__GetValue);
            this.Text16.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text16.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text16.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text16.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 251, 213, 181));
            this.Text16.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text16.Indicator = null;
            this.Text16.Interaction = null;
            this.Text16.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text16.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text16.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text20
            // 
            this.Text20 = new Stimulsoft.Report.Components.StiText();
            this.Text20.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.7, 0, 1, 0.3);
            this.Text20.ComponentStyle = "Collection_Header1";
            this.Text20.Guid = "1e1e1387774d4d16bfe483904df96ee5";
            this.Text20.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text20.Name = "Text20";
            this.Text20.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text20__GetValue);
            this.Text20.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text20.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text20.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text20.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 251, 213, 181));
            this.Text20.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text20.Indicator = null;
            this.Text20.Interaction = null;
            this.Text20.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text20.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text20.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text21
            // 
            this.Text21 = new Stimulsoft.Report.Components.StiText();
            this.Text21.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.9, 0, 0.8, 0.3);
            this.Text21.ComponentStyle = "Collection_Header1";
            this.Text21.Guid = "23ee04b2ff004955b100c24222779b2c";
            this.Text21.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text21.Name = "Text21";
            this.Text21.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text21__GetValue);
            this.Text21.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text21.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text21.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text21.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 251, 213, 181));
            this.Text21.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text21.Indicator = null;
            this.Text21.Interaction = null;
            this.Text21.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text21.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text21.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text22
            // 
            this.Text22 = new Stimulsoft.Report.Components.StiText();
            this.Text22.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.1, 0, 0.8, 0.3);
            this.Text22.ComponentStyle = "Collection_Header1";
            this.Text22.Guid = "5a25a37c8649486a8bef7db3c69c6851";
            this.Text22.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text22.Name = "Text22";
            this.Text22.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text22__GetValue);
            this.Text22.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text22.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text22.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text22.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 251, 213, 181));
            this.Text22.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text22.Indicator = null;
            this.Text22.Interaction = null;
            this.Text22.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text22.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text22.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text23
            // 
            this.Text23 = new Stimulsoft.Report.Components.StiText();
            this.Text23.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.3, 0, 0.8, 0.3);
            this.Text23.ComponentStyle = "Collection_Header1";
            this.Text23.Guid = "2bd7e38f36b246f7a2186b0b743159fe";
            this.Text23.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text23.Name = "Text23";
            this.Text23.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text23__GetValue);
            this.Text23.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text23.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text23.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text23.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 251, 213, 181));
            this.Text23.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text23.Indicator = null;
            this.Text23.Interaction = null;
            this.Text23.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text23.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text23.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text24
            // 
            this.Text24 = new Stimulsoft.Report.Components.StiText();
            this.Text24.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.5, 0, 0.8, 0.3);
            this.Text24.ComponentStyle = "Collection_Header1";
            this.Text24.Guid = "cfd4a233c24042788f8096b27be4241c";
            this.Text24.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text24.Name = "Text24";
            this.Text24.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text24__GetValue);
            this.Text24.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text24.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text24.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text24.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 251, 213, 181));
            this.Text24.Font = new System.Drawing.Font("B Nazanin", 8F, System.Drawing.FontStyle.Bold);
            this.Text24.Indicator = null;
            this.Text24.Interaction = null;
            this.Text24.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text24.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text24.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // HorizontalLinePrimitive2
            // 
            this.HorizontalLinePrimitive2 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLinePrimitive2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.8, -0.1, 5.8, 0.01);
            this.HorizontalLinePrimitive2.Color = System.Drawing.Color.FromArgb(255, 81, 104, 36);
            this.HorizontalLinePrimitive2.ComponentStyle = "Collection_Report_Title1";
            this.HorizontalLinePrimitive2.Guid = "d859e23db21fb791547d55c8c97a9a8d";
            this.HorizontalLinePrimitive2.Name = "HorizontalLinePrimitive2";
            this.HorizontalLinePrimitive2.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLinePrimitive2.Interaction = null;
            this.HorizontalLinePrimitive2.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HeaderBand2.Interaction = null;
            // 
            // Data
            // 
            this.Data = new Stimulsoft.Report.Components.StiDataBand();
            this.Data.BusinessObjectGuid = "0e798cde640646e09f2515086abda96b";
            this.Data.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 3.1, 7.72, 0.3);
            this.Data.Name = "Data";
            this.Data.Sort = new System.String[0];
            this.Data.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Data.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // DataObjects_Symbol
            // 
            this.DataObjects_Symbol = new Stimulsoft.Report.Components.StiText();
            this.DataObjects_Symbol.CanGrow = true;
            this.DataObjects_Symbol.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(7.2, 0, 0.5, 0.3);
            this.DataObjects_Symbol.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.DataObjects_Symbol.Name = "DataObjects_Symbol";
            this.DataObjects_Symbol.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.DataObjects_Symbol__GetValue);
            this.DataObjects_Symbol.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.DataObjects_Symbol.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.Right, System.Drawing.Color.FromArgb(255, 219, 229, 241), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.DataObjects_Symbol.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.DataObjects_Symbol.Font = new System.Drawing.Font("Arial", 7F);
            this.DataObjects_Symbol.Guid = null;
            this.DataObjects_Symbol.Indicator = null;
            this.DataObjects_Symbol.Interaction = null;
            this.DataObjects_Symbol.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.DataObjects_Symbol.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.DataObjects_Symbol.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, true, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // DataObjects_Account
            // 
            this.DataObjects_Account = new Stimulsoft.Report.Components.StiText();
            this.DataObjects_Account.CanGrow = true;
            this.DataObjects_Account.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.7, 0, 0.5, 0.3);
            this.DataObjects_Account.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.DataObjects_Account.Name = "DataObjects_Account";
            this.DataObjects_Account.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.DataObjects_Account__GetValue);
            this.DataObjects_Account.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.DataObjects_Account.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.Right, System.Drawing.Color.FromArgb(255, 219, 229, 241), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.DataObjects_Account.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.DataObjects_Account.Font = new System.Drawing.Font("Arial", 7F);
            this.DataObjects_Account.Guid = null;
            this.DataObjects_Account.Indicator = null;
            this.DataObjects_Account.Interaction = null;
            this.DataObjects_Account.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.DataObjects_Account.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.DataObjects_Account.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, true, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text28
            // 
            this.Text28 = new Stimulsoft.Report.Components.StiText();
            this.Text28.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6, 0, 0.7, 0.3);
            this.Text28.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text28.Name = "Text28";
            this.Text28.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text28__GetValue);
            this.Text28.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text28.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.Right, System.Drawing.Color.FromArgb(255, 219, 229, 241), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text28.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text28.Font = new System.Drawing.Font("Arial", 7F);
            this.Text28.Guid = null;
            this.Text28.Indicator = null;
            this.Text28.Interaction = null;
            this.Text28.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text28.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text28.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text28.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text29
            // 
            this.Text29 = new Stimulsoft.Report.Components.StiText();
            this.Text29.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(5.4, 0, 0.6, 0.3);
            this.Text29.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text29.Name = "Text29";
            this.Text29.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text29__GetValue);
            this.Text29.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text29.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.Right, System.Drawing.Color.FromArgb(255, 219, 229, 241), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text29.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text29.Font = new System.Drawing.Font("Arial", 7F);
            this.Text29.Guid = null;
            this.Text29.Indicator = null;
            this.Text29.Interaction = null;
            this.Text29.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text29.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text29.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 1, ",", 3, true, false, " ");
            this.Text29.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text31
            // 
            this.Text31 = new Stimulsoft.Report.Components.StiText();
            this.Text31.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(3.7, 0, 1, 0.3);
            this.Text31.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text31.Name = "Text31";
            this.Text31.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text31__GetValue);
            this.Text31.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text31.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.Right, System.Drawing.Color.FromArgb(255, 219, 229, 241), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text31.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text31.Font = new System.Drawing.Font("Arial", 7F);
            this.Text31.Guid = null;
            this.Text31.Indicator = null;
            this.Text31.Interaction = null;
            this.Text31.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text31.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text31.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 0, ",", 3, true, false, " ");
            this.Text31.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text32
            // 
            this.Text32 = new Stimulsoft.Report.Components.StiText();
            this.Text32.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.1, 0, 0.8, 0.3);
            this.Text32.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text32.Name = "Text32";
            this.Text32.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text32__GetValue);
            this.Text32.Type = Stimulsoft.Report.Components.StiSystemTextType.DataColumn;
            this.Text32.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text32.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.Right, System.Drawing.Color.FromArgb(255, 219, 229, 241), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text32.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text32.Font = new System.Drawing.Font("Arial", 7F);
            this.Text32.Guid = null;
            this.Text32.Indicator = null;
            this.Text32.Interaction = null;
            this.Text32.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text32.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text32.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 0, ",", 3, true, false, " ");
            this.Text32.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text33
            // 
            this.Text33 = new Stimulsoft.Report.Components.StiText();
            this.Text33.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(1.3, 0, 0.8, 0.3);
            this.Text33.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text33.Name = "Text33";
            this.Text33.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text33__GetValue);
            this.Text33.Type = Stimulsoft.Report.Components.StiSystemTextType.DataColumn;
            this.Text33.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text33.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.Right, System.Drawing.Color.FromArgb(255, 219, 229, 241), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text33.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text33.Font = new System.Drawing.Font("Arial", 7F);
            this.Text33.Guid = null;
            this.Text33.Indicator = null;
            this.Text33.Interaction = null;
            this.Text33.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text33.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text33.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 0, ",", 3, true, false, " ");
            this.Text33.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text35
            // 
            this.Text35 = new Stimulsoft.Report.Components.StiText();
            this.Text35.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.9, 0, 0.8, 0.3);
            this.Text35.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text35.Name = "Text35";
            this.Text35.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text35__GetValue);
            this.Text35.Type = Stimulsoft.Report.Components.StiSystemTextType.DataColumn;
            this.Text35.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text35.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.Right, System.Drawing.Color.FromArgb(255, 219, 229, 241), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text35.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text35.Font = new System.Drawing.Font("Arial", 7F);
            this.Text35.Guid = null;
            this.Text35.Indicator = null;
            this.Text35.Interaction = null;
            this.Text35.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text35.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text35.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 0, ",", 3, true, false, " ");
            this.Text35.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text36
            // 
            this.Text36 = new Stimulsoft.Report.Components.StiText();
            this.Text36.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.5, 0, 0.8, 0.3);
            this.Text36.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text36.Name = "Text36";
            this.Text36.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text36__GetValue);
            this.Text36.Type = Stimulsoft.Report.Components.StiSystemTextType.DataColumn;
            this.Text36.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text36.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.Right, System.Drawing.Color.FromArgb(255, 219, 229, 241), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text36.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text36.Font = new System.Drawing.Font("Arial", 7F);
            this.Text36.Guid = null;
            this.Text36.Indicator = null;
            this.Text36.Interaction = null;
            this.Text36.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text36.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text36.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 0, ",", 3, true, false, " ");
            this.Text36.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text37
            // 
            this.Text37 = new Stimulsoft.Report.Components.StiText();
            this.Text37.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0, 0.5, 0.3);
            this.Text37.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text37.Name = "Text37";
            this.Text37.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text37__GetValue);
            this.Text37.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text37.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.Right, System.Drawing.Color.FromArgb(255, 219, 229, 241), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text37.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text37.Font = new System.Drawing.Font("Arial", 7F);
            this.Text37.Guid = null;
            this.Text37.Indicator = null;
            this.Text37.Interaction = null;
            this.Text37.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text37.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text37.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text30
            // 
            this.Text30 = new Stimulsoft.Report.Components.StiText();
            this.Text30.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.7, 0, 0.7, 0.3);
            this.Text30.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text30.Name = "Text30";
            this.Text30.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text30__GetValue);
            this.Text30.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text30.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.Right, System.Drawing.Color.FromArgb(255, 219, 229, 241), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text30.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text30.Font = new System.Drawing.Font("Arial", 7F);
            this.Text30.Guid = null;
            this.Text30.Indicator = null;
            this.Text30.Interaction = null;
            this.Text30.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text30.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text30.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 0, ",", 3, true, false, " ");
            this.Text30.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            this.Data.DataSourceName = null;
            this.Data.Guid = null;
            this.Data.Interaction = null;
            this.Data.MasterComponent = null;
            this.Page1.ExcelSheetValue = null;
            this.Page1.Interaction = null;
            this.Page1.Margins = new Stimulsoft.Report.Components.StiMargins(0.39, 0.39, 0.39, 0.39);
            this.Page1_Watermark = new Stimulsoft.Report.Components.StiWatermark();
            this.Page1_Watermark.Font = new System.Drawing.Font("Arial", 100F);
            this.Page1_Watermark.Image = null;
            this.Page1_Watermark.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(50, 0, 0, 0));
            // 
            // Page2
            // 
            this.Page2 = new Stimulsoft.Report.Components.StiPage();
            this.Page2.Guid = "eebd9d8dac0a4683acb527ea6cdfd668";
            this.Page2.Name = "Page2";
            this.Page2.PageHeight = 11;
            this.Page2.PageWidth = 8.5;
            this.Page2.PaperSize = System.Drawing.Printing.PaperKind.Letter;
            this.Page2.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 2, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Page2.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Page2.ExcelSheetValue = null;
            this.Page2.Interaction = null;
            this.Page2.Margins = new Stimulsoft.Report.Components.StiMargins(0.39, 0.39, 0.39, 0.39);
            this.Page2_Watermark = new Stimulsoft.Report.Components.StiWatermark();
            this.Page2_Watermark.Font = new System.Drawing.Font("Arial", 100F);
            this.Page2_Watermark.Image = null;
            this.Page2_Watermark.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(50, 0, 0, 0));
            this.Report_PrinterSettings = new Stimulsoft.Report.Print.StiPrinterSettings();
            this.PrinterSettings = this.Report_PrinterSettings;
            this.Page1.Report = this;
            this.Page1.Watermark = this.Page1_Watermark;
            this.PageFooterBand2.Page = this.Page1;
            this.PageFooterBand2.Parent = this.Page1;
            this.Text18.Page = this.Page1;
            this.Text18.Parent = this.PageFooterBand2;
            this.Text19.Page = this.Page1;
            this.Text19.Parent = this.PageFooterBand2;
            this.Image1.Page = this.Page1;
            this.Image1.Parent = this.PageFooterBand2;
            this.Text12.Page = this.Page1;
            this.Text12.Parent = this.Page1;
            this.Text15.Page = this.Page1;
            this.Text15.Parent = this.Page1;
            this.Text11.Page = this.Page1;
            this.Text11.Parent = this.Page1;
            this.Text14.Page = this.Page1;
            this.Text14.Parent = this.Page1;
            this.ReportTitleBand2.Page = this.Page1;
            this.ReportTitleBand2.Parent = this.Page1;
            this.Panel2.Page = this.Page1;
            this.Panel2.Parent = this.ReportTitleBand2;
            this.Text2.Page = this.Page1;
            this.Text2.Parent = this.Panel2;
            this.Text4.Page = this.Page1;
            this.Text4.Parent = this.Panel2;
            this.Text6.Page = this.Page1;
            this.Text6.Parent = this.Panel2;
            this.Text34.Page = this.Page1;
            this.Text34.Parent = this.Panel2;
            this.Text5.Page = this.Page1;
            this.Text5.Parent = this.Panel2;
            this.Text3.Page = this.Page1;
            this.Text3.Parent = this.Panel2;
            this.Text1.Page = this.Page1;
            this.Text1.Parent = this.Panel2;
            this.Text25.Page = this.Page1;
            this.Text25.Parent = this.Panel2;
            this.Text26.Page = this.Page1;
            this.Text26.Parent = this.Panel2;
            this.Text27.Page = this.Page1;
            this.Text27.Parent = this.Panel2;
            this.HeaderBand2.Page = this.Page1;
            this.HeaderBand2.Parent = this.Page1;
            this.Text13.Page = this.Page1;
            this.Text13.Parent = this.HeaderBand2;
            this.Text7.Page = this.Page1;
            this.Text7.Parent = this.HeaderBand2;
            this.Text8.Page = this.Page1;
            this.Text8.Parent = this.HeaderBand2;
            this.Text9.Page = this.Page1;
            this.Text9.Parent = this.HeaderBand2;
            this.Text10.Page = this.Page1;
            this.Text10.Parent = this.HeaderBand2;
            this.Text16.Page = this.Page1;
            this.Text16.Parent = this.HeaderBand2;
            this.Text20.Page = this.Page1;
            this.Text20.Parent = this.HeaderBand2;
            this.Text21.Page = this.Page1;
            this.Text21.Parent = this.HeaderBand2;
            this.Text22.Page = this.Page1;
            this.Text22.Parent = this.HeaderBand2;
            this.Text23.Page = this.Page1;
            this.Text23.Parent = this.HeaderBand2;
            this.Text24.Page = this.Page1;
            this.Text24.Parent = this.HeaderBand2;
            this.HorizontalLinePrimitive2.Page = this.Page1;
            this.HorizontalLinePrimitive2.Parent = this.HeaderBand2;
            this.Data.Page = this.Page1;
            this.Data.Parent = this.Page1;
            this.DataObjects_Symbol.Page = this.Page1;
            this.DataObjects_Symbol.Parent = this.Data;
            this.DataObjects_Account.Page = this.Page1;
            this.DataObjects_Account.Parent = this.Data;
            this.Text28.Page = this.Page1;
            this.Text28.Parent = this.Data;
            this.Text29.Page = this.Page1;
            this.Text29.Parent = this.Data;
            this.Text31.Page = this.Page1;
            this.Text31.Parent = this.Data;
            this.Text32.Page = this.Page1;
            this.Text32.Parent = this.Data;
            this.Text33.Page = this.Page1;
            this.Text33.Parent = this.Data;
            this.Text35.Page = this.Page1;
            this.Text35.Parent = this.Data;
            this.Text36.Page = this.Page1;
            this.Text36.Parent = this.Data;
            this.Text37.Page = this.Page1;
            this.Text37.Parent = this.Data;
            this.Text30.Page = this.Page1;
            this.Text30.Parent = this.Data;
            this.Page2.Report = this;
            this.Page2.Watermark = this.Page2_Watermark;
            this.EndRender += new System.EventHandler(this.ReportWordsToEnd__EndRender);
            // 
            // Add to PageFooterBand2.Components
            // 
            this.PageFooterBand2.Components.Clear();
            this.PageFooterBand2.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Text18,
                        this.Text19,
                        this.Image1});
            // 
            // Add to Panel2.Components
            // 
            this.Panel2.Components.Clear();
            this.Panel2.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Text2,
                        this.Text4,
                        this.Text6,
                        this.Text34,
                        this.Text5,
                        this.Text3,
                        this.Text1,
                        this.Text25,
                        this.Text26,
                        this.Text27});
            // 
            // Add to ReportTitleBand2.Components
            // 
            this.ReportTitleBand2.Components.Clear();
            this.ReportTitleBand2.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Panel2});
            // 
            // Add to HeaderBand2.Components
            // 
            this.HeaderBand2.Components.Clear();
            this.HeaderBand2.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Text13,
                        this.Text7,
                        this.Text8,
                        this.Text9,
                        this.Text10,
                        this.Text16,
                        this.Text20,
                        this.Text21,
                        this.Text22,
                        this.Text23,
                        this.Text24,
                        this.HorizontalLinePrimitive2});
            // 
            // Add to Data.Components
            // 
            this.Data.Components.Clear();
            this.Data.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.DataObjects_Symbol,
                        this.DataObjects_Account,
                        this.Text28,
                        this.Text29,
                        this.Text31,
                        this.Text32,
                        this.Text33,
                        this.Text35,
                        this.Text36,
                        this.Text37,
                        this.Text30});
            // 
            // Add to Page1.Components
            // 
            this.Page1.Components.Clear();
            this.InitializeComponent2();
        }
        
        public void InitializeComponent2()
        {
            this.Page1.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.PageFooterBand2,
                        this.Text12,
                        this.Text15,
                        this.Text11,
                        this.Text14,
                        this.ReportTitleBand2,
                        this.HeaderBand2,
                        this.Data});
            // 
            // Add to Pages
            // 
            this.Pages.Clear();
            this.Pages.AddRange(new Stimulsoft.Report.Components.StiPage[] {
                        this.Page1,
                        this.Page2});
            this.Info.Columns.AddRange(new Stimulsoft.Report.Dictionary.StiDataColumn[] {
                        new Stimulsoft.Report.Dictionary.StiDataColumn("Id", "Id", "Id", typeof(int)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("Title", "Title", "Title", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("StartDate", "StartDate", "StartDate", typeof(int?)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("EndDate", "EndDate", "EndDate", typeof(int?)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("UserId", "UserId", "UserId", typeof(int?)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("_StartDate", "_StartDate", "_StartDate", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("_EndDate", "_EndDate", "_EndDate", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("symbol", "symbol", "symbol", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("Code", "Code", "Code", typeof(string))});
            this.Dictionary.BusinessObjects.Add(this.Info);
            this.Objects.Columns.AddRange(new Stimulsoft.Report.Dictionary.StiDataColumn[] {
                        new Stimulsoft.Report.Dictionary.StiDataColumn("Id", "Id", "Id", typeof(int?)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("Symbol", "Symbol", "Symbol", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("Account", "Account", "Account", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("Value", "Value", "Value", typeof(float)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("SumAllFee", "SumAllFee", "SumAllFee", typeof(float)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("Intrest", "Intrest", "Intrest", typeof(float)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("SumValueWithFee", "SumValueWithFee", "SumValueWithFee", typeof(float)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("BuyFee", "BuyFee", "BuyFee", typeof(float)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("BuyInterest", "BuyInterest", "BuyInterest", typeof(float)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("BuyTotal", "BuyTotal", "BuyTotal", typeof(float)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("BuyTotalAndFee", "BuyTotalAndFee", "BuyTotalAndFee", typeof(float)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("TradeDate", "TradeDate", "TradeDate", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("SellFee", "SellFee", "SellFee", typeof(float)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("SellInterest", "SellInterest", "SellInterest", typeof(float)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("SellTotal", "SellTotal", "SellTotal", typeof(float)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("SellTotalAndFee", "SellTotalAndFee", "SellTotalAndFee", typeof(float))});
            this.Dictionary.BusinessObjects.Add(this.Objects);
        }
        
        #region BusinessObject Info
        public class InfoBusinessObject : Stimulsoft.Report.Dictionary.StiBusinessObject
        {
            
            public InfoBusinessObject() : 
                    base("", "Info", "Info", "82b9ab83ffd64199ade1819baa747099")
            {
            }
            
            public virtual int Id
            {
                get
                {
                    return ((int)(StiReport.ChangeType(this["Id"], typeof(int), true)));
                }
            }
            
            public virtual string Title
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["Title"], typeof(string), true)));
                }
            }
            
            public virtual int? StartDate
            {
                get
                {
                    return ((int?)(StiReport.ChangeType(this["StartDate"], typeof(int?), true)));
                }
            }
            
            public virtual int? EndDate
            {
                get
                {
                    return ((int?)(StiReport.ChangeType(this["EndDate"], typeof(int?), true)));
                }
            }
            
            public virtual int? UserId
            {
                get
                {
                    return ((int?)(StiReport.ChangeType(this["UserId"], typeof(int?), true)));
                }
            }
            
            public virtual string _StartDate
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["_StartDate"], typeof(string), true)));
                }
            }
            
            public virtual string _EndDate
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["_EndDate"], typeof(string), true)));
                }
            }
            
            public virtual string symbol
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["symbol"], typeof(string), true)));
                }
            }
            
            public virtual string Code
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["Code"], typeof(string), true)));
                }
            }
        }
        #endregion BusinessObject Info
        
        #region BusinessObject Objects
        public class ObjectsBusinessObject : Stimulsoft.Report.Dictionary.StiBusinessObject
        {
            
            public ObjectsBusinessObject() : 
                    base("", "Objects", "Objects", "0e798cde640646e09f2515086abda96b")
            {
            }
            
            public virtual int? Id
            {
                get
                {
                    return ((int?)(StiReport.ChangeType(this["Id"], typeof(int?), true)));
                }
            }
            
            public virtual string Symbol
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["Symbol"], typeof(string), true)));
                }
            }
            
            public virtual string Account
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["Account"], typeof(string), true)));
                }
            }
            
            public virtual float Value
            {
                get
                {
                    return ((float)(StiReport.ChangeType(this["Value"], typeof(float), true)));
                }
            }
            
            public virtual float SumAllFee
            {
                get
                {
                    return ((float)(StiReport.ChangeType(this["SumAllFee"], typeof(float), true)));
                }
            }
            
            public virtual float Intrest
            {
                get
                {
                    return ((float)(StiReport.ChangeType(this["Intrest"], typeof(float), true)));
                }
            }
            
            public virtual float SumValueWithFee
            {
                get
                {
                    return ((float)(StiReport.ChangeType(this["SumValueWithFee"], typeof(float), true)));
                }
            }
            
            public virtual float BuyFee
            {
                get
                {
                    return ((float)(StiReport.ChangeType(this["BuyFee"], typeof(float), true)));
                }
            }
            
            public virtual float BuyInterest
            {
                get
                {
                    return ((float)(StiReport.ChangeType(this["BuyInterest"], typeof(float), true)));
                }
            }
            
            public virtual float BuyTotal
            {
                get
                {
                    return ((float)(StiReport.ChangeType(this["BuyTotal"], typeof(float), true)));
                }
            }
            
            public virtual float BuyTotalAndFee
            {
                get
                {
                    return ((float)(StiReport.ChangeType(this["BuyTotalAndFee"], typeof(float), true)));
                }
            }
            
            public virtual string TradeDate
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["TradeDate"], typeof(string), true)));
                }
            }
            
            public virtual float SellFee
            {
                get
                {
                    return ((float)(StiReport.ChangeType(this["SellFee"], typeof(float), true)));
                }
            }
            
            public virtual float SellInterest
            {
                get
                {
                    return ((float)(StiReport.ChangeType(this["SellInterest"], typeof(float), true)));
                }
            }
            
            public virtual float SellTotal
            {
                get
                {
                    return ((float)(StiReport.ChangeType(this["SellTotal"], typeof(float), true)));
                }
            }
            
            public virtual float SellTotalAndFee
            {
                get
                {
                    return ((float)(StiReport.ChangeType(this["SellTotalAndFee"], typeof(float), true)));
                }
            }
        }
        #endregion BusinessObject Objects
        #endregion StiReport Designer generated code - do not modify
    }
	
	
}