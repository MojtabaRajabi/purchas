﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Data;
using Stimulsoft.Controls;
using Stimulsoft.Base.Drawing;
using Stimulsoft.Report;
using Stimulsoft.Report.Dialogs;
using Stimulsoft.Report.Components;

namespace Reports
{
    public class Report : Stimulsoft.Report.StiReport
    {
        public Report()        {
            this.InitializeComponent();
        }

		
		public string DateToshamsi(object date)
		{
			System.Globalization.PersianCalendar shamsi = new        System.Globalization.PersianCalendar();

			DateTime da = (DateTime)date;
			int year = shamsi.GetYear(da);
			int month = shamsi.GetMonth(da);
			int day = shamsi.GetDayOfMonth(da);
			return year.ToString()+ "/"+ month.ToString() + "/"+day.ToString()  ;

		}
		
        #region StiReport Designer generated code - do not modify
        public string _StartDate;
        public Stimulsoft.Report.Components.StiPage Page1;
        public Stimulsoft.Report.Components.StiPageFooterBand PageFooterBand2;
        public Stimulsoft.Report.Components.StiText Text18;
        public Stimulsoft.Report.Components.StiText Text19;
        public Stimulsoft.Report.Components.StiText Text12;
        public Stimulsoft.Report.Components.StiText Text15;
        public Stimulsoft.Report.Components.StiText Text11;
        public Stimulsoft.Report.Components.StiText Text14;
        public Stimulsoft.Report.Components.StiReportTitleBand ReportTitleBand2;
        public Stimulsoft.Report.Components.StiPanel Panel2;
        public Stimulsoft.Report.Components.StiText Text2;
        public Stimulsoft.Report.Components.StiText Text34;
        public Stimulsoft.Report.Components.StiHeaderBand HeaderBand2;
        public Stimulsoft.Report.Components.StiText Text13;
        public Stimulsoft.Report.Components.StiText Text7;
        public Stimulsoft.Report.Components.StiText Text8;
        public Stimulsoft.Report.Components.StiText Text9;
        public Stimulsoft.Report.Components.StiHorizontalLinePrimitive HorizontalLinePrimitive2;
        public Stimulsoft.Report.Components.StiDataBand Data;
        public Stimulsoft.Report.Components.StiText DataObjects_Symbol;
        public Stimulsoft.Report.Components.StiText DataObjects_Account;
        public Stimulsoft.Report.Components.StiText Text1;
        public Stimulsoft.Report.Components.StiText Text3;
        public Stimulsoft.Report.Components.StiWatermark Page1_Watermark;
        public Stimulsoft.Report.Print.StiPrinterSettings Report_PrinterSettings;
        public new InfoBusinessObject Info;
        public ObjectsBusinessObject Objects;
        
        public void Text18__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "سامانه مدیریت ریسک ";
        }
        
        public void Text19__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "#%#صفحه‌ی {PageNumber} از {TotalPageCount}";
            e.StoreToPrinted = true;
        }
        
        public System.String Text19_GetValue_End(Stimulsoft.Report.Components.StiComponent sender)
        {
            return "صفحه‌ی " + ToString(sender, PageNumber, true) + " از " + ToString(sender, TotalPageCount, true);
        }
        
        public void Text12__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "_StartDate";
        }
        
        public void Text15__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "_EndDate";
        }
        
        public void Text11__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Info._StartDate, true);
        }
        
        public void Text14__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Info._EndDate, true);
        }
        
        public void Text2__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "پرتفوی";
        }
        
        public void Text34__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, DateToshamsi(Today), true);
        }
        
        public void Text13__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "نماد";
        }
        
        public void Text7__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "کد سهامداری";
        }
        
        public void Text8__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "تعداد";
        }
        
        public void Text9__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "تاریخ";
        }
        
        public void DataObjects_Symbol__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Objects.Symbol, true);
        }
        
        public void DataObjects_Account__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Objects.Account, true);
        }
        
        public void Text1__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text1.TextFormat.Format(CheckExcelValue(sender, Objects.Num));
        }
        
        public void Text3__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Objects._Date, true);
        }
        
        public void ReportWordsToEnd__EndRender(object sender, System.EventArgs e)
        {
            this.Text19.SetText(new Stimulsoft.Report.Components.StiGetValue(this.Text19_GetValue_End));
        }
        
        private void InitializeComponent()
        {
            this.Objects = new ObjectsBusinessObject();
            this.Info = new InfoBusinessObject();
            this.Dictionary.Variables.Add(new Stimulsoft.Report.Dictionary.StiVariable("", "_StartDate", "_StartDate", "", typeof(string), "", false, Stimulsoft.Report.Dictionary.StiVariableInitBy.Value, false));
            this.NeedsCompiling = false;
            // 
            // Variables init
            // 
            this._StartDate = "";
            this.EngineVersion = Stimulsoft.Report.Engine.StiEngineVersion.EngineV2;
            this.ReferencedAssemblies = new System.String[] {
                    "System.Dll",
                    "System.Drawing.Dll",
                    "System.Windows.Forms.Dll",
                    "System.Data.Dll",
                    "System.Xml.Dll",
                    "Stimulsoft.Controls.Dll",
                    "Stimulsoft.Base.Dll",
                    "Stimulsoft.Report.Dll"};
            this.ReportAlias = "Report";
            // 
            // ReportChanged
            // 
            this.ReportChanged = new DateTime(2019, 3, 11, 15, 13, 1, 207);
            // 
            // ReportCreated
            // 
            this.ReportCreated = new DateTime(2018, 7, 1, 16, 48, 34, 0);
            this.ReportFile = "C:\\x_ErmN\\erm\\Sanay.Lotus.Erm\\Content\\Reports\\positions.mrt";
            this.ReportGuid = "84d944462e17423e8beed4ca80ba76bd";
            this.ReportName = "Report";
            this.ReportUnit = Stimulsoft.Report.StiReportUnitType.Inches;
            this.ReportVersion = "2013.1.1600";
            this.ScriptLanguage = Stimulsoft.Report.StiReportLanguageType.CSharp;
            // 
            // Page1
            // 
            this.Page1 = new Stimulsoft.Report.Components.StiPage();
            this.Page1.Guid = "3212fef088394d08bce68018b3efe5a2";
            this.Page1.Name = "Page1";
            this.Page1.PageHeight = 11;
            this.Page1.PageWidth = 8.5;
            this.Page1.PaperSize = System.Drawing.Printing.PaperKind.Letter;
            this.Page1.RightToLeft = true;
            this.Page1.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 2, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Page1.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // PageFooterBand2
            // 
            this.PageFooterBand2 = new Stimulsoft.Report.Components.StiPageFooterBand();
            this.PageFooterBand2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 9.82, 7.72, 0.4);
            this.PageFooterBand2.Guid = "3784297c2c0947a096d46d9c3d9802b7";
            this.PageFooterBand2.Name = "PageFooterBand2";
            this.PageFooterBand2.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.PageFooterBand2.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // Text18
            // 
            this.Text18 = new Stimulsoft.Report.Components.StiText();
            this.Text18.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.8, 0.1, 2.9, 0.3);
            this.Text18.ComponentStyle = "Collection_Page_Footer";
            this.Text18.Guid = "166a39f97a4541baadd89ef03b9ebab0";
            this.Text18.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text18.Name = "Text18";
            this.Text18.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text18__GetValue);
            this.Text18.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text18.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text18.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text18.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text18.Font = new System.Drawing.Font("B Nazanin", 11F, System.Drawing.FontStyle.Bold);
            this.Text18.Indicator = null;
            this.Text18.Interaction = null;
            this.Text18.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text18.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 112, 48, 160));
            this.Text18.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text19
            // 
            this.Text19 = new Stimulsoft.Report.Components.StiText();
            this.Text19.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.2, 3.4, 0.3);
            this.Text19.ComponentStyle = "Collection_Page_Footer";
            this.Text19.Guid = "234c2848b941421aa5eef465745672d1";
            this.Text19.Name = "Text19";
            this.Text19.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text19__GetValue);
            this.Text19.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text19.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text19.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text19.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text19.Indicator = null;
            this.Text19.Interaction = null;
            this.Text19.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text19.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text19.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            this.PageFooterBand2.Interaction = null;
            // 
            // Text12
            // 
            this.Text12 = new Stimulsoft.Report.Components.StiText();
            this.Text12.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(8.7, 3.5, 1, 0.3);
            this.Text12.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text12.Name = "Text12";
            this.Text12.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text12__GetValue);
            this.Text12.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text12.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.All, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text12.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 181, 204, 136));
            this.Text12.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text12.Guid = null;
            this.Text12.Indicator = null;
            this.Text12.Interaction = null;
            this.Text12.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text12.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text12.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text15
            // 
            this.Text15 = new Stimulsoft.Report.Components.StiText();
            this.Text15.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(9.7, 3.5, 1, 0.3);
            this.Text15.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text15.Name = "Text15";
            this.Text15.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text15__GetValue);
            this.Text15.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text15.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.All, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text15.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 181, 204, 136));
            this.Text15.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text15.Guid = null;
            this.Text15.Indicator = null;
            this.Text15.Interaction = null;
            this.Text15.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text15.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text15.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text11
            // 
            this.Text11 = new Stimulsoft.Report.Components.StiText();
            this.Text11.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(8.7, 4.2, 1, 0.3);
            this.Text11.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text11.Name = "Text11";
            this.Text11.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text11__GetValue);
            this.Text11.Type = Stimulsoft.Report.Components.StiSystemTextType.DataColumn;
            this.Text11.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text11.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text11.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text11.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.Text11.Guid = null;
            this.Text11.Indicator = null;
            this.Text11.Interaction = null;
            this.Text11.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text11.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text11.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text14
            // 
            this.Text14 = new Stimulsoft.Report.Components.StiText();
            this.Text14.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(9.7, 4.2, 1, 0.3);
            this.Text14.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text14.Name = "Text14";
            this.Text14.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text14__GetValue);
            this.Text14.Type = Stimulsoft.Report.Components.StiSystemTextType.DataColumn;
            this.Text14.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text14.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text14.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text14.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.Text14.Guid = null;
            this.Text14.Indicator = null;
            this.Text14.Interaction = null;
            this.Text14.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text14.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text14.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // ReportTitleBand2
            // 
            this.ReportTitleBand2 = new Stimulsoft.Report.Components.StiReportTitleBand();
            this.ReportTitleBand2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.2, 7.72, 1);
            this.ReportTitleBand2.Guid = "b60594cb8fe4cc69fad155c8c979b8ee";
            this.ReportTitleBand2.Name = "ReportTitleBand2";
            this.ReportTitleBand2.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.ReportTitleBand2.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // Panel2
            // 
            this.Panel2 = new Stimulsoft.Report.Components.StiPanel();
            this.Panel2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.2, 7.7, 0.7);
            this.Panel2.Guid = "851d049ab4370bd84ee855c8c979886e";
            this.Panel2.Name = "Panel2";
            this.Panel2.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.DashDotDot, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Panel2.Brush = new Stimulsoft.Base.Drawing.StiEmptyBrush();
            // 
            // Text2
            // 
            this.Text2 = new Stimulsoft.Report.Components.StiText();
            this.Text2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.5, 0.1, 2.6, 0.3);
            this.Text2.Guid = "f5b51cdc0cde4de9abc5759889eac380";
            this.Text2.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text2.Name = "Text2";
            this.Text2.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text2__GetValue);
            this.Text2.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text2.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text2.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text2.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text2.Font = new System.Drawing.Font("B Nazanin", 14F, System.Drawing.FontStyle.Bold);
            this.Text2.Indicator = null;
            this.Text2.Interaction = null;
            this.Text2.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text2.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 112, 192));
            this.Text2.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            this.Panel2.Interaction = null;
            // 
            // Text34
            // 
            this.Text34 = new Stimulsoft.Report.Components.StiText();
            this.Text34.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0, 2, 0.4);
            this.Text34.Guid = "d886dec5c5684c4691ceda208996e169";
            this.Text34.Name = "Text34";
            this.Text34.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text34__GetValue);
            this.Text34.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text34.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.Right, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.None, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text34.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text34.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text34.Indicator = null;
            this.Text34.Interaction = null;
            this.Text34.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text34.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text34.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            this.ReportTitleBand2.Interaction = null;
            // 
            // HeaderBand2
            // 
            this.HeaderBand2 = new Stimulsoft.Report.Components.StiHeaderBand();
            this.HeaderBand2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 1.6, 7.72, 0.3);
            this.HeaderBand2.ComponentStyle = "Collection_Header1";
            this.HeaderBand2.Guid = "39f29c7dcae0cf9ff22555c8c97a05b2";
            this.HeaderBand2.Name = "HeaderBand2";
            this.HeaderBand2.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.HeaderBand2.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 184, 204, 228));
            // 
            // Text13
            // 
            this.Text13 = new Stimulsoft.Report.Components.StiText();
            this.Text13.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.2, 0, 1.5, 0.3);
            this.Text13.ComponentStyle = "Collection_Header1";
            this.Text13.Guid = "adb07f73423ea317ea4f55c8c97bba13";
            this.Text13.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text13.Name = "Text13";
            this.Text13.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text13__GetValue);
            this.Text13.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text13.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text13.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text13.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 184, 204, 228));
            this.Text13.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text13.Indicator = null;
            this.Text13.Interaction = null;
            this.Text13.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text13.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text13.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text7
            // 
            this.Text7 = new Stimulsoft.Report.Components.StiText();
            this.Text7.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.7, 0, 1.5, 0.3);
            this.Text7.ComponentStyle = "Collection_Header1";
            this.Text7.Guid = "ad8834a8db4d40f1a6e294c9f96965fc";
            this.Text7.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text7.Name = "Text7";
            this.Text7.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text7__GetValue);
            this.Text7.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text7.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text7.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text7.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 184, 204, 228));
            this.Text7.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text7.Indicator = null;
            this.Text7.Interaction = null;
            this.Text7.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text7.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text7.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text8
            // 
            this.Text8 = new Stimulsoft.Report.Components.StiText();
            this.Text8.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.9, 0, 1.8, 0.3);
            this.Text8.ComponentStyle = "Collection_Header1";
            this.Text8.Guid = "846660d756fb465dbabdfb11e5667543";
            this.Text8.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text8.Name = "Text8";
            this.Text8.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text8__GetValue);
            this.Text8.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text8.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text8.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text8.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 184, 204, 228));
            this.Text8.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text8.Indicator = null;
            this.Text8.Interaction = null;
            this.Text8.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text8.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text8.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text9
            // 
            this.Text9 = new Stimulsoft.Report.Components.StiText();
            this.Text9.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0, 1.5, 0.3);
            this.Text9.ComponentStyle = "Collection_Header1";
            this.Text9.Guid = "b59549c3b3184cc8a7e53390112df076";
            this.Text9.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text9.Name = "Text9";
            this.Text9.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text9__GetValue);
            this.Text9.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text9.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text9.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text9.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 184, 204, 228));
            this.Text9.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Bold);
            this.Text9.Indicator = null;
            this.Text9.Interaction = null;
            this.Text9.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text9.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text9.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // HorizontalLinePrimitive2
            // 
            this.HorizontalLinePrimitive2 = new Stimulsoft.Report.Components.StiHorizontalLinePrimitive();
            this.HorizontalLinePrimitive2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0.8, -0.1, 5.8, 0.01);
            this.HorizontalLinePrimitive2.Color = System.Drawing.Color.FromArgb(255, 81, 104, 36);
            this.HorizontalLinePrimitive2.ComponentStyle = "Collection_Report_Title1";
            this.HorizontalLinePrimitive2.Guid = "d859e23db21fb791547d55c8c97a9a8d";
            this.HorizontalLinePrimitive2.Name = "HorizontalLinePrimitive2";
            this.HorizontalLinePrimitive2.EndCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HorizontalLinePrimitive2.Interaction = null;
            this.HorizontalLinePrimitive2.StartCap = new Stimulsoft.Base.Drawing.StiCap(10, Stimulsoft.Base.Drawing.StiCapStyle.None, 10, true, System.Drawing.Color.Black);
            this.HeaderBand2.Interaction = null;
            // 
            // Data
            // 
            this.Data = new Stimulsoft.Report.Components.StiDataBand();
            this.Data.BusinessObjectGuid = "0e798cde640646e09f2515086abda96b";
            this.Data.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 2.3, 7.72, 0.3);
            this.Data.Name = "Data";
            this.Data.Sort = new System.String[0];
            this.Data.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Data.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // DataObjects_Symbol
            // 
            this.DataObjects_Symbol = new Stimulsoft.Report.Components.StiText();
            this.DataObjects_Symbol.CanGrow = true;
            this.DataObjects_Symbol.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(6.2, 0, 1.5, 0.3);
            this.DataObjects_Symbol.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.DataObjects_Symbol.Name = "DataObjects_Symbol";
            this.DataObjects_Symbol.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.DataObjects_Symbol__GetValue);
            this.DataObjects_Symbol.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.DataObjects_Symbol.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.DataObjects_Symbol.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.DataObjects_Symbol.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.DataObjects_Symbol.Guid = null;
            this.DataObjects_Symbol.Indicator = null;
            this.DataObjects_Symbol.Interaction = null;
            this.DataObjects_Symbol.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.DataObjects_Symbol.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.DataObjects_Symbol.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, true, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // DataObjects_Account
            // 
            this.DataObjects_Account = new Stimulsoft.Report.Components.StiText();
            this.DataObjects_Account.CanGrow = true;
            this.DataObjects_Account.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.7, 0, 1.5, 0.3);
            this.DataObjects_Account.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.DataObjects_Account.Name = "DataObjects_Account";
            this.DataObjects_Account.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.DataObjects_Account__GetValue);
            this.DataObjects_Account.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.DataObjects_Account.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.DataObjects_Account.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.DataObjects_Account.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.DataObjects_Account.Guid = null;
            this.DataObjects_Account.Indicator = null;
            this.DataObjects_Account.Interaction = null;
            this.DataObjects_Account.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.DataObjects_Account.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.DataObjects_Account.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, true, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text1
            // 
            this.Text1 = new Stimulsoft.Report.Components.StiText();
            this.Text1.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.9, 0, 1.8, 0.3);
            this.Text1.Name = "Text1";
            this.Text1.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text1__GetValue);
            this.Text1.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text1.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 79, 129, 189), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text1.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.Text1.Guid = null;
            this.Text1.Indicator = null;
            this.Text1.Interaction = null;
            this.Text1.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text1.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text1.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, ".", 0, ",", 3, true, false, " ");
            this.Text1.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text3
            // 
            this.Text3 = new Stimulsoft.Report.Components.StiText();
            this.Text3.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0, 1.5, 0.3);
            this.Text3.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text3.Name = "Text3";
            this.Text3.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text3__GetValue);
            this.Text3.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text3.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 79, 129, 189), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text3.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text3.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.Text3.Guid = null;
            this.Text3.Indicator = null;
            this.Text3.Interaction = null;
            this.Text3.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text3.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text3.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            this.Data.DataSourceName = null;
            this.Data.Guid = null;
            this.Data.Interaction = null;
            this.Data.MasterComponent = null;
            this.Page1.ExcelSheetValue = null;
            this.Page1.Interaction = null;
            this.Page1.Margins = new Stimulsoft.Report.Components.StiMargins(0.39, 0.39, 0.39, 0.39);
            this.Page1_Watermark = new Stimulsoft.Report.Components.StiWatermark();
            this.Page1_Watermark.Font = new System.Drawing.Font("Arial", 100F);
            this.Page1_Watermark.Image = null;
            this.Page1_Watermark.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(50, 0, 0, 0));
            this.Report_PrinterSettings = new Stimulsoft.Report.Print.StiPrinterSettings();
            this.PrinterSettings = this.Report_PrinterSettings;
            this.Page1.Report = this;
            this.Page1.Watermark = this.Page1_Watermark;
            this.PageFooterBand2.Page = this.Page1;
            this.PageFooterBand2.Parent = this.Page1;
            this.Text18.Page = this.Page1;
            this.Text18.Parent = this.PageFooterBand2;
            this.Text19.Page = this.Page1;
            this.Text19.Parent = this.PageFooterBand2;
            this.Text12.Page = this.Page1;
            this.Text12.Parent = this.Page1;
            this.Text15.Page = this.Page1;
            this.Text15.Parent = this.Page1;
            this.Text11.Page = this.Page1;
            this.Text11.Parent = this.Page1;
            this.Text14.Page = this.Page1;
            this.Text14.Parent = this.Page1;
            this.ReportTitleBand2.Page = this.Page1;
            this.ReportTitleBand2.Parent = this.Page1;
            this.Panel2.Page = this.Page1;
            this.Panel2.Parent = this.ReportTitleBand2;
            this.Text2.Page = this.Page1;
            this.Text2.Parent = this.Panel2;
            this.Text34.Page = this.Page1;
            this.Text34.Parent = this.ReportTitleBand2;
            this.HeaderBand2.Page = this.Page1;
            this.HeaderBand2.Parent = this.Page1;
            this.Text13.Page = this.Page1;
            this.Text13.Parent = this.HeaderBand2;
            this.Text7.Page = this.Page1;
            this.Text7.Parent = this.HeaderBand2;
            this.Text8.Page = this.Page1;
            this.Text8.Parent = this.HeaderBand2;
            this.Text9.Page = this.Page1;
            this.Text9.Parent = this.HeaderBand2;
            this.HorizontalLinePrimitive2.Page = this.Page1;
            this.HorizontalLinePrimitive2.Parent = this.HeaderBand2;
            this.Data.Page = this.Page1;
            this.Data.Parent = this.Page1;
            this.DataObjects_Symbol.Page = this.Page1;
            this.DataObjects_Symbol.Parent = this.Data;
            this.DataObjects_Account.Page = this.Page1;
            this.DataObjects_Account.Parent = this.Data;
            this.Text1.Page = this.Page1;
            this.Text1.Parent = this.Data;
            this.Text3.Page = this.Page1;
            this.Text3.Parent = this.Data;
            this.EndRender += new System.EventHandler(this.ReportWordsToEnd__EndRender);
            // 
            // Add to PageFooterBand2.Components
            // 
            this.PageFooterBand2.Components.Clear();
            this.PageFooterBand2.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Text18,
                        this.Text19});
            // 
            // Add to Panel2.Components
            // 
            this.Panel2.Components.Clear();
            this.Panel2.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Text2});
            // 
            // Add to ReportTitleBand2.Components
            // 
            this.ReportTitleBand2.Components.Clear();
            this.ReportTitleBand2.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Panel2,
                        this.Text34});
            // 
            // Add to HeaderBand2.Components
            // 
            this.HeaderBand2.Components.Clear();
            this.HeaderBand2.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Text13,
                        this.Text7,
                        this.Text8,
                        this.Text9,
                        this.HorizontalLinePrimitive2});
            // 
            // Add to Data.Components
            // 
            this.Data.Components.Clear();
            this.Data.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.DataObjects_Symbol,
                        this.DataObjects_Account,
                        this.Text1,
                        this.Text3});
            // 
            // Add to Page1.Components
            // 
            this.Page1.Components.Clear();
            this.Page1.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.PageFooterBand2,
                        this.Text12,
                        this.Text15,
                        this.Text11,
                        this.Text14,
                        this.ReportTitleBand2,
                        this.HeaderBand2,
                        this.Data});
            // 
            // Add to Pages
            // 
            this.Pages.Clear();
            this.Pages.AddRange(new Stimulsoft.Report.Components.StiPage[] {
                        this.Page1});
            this.Info.Columns.AddRange(new Stimulsoft.Report.Dictionary.StiDataColumn[] {
                        new Stimulsoft.Report.Dictionary.StiDataColumn("Id", "Id", "Id", typeof(int)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("Title", "Title", "Title", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("StartDate", "StartDate", "StartDate", typeof(int?)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("EndDate", "EndDate", "EndDate", typeof(int?)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("UserId", "UserId", "UserId", typeof(int?)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("_StartDate", "_StartDate", "_StartDate", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("_EndDate", "_EndDate", "_EndDate", typeof(string))});
            this.Dictionary.BusinessObjects.Add(this.Info);
            this.Objects.Columns.AddRange(new Stimulsoft.Report.Dictionary.StiDataColumn[] {
                        new Stimulsoft.Report.Dictionary.StiDataColumn("Id", "Id", "Id", typeof(int?)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("Symbol", "Symbol", "Symbol", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("Account", "Account", "Account", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("Num", "Num", "Num", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("Date", "Date", "Date", typeof(int?)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("ActionType", "ActionType", "ActionType", typeof(int?)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("ActionId", "ActionId", "ActionId", typeof(int?)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("_Date", "_Date", "_Date", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("_Num", "_Num", "_Num", typeof(string))});
            this.Dictionary.BusinessObjects.Add(this.Objects);
        }
        
        #region BusinessObject Info
        public class InfoBusinessObject : Stimulsoft.Report.Dictionary.StiBusinessObject
        {
            
            public InfoBusinessObject() : 
                    base("", "Info", "Info", "82b9ab83ffd64199ade1819baa747099")
            {
            }
            
            public virtual int Id
            {
                get
                {
                    return ((int)(StiReport.ChangeType(this["Id"], typeof(int), true)));
                }
            }
            
            public virtual string Title
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["Title"], typeof(string), true)));
                }
            }
            
            public virtual int? StartDate
            {
                get
                {
                    return ((int?)(StiReport.ChangeType(this["StartDate"], typeof(int?), true)));
                }
            }
            
            public virtual int? EndDate
            {
                get
                {
                    return ((int?)(StiReport.ChangeType(this["EndDate"], typeof(int?), true)));
                }
            }
            
            public virtual int? UserId
            {
                get
                {
                    return ((int?)(StiReport.ChangeType(this["UserId"], typeof(int?), true)));
                }
            }
            
            public virtual string _StartDate
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["_StartDate"], typeof(string), true)));
                }
            }
            
            public virtual string _EndDate
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["_EndDate"], typeof(string), true)));
                }
            }
        }
        #endregion BusinessObject Info
        
        #region BusinessObject Objects
        public class ObjectsBusinessObject : Stimulsoft.Report.Dictionary.StiBusinessObject
        {
            
            public ObjectsBusinessObject() : 
                    base("", "Objects", "Objects", "0e798cde640646e09f2515086abda96b")
            {
            }
            
            public virtual int? Id
            {
                get
                {
                    return ((int?)(StiReport.ChangeType(this["Id"], typeof(int?), true)));
                }
            }
            
            public virtual string Symbol
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["Symbol"], typeof(string), true)));
                }
            }
            
            public virtual string Account
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["Account"], typeof(string), true)));
                }
            }
            
            public virtual string Num
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["Num"], typeof(string), true)));
                }
            }
            
            public virtual int? Date
            {
                get
                {
                    return ((int?)(StiReport.ChangeType(this["Date"], typeof(int?), true)));
                }
            }
            
            public virtual int? ActionType
            {
                get
                {
                    return ((int?)(StiReport.ChangeType(this["ActionType"], typeof(int?), true)));
                }
            }
            
            public virtual int? ActionId
            {
                get
                {
                    return ((int?)(StiReport.ChangeType(this["ActionId"], typeof(int?), true)));
                }
            }
            
            public virtual string _Date
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["_Date"], typeof(string), true)));
                }
            }
            
            public virtual string _Num
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["_Num"], typeof(string), true)));
                }
            }
        }
        #endregion BusinessObject Objects
        #endregion StiReport Designer generated code - do not modify
    }
	
	
}