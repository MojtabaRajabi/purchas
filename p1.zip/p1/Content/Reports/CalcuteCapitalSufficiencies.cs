﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Data;
using Stimulsoft.Controls;
using Stimulsoft.Base.Drawing;
using Stimulsoft.Report;
using Stimulsoft.Report.Dialogs;
using Stimulsoft.Report.Components;

namespace Reports
{
    public class Report : Stimulsoft.Report.StiReport
    {
        public Report()        {
            this.InitializeComponent();
        }

		
		public string DateToshamsi(object date)
		{
			System.Globalization.PersianCalendar shamsi = new        System.Globalization.PersianCalendar();

			DateTime da = (DateTime)date;
			int year = shamsi.GetYear(da);
			int month = shamsi.GetMonth(da);
			int day = shamsi.GetDayOfMonth(da);
			return year.ToString()+ "/"+ month.ToString() + "/"+day.ToString()  ;

		}
		
        #region StiReport Designer generated code - do not modify
        public string _StartDate;
        public Stimulsoft.Report.Components.StiPage Page3;
        public Stimulsoft.Report.Components.StiPageFooterBand PageFooter2;
        public Stimulsoft.Report.Components.StiText Text136;
        public Stimulsoft.Report.Components.StiText Text137;
        public Stimulsoft.Report.Components.StiText Text138;
        public Stimulsoft.Report.Components.StiText Text139;
        public Stimulsoft.Report.Components.StiText Text140;
        public Stimulsoft.Report.Components.StiText Text141;
        public Stimulsoft.Report.Components.StiPanel Panel8;
        public Stimulsoft.Report.Components.StiText Text142;
        public Stimulsoft.Report.Components.StiText Text143;
        public Stimulsoft.Report.Components.StiText Text148;
        public Stimulsoft.Report.Components.StiText Text144;
        public Stimulsoft.Report.Components.StiText Text145;
        public Stimulsoft.Report.Components.StiText Text146;
        public Stimulsoft.Report.Components.StiText Text147;
        public Stimulsoft.Report.Components.StiText Text151;
        public Stimulsoft.Report.Components.StiImage Image2;
        public Stimulsoft.Report.Components.StiImage Image3;
        public Stimulsoft.Report.Components.StiImage Image4;
        public Stimulsoft.Report.Components.StiImage Image5;
        public Stimulsoft.Report.Components.StiImage Image6;
        public Stimulsoft.Report.Components.StiImage Image7;
        public Stimulsoft.Report.Components.StiImage Image8;
        public Stimulsoft.Report.Components.StiReportTitleBand ReportTitle2;
        public Stimulsoft.Report.Components.StiPanel Panel13;
        public Stimulsoft.Report.Components.StiText Text209;
        public Stimulsoft.Report.Components.StiText Text210;
        public Stimulsoft.Report.Components.StiWatermark Page3_Watermark;
        public Stimulsoft.Report.Print.StiPrinterSettings Report_PrinterSettings;
        public new InfoBusinessObject Info;
        public ObjectsBusinessObject Objects;
        
        public void Text136__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "سامانه مدیریت ریسک ";
        }
        
        public void Text137__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "#%#صفحه‌ی {PageNumber} از {TotalPageCount}";
            e.StoreToPrinted = true;
        }
        
        public System.String Text137_GetValue_End(Stimulsoft.Report.Components.StiComponent sender)
        {
            return "صفحه‌ی " + ToString(sender, PageNumber, true) + " از " + ToString(sender, TotalPageCount, true);
        }
        
        public void Text138__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "_StartDate";
        }
        
        public void Text139__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "_EndDate";
        }
        
        public void Text140__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Info._StartDate, true);
        }
        
        public void Text141__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, Info._EndDate, true);
        }
        
        public void Text142__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "بر اساس این گزارش اطلاعات زیر قابل مشاهده است:";
        }
        
        public void Text143__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "شکاف نقدینگی " + ToString(sender, Objects.LastMonthGap, true) + " ماه به میزان " + ToString(sender, Format("{0:N2}", Objects.LastNetInputOutput), true) + " ریال بر آورد شده است.";
        }
        
        public void Text148__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = this.Text148.TextFormat.Format(CheckExcelValue(sender, " منفی ترین شکاف نقدینگی مربوط به " + Objects.MinMonthGap + " ماه و به مبلغ   " + Format("{0:N2}", Objects.MinNetInputOutput) + " ریال می باشد و شکاف نقدینگی تجمعی در \r\nپایان سال به مبلغ  " + Format("{0:N2}", Objects.MinNetInputOutputAcc) + " ریال می باشد.\r\n"));
        }
        
        public void Text144__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "میزان کل منابع شرکت بر اساس اطلاعات اخذ شده تا انتهای " + ToString(sender, Objects.LastMonthGap, true) + " ماه به میزان  " + ToString(sender, Format("{0:N2}", Objects.SumTotla), true) + "  ریال می باشد که از این مبلغ  " + ToString(sender, Format("{0:N2}", Objects.TotalDeposit), true) + "  ریال مربوط به سپرده ها و" + ToString(sender, Format("{0:N2}", Objects.TotalAdditional), true) + "   ریال مربوط به صندوق های تحت مالکیت و " + ToString(sender, Format("{0:N2}", Objects.TotalBondIssuances), true) + "  ریال مربوط به انتشار اوراق از اجاره شرکت است ";
        }
        
        public void Text145__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "میزان تعهدات قراردادهای بازارگردانی فعلی شرکت 12,115,871,235,589  ریال می باشد.";
        }
        
        public void Text146__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "میزان پیش بینی تعهدات آتی بدهی و سرمایه ای تا انتهای سال به ترتیب 9,500,000,000,000 و 2,088,136,361,107\r\nریال می باشد.";
        }
        
        public void Text147__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "میزان پیش بینی تعهدات آتی سرمایه ای تا انتهای سال 218,552,327,000  ریال می باشد";
        }
        
        public void Text151__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "شرکت به میزان 480,000,000,000  ریال اوراق اجاره با نرخ 16% منتشر می نماید ";
        }
        
        public void Text209__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = "ظرفیت تعهدات آتی بر اساس کفایت";
        }
        
        public void Text210__GetValue(object sender, Stimulsoft.Report.Events.StiGetValueEventArgs e)
        {
            e.Value = ToString(sender, DateToshamsi(Today), true);
        }
        
        public void ReportWordsToEnd__EndRender(object sender, System.EventArgs e)
        {
            this.Text137.SetText(new Stimulsoft.Report.Components.StiGetValue(this.Text137_GetValue_End));
        }
        
        private void InitializeComponent()
        {
            this.Objects = new ObjectsBusinessObject();
            this.Info = new InfoBusinessObject();
            this.Dictionary.Variables.Add(new Stimulsoft.Report.Dictionary.StiVariable("", "_StartDate", "_StartDate", "", typeof(string), "", false, Stimulsoft.Report.Dictionary.StiVariableInitBy.Value, false));
            this.NeedsCompiling = false;
            // 
            // Variables init
            // 
            this._StartDate = "";
            this.EngineVersion = Stimulsoft.Report.Engine.StiEngineVersion.EngineV2;
            this.ReferencedAssemblies = new System.String[] {
                    "System.Dll",
                    "System.Drawing.Dll",
                    "System.Windows.Forms.Dll",
                    "System.Data.Dll",
                    "System.Xml.Dll",
                    "Stimulsoft.Controls.Dll",
                    "Stimulsoft.Base.Dll",
                    "Stimulsoft.Report.Dll"};
            this.ReportAlias = "Report";
            // 
            // ReportChanged
            // 
            this.ReportChanged = new DateTime(2019, 4, 14, 15, 53, 30, 389);
            // 
            // ReportCreated
            // 
            this.ReportCreated = new DateTime(2018, 7, 1, 16, 48, 34, 0);
            this.ReportFile = "C:\\x_ErmN\\erm\\Sanay.Lotus.Erm\\Content\\Reports\\CalcuteCapitalSufficiencies.mrt";
            this.ReportGuid = "deba64b5d4b5485cbe7a83e9c75b707e";
            this.ReportName = "Report";
            this.ReportUnit = Stimulsoft.Report.StiReportUnitType.Inches;
            this.ReportVersion = "2013.1.1600";
            this.ScriptLanguage = Stimulsoft.Report.StiReportLanguageType.CSharp;
            // 
            // Page3
            // 
            this.Page3 = new Stimulsoft.Report.Components.StiPage();
            this.Page3.Guid = "2a1f779d9fd14295af1f5a4a8d1c0fb1";
            this.Page3.Name = "Page3";
            this.Page3.PageHeight = 11;
            this.Page3.PageWidth = 8.5;
            this.Page3.PaperSize = System.Drawing.Printing.PaperKind.Letter;
            this.Page3.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 2, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Page3.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // PageFooter2
            // 
            this.PageFooter2 = new Stimulsoft.Report.Components.StiPageFooterBand();
            this.PageFooter2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 9.82, 7.72, 0.4);
            this.PageFooter2.Guid = "2867e5c9106848e088e36a1eb3b2514c";
            this.PageFooter2.Name = "PageFooter2";
            this.PageFooter2.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.PageFooter2.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // Text136
            // 
            this.Text136 = new Stimulsoft.Report.Components.StiText();
            this.Text136.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.8, 0.1, 2.9, 0.3);
            this.Text136.ComponentStyle = "Collection_Page_Footer";
            this.Text136.Guid = "27c34b1e09054d0e9db65b3855920c02";
            this.Text136.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text136.Name = "Text136";
            this.Text136.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text136__GetValue);
            this.Text136.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text136.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text136.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text136.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text136.Font = new System.Drawing.Font("B Nazanin", 11F, System.Drawing.FontStyle.Bold);
            this.Text136.Indicator = null;
            this.Text136.Interaction = null;
            this.Text136.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text136.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 112, 48, 160));
            this.Text136.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text137
            // 
            this.Text137 = new Stimulsoft.Report.Components.StiText();
            this.Text137.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.2, 3.4, 0.3);
            this.Text137.ComponentStyle = "Collection_Page_Footer";
            this.Text137.Guid = "0ecffabb17b44ae2b0cccfed23445df6";
            this.Text137.Name = "Text137";
            this.Text137.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text137__GetValue);
            this.Text137.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text137.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text137.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text137.Font = new System.Drawing.Font("B Nazanin", 10F, System.Drawing.FontStyle.Bold);
            this.Text137.Indicator = null;
            this.Text137.Interaction = null;
            this.Text137.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text137.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text137.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            this.PageFooter2.Interaction = null;
            // 
            // Text138
            // 
            this.Text138 = new Stimulsoft.Report.Components.StiText();
            this.Text138.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(8.6, 3.5, 1, 0.3);
            this.Text138.Guid = "aa7bb6a49b8a447ea50d3085dfd1dd64";
            this.Text138.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text138.Name = "Text138";
            this.Text138.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text138__GetValue);
            this.Text138.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text138.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.All, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text138.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 181, 204, 136));
            this.Text138.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text138.Indicator = null;
            this.Text138.Interaction = null;
            this.Text138.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text138.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text138.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text139
            // 
            this.Text139 = new Stimulsoft.Report.Components.StiText();
            this.Text139.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(9.6, 3.5, 1, 0.3);
            this.Text139.Guid = "c8e69664fbe64468b1fdf452bb50dbdd";
            this.Text139.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text139.Name = "Text139";
            this.Text139.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text139__GetValue);
            this.Text139.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text139.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.All, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Dash, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), true);
            this.Text139.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 181, 204, 136));
            this.Text139.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text139.Indicator = null;
            this.Text139.Interaction = null;
            this.Text139.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text139.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 4, 0));
            this.Text139.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text140
            // 
            this.Text140 = new Stimulsoft.Report.Components.StiText();
            this.Text140.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(8.6, 4.2, 1, 0.3);
            this.Text140.Guid = "e2d18b9c27cc42679a010e31081de702";
            this.Text140.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text140.Name = "Text140";
            this.Text140.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text140__GetValue);
            this.Text140.Type = Stimulsoft.Report.Components.StiSystemTextType.DataColumn;
            this.Text140.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text140.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text140.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text140.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text140.Indicator = null;
            this.Text140.Interaction = null;
            this.Text140.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text140.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text140.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text141
            // 
            this.Text141 = new Stimulsoft.Report.Components.StiText();
            this.Text141.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(9.6, 4.2, 1, 0.3);
            this.Text141.Guid = "4acb3b2aad69434fbc3ee6ebf69bdace";
            this.Text141.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text141.Name = "Text141";
            this.Text141.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text141__GetValue);
            this.Text141.Type = Stimulsoft.Report.Components.StiSystemTextType.DataColumn;
            this.Text141.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text141.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text141.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text141.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text141.Indicator = null;
            this.Text141.Interaction = null;
            this.Text141.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text141.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text141.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Panel8
            // 
            this.Panel8 = new Stimulsoft.Report.Components.StiPanel();
            this.Panel8.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 1.1, 7.7, 6);
            this.Panel8.Name = "Panel8";
            this.Panel8.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Panel8.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // Text142
            // 
            this.Text142 = new Stimulsoft.Report.Components.StiText();
            this.Text142.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(4.2, 0.2, 3.4, 0.2);
            this.Text142.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text142.Name = "Text142";
            this.Text142.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text142__GetValue);
            this.Text142.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text142.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text142.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text142.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text142.Font = new System.Drawing.Font("B Nazanin", 14F, System.Drawing.FontStyle.Bold);
            this.Text142.Guid = null;
            this.Text142.Indicator = null;
            this.Text142.Interaction = null;
            this.Text142.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text142.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text142.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text143
            // 
            this.Text143 = new Stimulsoft.Report.Components.StiText();
            this.Text143.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 1.3, 7.5, 0.4);
            this.Text143.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text143.Name = "Text143";
            this.Text143.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text143__GetValue);
            this.Text143.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text143.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text143.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text143.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text143.Font = new System.Drawing.Font("B Nazanin", 14F);
            this.Text143.Guid = null;
            this.Text143.Indicator = null;
            this.Text143.Interaction = null;
            this.Text143.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text143.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text143.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text148
            // 
            this.Text148 = new Stimulsoft.Report.Components.StiText();
            this.Text148.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.6, 7.5, 0.8);
            this.Text148.Guid = "2ff51e4b4ff94e0a91927ebfe56e5811";
            this.Text148.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text148.Name = "Text148";
            this.Text148.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text148__GetValue);
            this.Text148.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text148.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text148.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text148.Font = new System.Drawing.Font("B Nazanin", 14F);
            this.Text148.Indicator = null;
            this.Text148.Interaction = null;
            this.Text148.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text148.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text148.TextFormat = new Stimulsoft.Report.Components.TextFormats.StiNumberFormatService(1, "/", 2, ",", 3, true, false, " ");
            this.Text148.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text144
            // 
            this.Text144 = new Stimulsoft.Report.Components.StiText();
            this.Text144.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 1.7, 7.5, 1.2);
            this.Text144.Guid = "6c9fca4a6e3145c7a173de40cbdc1f95";
            this.Text144.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text144.Name = "Text144";
            this.Text144.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text144__GetValue);
            this.Text144.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text144.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text144.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text144.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text144.Font = new System.Drawing.Font("B Nazanin", 14F);
            this.Text144.Indicator = null;
            this.Text144.Interaction = null;
            this.Text144.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text144.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text144.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, true, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text145
            // 
            this.Text145 = new Stimulsoft.Report.Components.StiText();
            this.Text145.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.2, 3, 5.3, 0.3);
            this.Text145.Guid = "8895e12e646d4dbbb516f21e406baf10";
            this.Text145.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text145.Name = "Text145";
            this.Text145.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text145__GetValue);
            this.Text145.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text145.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text145.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text145.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text145.Font = new System.Drawing.Font("B Nazanin", 14F);
            this.Text145.Indicator = null;
            this.Text145.Interaction = null;
            this.Text145.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text145.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text145.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text146
            // 
            this.Text146 = new Stimulsoft.Report.Components.StiText();
            this.Text146.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 3.4, 7.5, 0.5);
            this.Text146.Guid = "fa23363f427b4c0fa5d2562bd6a1cc73";
            this.Text146.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text146.Name = "Text146";
            this.Text146.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text146__GetValue);
            this.Text146.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text146.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text146.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text146.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text146.Font = new System.Drawing.Font("B Nazanin", 14F);
            this.Text146.Indicator = null;
            this.Text146.Interaction = null;
            this.Text146.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text146.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text146.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text147
            // 
            this.Text147 = new Stimulsoft.Report.Components.StiText();
            this.Text147.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.2, 3.8, 5.3, 0.3);
            this.Text147.Guid = "618f927c369b41f49ced9d86def1d037";
            this.Text147.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text147.Name = "Text147";
            this.Text147.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text147__GetValue);
            this.Text147.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text147.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text147.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text147.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text147.Font = new System.Drawing.Font("B Nazanin", 14F);
            this.Text147.Indicator = null;
            this.Text147.Interaction = null;
            this.Text147.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text147.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text147.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text151
            // 
            this.Text151 = new Stimulsoft.Report.Components.StiText();
            this.Text151.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.2, 4.4, 5.3, 0.3);
            this.Text151.Guid = "282d9c5973994fc6af78afc67823ed52";
            this.Text151.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Right;
            this.Text151.Name = "Text151";
            this.Text151.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text151__GetValue);
            this.Text151.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text151.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text151.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text151.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text151.Font = new System.Drawing.Font("B Nazanin", 14F);
            this.Text151.Indicator = null;
            this.Text151.Interaction = null;
            this.Text151.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text151.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text151.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Image2
            // 
            this.Image2 = new Stimulsoft.Report.Components.StiImage();
            this.Image2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(7.5, 0.6, 0.2, 0.3);
            this.Image2.Guid = "e7c67f014dcd49409ce24887dc2ab692";
            this.Image2.HorAlignment = Stimulsoft.Base.Drawing.StiHorAlignment.Right;
            this.Image2.Image = StiImageConverter.StringToImage("iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAABGdBTUEAALGPC/xhBQAAAHVQTFRF////AAAA09PTxcXFoKCgaGholJSUo6Oj2NjYr6+vzs7O5OTkfn5++vr6b29vqampKioq3t7e9PT0v7+/6urqU1NTmZmZt7e3Xl5egoKCOjo6dXV1QkJC7u7u9vb2CgoKV1dXGxsbSkpKFRUVMDAwioqKRkZGVfFAEAAAA6hJREFUeF7t3OlS4kAUBWAGAwJiQAFRFsUF3/8Rp5g5KUZlSUjfc2+mzvdX6dNdgSS9tkRERERERERERERERERERERERERERESqu2/Pu8vN4v3XzsvHLO/2B2v8rfl6WedPw37aPAzwP8313D/WusJm1ORrOZ+hGaetRrf4QLPcDNGAMvIePtUc7XKXb29xhU82Q+8T9a5i3Jw2Tjeoc1WrO5QQ3Bb1vcQSZUTWfkFlLzRBOWE9oaKX66CkmKZjVLOWwE+OCapY1wjlhdNFBevLUWIw595Aq/hEmaG8oXJpjOO9qi5QtVTen1FwFKkbGK6Jl7yHnvOKskN4RKXSWqD0AOq/yBz2iPLd9VGh9LpIcHaH6liI0WVEZWzcI8RTyleZnwLcbVK9bR/zgBw3t6iInSmSvNh+R3dWSHLSRjUszZHlI0mf/hxkuZijDrY8n/uogjW/vqLd69pXW+Tx1RwaLc/rIlo/7PcyJLKtkE+ARLIbpDP49DHqzMBU5dMXRjiHx71mgGyOPlKZqkzT1zdDKhOiWfhfU8vRmUP4d9NrJLM8IZfHZhD4uDFyeRDMw/4hTpHLw17kx3vrLlwjmeUBuTzspTY5cnnYY27EnlMBySxIZSLfTJHKxB38vkcqE3epFLN/X+C+mfaQysRdtciYr/iOO3+hFlpQC9Ni9/B3uPdSfueJ3X3yeOKTtyoglYm8A4w2sbaHZJa0K4JLQTILd8R7hz3qzR4u5Q+YcudldthzM/zHBX0nDf1milyeJYJZ+HtMWGtpCvyFU" +
"Wsks7SRS0RZtLeHVKZ0O9XK8NjNxu0iuiyoeUU4BTK5MoQzDJHJxXytcdqob7+KveC164I38O22SZ82iYg8PlYXymNRG5AuItI8cIa+XbeUMFZGfSDLB6OH4XxMhv26Gvcja8w7UcjxYz2j77NK/wvb72mIY5UsB/hjnKtguVHWe4ss2PX2A/wI/7JabOq+j3vPprvv07E/wmIPVLBjzdLPJ4Y52KSQ+gSXcA1MPUIc8gDFlHM1QQ6m+S7doIZrn/eUdaKORuRjTFPMmwa8x/zrCtW8nOPAWjm39UbC3yIcm3TOoMakVPgTaGGE+lYV9Blx0CWP/6doZ0GeUbW70W1Y+3Ym5Y9lX4R9xJ+xzj7QhFNeuzf4/0aajk4P/M+yRjcPeqPloWs5zq8dlgHZmQ7m2XaYdzqdfLjN5oP/4dKJiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIFW6zfFADwrMxMCHQAAAABJRU5ErkJggg==");
            this.Image2.Name = "Image2";
            this.Image2.Stretch = true;
            this.Image2.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Image2.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Image2.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Image2.Interaction = null;
            // 
            // Image3
            // 
            this.Image3 = new Stimulsoft.Report.Components.StiImage();
            this.Image3.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(7.5, 1.4, 0.2, 0.3);
            this.Image3.Guid = "5fc7a385474647f4b87797410e1ebe90";
            this.Image3.HorAlignment = Stimulsoft.Base.Drawing.StiHorAlignment.Right;
            this.Image3.Image = StiImageConverter.StringToImage("iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAABGdBTUEAALGPC/xhBQAAAHVQTFRF////AAAA09PTxcXFoKCgaGholJSUo6Oj2NjYr6+vzs7O5OTkfn5++vr6b29vqampKioq3t7e9PT0v7+/6urqU1NTmZmZt7e3Xl5egoKCOjo6dXV1QkJC7u7u9vb2CgoKV1dXGxsbSkpKFRUVMDAwioqKRkZGVfFAEAAAA6hJREFUeF7t3OlS4kAUBWAGAwJiQAFRFsUF3/8Rp5g5KUZlSUjfc2+mzvdX6dNdgSS9tkRERERERERERERERERERERERERERESqu2/Pu8vN4v3XzsvHLO/2B2v8rfl6WedPw37aPAzwP8313D/WusJm1ORrOZ+hGaetRrf4QLPcDNGAMvIePtUc7XKXb29xhU82Q+8T9a5i3Jw2Tjeoc1WrO5QQ3Bb1vcQSZUTWfkFlLzRBOWE9oaKX66CkmKZjVLOWwE+OCapY1wjlhdNFBevLUWIw595Aq/hEmaG8oXJpjOO9qi5QtVTen1FwFKkbGK6Jl7yHnvOKskN4RKXSWqD0AOq/yBz2iPLd9VGh9LpIcHaH6liI0WVEZWzcI8RTyleZnwLcbVK9bR/zgBw3t6iInSmSvNh+R3dWSHLSRjUszZHlI0mf/hxkuZijDrY8n/uogjW/vqLd69pXW+Tx1RwaLc/rIlo/7PcyJLKtkE+ARLIbpDP49DHqzMBU5dMXRjiHx71mgGyOPlKZqkzT1zdDKhOiWfhfU8vRmUP4d9NrJLM8IZfHZhD4uDFyeRDMw/4hTpHLw17kx3vrLlwjmeUBuTzspTY5cnnYY27EnlMBySxIZSLfTJHKxB38vkcqE3epFLN/X+C+mfaQysRdtciYr/iOO3+hFlpQC9Ni9/B3uPdSfueJ3X3yeOKTtyoglYm8A4w2sbaHZJa0K4JLQTILd8R7hz3qzR4u5Q+YcudldthzM/zHBX0nDf1milyeJYJZ+HtMWGtpCvyFU" +
"Wsks7SRS0RZtLeHVKZ0O9XK8NjNxu0iuiyoeUU4BTK5MoQzDJHJxXytcdqob7+KveC164I38O22SZ82iYg8PlYXymNRG5AuItI8cIa+XbeUMFZGfSDLB6OH4XxMhv26Gvcja8w7UcjxYz2j77NK/wvb72mIY5UsB/hjnKtguVHWe4ss2PX2A/wI/7JabOq+j3vPprvv07E/wmIPVLBjzdLPJ4Y52KSQ+gSXcA1MPUIc8gDFlHM1QQ6m+S7doIZrn/eUdaKORuRjTFPMmwa8x/zrCtW8nOPAWjm39UbC3yIcm3TOoMakVPgTaGGE+lYV9Blx0CWP/6doZ0GeUbW70W1Y+3Ym5Y9lX4R9xJ+xzj7QhFNeuzf4/0aajk4P/M+yRjcPeqPloWs5zq8dlgHZmQ7m2XaYdzqdfLjN5oP/4dKJiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIFW6zfFADwrMxMCHQAAAABJRU5ErkJggg==");
            this.Image3.Name = "Image3";
            this.Image3.Stretch = true;
            this.Image3.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Image3.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Image3.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Image3.Interaction = null;
            // 
            // Image4
            // 
            this.Image4 = new Stimulsoft.Report.Components.StiImage();
            this.Image4.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(7.5, 1.7, 0.2, 0.3);
            this.Image4.Guid = "779ff8ad6f5543569e8064ad088bf3c3";
            this.Image4.HorAlignment = Stimulsoft.Base.Drawing.StiHorAlignment.Right;
            this.Image4.Image = StiImageConverter.StringToImage("iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAABGdBTUEAALGPC/xhBQAAAHVQTFRF////AAAA09PTxcXFoKCgaGholJSUo6Oj2NjYr6+vzs7O5OTkfn5++vr6b29vqampKioq3t7e9PT0v7+/6urqU1NTmZmZt7e3Xl5egoKCOjo6dXV1QkJC7u7u9vb2CgoKV1dXGxsbSkpKFRUVMDAwioqKRkZGVfFAEAAAA6hJREFUeF7t3OlS4kAUBWAGAwJiQAFRFsUF3/8Rp5g5KUZlSUjfc2+mzvdX6dNdgSS9tkRERERERERERERERERERERERERERESqu2/Pu8vN4v3XzsvHLO/2B2v8rfl6WedPw37aPAzwP8313D/WusJm1ORrOZ+hGaetRrf4QLPcDNGAMvIePtUc7XKXb29xhU82Q+8T9a5i3Jw2Tjeoc1WrO5QQ3Bb1vcQSZUTWfkFlLzRBOWE9oaKX66CkmKZjVLOWwE+OCapY1wjlhdNFBevLUWIw595Aq/hEmaG8oXJpjOO9qi5QtVTen1FwFKkbGK6Jl7yHnvOKskN4RKXSWqD0AOq/yBz2iPLd9VGh9LpIcHaH6liI0WVEZWzcI8RTyleZnwLcbVK9bR/zgBw3t6iInSmSvNh+R3dWSHLSRjUszZHlI0mf/hxkuZijDrY8n/uogjW/vqLd69pXW+Tx1RwaLc/rIlo/7PcyJLKtkE+ARLIbpDP49DHqzMBU5dMXRjiHx71mgGyOPlKZqkzT1zdDKhOiWfhfU8vRmUP4d9NrJLM8IZfHZhD4uDFyeRDMw/4hTpHLw17kx3vrLlwjmeUBuTzspTY5cnnYY27EnlMBySxIZSLfTJHKxB38vkcqE3epFLN/X+C+mfaQysRdtciYr/iOO3+hFlpQC9Ni9/B3uPdSfueJ3X3yeOKTtyoglYm8A4w2sbaHZJa0K4JLQTILd8R7hz3qzR4u5Q+YcudldthzM/zHBX0nDf1milyeJYJZ+HtMWGtpCvyFU" +
"Wsks7SRS0RZtLeHVKZ0O9XK8NjNxu0iuiyoeUU4BTK5MoQzDJHJxXytcdqob7+KveC164I38O22SZ82iYg8PlYXymNRG5AuItI8cIa+XbeUMFZGfSDLB6OH4XxMhv26Gvcja8w7UcjxYz2j77NK/wvb72mIY5UsB/hjnKtguVHWe4ss2PX2A/wI/7JabOq+j3vPprvv07E/wmIPVLBjzdLPJ4Y52KSQ+gSXcA1MPUIc8gDFlHM1QQ6m+S7doIZrn/eUdaKORuRjTFPMmwa8x/zrCtW8nOPAWjm39UbC3yIcm3TOoMakVPgTaGGE+lYV9Blx0CWP/6doZ0GeUbW70W1Y+3Ym5Y9lX4R9xJ+xzj7QhFNeuzf4/0aajk4P/M+yRjcPeqPloWs5zq8dlgHZmQ7m2XaYdzqdfLjN5oP/4dKJiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIFW6zfFADwrMxMCHQAAAABJRU5ErkJggg==");
            this.Image4.Name = "Image4";
            this.Image4.Stretch = true;
            this.Image4.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Image4.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Image4.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Image4.Interaction = null;
            // 
            // Image5
            // 
            this.Image5 = new Stimulsoft.Report.Components.StiImage();
            this.Image5.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(7.5, 3, 0.2, 0.3);
            this.Image5.Guid = "43ca223731744068ae443f124f978331";
            this.Image5.HorAlignment = Stimulsoft.Base.Drawing.StiHorAlignment.Right;
            this.Image5.Image = StiImageConverter.StringToImage("iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAABGdBTUEAALGPC/xhBQAAAHVQTFRF////AAAA09PTxcXFoKCgaGholJSUo6Oj2NjYr6+vzs7O5OTkfn5++vr6b29vqampKioq3t7e9PT0v7+/6urqU1NTmZmZt7e3Xl5egoKCOjo6dXV1QkJC7u7u9vb2CgoKV1dXGxsbSkpKFRUVMDAwioqKRkZGVfFAEAAAA6hJREFUeF7t3OlS4kAUBWAGAwJiQAFRFsUF3/8Rp5g5KUZlSUjfc2+mzvdX6dNdgSS9tkRERERERERERERERERERERERERERESqu2/Pu8vN4v3XzsvHLO/2B2v8rfl6WedPw37aPAzwP8313D/WusJm1ORrOZ+hGaetRrf4QLPcDNGAMvIePtUc7XKXb29xhU82Q+8T9a5i3Jw2Tjeoc1WrO5QQ3Bb1vcQSZUTWfkFlLzRBOWE9oaKX66CkmKZjVLOWwE+OCapY1wjlhdNFBevLUWIw595Aq/hEmaG8oXJpjOO9qi5QtVTen1FwFKkbGK6Jl7yHnvOKskN4RKXSWqD0AOq/yBz2iPLd9VGh9LpIcHaH6liI0WVEZWzcI8RTyleZnwLcbVK9bR/zgBw3t6iInSmSvNh+R3dWSHLSRjUszZHlI0mf/hxkuZijDrY8n/uogjW/vqLd69pXW+Tx1RwaLc/rIlo/7PcyJLKtkE+ARLIbpDP49DHqzMBU5dMXRjiHx71mgGyOPlKZqkzT1zdDKhOiWfhfU8vRmUP4d9NrJLM8IZfHZhD4uDFyeRDMw/4hTpHLw17kx3vrLlwjmeUBuTzspTY5cnnYY27EnlMBySxIZSLfTJHKxB38vkcqE3epFLN/X+C+mfaQysRdtciYr/iOO3+hFlpQC9Ni9/B3uPdSfueJ3X3yeOKTtyoglYm8A4w2sbaHZJa0K4JLQTILd8R7hz3qzR4u5Q+YcudldthzM/zHBX0nDf1milyeJYJZ+HtMWGtpCvyFU" +
"Wsks7SRS0RZtLeHVKZ0O9XK8NjNxu0iuiyoeUU4BTK5MoQzDJHJxXytcdqob7+KveC164I38O22SZ82iYg8PlYXymNRG5AuItI8cIa+XbeUMFZGfSDLB6OH4XxMhv26Gvcja8w7UcjxYz2j77NK/wvb72mIY5UsB/hjnKtguVHWe4ss2PX2A/wI/7JabOq+j3vPprvv07E/wmIPVLBjzdLPJ4Y52KSQ+gSXcA1MPUIc8gDFlHM1QQ6m+S7doIZrn/eUdaKORuRjTFPMmwa8x/zrCtW8nOPAWjm39UbC3yIcm3TOoMakVPgTaGGE+lYV9Blx0CWP/6doZ0GeUbW70W1Y+3Ym5Y9lX4R9xJ+xzj7QhFNeuzf4/0aajk4P/M+yRjcPeqPloWs5zq8dlgHZmQ7m2XaYdzqdfLjN5oP/4dKJiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIFW6zfFADwrMxMCHQAAAABJRU5ErkJggg==");
            this.Image5.Name = "Image5";
            this.Image5.Stretch = true;
            this.Image5.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Image5.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Image5.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Image5.Interaction = null;
            // 
            // Image6
            // 
            this.Image6 = new Stimulsoft.Report.Components.StiImage();
            this.Image6.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(7.5, 3.4, 0.2, 0.3);
            this.Image6.Guid = "ea785fdab5cb4ac7a39a7f33d8d6bb74";
            this.Image6.HorAlignment = Stimulsoft.Base.Drawing.StiHorAlignment.Right;
            this.Image6.Image = StiImageConverter.StringToImage("iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAABGdBTUEAALGPC/xhBQAAAHVQTFRF////AAAA09PTxcXFoKCgaGholJSUo6Oj2NjYr6+vzs7O5OTkfn5++vr6b29vqampKioq3t7e9PT0v7+/6urqU1NTmZmZt7e3Xl5egoKCOjo6dXV1QkJC7u7u9vb2CgoKV1dXGxsbSkpKFRUVMDAwioqKRkZGVfFAEAAAA6hJREFUeF7t3OlS4kAUBWAGAwJiQAFRFsUF3/8Rp5g5KUZlSUjfc2+mzvdX6dNdgSS9tkRERERERERERERERERERERERERERESqu2/Pu8vN4v3XzsvHLO/2B2v8rfl6WedPw37aPAzwP8313D/WusJm1ORrOZ+hGaetRrf4QLPcDNGAMvIePtUc7XKXb29xhU82Q+8T9a5i3Jw2Tjeoc1WrO5QQ3Bb1vcQSZUTWfkFlLzRBOWE9oaKX66CkmKZjVLOWwE+OCapY1wjlhdNFBevLUWIw595Aq/hEmaG8oXJpjOO9qi5QtVTen1FwFKkbGK6Jl7yHnvOKskN4RKXSWqD0AOq/yBz2iPLd9VGh9LpIcHaH6liI0WVEZWzcI8RTyleZnwLcbVK9bR/zgBw3t6iInSmSvNh+R3dWSHLSRjUszZHlI0mf/hxkuZijDrY8n/uogjW/vqLd69pXW+Tx1RwaLc/rIlo/7PcyJLKtkE+ARLIbpDP49DHqzMBU5dMXRjiHx71mgGyOPlKZqkzT1zdDKhOiWfhfU8vRmUP4d9NrJLM8IZfHZhD4uDFyeRDMw/4hTpHLw17kx3vrLlwjmeUBuTzspTY5cnnYY27EnlMBySxIZSLfTJHKxB38vkcqE3epFLN/X+C+mfaQysRdtciYr/iOO3+hFlpQC9Ni9/B3uPdSfueJ3X3yeOKTtyoglYm8A4w2sbaHZJa0K4JLQTILd8R7hz3qzR4u5Q+YcudldthzM/zHBX0nDf1milyeJYJZ+HtMWGtpCvyFU" +
"Wsks7SRS0RZtLeHVKZ0O9XK8NjNxu0iuiyoeUU4BTK5MoQzDJHJxXytcdqob7+KveC164I38O22SZ82iYg8PlYXymNRG5AuItI8cIa+XbeUMFZGfSDLB6OH4XxMhv26Gvcja8w7UcjxYz2j77NK/wvb72mIY5UsB/hjnKtguVHWe4ss2PX2A/wI/7JabOq+j3vPprvv07E/wmIPVLBjzdLPJ4Y52KSQ+gSXcA1MPUIc8gDFlHM1QQ6m+S7doIZrn/eUdaKORuRjTFPMmwa8x/zrCtW8nOPAWjm39UbC3yIcm3TOoMakVPgTaGGE+lYV9Blx0CWP/6doZ0GeUbW70W1Y+3Ym5Y9lX4R9xJ+xzj7QhFNeuzf4/0aajk4P/M+yRjcPeqPloWs5zq8dlgHZmQ7m2XaYdzqdfLjN5oP/4dKJiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIFW6zfFADwrMxMCHQAAAABJRU5ErkJggg==");
            this.Image6.Name = "Image6";
            this.Image6.Stretch = true;
            this.Image6.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Image6.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Image6.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Image6.Interaction = null;
            // 
            // Image7
            // 
            this.Image7 = new Stimulsoft.Report.Components.StiImage();
            this.Image7.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(7.5, 4, 0.2, 0.3);
            this.Image7.Guid = "7e995af2e71944c4b204c5bab31c0dd2";
            this.Image7.HorAlignment = Stimulsoft.Base.Drawing.StiHorAlignment.Right;
            this.Image7.Image = StiImageConverter.StringToImage("iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAABGdBTUEAALGPC/xhBQAAAHVQTFRF////AAAA09PTxcXFoKCgaGholJSUo6Oj2NjYr6+vzs7O5OTkfn5++vr6b29vqampKioq3t7e9PT0v7+/6urqU1NTmZmZt7e3Xl5egoKCOjo6dXV1QkJC7u7u9vb2CgoKV1dXGxsbSkpKFRUVMDAwioqKRkZGVfFAEAAAA6hJREFUeF7t3OlS4kAUBWAGAwJiQAFRFsUF3/8Rp5g5KUZlSUjfc2+mzvdX6dNdgSS9tkRERERERERERERERERERERERERERESqu2/Pu8vN4v3XzsvHLO/2B2v8rfl6WedPw37aPAzwP8313D/WusJm1ORrOZ+hGaetRrf4QLPcDNGAMvIePtUc7XKXb29xhU82Q+8T9a5i3Jw2Tjeoc1WrO5QQ3Bb1vcQSZUTWfkFlLzRBOWE9oaKX66CkmKZjVLOWwE+OCapY1wjlhdNFBevLUWIw595Aq/hEmaG8oXJpjOO9qi5QtVTen1FwFKkbGK6Jl7yHnvOKskN4RKXSWqD0AOq/yBz2iPLd9VGh9LpIcHaH6liI0WVEZWzcI8RTyleZnwLcbVK9bR/zgBw3t6iInSmSvNh+R3dWSHLSRjUszZHlI0mf/hxkuZijDrY8n/uogjW/vqLd69pXW+Tx1RwaLc/rIlo/7PcyJLKtkE+ARLIbpDP49DHqzMBU5dMXRjiHx71mgGyOPlKZqkzT1zdDKhOiWfhfU8vRmUP4d9NrJLM8IZfHZhD4uDFyeRDMw/4hTpHLw17kx3vrLlwjmeUBuTzspTY5cnnYY27EnlMBySxIZSLfTJHKxB38vkcqE3epFLN/X+C+mfaQysRdtciYr/iOO3+hFlpQC9Ni9/B3uPdSfueJ3X3yeOKTtyoglYm8A4w2sbaHZJa0K4JLQTILd8R7hz3qzR4u5Q+YcudldthzM/zHBX0nDf1milyeJYJZ+HtMWGtpCvyFU" +
"Wsks7SRS0RZtLeHVKZ0O9XK8NjNxu0iuiyoeUU4BTK5MoQzDJHJxXytcdqob7+KveC164I38O22SZ82iYg8PlYXymNRG5AuItI8cIa+XbeUMFZGfSDLB6OH4XxMhv26Gvcja8w7UcjxYz2j77NK/wvb72mIY5UsB/hjnKtguVHWe4ss2PX2A/wI/7JabOq+j3vPprvv07E/wmIPVLBjzdLPJ4Y52KSQ+gSXcA1MPUIc8gDFlHM1QQ6m+S7doIZrn/eUdaKORuRjTFPMmwa8x/zrCtW8nOPAWjm39UbC3yIcm3TOoMakVPgTaGGE+lYV9Blx0CWP/6doZ0GeUbW70W1Y+3Ym5Y9lX4R9xJ+xzj7QhFNeuzf4/0aajk4P/M+yRjcPeqPloWs5zq8dlgHZmQ7m2XaYdzqdfLjN5oP/4dKJiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIFW6zfFADwrMxMCHQAAAABJRU5ErkJggg==");
            this.Image7.Name = "Image7";
            this.Image7.Stretch = true;
            this.Image7.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Image7.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Image7.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Image7.Interaction = null;
            // 
            // Image8
            // 
            this.Image8 = new Stimulsoft.Report.Components.StiImage();
            this.Image8.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(7.5, 4.4, 0.2, 0.3);
            this.Image8.Guid = "84e47bc34712446985dfa6838836f0c4";
            this.Image8.HorAlignment = Stimulsoft.Base.Drawing.StiHorAlignment.Right;
            this.Image8.Image = StiImageConverter.StringToImage("iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAABGdBTUEAALGPC/xhBQAAAHVQTFRF////AAAA09PTxcXFoKCgaGholJSUo6Oj2NjYr6+vzs7O5OTkfn5++vr6b29vqampKioq3t7e9PT0v7+/6urqU1NTmZmZt7e3Xl5egoKCOjo6dXV1QkJC7u7u9vb2CgoKV1dXGxsbSkpKFRUVMDAwioqKRkZGVfFAEAAAA6hJREFUeF7t3OlS4kAUBWAGAwJiQAFRFsUF3/8Rp5g5KUZlSUjfc2+mzvdX6dNdgSS9tkRERERERERERERERERERERERERERESqu2/Pu8vN4v3XzsvHLO/2B2v8rfl6WedPw37aPAzwP8313D/WusJm1ORrOZ+hGaetRrf4QLPcDNGAMvIePtUc7XKXb29xhU82Q+8T9a5i3Jw2Tjeoc1WrO5QQ3Bb1vcQSZUTWfkFlLzRBOWE9oaKX66CkmKZjVLOWwE+OCapY1wjlhdNFBevLUWIw595Aq/hEmaG8oXJpjOO9qi5QtVTen1FwFKkbGK6Jl7yHnvOKskN4RKXSWqD0AOq/yBz2iPLd9VGh9LpIcHaH6liI0WVEZWzcI8RTyleZnwLcbVK9bR/zgBw3t6iInSmSvNh+R3dWSHLSRjUszZHlI0mf/hxkuZijDrY8n/uogjW/vqLd69pXW+Tx1RwaLc/rIlo/7PcyJLKtkE+ARLIbpDP49DHqzMBU5dMXRjiHx71mgGyOPlKZqkzT1zdDKhOiWfhfU8vRmUP4d9NrJLM8IZfHZhD4uDFyeRDMw/4hTpHLw17kx3vrLlwjmeUBuTzspTY5cnnYY27EnlMBySxIZSLfTJHKxB38vkcqE3epFLN/X+C+mfaQysRdtciYr/iOO3+hFlpQC9Ni9/B3uPdSfueJ3X3yeOKTtyoglYm8A4w2sbaHZJa0K4JLQTILd8R7hz3qzR4u5Q+YcudldthzM/zHBX0nDf1milyeJYJZ+HtMWGtpCvyFU" +
"Wsks7SRS0RZtLeHVKZ0O9XK8NjNxu0iuiyoeUU4BTK5MoQzDJHJxXytcdqob7+KveC164I38O22SZ82iYg8PlYXymNRG5AuItI8cIa+XbeUMFZGfSDLB6OH4XxMhv26Gvcja8w7UcjxYz2j77NK/wvb72mIY5UsB/hjnKtguVHWe4ss2PX2A/wI/7JabOq+j3vPprvv07E/wmIPVLBjzdLPJ4Y52KSQ+gSXcA1MPUIc8gDFlHM1QQ6m+S7doIZrn/eUdaKORuRjTFPMmwa8x/zrCtW8nOPAWjm39UbC3yIcm3TOoMakVPgTaGGE+lYV9Blx0CWP/6doZ0GeUbW70W1Y+3Ym5Y9lX4R9xJ+xzj7QhFNeuzf4/0aajk4P/M+yRjcPeqPloWs5zq8dlgHZmQ7m2XaYdzqdfLjN5oP/4dKJiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIFW6zfFADwrMxMCHQAAAABJRU5ErkJggg==");
            this.Image8.Name = "Image8";
            this.Image8.Stretch = true;
            this.Image8.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Image8.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.FromArgb(255, 81, 104, 36), 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Image8.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Image8.Interaction = null;
            this.Panel8.Guid = null;
            this.Panel8.Interaction = null;
            // 
            // ReportTitle2
            // 
            this.ReportTitle2 = new Stimulsoft.Report.Components.StiReportTitleBand();
            this.ReportTitle2.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0.2, 7.72, 0.7);
            this.ReportTitle2.Guid = "bb8be3884f104367aab770660b4d7b80";
            this.ReportTitle2.Name = "ReportTitle2";
            this.ReportTitle2.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.ReportTitle2.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            // 
            // Panel13
            // 
            this.Panel13 = new Stimulsoft.Report.Components.StiPanel();
            this.Panel13.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0, 7.7, 0.7);
            this.Panel13.Guid = "91b4eef7a7314be3986fb10611e316fa";
            this.Panel13.Name = "Panel13";
            this.Panel13.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.DashDotDot, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Panel13.Brush = new Stimulsoft.Base.Drawing.StiEmptyBrush();
            // 
            // Text209
            // 
            this.Text209 = new Stimulsoft.Report.Components.StiText();
            this.Text209.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(2.4, 0.2, 2.6, 0.3);
            this.Text209.Guid = "1974ef6bf54141eaa0cce8fd1c3bc661";
            this.Text209.HorAlignment = Stimulsoft.Base.Drawing.StiTextHorAlignment.Center;
            this.Text209.Name = "Text209";
            this.Text209.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text209__GetValue);
            this.Text209.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text209.VertAlignment = Stimulsoft.Base.Drawing.StiVertAlignment.Center;
            this.Text209.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.None, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.Solid, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text209.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text209.Font = new System.Drawing.Font("B Nazanin", 14F, System.Drawing.FontStyle.Bold);
            this.Text209.Indicator = null;
            this.Text209.Interaction = null;
            this.Text209.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text209.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(255, 0, 112, 192));
            this.Text209.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            // 
            // Text210
            // 
            this.Text210 = new Stimulsoft.Report.Components.StiText();
            this.Text210.ClientRectangle = new Stimulsoft.Base.Drawing.RectangleD(0, 0, 2, 0.4);
            this.Text210.Guid = "4727f97a734b40f1bb13f620f77aaaa0";
            this.Text210.Name = "Text210";
            this.Text210.GetValue += new Stimulsoft.Report.Events.StiGetValueEventHandler(this.Text210__GetValue);
            this.Text210.Type = Stimulsoft.Report.Components.StiSystemTextType.Expression;
            this.Text210.Border = new Stimulsoft.Base.Drawing.StiBorder(Stimulsoft.Base.Drawing.StiBorderSides.Right, System.Drawing.Color.Black, 1, Stimulsoft.Base.Drawing.StiPenStyle.None, false, 4, new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black), false);
            this.Text210.Brush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Transparent);
            this.Text210.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold);
            this.Text210.Indicator = null;
            this.Text210.Interaction = null;
            this.Text210.Margins = new Stimulsoft.Report.Components.StiMargins(0, 0, 0, 0);
            this.Text210.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.Black);
            this.Text210.TextOptions = new Stimulsoft.Base.Drawing.StiTextOptions(false, false, false, 0F, System.Drawing.Text.HotkeyPrefix.None, System.Drawing.StringTrimming.None);
            this.Panel13.Interaction = null;
            this.ReportTitle2.Interaction = null;
            this.Page3.ExcelSheetValue = null;
            this.Page3.Interaction = null;
            this.Page3.Margins = new Stimulsoft.Report.Components.StiMargins(0.39, 0.39, 0.39, 0.39);
            this.Page3_Watermark = new Stimulsoft.Report.Components.StiWatermark();
            this.Page3_Watermark.Font = new System.Drawing.Font("Arial", 100F);
            this.Page3_Watermark.Image = null;
            this.Page3_Watermark.TextBrush = new Stimulsoft.Base.Drawing.StiSolidBrush(System.Drawing.Color.FromArgb(50, 0, 0, 0));
            this.Report_PrinterSettings = new Stimulsoft.Report.Print.StiPrinterSettings();
            this.ReportResources.Add(new Stimulsoft.Report.StiReportResource("Image2.png", "Image2", "Image", Stimulsoft.Report.StiReportResourceType.Bitmap));
            this.ReportResources.Add(new Stimulsoft.Report.StiReportResource("Image3.png", "Image3", "Image", Stimulsoft.Report.StiReportResourceType.Bitmap));
            this.ReportResources.Add(new Stimulsoft.Report.StiReportResource("Image4.png", "Image4", "Image", Stimulsoft.Report.StiReportResourceType.Bitmap));
            this.ReportResources.Add(new Stimulsoft.Report.StiReportResource("Image5.png", "Image5", "Image", Stimulsoft.Report.StiReportResourceType.Bitmap));
            this.ReportResources.Add(new Stimulsoft.Report.StiReportResource("Image6.png", "Image6", "Image", Stimulsoft.Report.StiReportResourceType.Bitmap));
            this.ReportResources.Add(new Stimulsoft.Report.StiReportResource("Image7.png", "Image7", "Image", Stimulsoft.Report.StiReportResourceType.Bitmap));
            this.ReportResources.Add(new Stimulsoft.Report.StiReportResource("Image8.png", "Image8", "Image", Stimulsoft.Report.StiReportResourceType.Bitmap));
            this.PrinterSettings = this.Report_PrinterSettings;
            this.Page3.Report = this;
            this.Page3.Watermark = this.Page3_Watermark;
            this.PageFooter2.Page = this.Page3;
            this.PageFooter2.Parent = this.Page3;
            this.Text136.Page = this.Page3;
            this.Text136.Parent = this.PageFooter2;
            this.Text137.Page = this.Page3;
            this.Text137.Parent = this.PageFooter2;
            this.Text138.Page = this.Page3;
            this.Text138.Parent = this.Page3;
            this.Text139.Page = this.Page3;
            this.Text139.Parent = this.Page3;
            this.Text140.Page = this.Page3;
            this.Text140.Parent = this.Page3;
            this.Text141.Page = this.Page3;
            this.Text141.Parent = this.Page3;
            this.Panel8.Page = this.Page3;
            this.Panel8.Parent = this.Page3;
            this.Text142.Page = this.Page3;
            this.Text142.Parent = this.Panel8;
            this.Text143.Page = this.Page3;
            this.Text143.Parent = this.Panel8;
            this.Text148.Page = this.Page3;
            this.Text148.Parent = this.Panel8;
            this.Text144.Page = this.Page3;
            this.Text144.Parent = this.Panel8;
            this.Text145.Page = this.Page3;
            this.Text145.Parent = this.Panel8;
            this.Text146.Page = this.Page3;
            this.Text146.Parent = this.Panel8;
            this.Text147.Page = this.Page3;
            this.Text147.Parent = this.Panel8;
            this.Text151.Page = this.Page3;
            this.Text151.Parent = this.Panel8;
            this.Image2.Page = this.Page3;
            this.Image2.Parent = this.Panel8;
            this.Image3.Page = this.Page3;
            this.Image3.Parent = this.Panel8;
            this.Image4.Page = this.Page3;
            this.Image4.Parent = this.Panel8;
            this.Image5.Page = this.Page3;
            this.Image5.Parent = this.Panel8;
            this.Image6.Page = this.Page3;
            this.Image6.Parent = this.Panel8;
            this.Image7.Page = this.Page3;
            this.Image7.Parent = this.Panel8;
            this.Image8.Page = this.Page3;
            this.Image8.Parent = this.Panel8;
            this.ReportTitle2.Page = this.Page3;
            this.ReportTitle2.Parent = this.Page3;
            this.Panel13.Page = this.Page3;
            this.Panel13.Parent = this.ReportTitle2;
            this.Text209.Page = this.Page3;
            this.Text209.Parent = this.Panel13;
            this.Text210.Page = this.Page3;
            this.Text210.Parent = this.Panel13;
            this.EndRender += new System.EventHandler(this.ReportWordsToEnd__EndRender);
            // 
            // Add to PageFooter2.Components
            // 
            this.PageFooter2.Components.Clear();
            this.PageFooter2.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Text136,
                        this.Text137});
            // 
            // Add to Panel8.Components
            // 
            this.Panel8.Components.Clear();
            this.Panel8.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Text142,
                        this.Text143,
                        this.Text148,
                        this.Text144,
                        this.Text145,
                        this.Text146,
                        this.Text147,
                        this.Text151,
                        this.Image2,
                        this.Image3,
                        this.Image4,
                        this.Image5,
                        this.Image6,
                        this.Image7,
                        this.Image8});
            // 
            // Add to Panel13.Components
            // 
            this.Panel13.Components.Clear();
            this.Panel13.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Text209,
                        this.Text210});
            // 
            // Add to ReportTitle2.Components
            // 
            this.ReportTitle2.Components.Clear();
            this.ReportTitle2.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.Panel13});
            // 
            // Add to Page3.Components
            // 
            this.Page3.Components.Clear();
            this.Page3.Components.AddRange(new Stimulsoft.Report.Components.StiComponent[] {
                        this.PageFooter2,
                        this.Text138,
                        this.Text139,
                        this.Text140,
                        this.Text141,
                        this.Panel8,
                        this.ReportTitle2});
            // 
            // Add to Pages
            // 
            this.Pages.Clear();
            this.Pages.AddRange(new Stimulsoft.Report.Components.StiPage[] {
                        this.Page3});
            this.Info.Columns.AddRange(new Stimulsoft.Report.Dictionary.StiDataColumn[] {
                        new Stimulsoft.Report.Dictionary.StiDataColumn("Id", "Id", "Id", typeof(int)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("Title", "Title", "Title", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("StartDate", "StartDate", "StartDate", typeof(int?)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("EndDate", "EndDate", "EndDate", typeof(int?)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("UserId", "UserId", "UserId", typeof(int?)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("_StartDate", "_StartDate", "_StartDate", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("_EndDate", "_EndDate", "_EndDate", typeof(string))});
            this.Dictionary.BusinessObjects.Add(this.Info);
            this.Objects.Columns.AddRange(new Stimulsoft.Report.Dictionary.StiDataColumn[] {
                        new Stimulsoft.Report.Dictionary.StiDataColumn("Id", "Id", "Id", typeof(int?)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("MinMonthGap", "MinMonthGap", "MinMonthGap", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("MinYearGap", "MinYearGap", "MinYearGap", typeof(int?)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("MinNetInputOutput", "MinNetInputOutput", "MinNetInputOutput", typeof(double)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("MinNetInputOutputAcc", "MinNetInputOutputAcc", "MinNetInputOutputAcc", typeof(double)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("LastMonthGap", "LastMonthGap", "LastMonthGap", typeof(string)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("LastYearGap", "LastYearGap", "LastYearGap", typeof(int?)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("LastNetInputOutput", "LastNetInputOutput", "LastNetInputOutput", typeof(double)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("LastNetInputOutputAcc", "LastNetInputOutputAcc", "LastNetInputOutputAcc", typeof(double)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("TotalAdditional", "TotalAdditional", "TotalAdditional", typeof(double)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("TotalDeposit", "TotalDeposit", "TotalDeposit", typeof(double)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("TotalBondIssuances", "TotalBondIssuances", "TotalBondIssuances", typeof(double)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("TotalBondProfit", "TotalBondProfit", "TotalBondProfit", typeof(double)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("Date", "Date", "Date", typeof(int?)),
                        new Stimulsoft.Report.Dictionary.StiDataColumn("SumTotla", "SumTotla", "SumTotla", typeof(float))});
            this.Dictionary.BusinessObjects.Add(this.Objects);
        }
        
        #region BusinessObject Info
        public class InfoBusinessObject : Stimulsoft.Report.Dictionary.StiBusinessObject
        {
            
            public InfoBusinessObject() : 
                    base("", "Info", "Info", "82b9ab83ffd64199ade1819baa747099")
            {
            }
            
            public virtual int Id
            {
                get
                {
                    return ((int)(StiReport.ChangeType(this["Id"], typeof(int), true)));
                }
            }
            
            public virtual string Title
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["Title"], typeof(string), true)));
                }
            }
            
            public virtual int? StartDate
            {
                get
                {
                    return ((int?)(StiReport.ChangeType(this["StartDate"], typeof(int?), true)));
                }
            }
            
            public virtual int? EndDate
            {
                get
                {
                    return ((int?)(StiReport.ChangeType(this["EndDate"], typeof(int?), true)));
                }
            }
            
            public virtual int? UserId
            {
                get
                {
                    return ((int?)(StiReport.ChangeType(this["UserId"], typeof(int?), true)));
                }
            }
            
            public virtual string _StartDate
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["_StartDate"], typeof(string), true)));
                }
            }
            
            public virtual string _EndDate
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["_EndDate"], typeof(string), true)));
                }
            }
        }
        #endregion BusinessObject Info
        
        #region BusinessObject Objects
        public class ObjectsBusinessObject : Stimulsoft.Report.Dictionary.StiBusinessObject
        {
            
            public ObjectsBusinessObject() : 
                    base("", "Objects", "Objects", "0e798cde640646e09f2515086abda96b")
            {
            }
            
            public virtual int? Id
            {
                get
                {
                    return ((int?)(StiReport.ChangeType(this["Id"], typeof(int?), true)));
                }
            }
            
            public virtual string MinMonthGap
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["MinMonthGap"], typeof(string), true)));
                }
            }
            
            public virtual int? MinYearGap
            {
                get
                {
                    return ((int?)(StiReport.ChangeType(this["MinYearGap"], typeof(int?), true)));
                }
            }
            
            public virtual double MinNetInputOutput
            {
                get
                {
                    return ((double)(StiReport.ChangeType(this["MinNetInputOutput"], typeof(double), true)));
                }
            }
            
            public virtual double MinNetInputOutputAcc
            {
                get
                {
                    return ((double)(StiReport.ChangeType(this["MinNetInputOutputAcc"], typeof(double), true)));
                }
            }
            
            public virtual string LastMonthGap
            {
                get
                {
                    return ((string)(StiReport.ChangeType(this["LastMonthGap"], typeof(string), true)));
                }
            }
            
            public virtual int? LastYearGap
            {
                get
                {
                    return ((int?)(StiReport.ChangeType(this["LastYearGap"], typeof(int?), true)));
                }
            }
            
            public virtual double LastNetInputOutput
            {
                get
                {
                    return ((double)(StiReport.ChangeType(this["LastNetInputOutput"], typeof(double), true)));
                }
            }
            
            public virtual double LastNetInputOutputAcc
            {
                get
                {
                    return ((double)(StiReport.ChangeType(this["LastNetInputOutputAcc"], typeof(double), true)));
                }
            }
            
            public virtual double TotalAdditional
            {
                get
                {
                    return ((double)(StiReport.ChangeType(this["TotalAdditional"], typeof(double), true)));
                }
            }
            
            public virtual double TotalDeposit
            {
                get
                {
                    return ((double)(StiReport.ChangeType(this["TotalDeposit"], typeof(double), true)));
                }
            }
            
            public virtual double TotalBondIssuances
            {
                get
                {
                    return ((double)(StiReport.ChangeType(this["TotalBondIssuances"], typeof(double), true)));
                }
            }
            
            public virtual double TotalBondProfit
            {
                get
                {
                    return ((double)(StiReport.ChangeType(this["TotalBondProfit"], typeof(double), true)));
                }
            }
            
            public virtual int? Date
            {
                get
                {
                    return ((int?)(StiReport.ChangeType(this["Date"], typeof(int?), true)));
                }
            }
            
            public virtual float SumTotla
            {
                get
                {
                    return ((float)(StiReport.ChangeType(this["SumTotla"], typeof(float), true)));
                }
            }
        }
        #endregion BusinessObject Objects
        #endregion StiReport Designer generated code - do not modify
    }
	
	
}